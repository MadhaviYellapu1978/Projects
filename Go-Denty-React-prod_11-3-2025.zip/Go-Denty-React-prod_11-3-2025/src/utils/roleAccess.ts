/**
 * Enum representing different user roles in the system
 */
export enum UserRole {
  SUPER_ADMIN = "Super Admin",
  COMMUNITY_ADMIN = "Community Admin",
  EVENT_ADMIN = "Events Admin",
  HIRING_ADMIN = "Hiring Admin",
}

/**
 * Interface defining the structure of navigation access permissions
 */
interface NavigationAccess {
  [key: string]: UserRole[];
}

/**
 * Configuration object defining which roles have access to specific navigation items
 *
 * Access Matrix:
 * - Super Admin: All modules (Dashboard, Doctors, Clinics, Go Denty Posts, Courses, CDE Zone, Job Postings, Enquiries, Onboard, Notifications)
 * - Community Admin: Go Denty Posts only
 * - Event Admin: CDE Zone, Courses, Enquiries only
 * - Hiring Admin: Dashboard, Doctors, Clinics, Job Postings only
 */
export const navigationAccess: NavigationAccess = {
  dashboard: [UserRole.SUPER_ADMIN, UserRole.HIRING_ADMIN],
  doctors: [UserRole.SUPER_ADMIN, UserRole.HIRING_ADMIN],
  clinics: [UserRole.SUPER_ADMIN, UserRole.HIRING_ADMIN],
  posts: [UserRole.SUPER_ADMIN, UserRole.COMMUNITY_ADMIN],
  courses: [UserRole.SUPER_ADMIN, UserRole.EVENT_ADMIN],
  community: [UserRole.SUPER_ADMIN, UserRole.EVENT_ADMIN],
  jobs: [UserRole.SUPER_ADMIN, UserRole.HIRING_ADMIN],
  enquiries: [UserRole.SUPER_ADMIN, UserRole.EVENT_ADMIN],
  onboard: [UserRole.SUPER_ADMIN],
  notifications: [UserRole.SUPER_ADMIN],
  profile: [
    UserRole.SUPER_ADMIN,
    UserRole.COMMUNITY_ADMIN,
    UserRole.EVENT_ADMIN,
    UserRole.HIRING_ADMIN,
  ],
};

/**
 * Function to check if a user has access to a specific navigation item
 * @param userRole - The role of the user
 * @param requiredAccess - The access level required
 * @returns boolean indicating whether the user has access
 */
export const hasAccess = (
  userRole: UserRole,
  requiredAccess: string
): boolean => {
  if (!navigationAccess[requiredAccess]) {
    return false;
  }
  return navigationAccess[requiredAccess].includes(userRole);
};
