
// Generate mock data for the dashboard
export const generateMockData = () => {
  // Dashboard Stats
  const dashboardStats = {
    totalClinic: 120,
    totalMDS: 120,
    totalBDS: 120,
    totalRevenue: 120,
  };

  // Doctors Data
  const generateDoctors = (count: number) => {
    return Array(count)
      .fill(null)
      .map((_, index) => ({
        id: `#${214314 + index}`,
        name: `Doctor Name`,
        phone: '+91 9123456789',
        email: 'doctor@gmail.com',
        experience: '2 Years',
        workType: 'Full-Time',
        doctorType: index % 3 === 0 ? 'BDS' : 'MDS',
        status: 'Active',
      }));
  };

  // Clinics Data
  const generateClinics = (count: number) => {
    return Array(count)
      .fill(null)
      .map((_, index) => ({
        id: `#${214314 + index}`,
        clinicName: 'Clinic Name',
        ownerName: 'Owner Name',
        phone: '+91 9123456789',
        email: 'clinic@gmail.com',
        website: 'Clinic website',
        address: 'Madhapur',
        status: 'Active',
      }));
  };

  // Vendors Data
  const generateVendors = (count: number) => {
    return Array(count)
      .fill(null)
      .map((_, index) => ({
        id: `#${214314 + index}`,
        vendorName: 'Vendor Name',
        phone: '+91 9123456789',
        email: 'vendor@gmail.com',
        website: 'vendor website',
        address: 'Madhapur',
        status: 'Active',
      }));
  };

  // Treatment Plans
  const generateTreatmentPlans = (count: number) => {
    return Array(count)
      .fill(null)
      .map((_, index) => ({
        planName: 'Plan Name',
        description: 'Lorem ipsum dolor sit amet consectetur. dolor sit amet',
        file: 'File.pdf',
        amount: 'Rs. 400',
        status: 'Active',
      }));
  };

  // Events
  const eventImages = [
    '/lovable-uploads/5a4ffead-92d1-4868-8d4c-a70bfd9daaf0.png',
    '/lovable-uploads/95dda499-04e3-409d-83ad-a60a3793a25f.png',
    '/lovable-uploads/ab4e2c72-66c0-4a4c-9ad9-1021c72acc49.png',
    '/lovable-uploads/fa723da9-3cc3-46e1-b65a-5f4333ea9fba.png',
    '/lovable-uploads/ad4b79fd-6e0e-46b4-8d16-e265cac0e593.png',
    '/lovable-uploads/48fed93c-71ac-47b0-87bb-8c4d88d873b6.png',
    '/lovable-uploads/f3e904ad-b3f2-4214-bb47-09d92b02c7d4.png',
  ];
  
  const generateEvents = (count: number, type: string) => {
    return Array(count)
      .fill(null)
      .map((_, index) => ({
        id: index + 1,
        title: type === 'Dental Event' ? 'when the event name is big' : '',
        image: eventImages[index % eventImages.length],
        date: '24 May',
        type,
      }));
  };

  // Posts
  const generateBlogPosts = (count: number) => {
    return Array(count)
      .fill(null)
      .map((_, index) => ({
        id: index + 1,
        title: 'Lorem Ipsum dolor',
        description: 'Lorem ipsum dolor sit amet consectetur. Tellus quisque ipsum cras magna dictum.',
        date: '02 July 2022',
        likes: Math.floor(Math.random() * 100),
        share: Math.floor(Math.random() * 50),
        comments: Math.floor(Math.random() * 30),
      }));
  };

  // Community Posts
  const generateCommunityPosts = (count: number) => {
    return Array(count)
      .fill(null)
      .map((_, index) => ({
        id: index + 1,
        title: 'Lorem ipsum dolor sit amet consectetur. Euismod curabitur nibh massa sed felis pulvinar amet dignissim.',
        description: 'Lorem ipsum dolor sit amet consectetur. Neque aliquet facilisi arcu morbi volutpat nunc scelerisque imperdiet. Mattis neque nisl faucibus volutpat.',
        timeAgo: '1d',
      }));
  };

  return {
    dashboardStats,
    doctors: generateDoctors(100),
    clinics: generateClinics(100),
    vendors: generateVendors(100),
    treatmentPlans: generateTreatmentPlans(5),
    events: generateEvents(8, 'Dental Event'),
    webinars: generateEvents(8, 'Dental Webinar'),
    workshops: generateEvents(8, 'Dental Workshop'),
    conferences: generateEvents(8, 'Dental Conference'),
    blogPosts: generateBlogPosts(100),
    communityPosts: generateCommunityPosts(9),
  };
};

export const mockData = generateMockData();
