export const ROLES = {
  ADMIN: "admin",
  USER: "user",
};
