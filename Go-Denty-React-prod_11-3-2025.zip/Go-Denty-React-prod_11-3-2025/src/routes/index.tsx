import Layout from "@/components/layout/Layout";
import Rbac from "@/components/layout/Rbac";
import ClinicsPage from "@/pages/ClinicsPage";
import CommunityPage from "@/pages/CommunityPage";
import Courses from "@/pages/Courses";
import Dashboard from "@/pages/Dashboard";
import DoctorsPage from "@/pages/DoctorsPage";
import ForgetPassword from "@/pages/ForgetPassword";
import Login from "@/pages/Login";
import NotFoundPage from "@/pages/NotFoundPage";
import NotificationsPage from "@/pages/NotificationsPage";
import Onboard from "@/pages/Onboard";
import PostsPage from "@/pages/PostsPage";
import ProfilePage from "@/pages/ProfilePage";
import Enquiries from "@/pages/Enquiries";
import JobPostingsPage from "@/pages/JobPostingsPage";
import { createBrowserRouter } from "react-router-dom";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <Layout />,
    children: [
      {
        index: true,
        element: (
          <Rbac requiredAccess="dashboard">
            <Dashboard />
          </Rbac>
        ),
      },
      {
        path: "doctors",
        element: (
          <Rbac requiredAccess="doctors">
            <DoctorsPage />
          </Rbac>
        ),
      },
      {
        path: "clinics",
        element: (
          <Rbac requiredAccess="clinics">
            <ClinicsPage />
          </Rbac>
        ),
      },
      {
        path: "onboard",
        element: <Onboard />,
      },
      {
        path: "courses",
        element: (
          <Rbac requiredAccess="courses">
            <Courses />
          </Rbac>
        ),
      },
      {
        path: "posts",
        element: (
          <Rbac requiredAccess="posts">
            <PostsPage />
          </Rbac>
        ),
      },
      {
        path: "community",
        element: (
          <Rbac requiredAccess="community">
            <CommunityPage />
          </Rbac>
        ),
      },
      {
        path: "jobs",
        element: (
          <Rbac requiredAccess="jobs">
            <JobPostingsPage />
          </Rbac>
        ),
      },
      {
        path: "enquiries",
        element: (
          <Rbac requiredAccess="enquiries">
            <Enquiries />
          </Rbac>
        ),
      },
      {
        path: "profile",
        element: (
          <Rbac requiredAccess="profile">
            <ProfilePage />
          </Rbac>
        ),
      },
      {
        path: "notifications",
        element: (
          <Rbac requiredAccess="notifications">
            <NotificationsPage />
          </Rbac>
        ),
      },
    ],
  },
  {
    path: "login",
    element: <Login />,
  },
  // {
  //   path: "forget-password",
  //   element: <ForgetPassword />,
  // },
  {
    path: "*",
    element: <NotFoundPage />,
  },
]);
