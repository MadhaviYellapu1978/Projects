/* eslint-disable @typescript-eslint/no-explicit-any */
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import axiosInstance from "./axios";

interface User {
  user_name: string;
  phoneNumber: string | null;
  user_email: string;
  experience: string;
  work_type: "Full Time" | "Part Time";
  doctor_type: "MDS Doctor" | "BDS Doctor";
  user_id: string;
  role_id: number;
  is_Verified: "Approved" | "Reject" | "Pending";
}

interface CourseCategory {
  id: number;
  name: string;
}

interface LoginCredentials {
  email: string;
  password: string;
}

export interface UserResponse {
  id: number;
  name: string;
  email: string;
  role: string;
  status: "Active" | "Inactive" | "Pending";
  createdAt: string;
  // Add other fields as needed
}

export interface PaginatedResponse<T> {
  result: T[];
  count: number;
}

interface UploadReelsRequest {
  image: File;
  media_type: number;
  title: string;
  description: string;
  content?: string;
  media_id?: number;
  isShopAvailable?: boolean;
  shoppingUrl?: string;
}

interface ClinicResponse {
  user_id: string;
  Clinic_id: string;
  Clinic_name: string;
  clinic_Address: string;
  Clinic_Contact_Number: string;
  Clinic_Website: string;
  Clinic_Geolaction: string;
  No_of_Dental_Chairs: number;
  Avg_per_month: number;
  Clinic_certificate: string;
  is_Verified: "Approved" | "Reject" | "Pending";
  Clinic_email: string;
  Created_date: string;
  owner_name?: string;
  doctor_type?: string;
}

interface ClinicsApiResponse {
  result: ClinicResponse[];
  count: number;
}

export enum MediaType {
  Reels = 1,
  Feeds = 2,
  Blogs = 3,
  Banners = 4,
}

interface MediaItem {
  media_id: number;
  title: string;
  description: string;
  thumbnail_url: string;
  image: string;
  createdAt: string;
  likes: number;
  shares: number;
  comments: number;
}

interface GetMediaResponse {
  result: MediaItem[];
  count: number;
  feeds: MediaItem[];
  reels: MediaItem[];
  blogs: MediaItem[];
  banners: MediaItem[];
}

interface AdminResponse {
  user_id: string;
  first_name: string;
  last_name: string;
  email: string;
  phoneNumber: string;
  role_name: string;
  role_id: number;
  [key: string]: unknown;
}

interface AdminsApiResponse {
  result: AdminResponse[];
  count: number;
}

interface OnboardAdminRequest {
  first_name: string;
  last_name: string;
  email: string;
  phoneNumber: string;
  role_Id: number;
}

interface VerifyClinicRequest {
  Clinic_id: string;
  status: "Pending" | "Approved" | "Reject";
  body: string;
  user_id: string;
}

export interface UpdateClinicRequest {
  user_id: string;
  Clinic_name: string;
  clinic_Address: string;
  Clinic_Contact_Number: string;
  Clinic_Website: string;
  Clinic_lat: string;
  Clinic_long: string;
  Clinic_email: string;
  No_of_Dental_Chairs: number;
  Avg_per_month: number;
  is_Verified: string;
  clinic_About?: string;
}

interface OnboardClinicRequest {
  user_id: string;
  owner_name: string;
  doctor_type: string;
  Clinic_name: string;
  clinic_Address: string;
  google_map_location: string;
  Clinic_Contact_Number: string;
  Clinic_Website: string;
  Clinic_lat: number;
  Clinic_long: number;
  Clinic_email: string;
  No_of_Dental_Chairs: number;
  Avg_per_month: number;
  is_Verified: string;
}

interface Specialization {
  specialization_id: number;
  specialization_name: string;
}

interface PersonalInfo {
  profile_name: string;
  profile_email_id: string;
  profile_phone_number: string;
  specialization: Specialization[];
}

interface Education {
  state: string;
  collage_name: string;
  passed_out_year: string;
  state_councel_reg_number: string;
  state_councel_certificate: string;
}

interface Work {
  work_type: string;
  designation: string;
  expertise_in: string;
  experience: string;
  clinic_name: string;
  joined_Date: string;
  Departure: string;
}

interface UploadImageRequest {
  image: File;
  user_id: string;
}

export interface PostProfileInfoRequest {
  user_id: string;
  role_id: number;
  other_specialization: string;
  user_name: string;
  user_email: string;
  profile_pic: string;
  is_work_experience: boolean;
  is_Verified: string;
  PersonalInfo: PersonalInfo;
  Education: Education;
  Work: Work & {
    is_experience: boolean;
  };
}

export interface ProfileResponse {
  profile_pic: string;
  user_id: string;
  role_id: number;
  is_work_experience: boolean;
  user_name: string;
  user_email: string;
  phoneNumber: string;
  other_specialization: string;
  total_percentage: number;
  is_Verified: string;
  specialization: Specialization[];
  Education: Education;
  Work: Work;
}

interface VerifyDoctorRequest {
  user_id: string;
  status: "Pending" | "Approved" | "Reject";
  body: string;
}

interface PostEventRequest {
  user_id: string;
  event_type: {
    event_type_id: number;
    event_type_name: string;
  };
  Phone_number: string;
  Email: string;
  description: string;
  image: string;
  start_date: string;
  end_date: string;
  start_time: string;
  end_time: string;
  price: number;
  name: string;
  course_title: string;
  course_duration: string;
  pricingmode: string;
  course_preview: string;
  event_lat: number;
  event_long: number;
  event_address: string;
  is_paid: boolean;
}

interface VerifyEventRequest {
  event_id: string;
  status: "Approved" | "Reject";
  body?: string;
  user_id: string;
}

interface ChangePasswordRequest {
  old_password: string;
  new_password: string;
  confirm_password: string;
  user_id: string;
}

interface ChangePasswordResponse {
  code: number;
  type: string;
  message: string;
}

interface PostNotificationRequest {
  user_id: string;
  title: string;
  message: string;
  notification_id: string;
  role_id: number[];
  is_clinic: boolean;
  is_event: boolean;
  state: string[];
  is_selected_all: boolean;
}

interface PostNotificationResponse {
  code: number;
  type: string;
  message: string;
}

interface Job {
  job_type: number;
  Clinic_id: string;
  Clinic_name: string;
  Clinic_address: string;
  job_id: string;
  user_id: string;
  job_title: string;
  eligibility: "MDS Doctor" | "BDS Doctor";
  type: "Full Time" | "Part Time";
  skills: string;
  Responsibilities: string;
  minimum_req_experience: string;
  monthly_scalary_range: number;
  working_hours: string;
  working_timings: string;
  holidays: string;
  other_info: string;
  job_description: string;
  is_saved: boolean;
  is_applied: boolean;
  job_applied_count: number;
  Created_at: string;
}

interface Consultation {
  job_type: number;
  Clinic_id: string;
  job_id: string;
  user_id: string;
  job_title: string;
  job_description: string;
  special_required: string;
  date: string;
  time: string;
  case_description: string;
  payment: string;
  is_saved: boolean;
  is_applied: boolean;
  job_applied_count: number;
  Clinic_name: string;
  Clinic_address: string;
  eligibility: "MDS Doctor" | "BDS Doctor";
  Created_at: string;
}

interface JobsResponse {
  jobs: Job[];
  is_verified: boolean;
  totalCount: number;
}

interface ConsultationsResponse {
  consultations: Consultation[];
  is_verified: boolean;
  totalCount: number;
}

export const API_ENDPOINTS = {
  users: "/users",
  login: "/Login",
  deleteJob: (job_id: string) => `/DeleteJob?job_id=${job_id}`,
  getOverview: "/GetOverView",
  getRolesWeb: "/GetRoles?isWeb=true",
  getRolesMobile: "/GetRoles?isWeb=false",
  uploadReels: "/UploadReels",
  getJobs: (
    job_type?: number,
    offset?: number,
    pageSize?: number,
    searchUser?: string
  ) => {
    const params = new URLSearchParams();
    if (job_type !== undefined) params.append("job_type", job_type.toString());
    if (offset !== undefined) params.append("offset", offset.toString());
    if (pageSize !== undefined) params.append("pageSize", pageSize.toString());
    if (searchUser) params.append("search_user", searchUser);
    return `/GetJobs${params.toString() ? `?${params.toString()}` : ""}`;
  },
  getMedia: (
    media_type: number,
    offset: number,
    pageSize: number,
    search_user?: string
  ) => {
    const params = new URLSearchParams();
    params.append("media_type", media_type.toString());
    params.append("offset", offset.toString());
    params.append("pageSize", pageSize.toString());
    if (search_user) {
      params.append("search_user", search_user);
    }
    return `/GetMedia?${params.toString()}`;
  },
  getAllCourse_Categories: "/getAllCourse_Categories",
  deleteMedia: (media_id: number) => `/DeleteMedia?media_id=${media_id}`,
  getAllUsers: (
    page: number,
    pageSize: number,
    searchUser?: string,
    roleId?: string,
    startDate?: Date,
    isVerified?: string,
    endDate?: Date
  ) => {
    const params = new URLSearchParams();
    params.append("page", page.toString());
    params.append("pageSize", pageSize.toString());

    if (searchUser) params.append("search_user", searchUser);
    if (roleId) params.append("role_id", roleId);
    if (startDate) {
      const year = startDate.getFullYear();
      const month = (startDate.getMonth() + 1).toString().padStart(2, "0");
      const day = startDate.getDate().toString().padStart(2, "0");
      params.append("start_date", `${year}-${month}-${day}`);
    }
    if (endDate) {
      const year = endDate.getFullYear();
      const month = (endDate.getMonth() + 1).toString().padStart(2, "0");
      const day = endDate.getDate().toString().padStart(2, "0");
      params.append("end_date", `${year}-${month}-${day}`);
    }
    if (isVerified) params.append("is_Verified", isVerified);

    return `/GetAllUsers?${params.toString()}`;
  },
  getAllClinics: (
    page: number,
    pageSize: number,
    searchUser?: string,
    status?: "Pending" | "Approved" | "Reject",
    startDate?: Date,
    endDate?: Date
  ) => {
    const params = new URLSearchParams();
    params.append("page", page.toString());
    params.append("pageSize", pageSize.toString());
    if (searchUser) params.append("search", searchUser);
    if (status) params.append("is_Verified", status);
    if (startDate) {
      const year = startDate.getFullYear();
      const month = (startDate.getMonth() + 1).toString().padStart(2, "0");
      const day = startDate.getDate().toString().padStart(2, "0");
      params.append("start_date", `${year}-${month}-${day}`);
    }
    if (endDate) {
      const year = endDate.getFullYear();
      const month = (endDate.getMonth() + 1).toString().padStart(2, "0");
      const day = endDate.getDate().toString().padStart(2, "0");
      params.append("end_date", `${year}-${month}-${day}`);
    }
    console.log("getAllClinics params:", Object.fromEntries(params.entries()));
    return `/GetAllClincs?${params.toString()}`;
  },
  deleteEvent: (eventId: string) => `/DeleteEvent?event_id=${eventId}`,
  getAllAdmins: (
    page: number,
    pageSize: number,
    searchUser?: string,
    role_id?: number
  ) => {
    const params = new URLSearchParams();
    params.append("page", page.toString());
    params.append("pageSize", pageSize.toString());
    if (searchUser) params.append("search", searchUser);
    if (role_id) params.append("role_id", role_id.toString());
    return `/GetAllAdmins?${params.toString()}`;
  },
  onboardAdmin: (userId: string) => `/OnBoardAdmin?user_id=${userId}`,
  deleteOnboardAdmin: (userId: string) =>
    `/DeleteOnBoardAdmin?user_id=${userId}`,
  verifyClinic: (params: VerifyClinicRequest) =>
    `/postVerifiedClincs?Clinic_id=${params.Clinic_id}&status=${params.status}&body=${params.body}&user_id=${params.user_id}`,
  updateClinic: (clinicId: string) => `/UpdateClinic?Clinic_id=${clinicId}`,
  deleteClinic: (clinicId: string) => `/DeleteClinic?Clinic_id=${clinicId}`,
  onboardClinic: "/OnboardClincs",
  getUserByPhone: (phoneNumber: string) =>
    `/GetUserIdByPhoneNumber?phoneNumber=${phoneNumber}`,
  getProfileByUserId: (userId: string) =>
    `/getProfileByUser_id?user_id=${userId}`,
  postProfileInfo: (isWeb: boolean = true, is_edited: boolean = false) =>
    `/PostProfileInfo?isWeb=${isWeb}&is_edited=${is_edited}`,
  uploadImage: "/UploadImage",
  getAllEvents: (
    page: number,
    pageSize: number,
    eventTypeId?: number,
    searchUser?: string,
    isAdmin?: boolean,
    startDate?: string,
    endDate?: string
  ) => {
    const params = new URLSearchParams();
    params.append("page", page.toString());
    params.append("pageSize", pageSize.toString());
    if (eventTypeId) params.append("event_type_id", eventTypeId.toString());
    if (searchUser) params.append("search_user", searchUser);
    if (isAdmin !== undefined) params.append("is_admin", isAdmin.toString());
    if (startDate) params.append("start_date", startDate);
    if (endDate) params.append("end_date", endDate);
    return `/getAllEvents?${params.toString()}`;
  },
  getAllEventTypes: () => "/getAllEventTypes",
  verifyDoctor: (params: VerifyDoctorRequest) =>
    `/postVerifiedDoctors?user_id=${params.user_id}&status=${params.status}&body=${params.body}`,
  getNotificationsByUser_id: (user_id: string) =>
    `/GetNotificationsByUser_id?user_id=${user_id}`,
  postEvent: () => `/postEvent`,
  verifyEvent: (params: VerifyEventRequest) =>
    `/postVerifiedEvent?event_id=${params.event_id}&status=${
      params.status
    }&body=${encodeURIComponent(params.body || "")}&user_id=${params.user_id}`,
  changePassword: "/ChangePassword",
  postNotification: "/PostNotification",
  deleteProfileInfo: "/DeleteProfileInfo",
  getStates: "/GetStates",
};

export const queryKeys = {
  deleteJob: (job_id: string) => ["deleteJob", job_id],
  users: ["users"],
  jobs: ["jobs"],
  user: (id: number) => ["user", id],
  overview: ["overview"],
  rolesWeb: ["rolesWeb"],
  getAllCourse_Categories: ["getAllCourse_Categories"],
  rolesMobile: ["rolesMobile", 1, 10, "", "", new Date(), false],
  media: (
    media_type: number,
    offset: number,
    pageSize: number,
    search_user?: string
  ) => ["media", media_type, offset, pageSize, search_user],
  getAllUsers: (
    page: number,
    pageSize: number,
    searchUser: string,
    roleId: string,
    date: Date,
    is_Verified: boolean
  ) => ["getAllUsers", page, pageSize, searchUser, roleId, date, is_Verified],
  getAllClinics: (
    page: number,
    pageSize: number,
    searchUser?: string,
    status?: "Pending" | "Approved" | "Reject",
    startDate?: Date,
    endDate?: Date
  ) => ["clinics", page, pageSize, searchUser, status, startDate, endDate],
  getAllAdmins: (
    page: number,
    pageSize: number,
    searchUser?: string,
    role_id?: number
  ) => ["admins", page, pageSize, searchUser, role_id],
  getProfileByUserId: (userId: string) => ["profile", userId],
  postProfileInfo: ["postProfileInfo"],
  uploadImage: ["uploadImage"],
  getAllEvents: (
    page: number,
    pageSize: number,
    eventTypeId: number,
    searchUser?: string,
    isAdmin?: boolean,
    startDate?: string,
    endDate?: string
  ) => [
    "getAllEvents",
    page,
    pageSize,
    eventTypeId,
    searchUser,
    isAdmin,
    startDate,
    endDate,
  ],
  getAllEventTypes: ["getAllEventTypes"],
  getNotificationsByUser_id: (user_id: string) => [
    "getNotificationsByUser_id",
    user_id,
  ],
  postEvent: ["postEvent"],
};

export const api = {
  deleteJob: (job_id: string) =>
    axiosInstance.post(API_ENDPOINTS.deleteJob(job_id)),
  getUsers: () => axiosInstance.get<User[]>(API_ENDPOINTS.users),
  getJobs: (
    job_type?: number,
    offset?: number,
    pageSize?: number,
    searchUser?: string
  ) => {
    const params = new URLSearchParams();
    if (job_type !== undefined) params.append("job_type", job_type.toString());
    if (offset !== undefined) params.append("offset", offset.toString());
    if (pageSize !== undefined) params.append("pageSize", pageSize.toString());
    if (searchUser) params.append("search_user", searchUser);
    return axiosInstance.get<JobsResponse | ConsultationsResponse>(
      `/GetJobs${params.toString() ? `?${params.toString()}` : ""}`
    );
  },
  getAllCourse_Categories: () =>
    axiosInstance.get<CourseCategory[]>(API_ENDPOINTS.getAllCourse_Categories),
  getUser: (id: number) =>
    axiosInstance.get<User>(`${API_ENDPOINTS.users}/${id}`),
  deleteEvent: (eventId: string) =>
    axiosInstance.post(API_ENDPOINTS.deleteEvent(eventId)),
  uploadReels: (data: UploadReelsRequest) => {
    const formData = new FormData();
    formData.append("image", data.image);
    formData.append("media_type", data.media_type.toString());
    formData.append("title", data.title);
    formData.append("description", data.description);

    if (data.media_type === 3) {
      formData.append("html_string_mobile", data.content || data.description);
    }

    if (data.isShopAvailable) {
      formData.append("isShopAvalible", "true");
      if (data.shoppingUrl) {
        formData.append("shoping_url", data.shoppingUrl);
      }
    }

    const url = data.media_id
      ? `${API_ENDPOINTS.uploadReels}?media_id=${data.media_id}`
      : API_ENDPOINTS.uploadReels;

    return axiosInstance.post(url, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });
  },
  login: (credentials: LoginCredentials) =>
    axiosInstance.post<{
      user_id(arg0: string, user_id: any): unknown;
      role_id: any;
      role_name(arg0: string, role_name: any): unknown;
      first_name(arg0: string, first_name: any): unknown;
      last_name(arg0: string, last_name: any): unknown;
      verified(arg0: string, verified: any): unknown;
      message(arg0: string, message: any): unknown;
      user: User;
    }>(API_ENDPOINTS.login, credentials),
  getOverview: () => axiosInstance.get<any>(API_ENDPOINTS.getOverview),
  getRolesWeb: () => axiosInstance.get<any>(API_ENDPOINTS.getRolesWeb),
  getRolesMobile: () => axiosInstance.get<any>(API_ENDPOINTS.getRolesMobile),
  getMedia: (
    media_type: number,
    offset: number,
    pageSize: number,
    search_user?: string
  ) =>
    axiosInstance.get<GetMediaResponse>(
      API_ENDPOINTS.getMedia(media_type, offset, pageSize, search_user)
    ),
  getAllUsers: (
    page: number,
    pageSize: number,
    searchUser: string,
    roleId: string,
    date: Date,
    is_Verified: boolean
  ) =>
    axiosInstance.get(
      API_ENDPOINTS.getAllUsers(
        page,
        pageSize,
        searchUser,
        roleId,
        date,
        is_Verified.toString()
      )
    ),
  getAllClinics: (
    page: number,
    pageSize: number,
    searchUser?: string,
    status?: "Pending" | "Approved" | "Reject",
    startDate?: Date,
    endDate?: Date
  ) =>
    axiosInstance.get<ClinicsApiResponse>(
      API_ENDPOINTS.getAllClinics(
        page,
        pageSize,
        searchUser,
        status,
        startDate,
        endDate
      )
    ),
  deleteMedia: (media_id: number) =>
    axiosInstance.post<{ message: string }>(
      API_ENDPOINTS.deleteMedia(media_id)
    ),
  getAllAdmins: (
    page: number,
    pageSize: number,
    searchUser?: string,
    role_id?: number
  ) =>
    axiosInstance.get<AdminsApiResponse>(
      API_ENDPOINTS.getAllAdmins(page, pageSize, searchUser, role_id)
    ),
  onboardAdmin: (userId: string, data: OnboardAdminRequest) =>
    axiosInstance.post(API_ENDPOINTS.onboardAdmin(userId), data),
  deleteOnboardAdmin: (userId: string) =>
    axiosInstance.post(API_ENDPOINTS.deleteOnboardAdmin(userId)),
  verifyClinic: (data: VerifyClinicRequest) =>
    axiosInstance.post(API_ENDPOINTS.verifyClinic(data)),
  updateClinic: (clinicId: string, data: UpdateClinicRequest) =>
    axiosInstance.post(API_ENDPOINTS.updateClinic(clinicId), data),
  deleteClinic: (clinicId: string) =>
    axiosInstance.post(API_ENDPOINTS.deleteClinic(clinicId)),
  onboardClinic: (data: OnboardClinicRequest) =>
    axiosInstance.post(API_ENDPOINTS.onboardClinic, data),
  postProfileInfo: (
    data: PostProfileInfoRequest,
    isWeb: boolean = true,
    is_edited: boolean = false
  ) =>
    axiosInstance.post(API_ENDPOINTS.postProfileInfo(isWeb, is_edited), data),
  uploadImage: (data: UploadImageRequest) => {
    const formData = new FormData();
    formData.append("image", data.image);
    formData.append("user_id", data.user_id);

    return axiosInstance.post(API_ENDPOINTS.uploadImage, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });
  },
  getAllEvents: (
    page: number,
    pageSize: number,
    eventTypeId?: number,
    searchUser?: string,
    isAdmin?: boolean,
    startDate?: string,
    endDate?: string
  ) =>
    axiosInstance.get(
      API_ENDPOINTS.getAllEvents(
        page,
        pageSize,
        eventTypeId,
        searchUser,
        isAdmin,
        startDate,
        endDate
      )
    ),
  getAllEventTypes: () => axiosInstance.get(API_ENDPOINTS.getAllEventTypes()),
  getUserByPhone: (phoneNumber: string) =>
    axiosInstance.get(API_ENDPOINTS.getUserByPhone(phoneNumber)),
  getProfileByUserId: (userId: string) =>
    axiosInstance.get(API_ENDPOINTS.getProfileByUserId(userId)),
  verifyDoctor: (data: VerifyDoctorRequest) =>
    axiosInstance.post(API_ENDPOINTS.verifyDoctor(data)),
  getNotificationsByUser_id: (user_id: string) =>
    axiosInstance.get(API_ENDPOINTS.getNotificationsByUser_id(user_id)),
  postEvent: (data: PostEventRequest) =>
    axiosInstance.post(API_ENDPOINTS.postEvent(), data),
  verifyEvent: (data: VerifyEventRequest) =>
    axiosInstance.post(API_ENDPOINTS.verifyEvent(data)),
  changePassword: (data: ChangePasswordRequest) =>
    axiosInstance.post<ChangePasswordResponse>(
      API_ENDPOINTS.changePassword,
      data
    ),
  postNotification: (data: PostNotificationRequest) =>
    axiosInstance.post<PostNotificationResponse>(
      API_ENDPOINTS.postNotification,
      data
    ),
  deleteProfileInfo: (user_id: string) =>
    axiosInstance.post(API_ENDPOINTS.deleteProfileInfo, { user_id }),
  getStates: () =>
    axiosInstance.get<{ result: Array<{ name: string; code: string }> }>(
      API_ENDPOINTS.getStates
    ),
};

export const useDeleteJob = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: api.deleteJob,
    onSuccess: () => {
      // Invalidate all queries to refresh data
      queryClient.invalidateQueries();
    },
  });
};

export const useDeleteEvent = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: api.deleteEvent,
    onSuccess: () => {
      queryClient.invalidateQueries();
    },
  });
};

export const useGetNotificationsByUser_id = (user_id: string) => {
  return useQuery({
    queryKey: queryKeys.getNotificationsByUser_id(user_id),
    queryFn: () => api.getNotificationsByUser_id(user_id),
    select: (data) => {
      return data.data;
    },
  });
};

export const useUsers = () => {
  return useQuery({
    queryKey: queryKeys.users,
    queryFn: api.getUsers,
  });
};

export const useJobs = (
  job_type?: number,
  offset?: number,
  pageSize?: number,
  searchUser?: string
) => {
  return useQuery({
    queryKey: [...queryKeys.jobs, job_type, offset, pageSize],
    queryFn: () => api.getJobs(job_type, offset, pageSize, searchUser),
  });
};

export const useUser = (id: number) => {
  return useQuery({
    queryKey: queryKeys.user(id),
    queryFn: () => api.getUser(id),
    enabled: !!id,
  });
};

export const useLogin = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: api.login,
    onSuccess: (response) => {
      localStorage.setItem("userId", response.data.user_id.toString());
      localStorage.setItem("roleId", response.data.role_id.toString());
      localStorage.setItem("roleName", response.data.role_name.toString());
      localStorage.setItem("firstName", response.data.first_name.toString());
      localStorage.setItem("lastName", response.data.last_name.toString());
      queryClient.invalidateQueries({ queryKey: queryKeys.users });
    },
  });
};

export const useOverview = () => {
  return useQuery({
    queryKey: queryKeys.overview,
    queryFn: api.getOverview,
    select: (data) => {
      console.log("useOverview: Raw API data received:", data);
      // Ensure we're returning the correct data structure
      const result = {
        data: {
          Total_Clinic: data?.data?.Total_Clinic || 0,
          Total_MDS: data?.data?.Total_MDS || 0,
          Total_BDS: data?.data?.Total_BDS || 0,
          Total_Doctors: data?.data?.Total_Doctors || 0,
        },
      };
      console.log("useOverview: Processed data:", result);
      return result;
    },
  });
};

export const useRolesWeb = () => {
  return useQuery({
    queryKey: queryKeys.rolesWeb,
    queryFn: api.getRolesWeb,
    select: (data) => {
      return data.data;
    },
  });
};

export const useRolesMobile = () => {
  return useQuery({
    queryKey: queryKeys.rolesMobile,
    queryFn: api.getRolesMobile,
    select: (data) => {
      return data.data;
    },
  });
};

interface UsersApiResponse {
  result: Array<{
    user_name: string;
    phoneNumber: string | null;
    user_email: string;
    experience: string;
    work_type: string;
    doctor_type: string;
    user_id: string;
    role_id: number;
    is_Verified: string;
  }>;
  count: number;
}

export const useAllUsers = (
  page: number,
  pageSize: number,
  searchUser?: string | null,
  roleId?: string | undefined,
  startDate?: Date | undefined,
  isVerified?: string | undefined,
  endDate?: Date | undefined
) => {
  return useQuery({
    queryKey: [
      "getAllUsers",
      page,
      pageSize,
      searchUser,
      roleId,
      startDate,
      endDate,
      isVerified,
    ],
    queryFn: async () => {
      const response = await axiosInstance.get<UsersApiResponse>(
        API_ENDPOINTS.getAllUsers(
          page,
          pageSize,
          searchUser || "",
          roleId || "",
          startDate,
          isVerified || "",
          endDate
        )
      );
      return response.data;
    },
    select: (data) => ({
      result: data.result || [],
      count: data.count || 0,
    }),
  });
};

export const useUploadReels = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: api.uploadReels,
    onSuccess: () => {
      // Invalidate all queries to refresh all data
      queryClient.invalidateQueries();
    },
  });
};

export const useAllClinics = (
  page: number,
  pageSize: number,
  searchUser?: string,
  status?: "Pending" | "Approved" | "Reject",
  startDate?: Date,
  endDate?: Date
) => {
  return useQuery({
    queryKey: [
      "clinics",
      page,
      pageSize,
      searchUser,
      status,
      startDate,
      endDate,
    ],
    queryFn: () =>
      api.getAllClinics(page, pageSize, searchUser, status, startDate, endDate),
  });
};

export const useMedia = (
  media_type: MediaType,
  offset: number,
  pageSize: number,
  search_user?: string
) => {
  return useQuery({
    queryKey: queryKeys.media(media_type, offset, pageSize, search_user),
    queryFn: () => api.getMedia(media_type, offset, pageSize, search_user),
    select: (data) => {
      switch (media_type) {
        case MediaType.Feeds:
          return data.data.feeds;
        case MediaType.Reels:
          return data.data.reels;
        case MediaType.Blogs:
          return data.data.blogs;
        case MediaType.Banners:
          return data.data.banners;
        default:
          return data.data.result;
      }
    },
  });
};

export const useDeleteMedia = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: api.deleteMedia,
    onSuccess: () => {
      // Invalidate all media queries to ensure the list is refreshed
      queryClient.invalidateQueries();
    },
  });
};

export const useAllAdmins = (
  page: number,
  pageSize: number,
  searchUser?: string,
  role_id?: number
) => {
  return useQuery({
    queryKey: queryKeys.getAllAdmins(page, pageSize, searchUser, role_id),
    queryFn: () => api.getAllAdmins(page, pageSize, searchUser, role_id),
    select: (data) => {
      return data.data;
    },
  });
};

export const useOnboardAdmin = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      userId,
      data,
    }: {
      userId: string;
      data: OnboardAdminRequest;
    }) => {
      const response = await api.onboardAdmin(userId, data);
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admins"] });
    },
  });
};

export const useDeleteOnboardAdmin = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (userId: string) => {
      const response = await axiosInstance.post(
        API_ENDPOINTS.deleteOnboardAdmin(userId)
      );
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries();
    },
  });
};

export const useVerifyClinic = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: VerifyClinicRequest) => {
      const response = await api.verifyClinic(data);
      return response.data;
    },
    onSuccess: (_, variables) => {
      console.log("Clinic verification successful, invalidating cache...");
      // Invalidate all clinic queries to ensure counts are updated
      queryClient.invalidateQueries({ queryKey: ["clinics"] });
      queryClient.invalidateQueries({ queryKey: queryKeys.overview });
      queryClient.refetchQueries({ queryKey: queryKeys.overview });

      // Immediately refetch the queries for both old and new status
      queryClient.refetchQueries({
        queryKey: ["clinics", undefined, undefined, undefined, "Pending"],
        exact: false,
      });
      queryClient.refetchQueries({
        queryKey: ["clinics", undefined, undefined, undefined, "Approved"],
        exact: false,
      });
      console.log("Cache invalidation completed for clinic verification");
    },
  });
};

export const useUpdateClinic = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      clinicId,
      data,
    }: {
      clinicId: string;
      data: UpdateClinicRequest;
    }) => {
      const response = await api.updateClinic(clinicId, data);
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["clinics"] });
      queryClient.invalidateQueries({ queryKey: queryKeys.overview });
      queryClient.refetchQueries({ queryKey: queryKeys.overview });
    },
  });
};

export const useDeleteClinic = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (clinicId: string) => {
      const response = await axiosInstance.post(
        API_ENDPOINTS.deleteClinic(clinicId)
      );
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["clinics"] });
      queryClient.invalidateQueries({ queryKey: queryKeys.overview });
      queryClient.refetchQueries({ queryKey: queryKeys.overview });
    },
  });
};

export const useOnboardClinic = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: OnboardClinicRequest) => {
      const roleName = localStorage.getItem("roleName");
      const isVerified = roleName === "Super Admin" ? "Approved" : "Pending";

      const response = await api.onboardClinic({
        ...data,
        is_Verified: isVerified,
      });
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["clinics"] });
      queryClient.invalidateQueries({ queryKey: queryKeys.overview });
      queryClient.refetchQueries({ queryKey: queryKeys.overview });
    },
  });
};

export const useGetUserByPhone = (phoneNumber: string) => {
  return useQuery({
    queryKey: ["user", phoneNumber],
    queryFn: async () => {
      const response = await api.getUserByPhone(phoneNumber);
      return response.data;
    },
    enabled:
      !!phoneNumber &&
      phoneNumber.length === 10 &&
      /^[0-9]{10}$/.test(phoneNumber),
  });
};

export const useUploadImage = () => {
  return useMutation({
    mutationFn: api.uploadImage,
  });
};

export const usePostEvent = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (eventData: Omit<PostEventRequest, "user_id">) => {
      const userId = localStorage.getItem("userId");
      if (!userId) {
        throw new Error("User ID not found. Please login first.");
      }
      return api.postEvent({
        ...eventData,
        user_id: userId,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries();
    },
  });
};

export const usePostProfileInfo = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (
      data: PostProfileInfoRequest & { is_edited?: boolean }
    ) => {
      const { is_edited, ...requestData } = data;
      const roleName = localStorage.getItem("roleName");

      // For profile updates, maintain the current verification status
      // Only Super Admin can change verification status
      const isVerified =
        roleName === "Super Admin"
          ? requestData.is_Verified || "Approved"
          : requestData.is_Verified || "Pending";

      // Prepare the final payload with validation
      const payload = {
        ...requestData,
        is_Verified: isVerified,
      };

      // Validate required fields
      // For new doctors (when is_edited is false), user_id can be empty as backend will generate it
      if (is_edited && !payload.user_id) {
        throw new Error("user_id is required for updates");
      }
      if (!payload.user_name) {
        throw new Error("user_name is required");
      }
      if (!payload.user_email) {
        throw new Error("user_email is required");
      }

      console.log("PostProfileInfo API call payload:", payload);
      console.log("API endpoint:", API_ENDPOINTS.postProfileInfo);

      try {
        // Use the API call with URL parameters
        const response = await axiosInstance.post(
          API_ENDPOINTS.postProfileInfo(true, is_edited || false),
          payload
        );
        console.log("PostProfileInfo API response:", response.data);
        console.log("API response message:", response.data?.message);
        console.log("API response data type:", typeof response.data);
        console.log(
          "API response keys:",
          response.data ? Object.keys(response.data) : "no data"
        );
        return response.data;
      } catch (error: any) {
        console.error("PostProfileInfo API error:", error);
        console.error("Error response:", error.response?.data);
        console.error("Error status:", error.response?.status);
        console.error("Error headers:", error.response?.headers);
        console.error("Full error object:", error);
        console.error("Error response data type:", typeof error.response?.data);
        console.error(
          "Error response data keys:",
          error.response?.data ? Object.keys(error.response.data) : "no data"
        );

        // If JSON fails, try with form data
        if (error.response?.status === 400 || error.response?.status === 415) {
          console.log("Retrying with form data format...");
          try {
            const formData = new FormData();
            Object.keys(payload).forEach((key) => {
              if (
                key === "PersonalInfo" ||
                key === "Education" ||
                key === "Work"
              ) {
                formData.append(key, JSON.stringify(payload[key]));
              } else {
                formData.append(key, payload[key]);
              }
            });

            const formResponse = await axiosInstance.post(
              API_ENDPOINTS.postProfileInfo(true, is_edited || false),
              formData,
              {
                headers: {
                  "Content-Type": "multipart/form-data",
                },
              }
            );
            console.log(
              "PostProfileInfo API response (form data):",
              formResponse.data
            );
            console.log(
              "Form data response message:",
              formResponse.data?.message
            );
            console.log(
              "Form data response data type:",
              typeof formResponse.data
            );
            console.log(
              "Form data response keys:",
              formResponse.data ? Object.keys(formResponse.data) : "no data"
            );
            return formResponse.data;
          } catch (formError: any) {
            console.error("Form data also failed:", formError);
            // If the original error has a better error message, use it instead
            if (
              error.response?.data?.message &&
              !formError.response?.data?.message
            ) {
              console.log("Using original error with better message");
              throw error;
            }
            throw formError;
          }
        }

        // If both JSON and form data fail, try with flattened structure
        if (error.response?.status === 422 || error.response?.status === 500) {
          console.log("Retrying with flattened structure...");
          try {
            const flattenedPayload = {
              ...payload,
              // Flatten nested objects
              profile_name: payload.PersonalInfo?.profile_name || "",
              profile_email_id: payload.PersonalInfo?.profile_email_id || "",
              profile_phone_number:
                payload.PersonalInfo?.profile_phone_number || "",
              specialization: JSON.stringify(
                payload.PersonalInfo?.specialization || []
              ),
              state: payload.Education?.state || "",
              collage_name: payload.Education?.collage_name || "",
              passed_out_year: payload.Education?.passed_out_year || "",
              state_councel_reg_number:
                payload.Education?.state_councel_reg_number || "",
              state_councel_certificate:
                payload.Education?.state_councel_certificate || "",
              work_type: payload.Work?.work_type || "",
              designation: payload.Work?.designation || "",
              expertise_in: payload.Work?.expertise_in || "",
              experience: payload.Work?.experience || "",
              is_experience: payload.Work?.is_experience || false,
              clinic_name: payload.Work?.clinic_name || "",
              joined_Date: payload.Work?.joined_Date || "",
              Departure: payload.Work?.Departure || "",
            };

            const flattenedResponse = await axiosInstance.post(
              API_ENDPOINTS.postProfileInfo(true, is_edited || false),
              flattenedPayload
            );
            console.log(
              "PostProfileInfo API response (flattened):",
              flattenedResponse.data
            );
            return flattenedResponse.data;
          } catch (flattenedError: any) {
            console.error("Flattened structure also failed:", flattenedError);
            throw flattenedError;
          }
        }

        throw error;
      }
    },
    onSuccess: (data, variables) => {
      console.log(
        "Profile update successful, invalidating queries for user:",
        variables.user_id
      );
      // Invalidate specific profile query for this user
      queryClient.invalidateQueries({
        queryKey: ["profile", variables.user_id],
      });
      // Invalidate all profile queries
      queryClient.invalidateQueries({ queryKey: ["profile"] });
      // Invalidate other user-related queries
      queryClient.invalidateQueries({ queryKey: ["getAllUsers"] });
      queryClient.invalidateQueries({ queryKey: ["doctors"] });
      queryClient.invalidateQueries({ queryKey: ["users"] });
      queryClient.invalidateQueries({ queryKey: queryKeys.overview });
      queryClient.refetchQueries({ queryKey: queryKeys.overview });

      // Force refetch all queries immediately
      queryClient.refetchQueries({ queryKey: ["profile"] });
      console.log("Cache invalidation completed for profile update");
    },
  });
};

export const useAllEvents = (
  page: number,
  pageSize: number,
  eventTypeId?: number,
  searchUser?: string,
  isAdmin?: boolean,
  startDate?: string,
  endDate?: string
) => {
  return useQuery({
    queryKey: [
      "getAllEvents",
      page,
      pageSize,
      eventTypeId,
      searchUser,
      isAdmin,
      startDate,
      endDate,
    ],
    queryFn: () =>
      api.getAllEvents(
        page,
        pageSize,
        eventTypeId,
        searchUser,
        isAdmin,
        startDate,
        endDate
      ),
    select: (data) => {
      return {
        result: data.data.result,
        count: data.data.count,
      };
    },
  });
};

export const useAllEventTypes = () => {
  return useQuery({
    queryKey: queryKeys.getAllEventTypes,
    queryFn: api.getAllEventTypes,
    select: (data) => {
      return data.data;
    },
  });
};

export const useGetProfileByUserId = (userId: string) => {
  return useQuery({
    queryKey: queryKeys.getProfileByUserId(userId),
    queryFn: () => api.getProfileByUserId(userId),
    select: (data): ProfileResponse => {
      return data.data;
    },
    enabled: !!userId,
  });
};

export const useVerifyDoctor = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: VerifyDoctorRequest) => {
      const response = await api.verifyDoctor(data);
      return response.data;
    },
    onSuccess: () => {
      console.log("Doctor verification successful, invalidating cache...");
      // Invalidate related queries to refresh data
      queryClient.invalidateQueries({ queryKey: ["doctors"] });
      queryClient.invalidateQueries({ queryKey: ["getAllUsers"] });
      queryClient.invalidateQueries({ queryKey: queryKeys.overview });
      queryClient.refetchQueries({ queryKey: queryKeys.overview });
      console.log("Cache invalidation completed for doctor verification");
    },
  });
};

export const useVerifyEvent = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: VerifyEventRequest) => {
      try {
        const response = await api.verifyEvent(data);

        return response.data;
      } catch (error) {
        console.error("Verify event error:", error); // Debug log
        throw error;
      }
    },
    onSuccess: () => {
      // Invalidate events queries to refresh the data
      queryClient.invalidateQueries({ queryKey: ["getAllEvents"] });
    },
    onError: (error: any) => {
      console.error("Mutation error:", error);
    },
  });
};

export const useAllDoctors = (
  page: number,
  pageSize: number,
  searchUser?: string,
  status?: "Pending" | "Approved" | "Reject"
) => {
  return useQuery({
    queryKey: ["doctors", page, pageSize, searchUser, status],
    queryFn: () =>
      api.getAllUsers(
        page,
        pageSize,
        searchUser,
        "2",
        undefined,
        status === "Approved" ? true : status === "Reject" ? false : undefined
      ),
    select: (data) => {
      return {
        result: data.data.result.filter((user) => user.role_id === 2), // Filter for doctors only
        count: data.data.count,
      };
    },
  });
};

export const useChangePassword = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: api.changePassword,
    onSuccess: () => {
      queryClient.invalidateQueries();
    },
  });
};

export const usePostNotification = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: PostNotificationRequest) => {
      const userId = localStorage.getItem("userId");
      if (!userId) {
        throw new Error("User ID not found. Please login first.");
      }
      return api.postNotification({
        ...data,
        user_id: userId,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries();
    },
  });
};

export const useDeleteProfileInfo = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (user_id: string) => {
      const response = await axiosInstance.post(
        `${API_ENDPOINTS.deleteProfileInfo}?user_id=${user_id}`
      );
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["getAllUsers"] });
      queryClient.invalidateQueries({ queryKey: queryKeys.overview });
      queryClient.refetchQueries({ queryKey: queryKeys.overview });
    },
  });
};

export const useStates = () => {
  return useQuery({
    queryKey: ["states"],
    queryFn: api.getStates,
    select: (data) => {
      return data.data;
    },
  });
};

export const useAllCourseCategories = () => {
  return useQuery({
    queryKey: ["courseCategories"],
    queryFn: api.getAllCourse_Categories,
    select: (data) => {
      return data.data;
    },
  });
};
