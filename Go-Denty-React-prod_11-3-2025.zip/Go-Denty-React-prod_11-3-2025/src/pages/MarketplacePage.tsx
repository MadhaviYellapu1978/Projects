import React, { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CreateButton } from "../components/ui/button";
import SearchInput from "../components/ui/SearchInput";
import { CircleDollarSign, Package, ShoppingBag, Store } from "lucide-react";
import { mockData } from "../data/mockData";
import TabButton from "../components/ui/TabButton";

const MarketplacePage = () => {
  const [searchQuery, setSearchQuery] = useState("");

  const products = [
    {
      id: 1,
      name: "Dental Chair - Premium Model",
      price: "₹120,000",
      category: "Equipment",
      rating: 4.8,
      image: "/lovable-uploads/5a4ffead-92d1-4868-8d4c-a70bfd9daaf0.png",
    },
    {
      id: 2,
      name: "Digital X-Ray Machine",
      price: "₹350,000",
      category: "Equipment",
      rating: 4.9,
      image: "/lovable-uploads/95dda499-04e3-409d-83ad-a60a3793a25f.png",
    },
    {
      id: 3,
      name: "Dental Implant Kit",
      price: "₹78,000",
      category: "Instruments",
      rating: 4.7,
      image: "/lovable-uploads/ab4e2c72-66c0-4a4c-9ad9-1021c72acc49.png",
    },
    {
      id: 4,
      name: "Ultrasonic Scaler",
      price: "₹15,500",
      category: "Instruments",
      rating: 4.5,
      image: "/lovable-uploads/fa723da9-3cc3-46e1-b65a-5f4333ea9fba.png",
    },
    {
      id: 5,
      name: "Teeth Whitening Kit",
      price: "₹8,900",
      category: "Consumables",
      rating: 4.6,
      image: "/lovable-uploads/ad4b79fd-6e0e-46b4-8d16-e265cac0e593.png",
    },
    {
      id: 6,
      name: "Dental Impression Material",
      price: "₹3,200",
      category: "Consumables",
      rating: 4.4,
      image: "/lovable-uploads/48fed93c-71ac-47b0-87bb-8c4d88d873b6.png",
    },
  ];

  const filteredProducts = products.filter(
    (product) =>
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Dental Marketplace</h1>
        <CreateButton
          variant="default"
          onClick={() => console.log("List Product clicked")}
        >
          List Product
        </CreateButton>
      </div>

      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <div className="stats flex space-x-6">
          <div className="flex items-center gap-2">
            <Package className="text-primary" size={20} />
            <div>
              <p className="text-sm text-gray-500">Products</p>
              <p className="font-semibold">1,245</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Store className="text-primary" size={20} />
            <div>
              <p className="text-sm text-gray-500">Vendors</p>
              <p className="font-semibold">85</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <ShoppingBag className="text-primary" size={20} />
            <div>
              <p className="text-sm text-gray-500">Orders</p>
              <p className="font-semibold">324</p>
            </div>
          </div>
        </div>
        <div className="w-full sm:w-64">
          <SearchInput
            placeholder="Search products..."
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <Tabs defaultValue="all">
        <TabsList className="mb-6">
          <TabsTrigger value="all">All Products</TabsTrigger>
          <TabsTrigger value="equipment">Equipment</TabsTrigger>
          <TabsTrigger value="instruments">Instruments</TabsTrigger>
          <TabsTrigger value="consumables">Consumables</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-0">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((product) => (
              <Card
                key={product.id}
                className="overflow-hidden hover:shadow-md transition-shadow"
              >
                <div className="h-48 overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover object-center"
                  />
                </div>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">{product.name}</CardTitle>
                      <CardDescription>{product.category}</CardDescription>
                    </div>
                    <span className="inline-flex items-center justify-center bg-primary/10 text-primary text-sm font-medium rounded-full h-8 w-8">
                      {product.rating}
                    </span>
                  </div>
                </CardHeader>
                <CardContent className="pb-2">
                  <div className="flex items-center">
                    <CircleDollarSign className="mr-2 h-4 w-4 text-secondary" />
                    <span className="font-bold text-lg">{product.price}</span>
                  </div>
                </CardContent>
                <CardFooter>
                  <button className="w-full bg-primary text-white py-2 rounded-md hover:bg-primary/90 transition-colors">
                    View Details
                  </button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="equipment" className="mt-0">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts
              .filter((p) => p.category === "Equipment")
              .map((product) => (
                <Card
                  key={product.id}
                  className="overflow-hidden hover:shadow-md transition-shadow"
                >
                  <div className="h-48 overflow-hidden">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover object-center"
                    />
                  </div>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">
                          {product.name}
                        </CardTitle>
                        <CardDescription>{product.category}</CardDescription>
                      </div>
                      <span className="inline-flex items-center justify-center bg-primary/10 text-primary text-sm font-medium rounded-full h-8 w-8">
                        {product.rating}
                      </span>
                    </div>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <div className="flex items-center">
                      <CircleDollarSign className="mr-2 h-4 w-4 text-secondary" />
                      <span className="font-bold text-lg">{product.price}</span>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <button className="w-full bg-primary text-white py-2 rounded-md hover:bg-primary/90 transition-colors">
                      View Details
                    </button>
                  </CardFooter>
                </Card>
              ))}
          </div>
        </TabsContent>

        <TabsContent value="instruments" className="mt-0">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts
              .filter((p) => p.category === "Instruments")
              .map((product) => (
                <Card
                  key={product.id}
                  className="overflow-hidden hover:shadow-md transition-shadow"
                >
                  <div className="h-48 overflow-hidden">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover object-center"
                    />
                  </div>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">
                          {product.name}
                        </CardTitle>
                        <CardDescription>{product.category}</CardDescription>
                      </div>
                      <span className="inline-flex items-center justify-center bg-primary/10 text-primary text-sm font-medium rounded-full h-8 w-8">
                        {product.rating}
                      </span>
                    </div>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <div className="flex items-center">
                      <CircleDollarSign className="mr-2 h-4 w-4 text-secondary" />
                      <span className="font-bold text-lg">{product.price}</span>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <button className="w-full bg-primary text-white py-2 rounded-md hover:bg-primary/90 transition-colors">
                      View Details
                    </button>
                  </CardFooter>
                </Card>
              ))}
          </div>
        </TabsContent>

        <TabsContent value="consumables" className="mt-0">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts
              .filter((p) => p.category === "Consumables")
              .map((product) => (
                <Card
                  key={product.id}
                  className="overflow-hidden hover:shadow-md transition-shadow"
                >
                  <div className="h-48 overflow-hidden">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover object-center"
                    />
                  </div>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">
                          {product.name}
                        </CardTitle>
                        <CardDescription>{product.category}</CardDescription>
                      </div>
                      <span className="inline-flex items-center justify-center bg-primary/10 text-primary text-sm font-medium rounded-full h-8 w-8">
                        {product.rating}
                      </span>
                    </div>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <div className="flex items-center">
                      <CircleDollarSign className="mr-2 h-4 w-4 text-secondary" />
                      <span className="font-bold text-lg">{product.price}</span>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <button className="w-full bg-primary text-white py-2 rounded-md hover:bg-primary/90 transition-colors">
                      View Details
                    </button>
                  </CardFooter>
                </Card>
              ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default MarketplacePage;
