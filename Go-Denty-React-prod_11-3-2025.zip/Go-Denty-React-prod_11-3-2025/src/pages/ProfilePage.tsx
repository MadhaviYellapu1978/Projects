import React, { useState, useEffect, useMemo } from "react";
import TabButton from "../components/ui/TabButton";
import { Button } from "../components/ui/button";
import { Edit, Edit2, Pencil, X } from "lucide-react";
import ForgetPassword from "./ForgetPassword";
import EditProfileModal from "../components/modals/EditProfileModal";
import { useGetProfileByUserId } from "../services/api";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from "@/components/ui/dialog";

const ProfilePage = () => {
  const [activeTab, setActiveTab] = useState("Profile");
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showEditProfileModal, setShowEditProfileModal] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0); // Add this to force re-render

  // Get user ID from localStorage
  const userId =
    localStorage.getItem("userId") || localStorage.getItem("user_id") || "";

  // Fetch profile data using the API
  const {
    data: profileData,
    refetch,
    isLoading,
    error,
  } = useGetProfileByUserId(userId);

  console.log("Retrieved userId:", userId);
  console.log("Backend API Response - profileData:", profileData);
  console.log("API isLoading:", isLoading);
  console.log("API error:", error);

  // Debug the profileData structure
  if (profileData) {
    console.log("🔍 ProfileData structure:", {
      user_email: profileData.user_email,
      user_name: profileData.user_name,
      phoneNumber: profileData.phoneNumber,
      profile_pic: profileData.profile_pic,
      allKeys: Object.keys(profileData),
    });
  }

  // Transform API data to match the expected userData format, prioritize backend data completely
  const userData = useMemo(() => {
    if (!profileData) {
      // Return empty data while loading, don't use localStorage
      return {
        userId:
          localStorage.getItem("userId") ||
          localStorage.getItem("user_id") ||
          "",
        firstName: "",
        lastName: "",
        email: "",
        phoneNumber: "",
        profilePic: "",
      };
    }

    const nameParts = profileData.user_name?.split(" ") || [];
    const firstName = nameParts[0] || "";
    const lastName = nameParts.slice(1).join(" ") || "";

    const transformedData = {
      userId: profileData.user_id || userId,
      firstName,
      lastName,
      email: profileData.user_email || localStorage.getItem("email") || "",
      phoneNumber: profileData.phoneNumber || "",
      profilePic: profileData.profile_pic || "",
    };
    console.log(
      "Transformed userData for EditModal (backend data only):",
      transformedData
    );
    console.log("🔍 Email sources:", {
      profileData_user_email: profileData.user_email,
      localStorage_email: localStorage.getItem("email"),
      final_email: transformedData.email,
    });
    return transformedData;
  }, [profileData, userId]);

  // Refresh profile data when edit profile modal is closed
  const handleEditProfileClose = () => {
    setShowEditProfileModal(false);
  };

  // Handle successful profile update
  const handleProfileUpdateSuccess = async () => {
    console.log("Profile update success - triggering refetch");

    try {
      // Force refetch of profile data
      await refetch();
      console.log("Profile data refetched successfully");

      // Also update refreshKey to force component re-render
      setRefreshKey((prev) => prev + 1);
      console.log("Refetch triggered, refreshKey updated");
    } catch (error) {
      console.error("Error refetching profile data:", error);
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-8">
        <div className="flex space-x-4">
          <h2 className="text-2xl font-semibold text-gray-800">Profile Info</h2>
        </div>
        <div className="bg-white rounded-lg border border-gray-100 p-8">
          <div className="flex items-center justify-center h-64">
            <div className="text-gray-500">Loading profile...</div>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="space-y-8">
        <div className="flex space-x-4">
          <h2 className="text-2xl font-semibold text-gray-800">Profile Info</h2>
        </div>
        <div className="bg-white rounded-lg border border-gray-100 p-8">
          <div className="flex items-center justify-center h-64">
            <div className="text-red-500">Error loading profile data</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex space-x-4">
        <h2 className="text-2xl font-semibold text-gray-800">Profile Info</h2>
      </div>

      <div className="bg-white rounded-lg border border-gray-100 p-8">
        <div className="flex flex-col items-center mb-10">
          <div className="relative mb-4">
            <div className="h-24 w-24 rounded-full overflow-hidden border-4 border-white shadow-md bg-gray-200 flex items-center justify-center">
              {userData.profilePic ? (
                <img
                  src={userData.profilePic}
                  alt="Profile"
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="h-full w-full bg-gray-300 flex items-center justify-center text-gray-600 text-2xl font-medium">
                  {userData.firstName.charAt(0).toUpperCase()}
                </div>
              )}
            </div>
            {/* <button className="absolute bottom-0 right-0 bg-white rounded-full p-1 shadow-md">
              <Pencil size={16} className="text-gray-600" />
            </button> */}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-6">
          {/* <div>
            <label className="block text-gray-500 text-sm mb-1">User ID</label>
            <input
              type="text"
              className="border border-gray-200 rounded p-3 w-full bg-gray-50"
              value={userData.userId}
              disabled
            />
          </div> */}
          <div>
            <label className="block text-gray-500 text-sm mb-1">Name</label>
            <input
              type="text"
              className="border border-gray-200 rounded p-3 w-full bg-gray-50"
              value={`${userData.firstName} ${userData.lastName}`}
              disabled
            />
          </div>
          {/* <div>
            <label className="block text-gray-500 text-sm mb-1">Email</label>
            <input
              type="email"
              className="border border-gray-200 rounded p-3 w-full bg-gray-50"
              value={userData.email}
              disabled
            />
          </div> */}
          <div>
            <label className="block text-gray-500 text-sm mb-1">
              Phone Number
            </label>
            <input
              type="tel"
              className="border border-gray-200 rounded p-3 w-full bg-gray-50"
              value={userData.phoneNumber}
              disabled
            />
          </div>
        </div>

        <div className="flex justify-between mt-10">
          <Button
            variant="default"
            onClick={() => setShowEditProfileModal(true)}
          >
            Edit Profile
          </Button>
          <Button variant="outline" onClick={() => setShowPasswordModal(true)}>
            Change Password
          </Button>
        </div>
      </div>

      {/* Password Change Modal */}
      <Dialog open={showPasswordModal} onOpenChange={setShowPasswordModal}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">
              Change Password
            </DialogTitle>
          </DialogHeader>
          <DialogClose className="absolute right-4 top-4">
            <X className="h-4 w-4" />
            <span className="sr-only">Close</span>
          </DialogClose>

          <ForgetPassword setShowPasswordModal={setShowPasswordModal} />
        </DialogContent>
      </Dialog>

      {/* Edit Profile Modal */}
      {showEditProfileModal && (
        <EditProfileModal
          isOpen={showEditProfileModal}
          onClose={handleEditProfileClose}
          onSuccess={handleProfileUpdateSuccess}
          userData={userData}
        />
      )}
    </div>
  );
};

export default ProfilePage;
