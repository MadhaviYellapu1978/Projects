import React, { useState } from "react";
import { useGetNotificationsByUser_id } from "@/services/api";
import { Search, Plus } from "lucide-react";

interface Notification {
  message: string;
  notification_id: string;
  user_id: string;
}

const NotificationsPage = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const userId = localStorage.getItem("userId") || "";
  const { data, isLoading } = useGetNotificationsByUser_id(userId);

  const filteredNotifications =
    data?.notifications?.filter((notification) =>
      notification.message.toLowerCase().includes(searchQuery.toLowerCase())
    ) || [];

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="mb-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Notifications</h1>
          <button className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200 font-medium text-sm">
            <Plus className="w-4 h-4 mr-2" />
            Create Notification
          </button>
        </div>
        <div className="relative">
          <input
            type="text"
            placeholder="Search notifications..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <Search className="absolute left-3 top-2.5 text-gray-400 h-5 w-5" />
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
        </div>
      ) : filteredNotifications.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-500 text-lg">No notifications found</p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredNotifications.map((notification) => (
            <div
              key={notification.notification_id}
              className="bg-white rounded-lg shadow-sm border border-gray-100 p-4 transition-all hover:shadow-md"
            >
              <p className="text-gray-800">{notification.message}</p>
              <div className="mt-2 flex justify-end">
                <span className="text-xs text-gray-500">
                  ID: {notification.notification_id}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default NotificationsPage;
