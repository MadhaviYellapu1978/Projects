/* eslint-disable @typescript-eslint/no-explicit-any */

import React, { useState, useEffect } from "react";
import * as XLSX from "xlsx";
import ExcelJS from "exceljs";
import {
  Heart,
  Search,
  Check,
  // X,
  FileText,
  Phone,
  Mail,
  Globe,
  MapPin,
  Briefcase,
  Calendar,
  Download,
} from "lucide-react";
import StatCard from "../components/ui/StatCard";
import TabButton from "../components/ui/TabButton";
import DataTable from "../components/ui/DataTable";
// import { mockData } from "../data/mockData";
import SelectDropdown from "../components/ui/SelectDropdown";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogTitle,
  AlertDialogDescription,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import {
  useOverview,
  useRolesMobile,
  useAllUsers,
  useAllClinics,
} from "@/services/api";
import { DatePickerWithRange } from "@/components/ui/date-range";
import StatusBadge from "../components/ui/StatusBadge";
import DoctorDetailsModal from "@/components/doctors/DoctorDetailsModal";
import ReadOnlyDoctorDetailsModal from "@/components/doctors/ReadonlyDoctorModal";
import ReadOnlyClinicDetailsModal from "@/components/doctors/ReadOnlyClinicModal";
import Hearts from "../../public/lovable-uploads/Hearts.svg";
import { baseURL } from "@/services/axios";

const tooltipStyles = `
  .tooltip {
    position: relative;
    display: inline-block;
    max-width: 100%;
  }
  .tooltip:hover .tooltip-text {
    visibility: visible;
    opacity: 1;
  }
  .tooltip-text {
    visibility: hidden;
    opacity: 0;
    position: absolute;
    z-index: 1;
    top: 125%;
    left: 0;
    transform: none;
    background-color: #333;
    color: white;
    text-align: left;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 14px;
    transition: opacity 0.3s;
    white-space: nowrap;
    max-width: 800px;
    word-break: normal;
    overflow-x: auto;
    text-overflow: ellipsis;
    box-shadow: 0 2px 8px rgba(0,0,0,0.15);
  }
`;

/**
 * Formats a date string to a consistent format (DD-MM-YYYY), handling various input formats
 * @param dateStr The date string to format
 * @returns Formatted date string or fallback text
 */
const formatDate = (dateStr: string): string => {
  if (!dateStr) return "-";

  // Try parsing different date formats
  const date = new Date(dateStr);

  // Check if the date is valid
  if (isNaN(date.getTime())) {
    // Try parsing DD-MM-YYYY format
    const [day, month, year] = dateStr.split("-").map(Number);
    if (day && month && year) {
      const parsedDate = new Date(year, month - 1, day);
      if (!isNaN(parsedDate.getTime())) {
        return `${day.toString().padStart(2, "0")}-${month
          .toString()
          .padStart(2, "0")}-${year}`;
      }
    }
    return "-";
  }

  // Format the date as DD-MM-YYYY
  const day = date.getDate().toString().padStart(2, "0");
  const month = (date.getMonth() + 1).toString().padStart(2, "0");
  const year = date.getFullYear();
  return `${day}-${month}-${year}`;
};

const Dashboard = () => {
  const [activeTab, setActiveTab] = React.useState("Guest Users");
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [showDoctorDetailsModal, setShowDoctorDetailsModal] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState<any | null>(null);
  const [showClinicDetailsModal, setShowClinicDetailsModal] = useState(false);
  const [showDetailsDialog, setShowDetailsDialog] = useState(false);
  const [totalUsersCount, setTotalUsersCount] = useState(0);
  const [pendingUsersCount, setPendingUsersCount] = useState(0);
  const [guestUsersCount, setGuestUsersCount] = useState(0);
  const [doctorsCount, setDoctorsCount] = useState(0);
  const [totalClinicsCount, setTotalClinicsCount] = useState(0);

  const [showSuccessDialog, setShowSuccessDialog] = useState(false);
  const [showCancelDialog, setShowCancelDialog] = useState(false);
  const [showReasonDialog, setShowReasonDialog] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [cancelMessage, setCancelMessage] = useState("");
  const [reasonText, setReasonText] = useState("");
  const [rejectType, setRejectType] = useState<"doctor" | "clinic">("doctor");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [searchUser, setSearchUser] = useState("");
  const [roleId, setRoleId] = useState<string | null>(null);
  const [isVerified, setIsVerified] = useState<string | null>(null);
  const { toast } = useToast();
  const { data: stats, isLoading } = useOverview();
  const [clinicSearch, setClinicSearch] = useState("");
  const dashboardStats = stats?.data;

  // Debug logging for overview data
  useEffect(() => {
    console.log("Dashboard overview data updated:", dashboardStats);
  }, [dashboardStats]);

  // Add state for clinic verification status
  const [clinicStatus, setClinicStatus] = useState<
    "Pending" | "Approved" | "Reject" | undefined
  >(activeTab === "Pending" ? "Pending" : undefined);

  // Add date range state
  const [dateRange, setDateRange] = useState<{
    from: Date | null;
    to: Date | null;
  }>({
    from: null,
    to: null,
  });

  // Export Functionality using ExcelJS for proper styling
  const handleExport = async () => {
    try {
      let dataToExport = [];

      if (activeTab === "Clinics") {
        // Fetch all clinics data with current filters but without pagination
        const clinicParams = new URLSearchParams({
          page: "1",
          pageSize: "10000", // Large number to get all records
        });

        // Add current filters
        if (clinicStatus) {
          clinicParams.append("is_Verified", clinicStatus);
        }
        if (dateRange.from) {
          clinicParams.append(
            "startDate",
            dateRange.from.toISOString().split("T")[0]
          );
        }
        if (dateRange.to) {
          clinicParams.append(
            "endDate",
            dateRange.to.toISOString().split("T")[0]
          );
        }
        if (clinicSearch) {
          clinicParams.append("search", clinicSearch);
        }

        const response = await fetch(`${baseURL}/GetAllClincs?${clinicParams}`);
        const allClinicsData = await response.json();
        dataToExport = allClinicsData?.result || [];
      } else {
        // Fetch all users data with current filters but without pagination
        const userParams = new URLSearchParams({
          page: "1",
          pageSize: "10000", // Large number to get all records
        });

        // Add current filters
        if (activeTab === "Pending") {
          userParams.append("role_id", "0");
          userParams.append("is_Verified", "Pending");
        } else if (activeTab === "Guest Users") {
          userParams.append("role_id", "7");
        } else if (activeTab === "Doctors") {
          if (roleId) {
            userParams.append("role_id", roleId);
          }
          userParams.append("is_Verified", "Approved");
        }

        if (dateRange.from) {
          userParams.append(
            "startDate",
            dateRange.from.toISOString().split("T")[0]
          );
        }
        if (dateRange.to) {
          userParams.append(
            "endDate",
            dateRange.to.toISOString().split("T")[0]
          );
        }
        if (searchUser) {
          userParams.append("search", searchUser);
        }

        const response = await fetch(`${baseURL}/GetAllUsers?${userParams}`);
        const allUsersData = await response.json();
        dataToExport = allUsersData?.result || [];
      }

      // Use ExcelJS for proper styling
      await exportWithExcelJS(dataToExport);
    } catch (error) {
      console.error("Export error:", error);
    }
  };

  // New ExcelJS export function with proper styling
  const exportWithExcelJS = async (dataToExport: any[]) => {
    try {
      console.log("Using ExcelJS for export with proper styling");

      // Create a new workbook and worksheet
      const workbook = new ExcelJS.Workbook();
      const worksheetName =
        activeTab === "Pending" ? "Unregistered Users" : activeTab;
      const worksheet = workbook.addWorksheet(worksheetName);

      // Prepare columns based on active tab
      const columns =
        activeTab === "Clinics"
          ? [
              "Clinic_id",
              "Clinic_name",
              "user_name",
              "clinic_Address",
              "Clinic_Contact_Number",
              "status",
              "Clinic_email",
              "Clinic_Website",
            ]
          : activeTab === "Guest Users"
          ? ["role", "user_id", "registration_date"]
          : activeTab === "Pending"
          ? [
              "doctor_name",
              "email",
              "role",
              "status",
              "phoneNumber",
              "experience",
              "work_type",
              "collage_name",
              "passed_out_year",
              "state",
              "state_councel_reg_number",
              "expertise_in",
              "designation",
            ]
          : activeTab === "Doctors"
          ? [
              "doctor_name",
              "email",
              "role",
              "status",
              "phoneNumber",
              "experience",
              "work_type",
              "collage_name",
              "passed_out_year",
              "state",
              "state_councel_reg_number",
              "expertise_in",
              "designation",
            ]
          : [
              "user_name",
              "user_email",
              "doctor_type",
              "is_Verified",
              "phoneNumber",
              "experience",
              "work_type",
              "collage_name",
              "passed_out_year",
              "state",
              "state_councel_reg_number",
              "expertise_in",
              "designation",
            ];

      // Transform column headers to sentence case
      const formattedColumns = columns.map((column) => {
        const withSpaces = column.replace(/[_-]/g, " ");
        return withSpaces
          .split(" ")
          .map(
            (word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
          )
          .join(" ");
      });

      // Add S.No as first column
      const headers = ["S.No", ...formattedColumns];
      console.log("Headers:", headers);

      // Add header row
      worksheet.addRow(headers);

      // Style the header row - THIS IS THE KEY PART!
      const headerRow = worksheet.getRow(1);
      headerRow.font = {
        bold: true,
        size: 10,
        name: "Arial",
        color: { argb: "FF000000" }, // Black color
      };
      headerRow.alignment = {
        horizontal: "center",
        vertical: "middle",
      };
      headerRow.border = {
        top: { style: "thin", color: { argb: "FF000000" } },
        left: { style: "thin", color: { argb: "FF000000" } },
        bottom: { style: "thin", color: { argb: "FF000000" } },
        right: { style: "thin", color: { argb: "FF000000" } },
      };

      console.log("Applied ExcelJS styling to header row");

      // Add data rows
      for (let i = 0; i < dataToExport.length; i++) {
        const item = dataToExport[i];
        const rowData = [i + 1]; // S.No

        // Add other columns based on active tab
        for (const col of columns) {
          if (col === "expertise_in") {
            rowData.push(item["expertise_in"] || "N/A");
          } else if (col === "collage_name") {
            rowData.push(item[col] || "N/A");
          } else if (col === "role" && activeTab === "Guest Users") {
            rowData.push(item["doctor_type"] || "N/A");
          } else if (col === "registration_date") {
            const dateValue = item["created_date"];
            if (dateValue) {
              const dateOnly = dateValue.split("T")[0];
              rowData.push(dateOnly);
            } else {
              rowData.push("N/A");
            }
          } else if (col === "doctor_name") {
            rowData.push(item["user_name"] || "N/A");
          } else if (col === "email") {
            rowData.push(item["user_email"] || "N/A");
          } else if (
            col === "role" &&
            (activeTab === "Pending" || activeTab === "Doctors")
          ) {
            rowData.push(item["doctor_type"] || "N/A");
          } else if (
            col === "status" &&
            (activeTab === "Pending" ||
              activeTab === "Doctors" ||
              activeTab === "Clinics")
          ) {
            rowData.push(item["is_Verified"] || "N/A");
          } else {
            rowData.push(item[col] || "N/A");
          }
        }

        worksheet.addRow(rowData);
      }

      // Set column widths
      worksheet.columns.forEach((column) => {
        column.width = 15;
      });

      // Export the file
      const fileName =
        activeTab === "Pending" ? "Unregistered Users" : activeTab;
      const buffer = await workbook.xlsx.writeBuffer();

      // Create blob and download
      const blob = new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `${fileName}_export_${
        new Date().toISOString().split("T")[0]
      }.xlsx`;
      link.click();
      URL.revokeObjectURL(url);

      console.log(
        `ExcelJS export completed: ${dataToExport.length} records exported for ${activeTab}`
      );
    } catch (error) {
      console.error("ExcelJS export error:", error);
    }
  };

  // Rest of the existing code remains the same...
  const { data: rolesMobile, isLoading: isLoadingRolesMobile } =
    useRolesMobile();
  const {
    data: usersData,
    isLoading: isLoadingUsers,
    error: usersError,
  } = useAllUsers(
    page,
    pageSize,
    searchUser,
    activeTab === "Pending" ? "0" : activeTab === "Guest Users" ? "7" : roleId,
    dateRange.from || undefined,
    activeTab === "Pending"
      ? "Pending"
      : activeTab === "Guest Users"
      ? undefined
      : activeTab === "Doctors"
      ? "Approved"
      : isVerified?.toString(),
    dateRange.to || undefined
  );
  // Add debug logging

  // Memoize the date to prevent unnecessary changes
  const memoizedDate = React.useMemo(() => dateRange.from, [dateRange.from]);

  // Add console.log to debug the parameters
  console.log("Clinic Query Params:", {
    page,
    pageSize,
    searchUser,
    dateRange,
    isVerified,
  });

  // Add new state for clinic search

  const {
    data: clinicsResponse,
    isLoading: isLoadingClinics,
    error: clinicsError,
  } = useAllClinics(
    activeTab === "Clinics" ? 1 : page, // Use page 1 when on Clinics tab to get all data
    activeTab === "Clinics" ? 10000 : pageSize, // Use large page size for Clinics tab
    clinicSearch,
    clinicStatus,
    dateRange.from,
    dateRange.to
  );

  // Debug logging will be moved after data processing

  // Add a separate query for total clinics
  const { data: totalClinicsData } = useAllClinics(
    1,
    1000,
    "",
    undefined,
    dateRange.from,
    dateRange.to
  );

  // Get all clinics data (without status filter) for total count - WITHOUT date range filter
  const { data: allClinicsData, isLoading: isLoadingClinicCount } =
    useAllClinics(1, 1, "", undefined, undefined, undefined);

  // Get pending clinics count - with date range
  const { data: pendingClinicsData } = useAllClinics(
    1,
    1,
    "",
    "Pending",
    dateRange.from,
    dateRange.to
  );

  const statIcons = {
    clinic: (
      <div className=" rounded-md">
        <img
          src={Hearts}
          alt="clinic"
          className="bg-blue-950 text-white p-2 rounded-md"
        />
      </div>
    ),
    mds: (
      <div className="rounded-md">
        <img
          src={Hearts}
          alt="clinic"
          className="bg-blue-950 text-white p-2 rounded-md"
        />
      </div>
    ),
    bds: (
      <div className="rounded-md">
        <img
          src={Hearts}
          alt="clinic"
          className="bg-blue-950 text-white p-2 rounded-md"
        />
      </div>
    ),
    revenue: (
      <div className=" rounded-md">
        <img
          src={Hearts}
          alt="clinic"
          className="bg-blue-950 text-white p-2 rounded-md"
        />
      </div>
    ),
  };

  const doctorColumns = [
    {
      header: "S.NO",
      accessor: "serialNumber",
      cell: (_: string, __: any, rowIndex: number | undefined) => {
        return ((page - 1) * pageSize + (rowIndex ?? 0) + 1).toString();
      },
    },
    {
      header: "DOCTOR NAME",
      accessor: "user_name",
      cell: (value: string) => value || "-",
    },
    {
      header: "PHONE NUMBER",
      accessor: "phoneNumber",
      cell: (value: string | null) => value || "-",
    },
    {
      header: "EMAIL",
      accessor: "user_email",
      cell: (value: string) => value || "-",
    },
    {
      header: "EXPERIENCE",
      accessor: "experience",
      cell: (value: string) => value || "-",
    },
    {
      header: "WORK TYPE",
      accessor: "work_type",
      cell: (value: string) => value || "-",
    },
    {
      header: "ROLE",
      accessor: "doctor_type",
      cell: (value: string) => value || "-",
    },
    {
      header: "REGISTRATION DATE",
      accessor: "created_date",
      cell: (value: string) => {
        if (!value) return "-";
        return formatDate(value);
      },
    },
    {
      header: "STATUS",
      accessor: "is_Verified",
      cell: (value: string) => (
        <StatusBadge status={value as "Active" | "Inactive" | "Pending"} />
      ),
    },
    {
      header: "ACTION",
      accessor: "user_id",
      cell: (value: string, row: any) => (
        <button
          className="view-button"
          onClick={(e) => {
            e.stopPropagation();
            handleViewDetails(row, "doctor");
          }}
        >
          View
        </button>
      ),
    },
  ];

  const unregisteredClinicColumns = [
    {
      header: "S.NO",
      accessor: "serialNumber",
      cell: (_: string, __: any, rowIndex: number | undefined) => {
        return ((page - 1) * pageSize + (rowIndex ?? 0) + 1).toString();
      },
    },

    {
      header: "DOCTOR NAME",
      accessor: "user_name",
      cell: (value: string) => value || "-",
    },
    {
      header: "PHONE NUMBER",
      accessor: "phoneNumber",
      cell: (value: string | null) => value || "-",
    },
    {
      header: "EMAIL",
      accessor: "user_email",
      cell: (value: string) => value || "-",
    },
    {
      header: "EXPERIENCE",
      accessor: "experience",
      cell: (value: string) => value || "-",
    },
    {
      header: "WORK TYPE",
      accessor: "work_type",
      cell: (value: string) => value || "-",
    },
    {
      header: "ROLE",
      accessor: "doctor_type",
      cell: (value: string) => value || "-",
    },
    {
      header: "REGISTRATION DATE",
      accessor: "created_date",
      cell: (value: string) => {
        if (!value) return "-";
        return formatDate(value);
      },
    },
    {
      header: "STATUS",
      accessor: "is_Verified",
      cell: (value: string) => (
        <StatusBadge status={value as "Active" | "Inactive" | "Pending"} />
      ),
    },
    {
      header: "ACTION",
      accessor: "user_id",
      cell: (value: string, row: any) => (
        <button
          className="view-button"
          onClick={(e) => {
            e.stopPropagation();
            handleViewDetails(row, "doctor");
          }}
        >
          View
        </button>
      ),
    },
  ];

  const clinicColumns = [
    {
      header: "S.NO",
      accessor: "serialNumber",
      cell: (_: string, __: any, rowIndex: number | undefined) => {
        return ((page - 1) * pageSize + (rowIndex ?? 0) + 1).toString();
      },
    },
    {
      header: "CLINIC NAME",
      accessor: "Clinic_name",
      cell: (value: string) => {
        if (!value) return "-";
        if (value.length > 10) {
          return (
            <div className="tooltip">
              <span>{value.slice(0, 10)}...</span>
              <span className="tooltip-text">{value}</span>
            </div>
          );
        }
        return value;
      },
    },
    {
      header: "ADDRESS",
      accessor: "clinic_Address",
      cell: (value: string) => {
        if (!value) return "-";
        if (value.length > 12) {
          return (
            <div className="tooltip">
              <span>{value.slice(0, 12)}...</span>
              <span className="tooltip-text">{value}</span>
            </div>
          );
        }
        return value;
      },
    },
    {
      header: "PHONE NUMBER",
      accessor: "Clinic_Contact_Number",
      cell: (value: string) => value || "-",
    },
    {
      header: "EMAIL",
      accessor: "Clinic_email",
      cell: (value: string) => value || "-",
    },
    {
      header: "REGISTRATION DATE",
      accessor: "Created_date",
      cell: (value: string) => formatDate(value),
    },
    {
      header: "STATUS",
      accessor: "is_Verified",
      cell: (value: string) => (
        <StatusBadge status={value as "Active" | "Inactive" | "Pending"} />
      ),
    },
    {
      header: "ACTION",
      accessor: "Clinic_id",
      cell: (value: string, row: any) => (
        <button
          className="view-button"
          onClick={(e) => {
            e.stopPropagation();
            handleViewDetails(row, "clinic");
          }}
        >
          View
        </button>
      ),
    },
  ];

  const guestUserColumns = [
    {
      header: "S.NO",
      accessor: "serialNumber",
      cell: (_: string, __: any, rowIndex: number | undefined) => {
        return ((page - 1) * pageSize + (rowIndex ?? 0) + 1).toString();
      },
    },
    {
      header: "ROLE",
      accessor: "doctor_type",
      cell: (value: string) => value || "-",
    },
    {
      header: "USER ID",
      accessor: "user_id",
      cell: (value: string) => value || "-",
    },
    {
      header: "REGISTRATION DATE",
      accessor: "created_date",
      cell: (value: string) => {
        if (!value) return "-";
        return formatDate(value);
      },
    },
  ];

  const handleViewDetails = (item: any, type: "doctor" | "clinic") => {
    if (type === "doctor") {
      setSelectedDoctor(item);
      setShowDoctorDetailsModal(true);
    } else {
      setSelectedItem(item);
      setRejectType(type);
      setShowClinicDetailsModal(true);
    }
  };

  const handleViewClick = (row: any) => {
    console.log("View clicked for row:", row);
  };

  const handleApprove = () => {
    setShowDetailsDialog(false);
    if (rejectType === "doctor") {
      setSuccessMessage("The doctor has been added successfully.");
    } else {
      setSuccessMessage("The clinic has been added successfully.");
    }
    setShowSuccessDialog(true);

    toast({
      title: "Success",
      description:
        rejectType === "doctor"
          ? "The doctor has been approved successfully."
          : "The clinic has been approved successfully.",
    });
  };

  const handleReject = () => {
    setShowDetailsDialog(false);
    setShowReasonDialog(true);
  };

  const handleReasonSubmit = () => {
    setShowReasonDialog(false);
    if (rejectType === "doctor") {
      setCancelMessage("The doctor has been cancelled.");
    } else {
      setCancelMessage("The clinic has been cancelled.");
    }
    setShowCancelDialog(true);
    setReasonText("");

    toast({
      variant: "destructive",
      title: "Rejected",
      description:
        rejectType === "doctor"
          ? "The doctor has been rejected."
          : "The clinic has been rejected.",
    });
  };

  const handleCloseSuccessDialog = () => {
    setShowSuccessDialog(false);
  };

  const handleCloseCancelDialog = () => {
    setShowCancelDialog(false);
  };

  const handleRoleChange = (value: string) => {
    if (value === "all") {
      setRoleId(null);
      setIsVerified(null);
    } else {
      setRoleId(value || null);
      setIsVerified(null);
    }
    setPage(1); // Reset to first page when filter changes
  };

  const handleDateChange = (range: { from: Date | null; to: Date | null }) => {
    setDateRange(range);
    setPage(1); // Reset to first page when filter changes
    console.log("Date range filter applied:", range);
  };

  // When using the data, access the result array
  const mergedClinicData =
    clinicsResponse?.data?.result?.map((clinic) => {
      const correspondingDoctor = usersData?.result?.find(
        (doctor) => doctor.user_id === clinic.user_id
      );
      return {
        ...clinic,
        user_name: correspondingDoctor?.user_name || "N/A",
      };
    }) || [];

  // Frontend filtering for clinic search to ensure phone number search works
  const filteredClinicData = React.useMemo(() => {
    if (activeTab !== "Clinics") {
      return mergedClinicData;
    }

    if (!clinicSearch) {
      return mergedClinicData;
    }

    const searchTerm = clinicSearch.toLowerCase();
    return mergedClinicData.filter((clinic) => {
      return (
        (clinic.Clinic_name || "").toLowerCase().includes(searchTerm) ||
        (clinic.Clinic_Contact_Number || "")
          .toLowerCase()
          .includes(searchTerm) ||
        (clinic.Clinic_email || "").toLowerCase().includes(searchTerm) ||
        (clinic.user_name || "").toLowerCase().includes(searchTerm)
      );
    });
  }, [mergedClinicData, clinicSearch, activeTab]);

  // Frontend pagination for clinics
  const paginatedClinicData = React.useMemo(() => {
    if (activeTab !== "Clinics") {
      return filteredClinicData;
    }

    const startIndex = (page - 1) * pageSize;
    const endIndex = startIndex + pageSize;
    return filteredClinicData.slice(startIndex, endIndex);
  }, [filteredClinicData, page, pageSize, activeTab]);

  const tableData = React.useMemo(() => {
    if (activeTab === "Pending") {
      return usersData?.result || [];
    } else if (activeTab === "Guest Users") {
      return usersData?.result || [];
    } else if (activeTab === "Doctors") {
      return usersData?.result || [];
    } else if (activeTab === "Clinics") {
      return paginatedClinicData;
    }
    return [];
  }, [activeTab, usersData, paginatedClinicData]);

  // Debug logging for clinic search
  console.log("Dashboard Clinic Search Debug:", {
    activeTab,
    clinicSearch,
    clinicStatus,
    dateRange,
    totalResults: clinicsResponse?.data?.count,
    currentPageResults: clinicsResponse?.data?.result?.length,
    filteredResults: filteredClinicData.length,
    paginatedResults: paginatedClinicData.length,
    searchResults: clinicsResponse?.data?.result?.map((clinic) => ({
      name: clinic.Clinic_name,
      phone: clinic.Clinic_Contact_Number,
      email: clinic.Clinic_email,
      owner: (clinic as any).Clinic_Owner || "N/A",
    })),
    apiUrl: `GetAllClincs?search=${clinicSearch}&page=${page}&pageSize=${pageSize}&is_Verified=${clinicStatus}`,
  });

  useEffect(() => {
    // Add tooltip styles to document
    const styleSheet = document.createElement("style");
    styleSheet.innerText = tooltipStyles;
    document.head.appendChild(styleSheet);

    return () => {
      document.head.removeChild(styleSheet);
    };
  }, []);

  // Move tableData definition after all clinic data processing

  useEffect(() => {
    if (usersError) {
      console.error("Error fetching users:", usersError);
    }
  }, [usersError]);

  useEffect(() => {
    if (usersData) {
      console.log("Users data received:", usersData);
    }
  }, [usersData]);

  // Add debounce function to prevent too many API calls
  const debounce = <T extends (...args: any[]) => any>(
    func: T,
    delay: number
  ) => {
    let timeoutId: NodeJS.Timeout;
    return (...args: Parameters<T>) => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        func(...args);
      }, delay);
    };
  };

  // Handle search input change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchUser(value);
    // Reset to first page when searching
    setPage(1);
  };

  // Debounced search handler
  const debouncedSearch = React.useCallback(
    debounce((value: string) => {
      setSearchUser(value);
      setPage(1);
    }, 300), // 300ms delay
    []
  );

  // Add new state for clinic search
  // const [clinicSearch, setClinicSearch] = useState("");

  // Update the useEffect to handle verification status (removed totalClinicsCount setting)
  useEffect(() => {
    console.log("Current clinicStatus:", clinicStatus);
    console.log("Clinics Response:", clinicsResponse);
    // Removed setTotalClinicsCount from here to prevent overriding the correct total count
  }, [clinicsResponse?.data?.count, clinicStatus]);

  // Get all users data (without verification filter) - with date range
  const { data: allUsersData } = useAllUsers(
    1,
    1,
    "",
    "",
    dateRange.from,
    undefined,
    dateRange.to
  );

  // Get guest users data for count - with date range
  const { data: guestUsersData } = useAllUsers(
    1,
    10,
    "",
    "7", // role_id for guest users
    dateRange.from,
    undefined, // No verification filter for guest users
    dateRange.to
  );

  // Get pending users data for count - with date range
  const { data: pendingUsersData } = useAllUsers(
    1,
    10,
    "",
    "0", // role_id for pending users
    dateRange.from,
    "Pending", // verification filter for pending users
    dateRange.to
  );

  // Get total doctors count (all approved doctors) - with date range
  const { data: totalDoctorsData } = useAllUsers(
    1,
    10,
    "",
    null, // No role filter to get all doctors
    dateRange.from,
    "Approved", // verification filter for approved doctors
    dateRange.to
  );

  // Get doctors data for count - with date range (filtered by selected role)
  const { data: doctorsData } = useAllUsers(
    1,
    10,
    "",
    roleId, // Use selected role (null for all types)
    dateRange.from,
    "Approved", // verification filter for approved doctors
    dateRange.to
  );

  // Update pending users count
  useEffect(() => {
    if (pendingUsersData?.count !== undefined) {
      setPendingUsersCount(pendingUsersData.count);
    }
  }, [pendingUsersData?.count]);

  useEffect(() => {
    if (allUsersData?.count !== undefined) {
      setTotalUsersCount(allUsersData.count);
    }
  }, [allUsersData?.count]);

  useEffect(() => {
    if (guestUsersData?.count !== undefined) {
      setGuestUsersCount(guestUsersData.count);
    }
  }, [guestUsersData?.count]);

  useEffect(() => {
    // Show filtered count when a specific role is selected, otherwise show total count
    if (roleId && doctorsData?.count !== undefined) {
      setDoctorsCount(doctorsData.count);
    } else if (!roleId && totalDoctorsData?.count !== undefined) {
      setDoctorsCount(totalDoctorsData.count);
    }
  }, [doctorsData?.count, totalDoctorsData?.count, roleId]);

  // Set initial doctors count from overview stats only when no date range is applied
  useEffect(() => {
    if (
      dashboardStats?.Total_Doctors !== undefined &&
      doctorsCount === 0 &&
      !dateRange.from &&
      !dateRange.to
    ) {
      setDoctorsCount(dashboardStats.Total_Doctors);
    }
  }, [
    dashboardStats?.Total_Doctors,
    doctorsCount,
    dateRange.from,
    dateRange.to,
  ]);

  // Reset doctors count when date range changes to ensure it reflects filtered data
  useEffect(() => {
    // When date range is applied, the count will be updated by the doctorsData/totalDoctorsData useEffect above
    // This ensures the count reflects the actual filtered data
    if (dateRange.from || dateRange.to) {
      // The count will be updated by the existing useEffect that watches doctorsData?.count and totalDoctorsData?.count
    }
  }, [dateRange.from, dateRange.to]);

  // Add debug logging for tab changes
  useEffect(() => {
    console.log("Active Tab Changed to:", activeTab);
    if (activeTab === "Pending") {
      setIsVerified("Pending");
      setRoleId("0");
      setClinicStatus("Pending");
    } else if (activeTab === "Guest Users") {
      setIsVerified(null); // No verification filter for guest users
      setRoleId("7");
      setClinicStatus(undefined);
    } else if (activeTab === "Doctors") {
      setIsVerified("Approved");
      setRoleId(null); // Reset to null to show total count
      setClinicStatus(undefined);
    } else if (activeTab === "Clinics") {
      setIsVerified(null);
      setRoleId(null);
      setClinicStatus(undefined);
    }

    // Reset search and date range when changing tabs
    setSearchUser("");
    setClinicSearch("");
    setDateRange({ from: null, to: null });
    setPage(1);
  }, [activeTab]);

  // Update the useEffect for total clinics count
  useEffect(() => {
    if (allClinicsData?.data?.count !== undefined) {
      // Always set the total clinics count from allClinicsData
      setTotalClinicsCount(allClinicsData.data.count);
    }
  }, [allClinicsData?.data?.count]);

  return (
    <div className="max-w-[100vw] overflow-hidden">
      <div className="space-y-8">
        <h1 className="text-2xl font-bold text-gray-800">Overview</h1>
        {/* Existing StatCard section */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard
            title="Total Clinics"
            value={totalClinicsCount}
            icon={statIcons.clinic}
            isLoading={isLoading}
          />
          <StatCard
            title="Total MDS"
            value={dashboardStats?.Total_MDS ?? 0}
            icon={statIcons.mds}
            isLoading={isLoading}
          />
          <StatCard
            title="Total BDS"
            value={dashboardStats?.Total_BDS ?? 0}
            icon={statIcons.bds}
            isLoading={isLoading}
          />
          <StatCard
            title="Total Doctors"
            value={doctorsCount}
            icon={statIcons.revenue}
            isLoading={isLoading}
          />
        </div>
        <div className="space-y-6 w-full">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <h2 className="text-xl font-bold text-gray-800"></h2>
            <div className="flex flex-wrap gap-4 items-center">
              {activeTab !== "Guest Users" && (
                <div className="relative">
                  <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    placeholder={
                      activeTab === "Pending" || activeTab === "Doctors"
                        ? "Search By Name, Phone "
                        : "Search By Name, Phone  "
                    }
                    className="pl-10 pr-4 py-2 border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={activeTab === "Clinics" ? clinicSearch : searchUser}
                    onChange={(e) => {
                      if (activeTab === "Clinics") {
                        setClinicSearch(e.target.value);
                      } else {
                        setSearchUser(e.target.value);
                        debouncedSearch(e.target.value);
                      }
                    }}
                  />
                </div>
              )}

              {/* Add DatePickerWithRange for all tabs */}
              <DatePickerWithRange
                onDateChange={handleDateChange}
                value={dateRange}
              />

              {activeTab === "Doctors" && (
                <SelectDropdown
                  label="Select Doctor Type"
                  className="w-36"
                  value={roleId || "all"}
                  options={[
                    { value: "all", label: "All Types" },
                    { value: "1", label: "MDS Doctor" },
                    { value: "2", label: "BDS Doctor" },
                  ]}
                  onChange={handleRoleChange}
                />
              )}

              <Button
                variant="outline"
                className="flex items-center gap-2"
                onClick={handleExport}
              >
                <Download className="h-4 w-4" />
                Export
              </Button>
            </div>
          </div>

          <div className="flex space-x-4 overflow-x-auto pb-2">
            <TabButton
              label={`Guest Users(${guestUsersCount})`}
              active={activeTab === "Guest Users"}
              onClick={() => setActiveTab("Guest Users")}
            />
            <TabButton
              label={`Unregistered Users(${pendingUsersCount})`}
              active={activeTab === "Pending"}
              onClick={() => setActiveTab("Pending")}
            />
            <TabButton
              label={`Doctors(${doctorsCount})`}
              active={activeTab === "Doctors"}
              onClick={() => setActiveTab("Doctors")}
            />
            <TabButton
              label={
                isLoadingClinicCount
                  ? "Clinics(loading...)"
                  : `Clinics(${allClinicsData?.data?.count || 0})`
              }
              active={activeTab === "Clinics"}
              onClick={() => setActiveTab("Clinics")}
            />
          </div>

          <div className="block md:hidden mb-4">
            <SelectDropdown
              label="Select Date Range"
              value=""
              options={[]}
              onChange={() => {}}
            />
          </div>

          <div className="w-full overflow-hidden">
            <DataTable
              columns={
                activeTab === "Clinics"
                  ? clinicColumns
                  : activeTab === "Pending"
                  ? unregisteredClinicColumns
                  : activeTab === "Guest Users"
                  ? guestUserColumns
                  : doctorColumns
              }
              data={tableData}
              onRowClick={handleViewClick}
              isLoading={
                activeTab === "Clinics" ? isLoadingClinics : isLoadingUsers
              }
              pagination={{
                currentPage: page,
                totalPages: Math.ceil(
                  (activeTab === "Clinics"
                    ? filteredClinicData.length
                    : usersData?.count || 0) / pageSize
                ),
                pageSize: pageSize,
                totalItems:
                  activeTab === "Clinics"
                    ? filteredClinicData.length
                    : usersData?.count || 0,
                onPageChange: setPage,
                onPageSizeChange: (newPageSize) => {
                  setPageSize(newPageSize);
                  setPage(1);
                },
              }}
            />
          </div>
        </div>
        <Dialog>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="text-xl font-bold flex justify-between items-center">
                <span>Details</span>
              </DialogTitle>
            </DialogHeader>

            {/* Doctor Details View */}
            {selectedItem && rejectType === "doctor" && (
              <div className="space-y-6 py-4">
                <div className="flex gap-4 items-center">
                  <div className="h-20 w-20 bg-blue-900 rounded-full flex items-center justify-center text-white text-2xl font-bold">
                    {selectedItem.user_name?.charAt(0)}
                  </div>
                  <h3 className="text-xl font-medium">
                    {selectedItem.user_name || "Doctor Name"}
                  </h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="flex items-center gap-3">
                    <div className="bg-blue-900 rounded-full p-2">
                      <Phone className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <p className="text-gray-500 text-sm">Phone Number</p>
                      <p className="font-medium">
                        {selectedItem.phoneNumber || "+91 9123456789"}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="bg-blue-900 rounded-full p-2">
                      <Calendar className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <p className="text-gray-500 text-sm">Passed out Year</p>
                      <p className="font-medium">2024</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="bg-blue-900 rounded-full p-2">
                      <Briefcase className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <p className="text-gray-500 text-sm">Up to work for</p>
                      <p className="font-medium">
                        {selectedItem.work_type || "Full-Time"}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="bg-blue-900 rounded-full p-2">
                      <FileText className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <p className="text-gray-500 text-sm">Experience</p>
                      <p className="font-medium">
                        {selectedItem.experience || "2 Years"}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="bg-blue-900 rounded-full p-2">
                      <Mail className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <p className="text-gray-500 text-sm">Email Address</p>
                      <p className="font-medium">
                        {selectedItem.user_email || "doctor@gmail.com"}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    {/* <div className="bg-blue-900 rounded-full p-2"> */}
                    {/* <StatusBadge status={selectedItem.is_Verified || "Pending"} /> */}
                    {/* </div> */}
                    <div className="p-2">
                      <p className="text-gray-500 text-sm ">Status</p>
                      <p className="font-medium">
                        {selectedItem.is_Verified || "Pending"}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Clinic Details View */}
            {selectedItem && rejectType === "clinic" && (
              <div className="space-y-6 py-4">
                <div className="flex gap-4 items-center">
                  <div className="h-20 w-20 bg-blue-900 rounded-full flex items-center justify-center text-white text-2xl font-bold">
                    {selectedItem.Clinic_name?.charAt(0).toUpperCase()}
                  </div>
                  <h3 className="text-xl font-medium">
                    {selectedItem.Clinic_name || "Clinic Name"}
                  </h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="flex items-center gap-3">
                    <div className="bg-blue-900 rounded-full p-2">
                      <FileText className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <p className="text-gray-500 text-sm">Owner Name</p>
                      <p className="font-medium">
                        {selectedItem.user_name || "Owner Name"}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="bg-blue-900 rounded-full p-2">
                      <Phone className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <p className="text-gray-500 text-sm">Phone Number</p>
                      <p className="font-medium">
                        {selectedItem.Clinic_Contact_Number || "+91 9123456789"}
                      </p>
                    </div>
                  </div>
                  {/* 
                <div className="flex items-center gap-3">
                  <div className="bg-blue-900 rounded-full p-2">
                    <Mail className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <p className="text-gray-500 text-sm">Email Address</p>
                    <p className="font-medium">
                      {selectedItem.user_email || "doctor@gmail.com"}
                    </p>
                  </div>
                </div> */}

                  <div className="flex items-center gap-3">
                    <div>
                      <p className="text-gray-500 text-sm ml-8">Status</p>
                      <p className="font-medium ml-8">
                        {selectedItem.is_Verified || "Pending"}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="bg-blue-900 rounded-full p-2">
                      <MapPin className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <p className="text-gray-500 text-sm">Address</p>
                      <p className="font-medium">
                        {selectedItem.clinic_Address || "Madhapur"}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
        {/* Success Dialog */}
        <AlertDialog
          open={showSuccessDialog}
          onOpenChange={handleCloseSuccessDialog}
        >
          <AlertDialogContent className="max-w-md text-center py-10">
            <div className="flex flex-col items-center gap-4">
              <div className="h-24 w-24 rounded-full bg-green-100 flex items-center justify-center">
                <div className="h-16 w-16 rounded-full border-4 border-green-500 flex items-center justify-center">
                  <Check className="h-8 w-8 text-green-500" />
                </div>
              </div>
              <AlertDialogTitle className="text-2xl font-bold text-green-500">
                Sent
              </AlertDialogTitle>
              <AlertDialogDescription className="text-gray-600 text-lg">
                {successMessage}
              </AlertDialogDescription>
            </div>
          </AlertDialogContent>
        </AlertDialog>
        {/* Cancel Dialog */}
        <AlertDialog
          open={showCancelDialog}
          onOpenChange={handleCloseCancelDialog}
        >
          <AlertDialogContent className="max-w-md text-center py-10">
            <div className="flex flex-col items-center gap-4">
              <AlertDialogTitle className="text-2xl font-bold text-red-500">
                Cancel
              </AlertDialogTitle>
              <AlertDialogDescription className="text-gray-600 text-lg">
                {cancelMessage}
              </AlertDialogDescription>
            </div>
          </AlertDialogContent>
        </AlertDialog>
        {/* Rejection Reason Dialog */}
        <Dialog open={showReasonDialog} onOpenChange={setShowReasonDialog}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Enter the Rejection Reason</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <p className="text-gray-500">Description</p>
                <Textarea
                  className="w-full min-h-[200px] border border-gray-200 rounded-md p-4 outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Type here"
                  value={reasonText}
                  onChange={(e) => setReasonText(e.target.value)}
                />
              </div>
              <div className="flex justify-center pt-4">
                <Button
                  className="bg-orange-400 hover:bg-orange-500 text-white px-10"
                  onClick={handleReasonSubmit}
                >
                  Submit
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>{" "}
        {selectedDoctor && (
          <ReadOnlyDoctorDetailsModal
            isOpen={showDoctorDetailsModal}
            onClose={() => setShowDoctorDetailsModal(false)}
            doctor={selectedDoctor}
          />
        )}
        {selectedItem && rejectType === "clinic" && (
          <ReadOnlyClinicDetailsModal
            isOpen={showClinicDetailsModal}
            onClose={() => setShowClinicDetailsModal(false)}
            clinic={selectedItem}
          />
        )}
      </div>
    </div>
  );
};

export default Dashboard;
