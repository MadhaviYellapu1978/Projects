import React, { useState, useEffect } from "react";
import {
  usePostEvent,
  useAllEvents,
  useAllCourseCategories,
  useUploadImage,
  useDeleteEvent,
} from "@/services/api";
import { toast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import {
  Eye,
  X,
  Plus,
  Search,
  MoreVertical,
  Check,
  XCircle,
  ExternalLink,
  FileText,
  Clock,
  IndianRupee,
  Trash,
  Trash2,
  Upload,
  File,
} from "lucide-react";
import axios from "axios";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import TablePagination from "@/components/ui/TablePagination";
import deleteicon from "../../public/lovable-uploads/delete bg.svg";

import { useQueryClient } from "@tanstack/react-query";
import { baseURL } from "@/services/axios";

interface CourseCategory {
  id: number;
  name: string;
}

interface FormData {
  courseTitle: string;
  courseDuration: string;
  courseLink: string;
  isPaid: boolean;
  price: string;
  courseCategory: string;
  image: File | null;
  thumbnail: File | null;
  aboutCourse: string;
}

const initialFormState: FormData = {
  courseTitle: "",
  courseDuration: "",
  courseLink: "",
  isPaid: false,
  price: "0",
  courseCategory: "",
  image: null,
  thumbnail: null,
  aboutCourse: "",
};

interface FormErrors {
  courseTitle?: string;
  courseDuration?: string;
  courseLink?: string;
  price?: string;
  courseCategory?: string;
  image?: string;
  thumbnail?: string;
  aboutCourse?: string;
}

/**
 * Courses component that manages course listings, creation, and approval workflows
 * @returns Courses page component
 */
function Courses() {
  const { mutate: deleteEvent } = useDeleteEvent();
  const { mutate: postEvent } = usePostEvent();
  const { data: categories } = useAllCourseCategories();
  const { mutate: uploadImage } = useUploadImage();
  const [isLoading, setIsLoading] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [image, setImage] = useState<File | null>(null);
  const [thumbnail, setThumbnail] = useState<File | null>(null);
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const thumbnailInputRef = React.useRef<HTMLInputElement>(null);
  const [courseCategories, setCourseCategories] = useState<CourseCategory[]>([
    { id: 0, name: "ALL" },
    { id: 1, name: "GENERAL DENTISTRY" },
    { id: 2, name: "ENDODONTICS" },
    { id: 3, name: "PROSTHODONTICS" },
    { id: 4, name: "ORTHODONTICS" },
    { id: 5, name: "PERIODONTICS" },
    { id: 6, name: "PEDODONTICS" },
    { id: 7, name: "ORAL PATHOLOGY" },
    { id: 8, name: "OMR" },
    { id: 9, name: "OMFS" },
  ]);
  const [pageConfig, setPageConfig] = useState({
    page: 1,
    pageSize: 10,
    event_type_id: 4, // Courses event type ID
  });

  const { data: coursesData, refetch: refetchCourses } = useAllEvents(
    pageConfig.page,
    pageConfig.pageSize,
    pageConfig.event_type_id,
    searchQuery,
    true
  );

  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState<FormErrors>({});
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [showStatusDialog, setShowStatusDialog] = useState(false);
  const [showReasonDialog, setShowReasonDialog] = useState(false);
  const [reasonError, setReasonError] = useState("");
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [courseToDelete, setCourseToDelete] = useState(null);
  const queryClient = useQueryClient();
  const courses = coursesData?.result || [];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setImage(e.target.files[0]);
      setFormData((prevData) => ({ ...prevData, image: e.target.files[0] }));
    }
  };

  const handleThumbnailUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setThumbnail(e.target.files[0]);
      setFormData((prevData) => ({
        ...prevData,
        thumbnail: e.target.files[0],
      }));
    }
  };

  const validateForm = (data: FormData): FormErrors => {
    const errors: FormErrors = {};

    if (!data.courseTitle.trim()) {
      errors.courseTitle = "Course title is required";
    }

    if (!data.courseDuration.trim()) {
      errors.courseDuration = "Course duration is required";
    }

    if (!data.courseLink.trim()) {
      errors.courseLink = "Course link is required";
    } else if (!isValidUrl(data.courseLink)) {
      errors.courseLink = "Please enter a valid URL";
    }

    if (data.isPaid && !data.price.trim()) {
      errors.price = "Price is required for paid courses";
    } else if (data.isPaid && Number(data.price) <= 0) {
      errors.price = "Price must be greater than 0 for paid courses";
    }

    if (!data.courseCategory.trim()) {
      errors.courseCategory = "Course category is required";
    }

    if (!data.aboutCourse.trim()) {
      errors.aboutCourse = "About course is required";
    } else if (data.aboutCourse.trim().length < 10) {
      errors.aboutCourse = "About course must be at least 10 characters";
    }

    if (!data.image) {
      errors.image = "Course image is required";
    } else {
      const supportedFormats = ["image/jpeg", "image/png", "image/jpg"];
      if (!supportedFormats.includes(data.image.type)) {
        errors.image = "Only JPG, PNG and JPEG files are accepted";
      } else if (data.image.size > 5 * 1024 * 1024) {
        errors.image = "File size is too large (max 5MB)";
      }
    }

    if (!data.thumbnail) {
      errors.thumbnail = "Course thumbnail is required";
    } else {
      const supportedFormats = ["image/jpeg", "image/png", "image/jpg"];
      if (!supportedFormats.includes(data.thumbnail.type)) {
        errors.thumbnail = "Only JPG, PNG and JPEG files are accepted";
      } else if (data.thumbnail.size > 5 * 1024 * 1024) {
        errors.thumbnail = "File size is too large (max 5MB)";
      }
    }

    return errors;
  };

  const isValidUrl = (url: string) => {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const errors = validateForm(formData);
    setErrors(errors);

    if (Object.keys(errors).length === 0) {
      setIsLoading(true);
      try {
        const userRole = localStorage.getItem("roleName");
        const userId = localStorage.getItem("userId");
        const status = userRole === "Super Admin" ? "Approved" : "Pending";

        if (!userId) {
          toast({
            title: "Error",
            description: "User ID not found. Please login again.",
            variant: "destructive",
          });
          setIsLoading(false);
          return;
        }

        // Handle image upload
        let imageUrl = "";
        let thumbnailUrl = "";

        if (formData.image) {
          try {
            const response = await new Promise<{ data: { image: string } }>(
              (resolve, reject) => {
                uploadImage(
                  { image: formData.image, user_id: userId },
                  {
                    onSuccess: (data) => resolve(data),
                    onError: (error) => reject(error),
                  }
                );
              }
            );
            imageUrl = response.data.image;
          } catch (error) {
            toast({
              title: "Error",
              description: "Failed to upload image. Please try again.",
              variant: "destructive",
            });
            setIsLoading(false);
            return;
          }
        }

        // Handle thumbnail upload
        if (formData.thumbnail) {
          try {
            const response = await new Promise<{ data: { image: string } }>(
              (resolve, reject) => {
                uploadImage(
                  { image: formData.thumbnail, user_id: userId },
                  {
                    onSuccess: (data) => resolve(data),
                    onError: (error) => reject(error),
                  }
                );
              }
            );
            thumbnailUrl = response.data.image;
          } catch (error) {
            toast({
              title: "Error",
              description: "Failed to upload thumbnail. Please try again.",
              variant: "destructive",
            });
            setIsLoading(false);
            return;
          }
        }

        const eventData = {
          course_title: formData.courseTitle,
          course_duration: formData.courseDuration,
          course_preview: formData.courseLink,
          course_category: formData.courseCategory,
          price: formData.isPaid ? Number(formData.price) : 0,
          is_paid: formData.isPaid,
          name: formData.courseTitle,
          is_admin: true,
          event_type: {
            event_type_id: 4,
            event_type_name: "Courses",
          },
          Phone_number: "",
          Email: "",
          description: formData.aboutCourse,
          image: imageUrl,
          thumbnail: thumbnailUrl,
          start_date: new Date().toISOString().split("T")[0],
          end_date: new Date().toISOString().split("T")[0],
          start_time: "00:00",
          end_time: "23:59",
          event_lat: 0,
          event_long: 0,
          event_address: "Online",
          pricingmode: formData.isPaid ? "paid" : "free",
          status: status,
        };

        postEvent(eventData, {
          onSuccess: () => {
            toast({
              title: "Success",
              description: `Course ${
                status === "Approved"
                  ? "posted and approved"
                  : "posted and pending approval"
              }`,
            });
            setIsModalOpen(false);
            resetFormState();
            setIsLoading(false);
          },
          onError: (error: any) => {
            const errorMessage =
              error?.response?.data?.message ||
              error?.message ||
              "Failed to post course. Please try again.";
            toast({
              title: "Error",
              description: errorMessage,
              variant: "destructive",
            });
            setIsLoading(false);
          },
        });
      } catch (error: any) {
        const errorMessage =
          error?.response?.data?.message ||
          error?.message ||
          "Failed to post course. Please try again.";
        toast({
          title: "Error",
          description: errorMessage,
          variant: "destructive",
        });
        setIsLoading(false);
      }
    }
  };

  const handleApprove = async () => {
    if (!selectedCourse) return;

    try {
      const userId = localStorage.getItem("userId");
      if (!userId) {
        toast({
          title: "Error",
          description: "User ID not found. Please login again.",
          variant: "destructive",
        });
        return;
      }

      await axios.post(`${baseURL}/postVerifiedEvent`, null, {
        params: {
          event_id: selectedCourse.event_id,
          status: "Approved",
          body: "Course approved",
          user_id: userId,
        },
      });

      toast({
        title: "Success",
        description: "Course has been approved successfully",
      });
      setShowStatusDialog(false);
      setSelectedCourse(null);
      await refetchCourses();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to approve course",
        variant: "destructive",
      });
    }
  };

  const handleReject = async (reason: string) => {
    if (!selectedCourse) return;

    try {
      const userId = localStorage.getItem("userId");
      if (!userId) {
        toast({
          title: "Error",
          description: "User ID not found. Please login again.",
          variant: "destructive",
        });
        return;
      }

      await axios.post(`${baseURL}/postVerifiedEvent`, null, {
        params: {
          event_id: selectedCourse.event_id,
          status: "Reject",
          body: reason,
          user_id: userId,
        },
      });

      toast({
        title: "Success",
        description: "Course has been rejected",
      });
      setShowReasonDialog(false);
      setShowStatusDialog(false);
      setSelectedCourse(null);
      await refetchCourses();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to reject course",
        variant: "destructive",
      });
    }
  };

  const handleCloseStatusDialog = () => {
    setShowStatusDialog(false);
    setSelectedCourse(null);
  };

  const handleOpenReasonDialog = () => {
    setShowReasonDialog(true);
  };

  const handleRejectSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const reason = formData.get("reason") as string;

    // Validate reason - minimum 100 alphabets
    const alphabeticCount = (reason.match(/[a-zA-Z]/g) || []).length;

    if (alphabeticCount < 3) {
      setReasonError(
        "Rejection reason must contain at least 3 alphabetic characters."
      );
      return;
    }

    setReasonError("");
    handleReject(reason);
  };

  const resetFormState = () => {
    setFormData(initialFormState);
    setErrors({});
    setImage(null);
    setThumbnail(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
    if (thumbnailInputRef.current) {
      thumbnailInputRef.current.value = "";
    }
    return undefined;
  };

  return (
    <div className="container mx-auto p-6 space-y-8">
      <div className="flex flex-col space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">Course Management</h1>
        <p className="text-muted-foreground">
          Create, view and manage course listings
        </p>
      </div>

      <div className="flex flex-col lg:flex-row justify-between gap-4">
        <div className="flex items-center gap-2 w-full lg:w-auto">
          <div className="relative flex-1 min-w-[400px]">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by Course Title, Category"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 w-full"
            />
            {searchQuery && (
              <Button
                variant="ghost"
                size="sm"
                className="absolute right-0 top-0 h-full rounded-l-none"
                onClick={() => setSearchQuery("")}
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
        <Button
          onClick={() => setIsModalOpen(true)}
          className="w-full lg:w-auto"
        >
          <Plus className="mr-2 h-4 w-4" /> Add New Course
        </Button>
      </div>

      {!coursesData?.result ? (
        <Card>
          <CardContent className="pt-6">
            <div className="space-y-2">
              {[1, 2, 3, 4, 5].map((item) => (
                <Skeleton key={item} className="w-full h-12" />
              ))}
            </div>
          </CardContent>
        </Card>
      ) : courses.length > 0 ? (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12 text-center">S.No</TableHead>
                  <TableHead>Course Title</TableHead>
                  <TableHead>Preview</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead>Price</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {courses.map((course, index) => (
                  <TableRow key={course.event_id}>
                    <TableCell className="text-center font-medium">
                      {(pageConfig.page - 1) * pageConfig.pageSize + index + 1}
                    </TableCell>
                    <TableCell>
                      <div className="font-medium">{course.course_title}</div>
                      {/* <div className="text-sm text-muted-foreground">
                          {course.name} course_preview
                        </div> */}
                    </TableCell>

                    <TableCell>
                      <a
                        href={course.course_preview}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:underline"
                      >
                        Visit
                      </a>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">
                        {course.course_category || "N/A"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <Clock className="h-3 w-3 mr-1" />
                        {course.course_duration}
                      </div>
                    </TableCell>
                    <TableCell>
                      {course.price == "0" ? (
                        <Badge variant="secondary">Free</Badge>
                      ) : (
                        <div className="flex items-center">
                          ₹{course.price || 0}
                        </div>
                      )}
                    </TableCell>
                    <TableCell className="max-w-[200px] truncate">
                      {course.description}
                    </TableCell>
                    <TableCell>
                      <div
                        onClick={() => {
                          setSelectedCourse(course);
                          setShowStatusDialog(true);
                        }}
                        className="cursor-pointer"
                      >
                        <Badge
                          variant={
                            course.status === "Approved"
                              ? "outline"
                              : course.status === "Reject"
                              ? "destructive"
                              : "secondary"
                          }
                          className={
                            course.status === "Approved"
                              ? "bg-green-100 text-green-800 hover:bg-green-200"
                              : course.status === "Reject"
                              ? "bg-red-100 text-red-800 hover:bg-red-200"
                              : ""
                          }
                        >
                          {course.status === "Reject"
                            ? "Rejected"
                            : course.status}
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-red-600 hover:text-red-800 hover:bg-red-100"
                        onClick={() => {
                          setCourseToDelete(course);
                          setShowDeleteDialog(true);
                        }}
                      >
                        <img
                          src={deleteicon}
                          alt="delete"
                          className="h-6 w-6"
                        />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
          <CardFooter className="flex flex-col sm:flex-row items-center justify-between border-t p-4 gap-3">
            <div className="flex flex-col sm:flex-row items-center gap-2 w-full sm:w-auto">
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground whitespace-nowrap">
                  Rows per page:
                </span>
                <Select
                  value={pageConfig.pageSize.toString()}
                  onValueChange={(value) =>
                    setPageConfig((prev) => ({
                      ...prev,
                      pageSize: parseInt(value),
                      page: 1,
                    }))
                  }
                >
                  <SelectTrigger className="h-8 w-[70px]">
                    <SelectValue placeholder={pageConfig.pageSize} />
                  </SelectTrigger>
                  <SelectContent>
                    {[10, 20, 30, 40, 50].map((size) => (
                      <SelectItem key={size} value={size.toString()}>
                        {size}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <span className="text-sm text-muted-foreground mt-1 sm:mt-0">
                {`${(pageConfig.page - 1) * pageConfig.pageSize + 1}-${Math.min(
                  pageConfig.page * pageConfig.pageSize,
                  coursesData?.count || 0
                )} of ${coursesData?.count || 0}`}
              </span>
            </div>
            <div className="w-full sm:w-auto flex justify-end">
              <TablePagination
                currentPage={pageConfig.page}
                pageSize={pageConfig.pageSize}
                totalItems={coursesData?.count || 0}
                onPageChange={(newPage) =>
                  setPageConfig((prev) => ({ ...prev, page: newPage }))
                }
                onPageSizeChange={(newPageSize) =>
                  setPageConfig((prev) => ({
                    ...prev,
                    pageSize: newPageSize,
                    page: 1,
                  }))
                }
                showPageSizeSelector={false}
                showItemRange={false}
                className="m-0 p-0"
              />
            </div>
          </CardFooter>
        </Card>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="rounded-full bg-muted p-4 mb-4">
              <FileText className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold">No courses found</h3>
            <p className="text-sm text-muted-foreground mt-1 mb-4">
              {searchQuery
                ? "No courses match your search criteria"
                : "Create your first course to get started"}
            </p>
            <Button onClick={() => setIsModalOpen(true)}>
              <Plus className="mr-2 h-4 w-4" /> Add New Course
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Add Course Modal */}
      <Dialog
        open={isModalOpen}
        onOpenChange={(open) => {
          if (!open) {
            resetFormState();
          }
          setIsModalOpen(open);
        }}
      >
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Post Course</DialogTitle>
            <DialogDescription>
              Enter course details to post a new course
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 gap-4">
              <div className="space-y-2">
                <Label htmlFor="courseTitle">
                  Course Title <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="courseTitle"
                  name="courseTitle"
                  value={formData.courseTitle}
                  onChange={handleChange}
                  placeholder="Enter course title"
                />
                {errors.courseTitle && (
                  <p className="text-sm text-destructive">
                    {errors.courseTitle}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="courseCategory">
                  Course Category <span className="text-red-500">*</span>
                </Label>
                <Select
                  value={formData.courseCategory}
                  onValueChange={(value) =>
                    setFormData((prev) => ({ ...prev, courseCategory: value }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select course category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories?.map((category) => (
                      <SelectItem key={category.id} value={category.name}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.courseCategory && (
                  <p className="text-sm text-destructive">
                    {errors.courseCategory}
                  </p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="courseDuration">
                  Course Duration <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="courseDuration"
                  name="courseDuration"
                  value={formData.courseDuration}
                  onChange={handleChange}
                  placeholder="e.g. 2 months, 10 weeks"
                />
                {errors.courseDuration && (
                  <p className="text-sm text-destructive">
                    {errors.courseDuration}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="courseLink">
                  Course Link <span className="text-red-500">*</span>
                </Label>
                <div className="relative">
                  <ExternalLink className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="courseLink"
                    name="courseLink"
                    type="url"
                    value={formData.courseLink}
                    onChange={handleChange}
                    className="pl-9"
                    placeholder="https://example.com/course"
                  />
                </div>
                {errors.courseLink && (
                  <p className="text-sm text-destructive">
                    {errors.courseLink}
                  </p>
                )}
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  id="isPaid"
                  checked={formData.isPaid}
                  onCheckedChange={(checked) => {
                    setFormData((prev) => ({
                      ...prev,
                      isPaid: checked,
                      price: checked ? prev.price : "Free",
                    }));
                  }}
                />
                <Label htmlFor="isPaid">Paid Course</Label>
              </div>

              {formData.isPaid && (
                <div className="space-y-2">
                  <Label htmlFor="price">
                    Price (₹) <span className="text-red-500">*</span>
                  </Label>
                  <div className="relative">
                    <IndianRupee className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="price"
                      name="price"
                      type="number"
                      min="1"
                      value={formData.price}
                      onChange={handleChange}
                      className="pl-9"
                      placeholder="Enter price"
                    />
                  </div>
                  {errors.price && (
                    <p className="text-sm text-destructive">{errors.price}</p>
                  )}
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="aboutCourse">
                  About Course <span className="text-red-500">*</span>
                </Label>
                <Textarea
                  id="aboutCourse"
                  name="aboutCourse"
                  value={formData.aboutCourse}
                  onChange={handleChange}
                  placeholder="Enter course description"
                  rows={4}
                  className="resize-none"
                />
                {errors.aboutCourse && (
                  <p className="text-sm text-destructive">
                    {errors.aboutCourse}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="image">
                  Course Image <span className="text-red-500">*</span>
                </Label>
                <div className="relative">
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileUpload}
                    accept="image/jpeg,image/png,image/jpg"
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                  />
                  {image ? (
                    <div className="flex items-center justify-between px-4 py-3 bg-gray-50 border border-gray-200 rounded-md">
                      <div className="flex items-center gap-2">
                        <File className="h-5 w-5 text-primary" />
                        <span className="text-sm truncate max-w-[180px]">
                          {image.name}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setImage(null);
                          setFormData((prev) => ({ ...prev, image: null }));
                          if (fileInputRef.current) {
                            fileInputRef.current.value = "";
                          }
                        }}
                        className="text-gray-500 hover:text-red-500"
                      >
                        <X size={16} />
                      </button>
                    </div>
                  ) : (
                    <div className="flex justify-between items-center px-4 py-3 bg-gray-50 border border-gray-200 rounded-md">
                      <span className="text-gray-500">
                        Upload Image (JPG, PNG)
                      </span>
                      <Upload className="h-5 w-5 text-gray-500" />
                    </div>
                  )}
                </div>
                {errors.image && (
                  <p className="text-sm text-destructive">{errors.image}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="thumbnail">
                  Course Thumbnail <span className="text-red-500">*</span>
                </Label>
                <div className="relative">
                  <input
                    type="file"
                    ref={thumbnailInputRef}
                    onChange={handleThumbnailUpload}
                    accept="image/jpeg,image/png,image/jpg"
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                  />
                  {thumbnail ? (
                    <div className="flex items-center justify-between px-4 py-3 bg-gray-50 border border-gray-200 rounded-md">
                      <div className="flex items-center gap-2">
                        <File className="h-5 w-5 text-primary" />
                        <span className="text-sm truncate max-w-[180px]">
                          {thumbnail.name}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setThumbnail(null);
                          setFormData((prev) => ({ ...prev, thumbnail: null }));
                          if (thumbnailInputRef.current) {
                            thumbnailInputRef.current.value = "";
                          }
                        }}
                        className="text-gray-500 hover:text-red-500"
                      >
                        <X size={16} />
                      </button>
                    </div>
                  ) : (
                    <div className="flex justify-between items-center px-4 py-3 bg-gray-50 border border-gray-200 rounded-md">
                      <span className="text-gray-500">
                        Upload Thumbnail (JPG, PNG)
                      </span>
                      <Upload className="h-5 w-5 text-gray-500" />
                    </div>
                  )}
                </div>
                {errors.thumbnail && (
                  <p className="text-sm text-destructive">{errors.thumbnail}</p>
                )}
              </div>
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setIsModalOpen(false);
                  resetFormState();
                }}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <svg
                      className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      ></circle>
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      ></path>
                    </svg>
                    Posting...
                  </>
                ) : (
                  "Post Course"
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* View Course Modal */}
      <Dialog open={isViewModalOpen} onOpenChange={setIsViewModalOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex justify-between items-center">
              <span>Course Details</span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsViewModalOpen(false)}
              ></Button>
            </DialogTitle>
          </DialogHeader>
          {selectedCourse && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h3 className="font-medium text-gray-700">Course Name</h3>
                  <p className="mt-1">{selectedCourse.name}</p>
                </div>
                <div>
                  <h3 className="font-medium text-gray-700">Course Title</h3>
                  <p className="mt-1">{selectedCourse.course_title}</p>
                </div>
                <div>
                  <h3 className="font-medium text-gray-700">Category</h3>
                  <p className="mt-1">{selectedCourse.course_category}</p>
                </div>
                <div>
                  <h3 className="font-medium text-gray-700">Duration</h3>
                  <p className="mt-1">{selectedCourse.course_duration}</p>
                </div>
                <div>
                  <h3 className="font-medium text-gray-700">Price</h3>
                  <p className="mt-1">
                    {selectedCourse.price === "0"
                      ? "Free"
                      : `₹${selectedCourse.price}`}
                  </p>
                </div>
                <div>
                  <h3 className="font-medium text-gray-700">Status</h3>
                  <p className="mt-1">
                    <Badge
                      variant={
                        selectedCourse.status === "Approved"
                          ? "outline"
                          : selectedCourse.status === "Reject"
                          ? "destructive"
                          : "secondary"
                      }
                    >
                      {selectedCourse.status === "Reject"
                        ? "Rejected"
                        : selectedCourse.status}
                    </Badge>
                  </p>
                </div>
                <div>
                  <h3 className="font-medium text-gray-700">Created By</h3>
                  <p className="mt-1">{selectedCourse.name}</p>
                </div>
              </div>

              <div>
                <h3 className="font-medium text-gray-700">Description</h3>
                <p className="mt-1 whitespace-pre-wrap">
                  {selectedCourse.description}
                </p>
              </div>

              {selectedCourse.course_preview && (
                <div>
                  <h3 className="font-medium text-gray-700">Course Preview</h3>
                  <a
                    href={selectedCourse.course_preview}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:text-blue-800 mt-1 block"
                  >
                    {selectedCourse.course_preview}
                  </a>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h3 className="font-medium text-gray-700">Contact Email</h3>
                  <p className="mt-1">{selectedCourse.Email}</p>
                </div>
                <div>
                  <h3 className="font-medium text-gray-700">Contact Phone</h3>
                  <p className="mt-1">{selectedCourse.Phone_number}</p>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Status Dialog */}
      <Dialog
        open={showStatusDialog}
        onOpenChange={(open) => {
          if (!open) {
            handleCloseStatusDialog();
          }
        }}
      >
        <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
          <DialogHeader className="pb-2 border-b">
            <DialogTitle className="text-2xl">
              {selectedCourse?.course_title}
            </DialogTitle>
            <div className="mt-1">
              <Badge
                variant={
                  selectedCourse?.status === "Approved"
                    ? "outline"
                    : selectedCourse?.status === "Reject"
                    ? "destructive"
                    : "secondary"
                }
                className={
                  selectedCourse?.status === "Approved"
                    ? "bg-green-100 text-green-800 hover:bg-green-200"
                    : selectedCourse?.status === "Reject"
                    ? "bg-red-100 text-red-800 hover:bg-red-200"
                    : ""
                }
              >
                {selectedCourse?.status === "Reject"
                  ? "Rejected"
                  : selectedCourse?.status}
              </Badge>
            </div>
          </DialogHeader>

          <StatusDialogContent
            course={selectedCourse}
            onClose={handleCloseStatusDialog}
            onReject={handleOpenReasonDialog}
            onApprove={handleApprove}
          />
        </DialogContent>
      </Dialog>

      {/* Rejection Reason Dialog */}
      <Dialog
        open={showReasonDialog}
        onOpenChange={(open) => {
          if (!open) {
            setShowReasonDialog(false);
            setReasonError("");
          }
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject Course</DialogTitle>
            <DialogDescription>
              Please provide a detailed reason for rejection (minimum 100
              alphabetic characters)
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleRejectSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="reason">Reason for Rejection</Label>
              <Textarea
                id="reason"
                name="reason"
                rows={6}
                placeholder="Please provide a detailed explanation for why this course is being rejected. Be specific about the issues and include any suggestions for improvements that would make it acceptable."
                className="resize-none"
                onChange={() => reasonError && setReasonError("")}
              />
              {reasonError && (
                <p className="text-sm font-medium text-destructive">
                  {reasonError}
                </p>
              )}
              <div className="text-xs text-muted-foreground">
                Your rejection reason should be detailed and specific,
                containing at least 3 alphabetic characters.
              </div>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setShowReasonDialog(false);
                  setReasonError("");
                }}
              >
                Cancel
              </Button>
              <Button type="submit" variant="destructive">
                Reject Course
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog
        open={showDeleteDialog}
        onOpenChange={(open) => {
          if (!open) {
            setShowDeleteDialog(false);
            setCourseToDelete(null);
          }
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete the course "
              {courseToDelete?.course_title}"? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setShowDeleteDialog(false);
                setCourseToDelete(null);
              }}
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="destructive"
              onClick={() => {
                if (courseToDelete) {
                  deleteEvent(courseToDelete.event_id, {
                    onSuccess: () => {
                      toast({
                        title: "Success",
                        description: "Course has been deleted",
                      });
                      queryClient.invalidateQueries();
                    },
                  });
                }
                setShowDeleteDialog(false);
                setCourseToDelete(null);
              }}
            >
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

const StatusDialogContent = ({ course, onClose, onReject, onApprove }) => {
  if (!course) return null;
  const role = localStorage.getItem("roleName");

  return (
    <div className="py-4">
      <div className="space-y-6">
        {/* Course Information */}
        <div>
          <h3 className="text-lg font-medium mb-3 text-primary/80">
            Course Information
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">Course Title</p>
              <p className="font-medium">{course.course_title}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Category</p>
              <p className="font-medium">{course.course_category}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Duration</p>
              <p className="font-medium">{course.course_duration}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Price</p>
              <p className="font-medium">
                {course.price == "0" ? "Free" : `₹${course.price}`}
              </p>
            </div>
          </div>
        </div>

        {/* Contact Information */}
        {/* <div>
          <h3 className="text-lg font-medium mb-3 text-primary/80">
            Contact Information
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">Email</p>
              <p className="font-medium">{course.Email}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Phone</p>
              <p className="font-medium">{course.Phone_number}</p>
            </div>
          </div>
        </div> */}

        {/* Course Details */}
        <div>
          <h3 className="text-lg font-medium mb-3 text-primary/80">
            Course Details
          </h3>
          <div>
            <p className="text-sm text-muted-foreground">Description</p>
            <p className="font-medium whitespace-pre-wrap">
              {course.description}
            </p>
          </div>
          {course.course_preview && (
            <div className="mt-4">
              <p className="text-sm text-muted-foreground">Preview Link</p>
              <a
                href={course.course_preview}
                target="_blank"
                rel="noopener noreferrer"
                className="font-medium text-primary hover:underline"
              >
                {course.course_preview}
              </a>
            </div>
          )}
        </div>
      </div>

      <div className="flex justify-end space-x-2 mt-6 pt-4 border-t">
        {course.status === "Pending" && role === "Super Admin" ? (
          <>
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={onReject}>
              Reject
            </Button>
            <Button
              onClick={onApprove}
              className="bg-green-600 hover:bg-green-700"
            >
              Approve
            </Button>
          </>
        ) : (
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
        )}
      </div>
    </div>
  );
};

export default Courses;
