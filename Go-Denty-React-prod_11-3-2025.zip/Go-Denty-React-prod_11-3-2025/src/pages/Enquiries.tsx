import React, { useState, useEffect } from "react";
import { usePostEvent, useAllEvents, useAllEventTypes } from "@/services/api";
import { toast } from "@/hooks/use-toast";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { DatePickerWithRange } from "@/components/ui/date-range";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

import {
  CalendarIcon,
  MapPinIcon,
  BookOpenIcon,
  CheckCircleIcon,
  ClockIcon,
  XCircleIcon,
  SearchIcon,
  // DownloadIcon,
  Eye,
  MoreVertical,
  Check,
  ExternalLink,
  FileText,
  Clock,
  ChevronLeft,
  ChevronRight,
  ChevronFirst,
  ChevronLast,
  Trash2,
} from "lucide-react";
import { addDays, format } from "date-fns";
import { DateRange } from "react-day-picker";
import axios from "axios";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import TablePagination from "@/components/ui/TablePagination";
import editicon from "../../public/lovable-uploads/edit bg.svg";
import deleteicon from "../../public/lovable-uploads/delete bg.svg";
import { baseURL } from "@/services/axios";

/**
 * Interface for Course Enquiry data structure
 */
interface CourseEnquiry {
  id: string;
  name: string;
  email: string;
  phone: string;
  courseName: string;
  date: string;
  status: "pending" | "approved" | "rejected";
}

/**
 * Interface for Event Enquiry data structure
 */
interface EventEnquiry {
  id: string;
  name: string;
  email: string;
  phone: string;
  eventName: string;
  location: string;
  date: string;
  status: "pending" | "approved" | "rejected";
}

/**
 * Interface for Course Category
 */
interface CourseCategory {
  id: number;
  name: string;
}

// Course categories data
const courseCategories: CourseCategory[] = [
  { id: 0, name: "ALL" },
  { id: 1, name: "GENERAL DENTISTRY" },
  { id: 2, name: "ENDODONTICS" },
  { id: 3, name: "PROSTHODONTICS" },
  { id: 4, name: "ORTHODONTICS" },
  { id: 5, name: "PERIODONTICS" },
  { id: 6, name: "PEDODONTICS" },
  { id: 7, name: "ORAL PATHOLOGY" },
  { id: 8, name: "OMR" },
  { id: 9, name: "OMFS" },
];

/**
 * StatusBadge Component - Displays the status of an enquiry with appropriate styling
 */
const StatusBadge = ({ status }: { status: string }) => {
  switch (status) {
    case "approved":
    case "Approved":
      return (
        <Badge
          variant="secondary"
          className="flex items-center gap-1 bg-green-100 text-green-800 border-green-200 w-fit"
        >
          <CheckCircleIcon size={14} />
          Approved
        </Badge>
      );
    case "rejected":
    case "Reject":
      return (
        <Badge variant="destructive" className="flex items-center gap-1 w-fit">
          <XCircleIcon size={14} />
          Rejected
        </Badge>
      );
    default:
      return (
        <Badge variant="outline" className="flex items-center gap-1 w-fit">
          <ClockIcon size={14} />
          Pending
        </Badge>
      );
  }
};

/**
 * FilterBar Component - Handles filtering and search functionality
 */
const FilterBar = ({
  onSearch,
  onCategoryFilter,
  onEventTypeFilter,
  onDateRangeChange,
  showCategoryFilter = false,
  showEventTypeFilter = false,
  showDateRange = true,
  eventTypes = [],
  dateRange,
  activeTab = "workshops",
}: {
  onSearch: (value: string) => void;
  onCategoryFilter?: (value: string) => void;
  onEventTypeFilter?: (value: number) => void;
  onDateRangeChange?: (dateRange: DateRange | undefined) => void;
  showCategoryFilter?: boolean;
  showEventTypeFilter?: boolean;
  showDateRange?: boolean;
  eventTypes?: { event_type_id: number; event_type_name: string }[];
  dateRange?: DateRange | undefined;
  activeTab?: string;
}) => {
  const handleDateChange = (newDate: DateRange | undefined) => {
    onDateRangeChange?.(newDate);
  };

  const getSearchPlaceholder = () => {
    switch (activeTab) {
      case "courses":
        return "Search by Course Title, Category";
      default:
        return "Search by Name, Email, Phone Number";
    }
  };

  return (
    <div className="flex flex-wrap justify-between items-center mb-6 p-4 bg-gray-50 rounded-lg">
      <div className="flex-none w-[400px] min-w-[300px]">
        <div className="relative">
          <SearchIcon
            className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
            size={18}
          />
          <Input
            placeholder={getSearchPlaceholder()}
            className="pl-10"
            onChange={(e) => onSearch(e.target.value)}
          />
        </div>
      </div>

      {showCategoryFilter && onCategoryFilter && (
        <div className="flex-none w-[200px]">
          <Select onValueChange={onCategoryFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Filter by category" />
            </SelectTrigger>
            <SelectContent>
              {courseCategories.map((category) => (
                <SelectItem key={category.id} value={category.id.toString()}>
                  {category.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      {showDateRange && (
        <div className="flex-none w-[300px]">
          <DatePickerWithRange
            value={
              dateRange
                ? { from: dateRange.from, to: dateRange.to }
                : { from: null, to: null }
            }
            onDateChange={handleDateChange}
          />
        </div>
      )}
    </div>
  );
};

/**
 * Parses a date string from DD-MM-YYYY format to a Date object
 * @param dateStr Date string in DD-MM-YYYY format
 * @returns Date object or null if invalid
 */
const parseDateString = (dateStr: string): Date | null => {
  if (!dateStr) return null;
  const [day, month, year] = dateStr.split("-").map(Number);
  if (!day || !month || !year) return null;
  return new Date(year, month - 1, day);
};

/**
 * Formats a date safely with a fallback
 * @param dateStr Date string in DD-MM-YYYY format
 * @returns Formatted date string or fallback text
 */
const formatDateSafely = (dateStr: string): string => {
  if (!dateStr) return "Not specified";
  const date = parseDateString(dateStr);
  if (!date) return "Invalid date";
  const day = date.getDate().toString().padStart(2, "0");
  const month = (date.getMonth() + 1).toString().padStart(2, "0");
  const year = date.getFullYear();
  return `${day}-${month}-${year}`;
};

/**
 * Enquiries Component - Main component for managing enquiries and courses
 */
const Enquiries = () => {
  const [activeTab, setActiveTab] = useState("workshops");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [showStatusDialog, setShowStatusDialog] = useState(false);
  const [showReasonDialog, setShowReasonDialog] = useState(false);
  const [reasonError, setReasonError] = useState("");
  const [selectedEventType, setSelectedEventType] = useState<number | null>(
    null
  );
  const [dateRange, setDateRange] = useState<DateRange | undefined>(undefined);

  const { data: eventTypesData } = useAllEventTypes();

  // Filter out "Courses" from event types
  const filteredEventTypes =
    eventTypesData?.filter((type) => type.event_type_name !== "Courses") || [];

  // Course API integration
  const [pageConfig, setPageConfig] = useState({
    page: 1,
    pageSize: 10,
    event_type_id: 1, // Default to Events event type ID
  });

  // Update event type ID when tab changes
  useEffect(() => {
    let eventTypeId = 1; // Default for general events
    switch (activeTab) {
      case "workshops":
        eventTypeId = 2;
        break;
      case "webinars":
        eventTypeId = 3;
        break;
      case "events":
        eventTypeId = 1;
        break;
      case "courses":
        eventTypeId = 4;
        break;
      default:
        eventTypeId = 2; // Default to workshops
    }

    setPageConfig((prev) => ({
      ...prev,
      event_type_id: eventTypeId,
      page: 1, // Reset to first page when changing tabs
    }));

    // Reset date range and search when changing tabs
    setDateRange(undefined);
    setSearchQuery("");
  }, [activeTab]);

  const { data: coursesData, refetch: refetchCourses } = useAllEvents(
    pageConfig.page,
    pageConfig.pageSize,
    pageConfig.event_type_id,
    searchQuery,
    false, // is_admin is false
    dateRange?.from ? format(dateRange.from, "yyyy-MM-dd") : undefined,
    dateRange?.to ? format(dateRange.to, "yyyy-MM-dd") : undefined
  );

  const handleDateRangeChange = (newDateRange: DateRange | undefined) => {
    setDateRange(newDateRange);
    setPageConfig((prev) => ({ ...prev, page: 1 })); // Reset to first page when date range changes
  };

  const handleEventTypeChange = (eventTypeId: number) => {
    setSelectedEventType(eventTypeId);
    setPageConfig((prev) => ({
      ...prev,
      event_type_id: eventTypeId,
      page: 1, // Reset to first page when changing event type
    }));
  };

  // Course approval/rejection handlers
  const handleApprove = async () => {
    if (!selectedCourse) return;

    try {
      const userId = localStorage.getItem("userId");
      if (!userId) {
        toast({
          title: "Error",
          description: "User ID not found. Please login again.",
          variant: "destructive",
        });
        return;
      }

      await axios.post(`${baseURL}/postVerifiedEvent`, null, {
        params: {
          event_id: selectedCourse.event_id,
          status: "Approved",
          body: "Course approved",
          user_id: userId,
        },
      });

      toast({
        title: "Success",
        description: "Course has been approved successfully",
      });
      setShowStatusDialog(false);
      setSelectedCourse(null);
      await refetchCourses();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to approve course",
        variant: "destructive",
      });
    }
  };

  const handleReject = async (reason: string) => {
    if (!selectedCourse) return;

    try {
      const userId = localStorage.getItem("userId");
      if (!userId) {
        toast({
          title: "Error",
          description: "User ID not found. Please login again.",
          variant: "destructive",
        });
        return;
      }

      await axios.post(`${baseURL}/postVerifiedEvent`, null, {
        params: {
          event_id: selectedCourse.event_id,
          status: "Reject",
          body: reason,
          user_id: userId,
        },
      });

      toast({
        title: "Success",
        description: "Course has been rejected",
      });
      setShowReasonDialog(false);
      setShowStatusDialog(false);
      setSelectedCourse(null);
      await refetchCourses();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to reject course",
        variant: "destructive",
      });
    }
  };

  const handleCloseStatusDialog = () => {
    setShowStatusDialog(false);
    setSelectedCourse(null);
  };

  const handleOpenReasonDialog = () => {
    setShowReasonDialog(true);
  };

  const handleRejectSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const reason = formData.get("reason") as string;

    const alphabeticCount = (reason.match(/[a-zA-Z]/g) || []).length;

    if (alphabeticCount < 3) {
      setReasonError(
        "Rejection reason must contain at least 3 alphabetic characters."
      );
      return;
    }

    setReasonError("");
    handleReject(reason);
  };

  return (
    <div className="container mx-auto py-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Enquiries Management</h1>
        <p className="text-gray-500">
          View and manage all enquiries for events, courses, workshops, and
          webinars
        </p>
      </div>

      <FilterBar
        onSearch={setSearchQuery}
        onEventTypeFilter={handleEventTypeChange}
        onDateRangeChange={handleDateRangeChange}
        showCategoryFilter={activeTab === "courses"}
        showEventTypeFilter={activeTab === "events"}
        showDateRange={activeTab !== "courses"}
        eventTypes={filteredEventTypes}
        dateRange={dateRange}
        activeTab={activeTab}
      />

      <Tabs
        defaultValue="workshops"
        value={activeTab}
        onValueChange={setActiveTab}
        className="w-full"
      >
        <TabsList className="grid w-full grid-cols-4 mb-8">
          <TabsTrigger value="workshops" className="text-base">
            Workshops Enquiries
          </TabsTrigger>
          <TabsTrigger value="webinars" className="text-base">
            Webinars Enquiries
          </TabsTrigger>
          <TabsTrigger value="events" className="text-base">
            Events Enquiries
          </TabsTrigger>
          <TabsTrigger value="courses" className="text-base">
            Courses Enquiries
          </TabsTrigger>
        </TabsList>

        {/* Workshops Tab Content */}
        <TabsContent
          value="workshops"
          className="border rounded-lg p-4 shadow-sm"
        >
          <Table>
            <TableCaption>A list of all workshop enquiries</TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12 text-center">S.NO</TableHead>
                <TableHead>WORKSHOP DETAILS</TableHead>
                <TableHead>CONTACT INFO</TableHead>
                <TableHead className="w-[200px]">DATE & TIME</TableHead>
                <TableHead>LOCATION</TableHead>
                <TableHead>PRICE</TableHead>
                <TableHead>ACTION</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {coursesData?.result ? (
                coursesData.result.map((workshop, index) => (
                  <TableRow key={workshop.event_id}>
                    <TableCell className="text-center font-medium">
                      {(pageConfig.page - 1) * pageConfig.pageSize + index + 1}
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="font-medium">{workshop.name}</div>
                        {/* <div className="text-sm text-muted-foreground">
                          {workshop.event_type_name}
                        </div> */}
                        {workshop.event_website_url && (
                          <a
                            href={workshop.event_website_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs text-blue-600 hover:text-blue-800 flex items-center gap-1"
                          >
                            <ExternalLink size={12} />
                            Website
                          </a>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="text-sm">
                          <span className="text-muted-foreground">Email:</span>{" "}
                          {workshop.Email}
                        </div>
                        <div className="text-sm">
                          <span className="text-muted-foreground">Phone:</span>{" "}
                          {workshop.Phone_number}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex items-center gap-1 text-sm">
                          <CalendarIcon
                            size={14}
                            className="text-muted-foreground"
                          />
                          <span>{formatDateSafely(workshop.start_date)}</span>
                        </div>
                        {workshop.start_time && (
                          <div className="flex items-center gap-1 text-sm">
                            <ClockIcon
                              size={14}
                              className="text-muted-foreground"
                            />
                            <span>
                              {workshop.start_time}
                              {workshop.end_time
                                ? ` - ${workshop.end_time}`
                                : ""}
                            </span>
                          </div>
                        )}
                        {workshop.end_date && (
                          <div className="text-xs text-muted-foreground">
                            Until {formatDateSafely(workshop.end_date)}
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      {workshop.event_address ? (
                        <div className="flex items-start gap-1">
                          <MapPinIcon
                            size={14}
                            className="text-muted-foreground mt-1 shrink-0"
                          />
                          <span className="text-sm">
                            {workshop.event_address}
                          </span>
                        </div>
                      ) : (
                        <span className="text-sm text-muted-foreground">
                          Location not specified
                        </span>
                      )}
                    </TableCell>
                    <TableCell>
                      {workshop.is_paid ? (
                        <div className="flex items-center gap-1">
                          <span>₹{workshop.price}</span>
                        </div>
                      ) : (
                        <Badge variant="secondary">Free</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            const userRole = localStorage.getItem("roleName");
                            if (userRole !== "Event Admin") {
                              setSelectedCourse(workshop);
                              setShowStatusDialog(true);
                            }
                          }}
                          className={
                            localStorage.getItem("roleName") === "Event Admin"
                              ? "opacity-50 cursor-not-allowed"
                              : "hover:bg-gray-100"
                          }
                          disabled={
                            localStorage.getItem("roleName") === "Event Admin"
                          }
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8">
                    <div className="flex flex-col items-center justify-center">
                      <FileText className="h-8 w-8 text-muted-foreground mb-4" />
                      <p className="text-lg font-semibold">
                        No workshops found
                      </p>
                      <p className="text-sm text-muted-foreground mt-1">
                        {searchQuery
                          ? "No workshops match your search criteria"
                          : "No workshops have been submitted yet"}
                      </p>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
          <TablePagination
            currentPage={pageConfig.page}
            pageSize={pageConfig.pageSize}
            totalItems={coursesData?.count || 0}
            onPageChange={(page) =>
              setPageConfig((prev) => ({ ...prev, page }))
            }
            onPageSizeChange={(newPageSize) =>
              setPageConfig((prev) => ({
                ...prev,
                pageSize: newPageSize,
                page: 1,
              }))
            }
          />
        </TabsContent>

        {/* Webinars Tab Content */}
        <TabsContent
          value="webinars"
          className="border rounded-lg p-4 shadow-sm"
        >
          <Table>
            <TableCaption>A list of all webinar enquiries</TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12 text-center">S.NO </TableHead>
                <TableHead>WEBINAR DETAILS</TableHead>
                <TableHead>CONTACT INFO</TableHead>
                <TableHead className="w-[200px]">DATE & TIME</TableHead>
                <TableHead>PLATFORM</TableHead>
                <TableHead>PRICE</TableHead>
                <TableHead>ACTION</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {coursesData?.result ? (
                coursesData.result.map((webinar, index) => (
                  <TableRow key={webinar.event_id}>
                    <TableCell className="text-center font-medium">
                      {(pageConfig.page - 1) * pageConfig.pageSize + index + 1}
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="font-medium">{webinar.name}</div>
                        {/* <div className="text-sm text-muted-foreground">
                          {webinar.event_type_name}
                        </div> */}
                        {webinar.event_website_url && (
                          <a
                            href={webinar.event_website_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs text-blue-600 hover:text-blue-800 flex items-center gap-1"
                          >
                            <ExternalLink size={12} />
                            Website
                          </a>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="text-sm">
                          <span className="text-muted-foreground">Email:</span>{" "}
                          {webinar.Email}
                        </div>
                        <div className="text-sm">
                          <span className="text-muted-foreground">Phone:</span>{" "}
                          {webinar.Phone_number}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex items-center gap-1 text-sm">
                          <CalendarIcon
                            size={14}
                            className="text-muted-foreground"
                          />
                          <span>{formatDateSafely(webinar.start_date)}</span>
                        </div>
                        {webinar.start_time && (
                          <div className="flex items-center gap-1 text-sm">
                            <ClockIcon
                              size={14}
                              className="text-muted-foreground"
                            />
                            <span>
                              {webinar.start_time}
                              {webinar.end_time ? ` - ${webinar.end_time}` : ""}
                            </span>
                          </div>
                        )}
                        {webinar.end_date && (
                          <div className="text-xs text-muted-foreground">
                            Until {formatDateSafely(webinar.end_date)}
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <BookOpenIcon
                          size={14}
                          className="text-muted-foreground"
                        />
                        <span className="text-sm">Online Platform</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {webinar.is_paid ? (
                        <div className="flex items-center gap-1">
                          <span>₹{webinar.price}</span>
                        </div>
                      ) : (
                        <Badge variant="secondary">Free</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            const userRole = localStorage.getItem("roleName");
                            if (userRole !== "Event Admin") {
                              setSelectedCourse(webinar);
                              setShowStatusDialog(true);
                            }
                          }}
                          className={
                            localStorage.getItem("roleName") === "Event Admin"
                              ? "opacity-50 cursor-not-allowed"
                              : "hover:bg-gray-100"
                          }
                          disabled={
                            localStorage.getItem("roleName") === "Event Admin"
                          }
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8">
                    <div className="flex flex-col items-center justify-center">
                      <FileText className="h-8 w-8 text-muted-foreground mb-4" />
                      <p className="text-lg font-semibold">No webinars found</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        {searchQuery
                          ? "No webinars match your search criteria"
                          : "No webinars have been submitted yet"}
                      </p>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
          <TablePagination
            currentPage={pageConfig.page}
            pageSize={pageConfig.pageSize}
            totalItems={coursesData?.count || 0}
            onPageChange={(page) =>
              setPageConfig((prev) => ({ ...prev, page }))
            }
            onPageSizeChange={(newPageSize) =>
              setPageConfig((prev) => ({
                ...prev,
                pageSize: newPageSize,
                page: 1,
              }))
            }
          />
        </TabsContent>

        {/* Events Tab Content */}
        <TabsContent value="events" className="border rounded-lg p-4 shadow-sm">
          <Table>
            <TableCaption>A list of all event enquiries</TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12 text-center">S.NO</TableHead>
                <TableHead>EVENT DETAILS</TableHead>
                <TableHead>CONTACT INFO</TableHead>
                <TableHead className="w-[200px]">DATE & TIME</TableHead>
                <TableHead>LOCATION</TableHead>
                <TableHead>PRICE</TableHead>
                <TableHead>ACTION</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {coursesData?.result ? (
                coursesData.result.map((event, index) => (
                  <TableRow key={event.event_id}>
                    <TableCell className="text-center font-medium">
                      {(pageConfig.page - 1) * pageConfig.pageSize + index + 1}
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="font-medium">{event.name}</div>
                        {/* <div className="text-sm text-muted-foreground">
                          {event.event_type_name}
                        </div> */}
                        {event.event_website_url && (
                          <a
                            href={event.event_website_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs text-blue-600 hover:text-blue-800 flex items-center gap-1"
                          >
                            <ExternalLink size={12} />
                            Website
                          </a>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="text-sm">
                          <span className="text-muted-foreground">Email:</span>{" "}
                          {event.Email}
                        </div>
                        <div className="text-sm">
                          <span className="text-muted-foreground">Phone:</span>{" "}
                          {event.Phone_number}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex items-center gap-1 text-sm">
                          <CalendarIcon
                            size={14}
                            className="text-muted-foreground"
                          />
                          <span>{formatDateSafely(event.start_date)}</span>
                        </div>
                        {event.start_time && (
                          <div className="flex items-center gap-1 text-sm">
                            <ClockIcon
                              size={14}
                              className="text-muted-foreground"
                            />
                            <span>
                              {event.start_time}
                              {event.end_time ? ` - ${event.end_time}` : ""}
                            </span>
                          </div>
                        )}
                        {event.end_date &&
                          event.end_date !== event.start_date && (
                            <div className="text-xs text-muted-foreground">
                              Until {formatDateSafely(event.end_date)}
                            </div>
                          )}
                      </div>
                    </TableCell>
                    <TableCell>
                      {event.event_address ? (
                        <div className="flex items-start gap-1">
                          <MapPinIcon
                            size={14}
                            className="text-muted-foreground mt-1 shrink-0"
                          />
                          <span className="text-sm">{event.event_address}</span>
                        </div>
                      ) : (
                        <span className="text-sm text-muted-foreground">
                          {event.event_type_name === "Webinars"
                            ? "Online Event"
                            : "Location not specified"}
                        </span>
                      )}
                    </TableCell>
                    <TableCell>
                      {event.is_paid ? (
                        <div className="flex items-center gap-1">
                          <span>₹{event.price}</span>
                        </div>
                      ) : (
                        <Badge variant="secondary">Free</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            const userRole = localStorage.getItem("roleName");
                            if (userRole !== "Event Admin") {
                              setSelectedCourse(event);
                              setShowStatusDialog(true);
                            }
                          }}
                          className={
                            localStorage.getItem("roleName") === "Event Admin"
                              ? "opacity-50 cursor-not-allowed"
                              : "hover:bg-gray-100"
                          }
                          disabled={
                            localStorage.getItem("roleName") === "Event Admin"
                          }
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8">
                    <div className="flex flex-col items-center justify-center">
                      <FileText className="h-8 w-8 text-muted-foreground mb-4" />
                      <p className="text-lg font-semibold">No events found</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        {searchQuery
                          ? "No events match your search criteria"
                          : "No events have been submitted yet"}
                      </p>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
          <TablePagination
            currentPage={pageConfig.page}
            pageSize={pageConfig.pageSize}
            totalItems={coursesData?.count || 0}
            onPageChange={(page) =>
              setPageConfig((prev) => ({ ...prev, page }))
            }
            onPageSizeChange={(newPageSize) =>
              setPageConfig((prev) => ({
                ...prev,
                pageSize: newPageSize,
                page: 1,
              }))
            }
          />
        </TabsContent>

        {/* Courses Tab Content */}
        <TabsContent
          value="courses"
          className="border rounded-lg p-4 shadow-sm"
        >
          <Table>
            <TableCaption>A list of all course enquiries</TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12 text-center">S.NO</TableHead>
                <TableHead>COURSE TITLE</TableHead>
                <TableHead>CATEGORY</TableHead>
                <TableHead>DURATION</TableHead>
                <TableHead>PRICE</TableHead>
                <TableHead>ACTION</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {coursesData?.result ? (
                coursesData.result.map((course, index) => {
                  console.log(course, "course");
                  return (
                    <TableRow key={course.event_id}>
                      <TableCell className="text-center font-medium">
                        {(pageConfig.page - 1) * pageConfig.pageSize +
                          index +
                          1}
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">{course.course_title}</div>
                        {/* <div className="text-sm text-muted-foreground">
                          {course.name}
                        </div> */}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {course.course_category || "N/A"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <Clock className="h-3 w-3 mr-1" />
                          {course.course_duration}
                        </div>
                      </TableCell>
                      <TableCell>
                        {course.price == "0" ? (
                          <Badge variant="secondary">Free</Badge>
                        ) : (
                          <div className="flex items-center">
                            ₹{course.price || 0}
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              const userRole = localStorage.getItem("roleName");
                              if (userRole !== "Event Admin") {
                                setSelectedCourse(course);
                                setShowStatusDialog(true);
                              }
                            }}
                            className={
                              localStorage.getItem("roleName") === "Event Admin"
                                ? "opacity-50 cursor-not-allowed"
                                : "hover:bg-gray-100"
                            }
                            disabled={
                              localStorage.getItem("roleName") === "Event Admin"
                            }
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8">
                    <div className="flex flex-col items-center justify-center">
                      <FileText className="h-8 w-8 text-muted-foreground mb-4" />
                      <p className="text-lg font-semibold">No courses found</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        {searchQuery
                          ? "No courses match your search criteria"
                          : "No courses have been submitted yet"}
                      </p>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
          <TablePagination
            currentPage={pageConfig.page}
            pageSize={pageConfig.pageSize}
            totalItems={coursesData?.count || 0}
            onPageChange={(page) =>
              setPageConfig((prev) => ({ ...prev, page }))
            }
            onPageSizeChange={(newPageSize) =>
              setPageConfig((prev) => ({
                ...prev,
                pageSize: newPageSize,
                page: 1,
              }))
            }
          />
        </TabsContent>
      </Tabs>

      {/* Status Dialog */}
      <Dialog
        open={
          showStatusDialog &&
          (localStorage.getItem("roleName") || "").trim().toLowerCase() !==
            "event admin".toLowerCase()
        }
        onOpenChange={(open) => {
          if (!open) {
            handleCloseStatusDialog();
          }
        }}
      >
        <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
          <DialogHeader className="pb-2 border-b">
            <DialogTitle className="text-2xl">
              {activeTab === "courses"
                ? selectedCourse?.course_title
                : selectedCourse?.name}
            </DialogTitle>
            <div className="mt-1">
              <StatusBadge status={selectedCourse?.status} />
            </div>
          </DialogHeader>

          {selectedCourse && (
            <div className="py-4">
              <div className="space-y-6">
                {activeTab === "courses" ? (
                  <>
                    {/* Course Information */}
                    <div>
                      <h3 className="text-lg font-medium mb-3 text-primary/80">
                        Course Information
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm text-[#918989] font-medium mb-1">
                            Course Name
                          </p>
                          <p className="font-medium">{selectedCourse.name}</p>
                        </div>
                        <div>
                          <p className="text-sm text-[#918989] font-medium mb-1">
                            Course Title
                          </p>
                          <p className="font-medium">
                            {selectedCourse.course_title}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-[#918989] font-medium mb-1">
                            Category
                          </p>
                          <p className="font-medium">
                            {selectedCourse.course_category}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-[#918989] font-medium mb-1">
                            Duration
                          </p>
                          <p className="font-medium">
                            {selectedCourse.course_duration}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-[#918989] font-medium mb-1">
                            Price
                          </p>
                          <p className="font-medium">
                            {selectedCourse.price === 0 ||
                            selectedCourse.price === "0"
                              ? "Free"
                              : `₹${selectedCourse.price}`}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Course Details */}
                    <div>
                      <h3 className="text-lg font-medium mb-3 text-primary/80">
                        Course Details
                      </h3>
                      <div>
                        <p className="text-sm text-[#918989] font-medium mb-1">
                          Description
                        </p>
                        <p className="font-medium whitespace-pre-wrap">
                          {selectedCourse.description}
                        </p>
                      </div>
                      {selectedCourse.course_preview && (
                        <div className="mt-4">
                          <p className="text-sm text-blue-600 font-medium mb-1">
                            Preview Link
                          </p>
                          <a
                            href={selectedCourse.course_preview}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="font-medium text-primary hover:underline"
                          >
                            {selectedCourse.course_preview}
                          </a>
                        </div>
                      )}
                    </div>
                  </>
                ) : (
                  <>
                    {/* Event/Workshop/Webinar Information */}
                    <div>
                      <h3 className="text-lg font-medium mb-3 text-primary/80">
                        {activeTab === "events" && "Event Information"}
                        {activeTab === "workshops" && "Workshop Information"}
                        {activeTab === "webinars" && "Webinar Information"}
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm text-[#918989] font-medium mb-1">
                            {activeTab === "events" && "Event Name"}
                            {activeTab === "workshops" && "Workshop Name"}
                            {activeTab === "webinars" && "Webinar Name"}
                          </p>
                          <p className="font-medium text-[303030]">
                            {selectedCourse.name}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-[#918989] font-medium mb-1">
                            Type
                          </p>
                          <p className="font-medium">
                            {selectedCourse.event_type_name}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-[#918989] font-medium mb-1">
                            Date
                          </p>
                          <div className="flex items-center gap-2">
                            <p className="font-medium text-[303030]">
                              {formatDateSafely(selectedCourse.start_date)}
                            </p>
                            {selectedCourse.end_date &&
                              selectedCourse.end_date !==
                                selectedCourse.start_date && (
                                <>
                                  <span className="text-muted-foreground">
                                    -
                                  </span>
                                  <p className="font-medium text-[303030]">
                                    {formatDateSafely(selectedCourse.end_date)}
                                  </p>
                                </>
                              )}
                          </div>
                        </div>
                        <div>
                          <p className="text-sm text-[#918989] font-medium mb-1">
                            Time
                          </p>
                          <p className="font-medium">
                            {selectedCourse.start_time}
                            {selectedCourse.end_time
                              ? ` - ${selectedCourse.end_time}`
                              : ""}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-[#918989] font-medium mb-1">
                            {activeTab === "webinars" ? "Platform" : "Location"}
                          </p>
                          <p className="font-medium">
                            {activeTab === "webinars"
                              ? selectedCourse.platform ||
                                "Platform not specified"
                              : selectedCourse.event_address ||
                                "Location not specified"}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-[#918989] font-medium mb-1">
                            Price
                          </p>
                          <p className="font-medium">
                            {selectedCourse.is_paid
                              ? `₹${selectedCourse.price}`
                              : "Free"}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Event/Workshop/Webinar Details */}
                    <div>
                      <h3 className="text-lg font-medium mb-3 text-primary/80">
                        {activeTab === "events" && "Event Details"}
                        {activeTab === "workshops" && "Workshop Details"}
                        {activeTab === "webinars" && "Webinar Details"}
                      </h3>
                      <div>
                        <p className="text-sm text-[#918989] font-medium mb-1">
                          Description
                        </p>
                        <p className="font-medium whitespace-pre-wrap">
                          {selectedCourse.description}
                        </p>
                      </div>
                      {selectedCourse.event_website_url && (
                        <div className="mt-4">
                          <p className="text-sm text-[#918989] font-medium mb-1">
                            Website
                          </p>
                          <a
                            href={selectedCourse.event_website_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="font-medium text-primary hover:underline flex items-center gap-1"
                          >
                            <ExternalLink size={14} />
                            {selectedCourse.event_website_url}
                          </a>
                        </div>
                      )}
                    </div>
                  </>
                )}

                {/* Contact Information */}
                <div>
                  <h3 className="text-lg font-medium mb-3 text-primary/80">
                    Contact Information
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-[#918989] font-medium mb-1">
                        Email
                      </p>
                      <p className="font-medium">{selectedCourse.Email}</p>
                    </div>
                    <div>
                      <p className="text-sm text-[#918989] font-medium mb-1">
                        Phone
                      </p>
                      <p className="font-medium text-[303030]">
                        {selectedCourse.Phone_number}
                      </p>
                    </div>
                  </div>

                  {/* Workshop Image */}
                  {selectedCourse.image && (
                    <div className="mt-4">
                      <p className="text-sm text-[#918989] font-medium mb-2">
                        Workshop Image
                      </p>
                      <div className="flex justify-center">
                        <img
                          src={selectedCourse.image}
                          alt="Workshop image"
                          className="max-w-full h-auto max-h-64 object-cover rounded-lg border shadow-sm"
                          onError={(e) => {
                            e.currentTarget.style.display = "none";
                          }}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Strict guard for Event Admin: only show Close button */}
              {(() => {
                const role = (localStorage.getItem("roleName") || "")
                  .trim()
                  .toLowerCase();
                if (role === "event admin") {
                  return (
                    <div className="flex justify-end space-x-2 mt-6 pt-4 border-t">
                      <Button
                        variant="outline"
                        onClick={handleCloseStatusDialog}
                      >
                        Close
                      </Button>
                    </div>
                  );
                }
                // if (selectedCourse.status === "Pending" && role === "super admin") {
                //   return (
                //     <div className="flex justify-end space-x-2 mt-6 pt-4 border-t">
                //       <Button variant="outline" onClick={handleCloseStatusDialog}>
                //         Cancel
                //       </Button>
                //       <Button
                //         variant="destructive"
                //         onClick={handleOpenReasonDialog}
                //       >
                //         Reject
                //       </Button>
                //       <Button
                //         onClick={handleApprove}
                //         className="bg-green-600 hover:bg-green-700"
                //       >
                //         Approve
                //       </Button>
                //     </div>
                //   );
                // }
                return (
                  <div className="flex justify-end space-x-2 mt-6 pt-4 border-t">
                    <Button variant="outline" onClick={handleCloseStatusDialog}>
                      Close
                    </Button>
                  </div>
                );
              })()}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Rejection Reason Dialog */}
      <Dialog
        open={showReasonDialog}
        onOpenChange={(open) => {
          if (!open) {
            setShowReasonDialog(false);
            setReasonError("");
          }
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject Course</DialogTitle>
            <DialogDescription>
              Please provide a detailed reason for rejection
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleRejectSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="reason">Reason for Rejection</Label>
              <Textarea
                id="reason"
                name="reason"
                rows={6}
                placeholder="Please provide a detailed explanation for why this course is being rejected. Be specific about the issues and include any suggestions for improvements that would make it acceptable."
                className="resize-none"
                onChange={() => reasonError && setReasonError("")}
              />
              {reasonError && (
                <p className="text-sm font-medium text-destructive">
                  {reasonError}
                </p>
              )}
              <div className="text-xs text-muted-foreground">
                Your rejection reason should be detailed and specific,
                containing at least 3 alphabetic characters.
              </div>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setShowReasonDialog(false);
                  setReasonError("");
                }}
              >
                Cancel
              </Button>
              <Button type="submit" variant="destructive">
                Reject Course
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Enquiries;
