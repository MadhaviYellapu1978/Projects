
import React from 'react';
import { AlertTriangle, Bell, Lock, MessageSquare, User } from 'lucide-react';

const SettingsPage = () => {
  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-8">Settings</h1>
      
      <div className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden">
        <div className="grid grid-cols-1 md:grid-cols-[240px,1fr]">
          <div className="bg-gray-50 border-r border-gray-100">
            <div className="p-4">
              <h3 className="text-sm font-medium text-gray-500 mb-3">User Settings</h3>
              <ul className="space-y-1">
                <li>
                  <button className="flex items-center gap-3 w-full p-2 rounded-md bg-primary/10 text-primary font-medium">
                    <User size={18} />
                    My Account
                  </button>
                </li>
                <li>
                  <button className="flex items-center gap-3 w-full p-2 rounded-md text-gray-700 hover:bg-gray-100">
                    <Bell size={18} />
                    Notifications
                  </button>
                </li>
                <li>
                  <button className="flex items-center gap-3 w-full p-2 rounded-md text-gray-700 hover:bg-gray-100">
                    <Lock size={18} />
                    Security
                  </button>
                </li>
              </ul>
            </div>
            
            <div className="p-4 border-t border-gray-100">
              <h3 className="text-sm font-medium text-gray-500 mb-3">Support</h3>
              <ul className="space-y-1">
                <li>
                  <button className="flex items-center gap-3 w-full p-2 rounded-md text-gray-700 hover:bg-gray-100">
                    <MessageSquare size={18} />
                    Help Center
                  </button>
                </li>
                <li>
                  <button className="flex items-center gap-3 w-full p-2 rounded-md text-gray-700 hover:bg-gray-100">
                    <AlertTriangle size={18} />
                    Report a Problem
                  </button>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="p-6">
            <h2 className="text-xl font-medium mb-6">Account Settings</h2>
            
            <div className="space-y-6">
              <div>
                <h3 className="text-md font-medium mb-2">Personal Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm text-gray-600 mb-1">Full Name</label>
                    <input 
                      type="text" 
                      className="w-full border border-gray-200 rounded-md p-2" 
                      defaultValue="Justin Schleifer"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-600 mb-1">Email</label>
                    <input 
                      type="email" 
                      className="w-full border border-gray-200 rounded-md p-2" 
                      defaultValue="justin.schleifer@example.com"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-600 mb-1">Phone</label>
                    <input 
                      type="tel" 
                      className="w-full border border-gray-200 rounded-md p-2" 
                      defaultValue="+91 9123456789"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-600 mb-1">Date of Birth</label>
                    <input 
                      type="date" 
                      className="w-full border border-gray-200 rounded-md p-2" 
                      defaultValue="1990-01-01"
                    />
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-md font-medium mb-2">Address Information</h3>
                <div className="grid grid-cols-1 gap-4">
                  <div>
                    <label className="block text-sm text-gray-600 mb-1">Address Line 1</label>
                    <input 
                      type="text" 
                      className="w-full border border-gray-200 rounded-md p-2" 
                      placeholder="Street address"
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm text-gray-600 mb-1">City</label>
                      <input 
                        type="text" 
                        className="w-full border border-gray-200 rounded-md p-2" 
                        placeholder="City"
                      />
                    </div>
                    <div>
                      <label className="block text-sm text-gray-600 mb-1">State</label>
                      <input 
                        type="text" 
                        className="w-full border border-gray-200 rounded-md p-2" 
                        placeholder="State"
                      />
                    </div>
                    <div>
                      <label className="block text-sm text-gray-600 mb-1">Zip Code</label>
                      <input 
                        type="text" 
                        className="w-full border border-gray-200 rounded-md p-2" 
                        placeholder="Zip code"
                      />
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="pt-4 border-t border-gray-100">
                <button className="bg-primary text-white px-4 py-2 rounded-md hover:bg-primary/90 transition-colors">
                  Save Changes
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;
