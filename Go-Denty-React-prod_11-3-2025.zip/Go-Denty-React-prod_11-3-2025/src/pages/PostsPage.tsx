/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState, useCallback, useEffect, useRef } from "react";
import { useDropzone } from "react-dropzone";
import { Formik, Form, Field } from "formik";
import * as Yup from "yup";
import TabButton from "../components/ui/TabButton";
import SearchInput from "../components/ui/SearchInput";
import { Editor } from "@toast-ui/react-editor";
import "@toast-ui/editor/dist/toastui-editor.css";
import DataTable from "../components/ui/DataTable";

import {
  ArrowRight,
  Edit2,
  Trash2,
  Upload,
  Plus,
  X,
  AlertCircle,
  Eye,
  Play,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  useUploadReels,
  useMedia,
  useDeleteMedia,
  MediaType,
  useUploadImage,
  queryKeys,
} from "@/services/api";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/components/ui/use-toast";
import { AxiosError } from "axios"; // Validation schema for the form
import axios from "axios";
import { useQueryClient } from "@tanstack/react-query";
import deleteicon from "../../public/lovable-uploads/delete bg.svg";
import editicon from "../../public/lovable-uploads/edit bg.svg";
import { baseURL } from "@/services/axios";

interface MediaPost {
  media_id: number | string;
  title?: string;
  caption?: string;
  description?: string;
  image?: string;
  video_url?: string;
  thumbnail_url?: string;
  createdAt: string;
  likes_count?: number;
  shares?: number;
  comments_count?: number;
  content?: string;
  isShopAvailable?: boolean;
  isShopAvalible?: string;
  shoppingUrl?: string;
  shoping_url?: string;
  html_string_mobile?: string;
  source_link?: string;
  references?: string[];
}

// First, update the FileUploadProps interface to include thumbnailUrl
interface FileUploadProps {
  setFieldValue: (file: File | null) => void;
  file: File | null;
  existingImage?: string;
  thumbnailUrl?: string;
  accept: string;
  placeholder?: string;
  isVideo?: boolean;
  onDeleteExisting?: () => void;
}

const getTabLabel = (tab: MediaType) => {
  switch (tab) {
    case MediaType.Feeds:
      return "Feed";
    case MediaType.Reels:
      return "Reel";
    case MediaType.Blogs:
      return "Blog";
    case MediaType.Banners:
      return "Banner";
    default:
      return "Post";
  }
};

const PostsPage = () => {
  const editorRef = useRef<any>(null);
  const [activeTab, setActiveTab] = useState<MediaType>(MediaType.Feeds);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [postToDelete, setPostToDelete] = useState<number | null>(null);
  const [postToEdit, setPostToEdit] = useState<MediaPost | null>(null);
  const [currentPage, setCurrentPage] = useState(0);
  const [pageSize, setPageSize] = useState(10);
  const [searchQuery, setSearchQuery] = useState("");
  const [initialEditorContent, setInitialEditorContent] = useState<string>("");
  const [isEditorDirty, setIsEditorDirty] = useState(false);
  const [initialReferences, setInitialReferences] = useState<string[]>([]);
  const [isReferencesDirty, setIsReferencesDirty] = useState(false);
  const uploadReelsMutation = useUploadReels();
  const uploadImageMutation = useUploadImage();
  const deleteMediaMutation = useDeleteMedia();
  const { data: recentMediaData, isLoading: isRecentLoading } = useMedia(
    activeTab,
    0,
    4
  );
  const { data: allMediaData, isLoading: isAllLoading } = useMedia(
    activeTab,
    0,
    1000 // Large number to fetch all items for frontend pagination
  );
  const [uploadProgress, setUploadProgress] = useState(0);
  const queryClient = useQueryClient();
  const [loadedFiles, setLoadedFiles] = useState<{
    file: File | null;
    thumbnail: File | null;
  }>({ file: null, thumbnail: null });
  const [deletedExistingMedia, setDeletedExistingMedia] = useState({
    file: false,
    thumbnail: false,
  });
  const { toast } = useToast();

  // Simplified reel preview state
  const [reelPreview, setReelPreview] = useState<{
    isOpen: boolean;
    post: MediaPost | null;
    isPlaying: boolean;
  }>({
    isOpen: false,
    post: null,
    isPlaying: false,
  });

  // Simplified view modal state
  const [viewModal, setViewModal] = useState<{
    isOpen: boolean;
    post: MediaPost | null;
    isVideoPlaying: boolean;
  }>({
    isOpen: false,
    post: null,
    isVideoPlaying: false,
  });

  // Video ref for view modal
  const viewVideoRef = useRef<HTMLVideoElement>(null);

  const recentPosts = recentMediaData || [];
  const allPosts = allMediaData || [];

  // Reset page when tab changes
  useEffect(() => {
    setCurrentPage(0);
    setSearchQuery(""); // Reset search when tab changes
  }, [activeTab]);

  // Reset progress when modal closes
  useEffect(() => {
    if (!showCreateModal) {
      setUploadProgress(0);
    }
  }, [showCreateModal]);

  const handleTabChange = (tab: MediaType) => {
    setActiveTab(tab);
  };

  const handleEditClick = (post: MediaPost) => {
    preparePostForEdit(post);
  };

  const handleCreateClick = () => {
    setPostToEdit(null);
    setDeletedExistingMedia({ file: false, thumbnail: false });
    setInitialEditorContent("");
    setIsEditorDirty(false);
    setInitialReferences([]);
    setIsReferencesDirty(false);
    setShowCreateModal(true);
  };

  const handleModalClose = () => {
    setShowCreateModal(false);
    setPostToEdit(null);
    // Add a small delay before resetting files to prevent video instability
    setTimeout(() => {
      setLoadedFiles({ file: null, thumbnail: null });
      setDeletedExistingMedia({ file: false, thumbnail: false });
      setInitialEditorContent("");
      setIsEditorDirty(false);
      setInitialReferences([]);
      setIsReferencesDirty(false);
    }, 100);
  };

  const handleDeleteClick = (mediaId: number) => {
    setPostToDelete(mediaId);
    setShowDeleteDialog(true);
  };

  const handleDeleteConfirm = async () => {
    if (!postToDelete) return;

    try {
      const response = await deleteMediaMutation.mutateAsync(postToDelete);
      if (response.data.message) {
        toast({
          title: "Success",
          description: `${getTabLabel(activeTab)} deleted successfully!`,
          duration: 1500,
        });
      } else {
        toast({
          title: "Success",
          description: `${getTabLabel(activeTab)} deleted successfully!`,
          duration: 1500,
        });
      }
    } catch (error) {
      const axiosError = error as AxiosError<{ message: string }>;
      toast({
        variant: "destructive",
        title: "Error",
        description:
          axiosError.response?.data?.message ||
          "There was an error deleting the post. Please try again.",
        duration: 4000,
      });
      console.error("Error deleting media:", error);
    } finally {
      // Always close the dialog and reset state regardless of success or failure
      setShowDeleteDialog(false);
      setPostToDelete(null);
    }
  };

  const getValidationSchema = (isEditing: boolean) => {
    // Custom URL validation function
    const validateUrl = (value: string) => {
      if (!value || value.trim().length === 0) return true; // Allow empty strings

      try {
        // More permissive URL validation
        const url = new URL(value);
        return url.protocol === "http:" || url.protocol === "https:";
      } catch {
        return false;
      }
    };

    // Custom validation to prevent first spaces
    const validateNoFirstSpace = (value: string) => {
      if (!value) return true; // Allow empty values
      return !value.startsWith(" ");
    };

    return Yup.object().shape({
      title: Yup.string().when([], {
        is: () => activeTab !== MediaType.Banners,
        then: () =>
          Yup.string()
            .required("Title is required")
            .test(
              "no-first-space",
              "Title cannot start with a space",
              validateNoFirstSpace
            ),
        otherwise: () => Yup.string().nullable(),
      }),
      description: Yup.string().when([], {
        is: () =>
          activeTab !== MediaType.Banners && activeTab !== MediaType.Reels,
        then: () =>
          Yup.string()
            .required("Description is required")
            .test(
              "no-first-space",
              "Description cannot start with a space",
              validateNoFirstSpace
            ),
        otherwise: () => Yup.string().nullable(),
      }),
      content: Yup.string().nullable(), // Content is no longer required for blogs
      sourceUrl: Yup.string()
        .url("Must be a valid URL")
        .test(
          "no-first-space",
          "Source URL cannot start with a space",
          validateNoFirstSpace
        )
        .nullable(),
      references: Yup.array()
        .of(
          Yup.string()
            .test("valid-url", "Must be a valid URL", validateUrl)
            .test("not-empty", "URL cannot be empty", (value) => {
              return !value || value.trim().length > 0;
            })
            .test(
              "no-first-space",
              "Reference URL cannot start with a space",
              validateNoFirstSpace
            )
        )
        .nullable(),
      file: Yup.mixed().when([], {
        is: () => activeTab === MediaType.Blogs,
        then: () => Yup.mixed().nullable(), // Files not required for blogs
        otherwise: () => {
          // Check if we need to require a file
          const hasExistingMedia =
            isEditing &&
            postToEdit &&
            ((activeTab === MediaType.Reels &&
              (postToEdit.video_url || postToEdit.image)) ||
              (activeTab !== MediaType.Reels && postToEdit.image));

          // Require file if: creating new post OR editing and existing media was deleted
          const shouldRequireFile =
            !isEditing || !hasExistingMedia || deletedExistingMedia.file;

          return shouldRequireFile
            ? Yup.mixed()
                .required(
                  activeTab === MediaType.Reels
                    ? "Video is required"
                    : "Image is required"
                )
                .test(
                  "fileFormat",
                  "Unsupported file format",
                  function (value) {
                    if (!value) return false;

                    if (activeTab === MediaType.Reels) {
                      return (value as File).type === "video/mp4";
                    }

                    const supportedFormats = [
                      "image/png",
                      "image/jpg",
                      "image/jpeg",
                    ];
                    return supportedFormats.includes((value as File).type);
                  }
                )
                .test(
                  "fileSize",
                  "File size must be less than 100MB",
                  function (value) {
                    if (!value) return false;
                    const maxSize = 100 * 1024 * 1024; // 100MB in bytes
                    return (value as File).size <= maxSize;
                  }
                )
            : Yup.mixed().nullable();
        },
      }),
      thumbnail: Yup.mixed().when([], {
        is: () => activeTab === MediaType.Reels,
        then: () => {
          // Check if we need to require a thumbnail
          const hasExistingThumbnail = isEditing && postToEdit?.thumbnail_url;

          // Require thumbnail if: creating new reel OR editing and existing thumbnail was deleted
          const shouldRequireThumbnail =
            !isEditing ||
            !hasExistingThumbnail ||
            deletedExistingMedia.thumbnail;

          return shouldRequireThumbnail
            ? Yup.mixed()
                .required("Thumbnail is required")
                .test(
                  "fileSize",
                  "File size must be less than 100MB",
                  function (value) {
                    if (!value) return false;
                    const maxSize = 100 * 1024 * 1024; // 100MB in bytes
                    return (value as File).size <= maxSize;
                  }
                )
            : Yup.mixed().nullable();
        },
        otherwise: () => Yup.mixed().nullable(),
      }),
      isShopAvailable: Yup.boolean().when([], {
        is: () => activeTab === MediaType.Blogs,
        then: () => Yup.boolean().strip(), // Remove this field for blogs
        otherwise: () => Yup.boolean(),
      }),
      shoppingUrl: Yup.string().when([], {
        is: () => activeTab === MediaType.Blogs,
        then: () => Yup.string().strip(), // Remove this field for blogs
        otherwise: () =>
          Yup.string().when("isShopAvailable", {
            is: true,
            then: () =>
              Yup.string()
                .required("Shopping URL is required")
                .url("Must be a valid URL")
                .test(
                  "no-first-space",
                  "Shopping URL cannot start with a space",
                  validateNoFirstSpace
                ),
            otherwise: () => Yup.string(),
          }),
      }),
    });
  };

  // Function to convert a URL to a File object
  const urlToFile = async (
    url: string,
    filename: string,
    mimeType: string
  ): Promise<File | null> => {
    try {
      // Check if the URL is from our S3 bucket to avoid CORS issues
      if (url.includes("godentybucket.s3.ap-south-1.amazonaws.com")) {
        console.log("S3 URL detected, skipping direct fetch to avoid CORS");
        return null;
      }

      const response = await fetch(url);

      if (!response.ok) {
        console.error(
          `Failed to fetch file: ${response.status} ${response.statusText}`
        );
        return null;
      }

      const blob = await response.blob();
      return new File([blob], filename, { type: mimeType });
    } catch (error) {
      console.error("Error converting URL to file:", error);
      return null;
    }
  };

  // Function to prepare post for editing by loading files
  const preparePostForEdit = async (post: MediaPost) => {
    // Set the post to edit state
    setPostToEdit(post);

    // Reset deleted media state when editing a post
    setDeletedExistingMedia({ file: false, thumbnail: false });

    // For Reels, the title is stored in caption
    if (activeTab === MediaType.Reels && post.caption) {
      post.title = post.caption;
    }

    // For Blogs, set the content from caption
    if (activeTab === MediaType.Blogs && post.html_string_mobile) {
      post.content = post.html_string_mobile;
      setInitialEditorContent(post.html_string_mobile);
      setIsEditorDirty(false);
      setInitialReferences(post.references || []);
      setIsReferencesDirty(false);
    }

    try {
      // For S3 URLs, we don't need to convert to File objects
      // The FileUpload component will handle existing images via URLs

      // Set loaded files to null since we'll use existing URLs
      setLoadedFiles({
        file: null,
        thumbnail: null,
      });

      // Show the create/edit modal
      setShowCreateModal(true);
    } catch (error) {
      console.error("Error preparing post for edit:", error);
      // Still open the modal even if file loading fails
      setShowCreateModal(true);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Error loading media files for editing",
      });
    }
  };

  const handleViewClick = (post: MediaPost) => {
    setViewModal({ isOpen: true, post, isVideoPlaying: false });
  };

  // Handle search input change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
    setCurrentPage(0); // Reset to first page when searching
  };

  // Filter posts based on search query
  const filteredPosts = allPosts.filter((post) => {
    if (!searchQuery.trim()) return true;

    const query = searchQuery.toLowerCase();
    const title = (
      post.title ||
      (post as MediaPost).caption ||
      ""
    ).toLowerCase();
    const description = (post.description || "").toLowerCase();

    return title.includes(query) || description.includes(query);
  });

  // Slice filteredPosts for pagination
  const paginatedPosts = filteredPosts.slice(
    currentPage * pageSize,
    currentPage * pageSize + pageSize
  );

  if (isRecentLoading) {
    return <div>Loading...</div>;
  }

  // Function to handle reel preview thumbnail click
  const handleReelPreviewThumbnailClick = () => {
    setReelPreview((prev) => ({ ...prev, isPlaying: true }));
  };

  // Function to handle view modal video click
  const handleViewThumbnailClick = () => {
    setViewModal((prev) => ({ ...prev, isVideoPlaying: true }));
  };

  const ReelPreviewModal = () => (
    <Dialog
      open={reelPreview.isOpen}
      onOpenChange={() =>
        setReelPreview({ isOpen: false, post: null, isPlaying: false })
      }
    >
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Reel Preview</DialogTitle>
        </DialogHeader>
        {reelPreview.post ? (
          !reelPreview.isPlaying ? (
            <div
              className="cursor-pointer relative"
              onClick={handleReelPreviewThumbnailClick}
              aria-label="Click to play video"
            >
              <img
                src={
                  reelPreview.post.thumbnail_url ||
                  reelPreview.post.image ||
                  "/video-placeholder.jpg"
                }
                alt="Video thumbnail"
                className="w-full max-h-[70vh] rounded shadow object-contain"
                onError={(e) => {
                  // Fallback to video frame if thumbnail fails to load
                  const target = e.target as HTMLImageElement;
                  if (
                    reelPreview.post?.video_url &&
                    target.src !== reelPreview.post.video_url
                  ) {
                    target.src = reelPreview.post.video_url;
                  } else if (target.src !== "/video-placeholder.jpg") {
                    target.src = "/video-placeholder.jpg";
                  }
                }}
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="bg-black bg-opacity-30 p-3 rounded-full">
                  <Play size={36} className="text-white" />
                </div>
              </div>
            </div>
          ) : (
            <div className="pt-2 pb-6">
              <video
                src={reelPreview.post.video_url || reelPreview.post.image}
                poster={reelPreview.post.thumbnail_url || undefined}
                controls
                className="w-full max-h-[70vh] rounded shadow"
                preload="metadata"
                autoPlay
              />
            </div>
          )
        ) : (
          <p className="text-center text-gray-500">No video available</p>
        )}
      </DialogContent>
    </Dialog>
  );

  // Update the success handler in the form submission
  const handleSuccess = () => {
    // Don't immediately reset loaded files to prevent video instability
    // The modal close will handle the cleanup

    // Invalidate all media queries to ensure data refresh
    queryClient.invalidateQueries({
      queryKey: ["media"],
    });

    // Also invalidate specific queries for the current tab
    queryClient.invalidateQueries({
      queryKey: queryKeys.media(activeTab, 0, 4),
    });
    queryClient.invalidateQueries({
      queryKey: queryKeys.media(activeTab, 0, 1000),
    });
  };

  return (
    <div className="space-y-8 ">
      <div className="flex space-x-4 overflow-x-auto ">
        <TabButton
          label="Feeds"
          active={activeTab === MediaType.Feeds}
          onClick={() => handleTabChange(MediaType.Feeds)}
        />
        <TabButton
          label="Reels"
          active={activeTab === MediaType.Reels}
          onClick={() => handleTabChange(MediaType.Reels)}
        />
        <TabButton
          label="Blogs"
          active={activeTab === MediaType.Blogs}
          onClick={() => handleTabChange(MediaType.Blogs)}
        />
        <TabButton
          label="Banners"
          active={activeTab === MediaType.Banners}
          onClick={() => handleTabChange(MediaType.Banners)}
        />
      </div>

      <div>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold">
            {activeTab === MediaType.Feeds && "Recently Posted Feeds"}
            {activeTab === MediaType.Reels && "Recently Posted Reels"}
            {activeTab === MediaType.Blogs && "Recently Posted Blogs"}
            {activeTab === MediaType.Banners && "Recently Posted Banners"}
          </h2>
          <Button
            onClick={handleCreateClick}
            className="flex items-center gap-2"
          >
            <Plus size={16} />
            Create
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {isRecentLoading ? (
            // Loading skeleton
            Array.from({ length: 4 }).map((_, index) => (
              <div
                key={index}
                className="rounded-lg overflow-hidden bg-gray-100 animate-pulse"
              >
                <div className="p-6 flex flex-col">
                  <div className="h-4 bg-gray-200 rounded w-1/3 mb-4"></div>
                  <div className="h-6 bg-gray-200 rounded w-3/4 mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-full mb-4"></div>
                  <div className="flex justify-between items-center mt-auto">
                    <div className="flex gap-2">
                      <div className="h-6 w-6 bg-gray-200 rounded"></div>
                      <div className="h-6 w-6 bg-gray-200 rounded"></div>
                    </div>
                    <div className="h-6 w-6 bg-gray-200 rounded"></div>
                  </div>
                </div>
              </div>
            ))
          ) : recentPosts?.length > 0 ? (
            recentPosts.map((post) => (
              <div
                key={post.media_id}
                className="rounded-lg overflow-hidden bg-primary"
              >
                <div className="p-6 flex flex-col text-white">
                  <p className="text-sm mb-4">
                    {(() => {
                      const date = new Date(post.createdAt);
                      const day = date.getDate().toString().padStart(2, "0");
                      const month = (date.getMonth() + 1)
                        .toString()
                        .padStart(2, "0");
                      const year = date.getFullYear();
                      return `${day}-${month}-${year}`;
                    })()}
                  </p>
                  {activeTab !== MediaType.Blogs && (
                    <img
                      src={post.image || post.thumbnail_url}
                      alt={post.title}
                      className="w-full h-48 object-cover mb-4 rounded-md"
                    />
                  )}
                  <h3
                    className="font-medium text-lg mb-2"
                    title={post.title || (post as MediaPost).caption}
                  >
                    {post.title?.length > 15
                      ? `${post.title.slice(0, 15)}...`
                      : post.title ||
                        ((post as MediaPost).caption?.length > 15
                          ? `${(post as MediaPost).caption.slice(0, 15)}...`
                          : (post as MediaPost).caption) ||
                        (activeTab !== MediaType.Banners && "Untitled")}
                  </h3>
                  <p
                    className="text-sm text-gray-300 mb-4"
                    title={post.description}
                  >
                    {post.description?.length > 25
                      ? `${post.description.slice(0, 25)}...`
                      : post.description}
                  </p>
                  <div className="flex gap-2">
                    {activeTab === MediaType.Reels && (
                      <button
                        className="text-white/80 hover:text-white"
                        onClick={() => {
                          setReelPreview({
                            isOpen: true,
                            post,
                            isPlaying: false,
                          });
                        }}
                        title="View Reel"
                      >
                        <Eye size={18} />
                      </button>
                    )}
                    <button
                      className="text-white/80 hover:text-white"
                      onClick={() => handleEditClick(post)}
                    >
                      <Edit2 size={18} />
                    </button>
                    <button
                      className="text-white/80 hover:text-white"
                      onClick={() => handleDeleteClick(post.media_id)}
                      disabled={deleteMediaMutation.isPending}
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>

                  <ReelPreviewModal />
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-full text-center py-8 text-gray-500">
              No posts found
            </div>
          )}
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between mb-4">
          <div className="text-lg font-medium">
            {activeTab === MediaType.Feeds && "Feeds"}
            {activeTab === MediaType.Reels && "Reels"}
            {activeTab === MediaType.Blogs && "Blogs"}
            {activeTab === MediaType.Banners && "Banners"}{" "}
            <span className="text-gray-500">({filteredPosts.length})</span>
          </div>
          {activeTab !== MediaType.Banners && (
            <div className="w-64">
              <SearchInput
                placeholder="Search by title"
                onChange={handleSearchChange}
                value={searchQuery}
              />
            </div>
          )}
        </div>

        <div className="overflow-x-auto w-full">
          <DataTable
            columns={[
              {
                header: "S.NO",
                accessor: "serialNumber",
                cell: (_: string, __: any, rowIndex: number | undefined) => {
                  return (
                    currentPage * pageSize +
                    (rowIndex ?? 0) +
                    1
                  ).toString();
                },
              },
              ...(activeTab !== MediaType.Banners
                ? [
                    {
                      header: "TITLE",
                      accessor: "title",
                      cell: (value: string, row: MediaPost) => {
                        return row.title || row.caption || "Untitled";
                      },
                    },
                  ]
                : []),
              {
                header: "DATE CREATED",
                accessor: "createdAt",
                cell: (value: string) => {
                  const date = new Date(value);
                  const day = date.getDate().toString().padStart(2, "0");
                  const month = (date.getMonth() + 1)
                    .toString()
                    .padStart(2, "0");
                  const year = date.getFullYear();
                  return `${day}-${month}-${year}`;
                },
              },
              {
                header: "VIEW",
                accessor: "view",
                cell: (_: any, row: MediaPost) => (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleViewClick(row)}
                    className="text-gray-600 hover:text-gray-900"
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                ),
              },
              ...(activeTab === MediaType.Reels
                ? [
                    {
                      header: "LIKES",
                      accessor: "likes_count",
                      cell: (value: number) => value ?? "N/A",
                    },
                    {
                      header: "COMMENTS",
                      accessor: "comments_count",
                      cell: (value: number) => value ?? "N/A",
                    },
                  ]
                : []),
              {
                header: "ACTIONS",
                accessor: "actions",
                cell: (_: any, row: MediaPost) => (
                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEditClick(row)}
                      className="text-blue-600 hover:text-blue-800"
                      title="Edit"
                    >
                      <img src={editicon} alt="edit" className="h-6 w-6" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteClick(row.media_id as number)}
                      disabled={deleteMediaMutation.isPending}
                      className="text-red-600 hover:text-red-800"
                      title="Delete"
                    >
                      <img src={deleteicon} alt="delete" className="h-6 w-6" />
                    </Button>
                  </div>
                ),
              },
            ]}
            data={paginatedPosts}
            isLoading={isAllLoading}
            pagination={{
              currentPage: currentPage + 1,
              totalPages: Math.ceil(filteredPosts.length / pageSize),
              pageSize: pageSize,
              totalItems: filteredPosts.length,
              onPageChange: (page) => setCurrentPage(page - 1),
              onPageSizeChange: (newPageSize) => {
                setPageSize(newPageSize);
                setCurrentPage(0);
              },
            }}
          />
        </div>
      </div>

      <Dialog open={showCreateModal} onOpenChange={handleModalClose}>
        <DialogContent className="sm:max-w-[600px] max-h-[650px] overflow-y-scroll">
          <DialogHeader>
            <DialogTitle>
              {postToEdit
                ? `Edit ${getTabLabel(activeTab)}`
                : `Create New ${getTabLabel(activeTab)}`}
            </DialogTitle>
          </DialogHeader>

          <Formik
            enableReinitialize={true}
            initialValues={{
              title: postToEdit?.title || "",
              description: postToEdit?.description || "",
              content: postToEdit?.content || "",
              file: activeTab === MediaType.Blogs ? null : loadedFiles.file,
              thumbnail: loadedFiles.thumbnail,
              isShopAvailable:
                activeTab === MediaType.Blogs
                  ? false
                  : postToEdit?.isShopAvailable ||
                    postToEdit?.isShopAvalible === "true" ||
                    false,
              shoppingUrl:
                activeTab === MediaType.Blogs
                  ? ""
                  : postToEdit?.shoppingUrl || postToEdit?.shoping_url || "",
              sourceUrl: postToEdit?.source_link || "",
              references: postToEdit?.references || [],
            }}
            validationSchema={getValidationSchema(!!postToEdit)}
            validateOnBlur={false}
            validateOnChange={false}
            validateOnMount={false}
            onSubmit={async (values, { setSubmitting }) => {
              try {
                console.log("Form submission values:", values);
                console.log("Post to edit:", postToEdit);
                setUploadProgress(0);
                const formData = new FormData();

                if (activeTab === MediaType.Reels) {
                  // Video file handling - only append if there's a new file
                  if (values.file && values.file.size > 0) {
                    formData.append("image", values.file);
                    console.log(
                      "Uploading new video file:",
                      values.file.name,
                      "Size:",
                      values.file.size
                    );
                  } else if (
                    postToEdit &&
                    (postToEdit.video_url || postToEdit.image)
                  ) {
                    console.log(
                      "Using existing video, not uploading a new one"
                    );
                    // We don't need to do anything for existing videos - the server will use what's already there
                  } else {
                    console.error(
                      "No video file provided and no existing video found"
                    );
                  }

                  // Thumbnail handling - only append if there's a new file
                  if (values.thumbnail && values.thumbnail.size > 0) {
                    formData.append("thumbnail", values.thumbnail);
                    console.log(
                      "Uploading new thumbnail file:",
                      values.thumbnail.name,
                      "Size:",
                      values.thumbnail.size
                    );
                  } else if (postToEdit?.thumbnail_url) {
                    console.log(
                      "Using existing thumbnail, not uploading a new one"
                    );
                    // We don't need to do anything for existing thumbnails
                  } else {
                    console.log("No thumbnail provided");
                  }

                  formData.append("media_type", activeTab.toString());

                  if (values.title) {
                    formData.append("caption", values.title);
                  }
                } else {
                  // For non-reel content (images, etc.)
                  if (values.file) {
                    formData.append("image", values.file);
                  } else if (
                    postToEdit?.image &&
                    activeTab !== MediaType.Blogs
                  ) {
                    // We don't need to do anything for existing images
                  }
                  formData.append("media_type", activeTab.toString());
                  if (values.title) {
                    formData.append("title", values.title);
                  }
                  if (values.description) {
                    formData.append("description", values.description);
                  }

                  // For blogs, get content from editor and send as caption
                  if (activeTab === MediaType.Blogs) {
                    const editorInstance = editorRef.current?.getInstance();
                    if (editorInstance) {
                      const content = editorInstance.getHTML();
                      if (content) {
                        // Process content to ensure all images have the center styling
                        const processedContent = content.replace(
                          /<img([^>]*)>/g,
                          (match, attributes) => {
                            // Check if style attribute already exists
                            if (attributes.includes("style=")) {
                              // Add margin:0 auto to existing style attribute
                              return match.replace(
                                /style="([^"]*)"/,
                                (styleMatch, styleValue) =>
                                  `style="${styleValue}; display: block; margin: 0 auto;"`
                              );
                            } else {
                              // Add style attribute if it doesn't exist
                              return `<img${attributes} style="display: block; margin: 0 auto;">`;
                            }
                          }
                        );
                        formData.append("html_string_mobile", processedContent);
                      }
                    }

                    // Add references to formData
                    if (values.references && values.references.length > 0) {
                      // Filter out empty URLs
                      const validReferences = values.references.filter(
                        (url) => url && url.trim().length > 0
                      );
                      if (validReferences.length > 0) {
                        validReferences.forEach((ref) => {
                          formData.append("references[]", ref);
                        });
                      }
                    }
                  }
                }

                // Handle shop availability
                if (values.isShopAvailable) {
                  formData.append("isShopAvalible", "true");
                  if (values.shoppingUrl) {
                    formData.append("shoping_url", values.shoppingUrl);
                  }
                }

                // If editing an existing post
                if (postToEdit?.media_id) {
                  formData.append("media_id", postToEdit.media_id.toString());
                }

                // Debug: Log FormData contents
                console.log("FormData contents:");
                for (const [key, value] of formData.entries()) {
                  if (value instanceof File) {
                    console.log(
                      `${key}: File(${value.name}, ${value.size} bytes, ${value.type})`
                    );
                  } else {
                    console.log(`${key}:`, value);
                  }
                }

                // If source URL exists, append it to the formData
                if (values.sourceUrl) {
                  formData.append("source_link", values.sourceUrl);
                }

                // Show a loading toast
                const loadingToast = toast({
                  title: "Loading",
                  description: postToEdit
                    ? `Updating ${getTabLabel(activeTab)}...`
                    : `Creating ${getTabLabel(activeTab)}...`,
                });

                // Use axios directly for more control over the request
                try {
                  const response = await axios.post(
                    `${baseURL}/UploadReels${
                      postToEdit?.media_id
                        ? `?media_id=${postToEdit.media_id}`
                        : ""
                    }`,
                    formData,
                    {
                      headers: {
                        "Content-Type": "multipart/form-data",
                        Authorization: `Bearer ${localStorage.getItem(
                          "token"
                        )}`,
                      },
                      onUploadProgress: (progressEvent) => {
                        const percentCompleted = Math.round(
                          (progressEvent.loaded * 100) / progressEvent.total
                        );
                        setUploadProgress(percentCompleted);
                      },
                    }
                  );

                  // Handle success
                  if (response.status === 200 || response.status === 201) {
                    // Dismiss loading toast
                    loadingToast.dismiss();

                    handleSuccess();

                    toast({
                      title: "Success",
                      description: `${getTabLabel(activeTab)} ${
                        postToEdit ? "updated" : "created"
                      } successfully!`,
                      variant: "success",
                    });

                    // Ensure modal is closed
                    handleModalClose();
                  }
                } catch (error) {
                  // Dismiss loading toast
                  loadingToast.dismiss();
                  console.error("Error uploading content:", error);
                  toast({
                    variant: "destructive",
                    title: "Error",
                    description: postToEdit
                      ? `Failed to update ${getTabLabel(
                          activeTab
                        )}. Please try again.`
                      : `Failed to create ${getTabLabel(
                          activeTab
                        )}. Please try again.`,
                  });
                }
              } catch (error) {
                toast({
                  variant: "destructive",
                  title: "Error",
                  description: postToEdit
                    ? `Failed to update ${getTabLabel(
                        activeTab
                      )}. Please try again.`
                    : `Failed to create ${getTabLabel(
                        activeTab
                      )}. Please try again.`,
                });
                console.error("Error saving post:", error);
              } finally {
                setSubmitting(false);
              }
            }}
          >
            {({
              setFieldValue,
              errors,
              touched,
              isSubmitting,
              values,
              dirty,
            }) => (
              <Form className="space-y-6 max-h-[700px]">
                {activeTab !== MediaType.Banners &&
                  activeTab !== MediaType.Reels && (
                    <>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">
                          Title <span className="text-red-500">*</span>
                        </label>
                        <Field
                          name="title"
                          className="w-full p-2 border rounded-md"
                          placeholder="Enter title"
                        />
                        {errors.title && (
                          <div className="text-red-500 text-sm">
                            {errors.title}
                          </div>
                        )}
                      </div>

                      <div className="space-y-2">
                        <label className="text-sm font-medium">
                          Description <span className="text-red-500">*</span>
                        </label>
                        <Field
                          as="textarea"
                          name="description"
                          className="w-full p-2 border rounded-md h-16"
                          placeholder="Enter description"
                        />
                        {errors.description && touched.description && (
                          <div className="text-red-500 text-sm">
                            {errors.description}
                          </div>
                        )}
                      </div>

                      {activeTab === MediaType.Feeds && (
                        <div className="space-y-2">
                          <label className="text-sm font-medium">
                            Source URL
                          </label>
                          <Field
                            name="sourceUrl"
                            className="w-full p-2 border rounded-md"
                            placeholder="Enter source URL (optional)"
                          />
                          {errors.sourceUrl && touched.sourceUrl && (
                            <div className="text-red-500 text-sm">
                              {errors.sourceUrl}
                            </div>
                          )}
                        </div>
                      )}
                    </>
                  )}

                {activeTab === MediaType.Reels && (
                  <>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">
                        Title <span className="text-red-500">*</span>
                      </label>
                      <Field
                        name="title"
                        className="w-full p-2 border rounded-md"
                        placeholder="Enter title"
                      />
                      {errors.title && touched.title && (
                        <div className="text-red-500 text-sm">
                          {errors.title}
                        </div>
                      )}
                    </div>
                  </>
                )}

                {(activeTab === MediaType.Reels ||
                  activeTab === MediaType.Banners) && (
                  <div className="space-y-4">
                    <div className="flex items-center space-x-2">
                      <Field
                        type="checkbox"
                        name="isShopAvailable"
                        className="rounded border-gray-300"
                      />
                      <span className="text-sm font-medium">
                        Is Shop Available?
                      </span>
                    </div>

                    {values.isShopAvailable && (
                      <div className="space-y-2">
                        <label className="text-sm font-medium">
                          Shopping URL <span className="text-red-500">*</span>
                        </label>
                        <Field
                          name="shoppingUrl"
                          className="w-full p-2 border rounded-md"
                          placeholder="Enter shopping URL"
                        />
                        {errors.shoppingUrl && touched.shoppingUrl && (
                          <div className="text-red-500 text-sm">
                            {errors.shoppingUrl}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}

                <div className="grid grid-cols-1 gap-2">
                  {activeTab === MediaType.Reels ? (
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">
                          Upload Reel
                          {!postToEdit?.video_url && !postToEdit?.image && (
                            <span className="text-red-500">*</span>
                          )}
                        </label>
                        <FileUpload
                          setFieldValue={(file) => setFieldValue("file", file)}
                          file={values.file}
                          existingImage={postToEdit?.video_url}
                          thumbnailUrl={postToEdit?.thumbnail_url}
                          accept="video/mp4"
                          placeholder="Upload your Reel file"
                          isVideo={true}
                          onDeleteExisting={() =>
                            setDeletedExistingMedia((prev) => ({
                              ...prev,
                              file: true,
                            }))
                          }
                        />
                        {errors.file && touched.file && (
                          <div className="text-red-500 text-sm">
                            {errors.file as string}
                          </div>
                        )}
                      </div>

                      <div className="space-y-2">
                        <label className="text-sm font-medium">
                          Upload Thumbnail
                          {!postToEdit?.thumbnail_url && (
                            <span className="text-red-500">*</span>
                          )}
                        </label>
                        <FileUpload
                          setFieldValue={(file) =>
                            setFieldValue("thumbnail", file)
                          }
                          file={values.thumbnail}
                          existingImage={postToEdit?.thumbnail_url}
                          accept="image/png,image/jpeg"
                          placeholder="Upload your Thumbnail file"
                          isVideo={false}
                          onDeleteExisting={() =>
                            setDeletedExistingMedia((prev) => ({
                              ...prev,
                              thumbnail: true,
                            }))
                          }
                        />
                        {errors.thumbnail && touched.thumbnail && (
                          <div className="text-red-500 text-sm">
                            {errors.thumbnail as string}
                          </div>
                        )}
                      </div>
                    </div>
                  ) : activeTab !== MediaType.Blogs ? (
                    <div className="space-y-2">
                      <label className="text-sm font-medium">
                        Upload Image
                        {!postToEdit?.image && (
                          <span className="text-red-500">*</span>
                        )}
                      </label>
                      <FileUpload
                        setFieldValue={(file) => {
                          setFieldValue("file", file);
                          if (!file)
                            setLoadedFiles((prev) => ({ ...prev, file: null }));
                        }}
                        file={values.file}
                        existingImage={postToEdit?.image}
                        accept="image/png,image/jpeg"
                        placeholder="Upload your image"
                        clearParentFileState={() =>
                          setLoadedFiles((prev) => ({ ...prev, file: null }))
                        }
                        onDeleteExisting={() =>
                          setDeletedExistingMedia((prev) => ({
                            ...prev,
                            file: true,
                          }))
                        }
                      />
                      {errors.file && touched.file && (
                        <div className="text-red-500 text-sm">
                          {errors.file as string}
                        </div>
                      )}
                    </div>
                  ) : null}

                  {activeTab === MediaType.Blogs && (
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Content</label>
                      <Editor
                        initialValue={values.content || ""}
                        previewStyle="vertical"
                        height="300px"
                        initialEditType="wysiwyg"
                        useCommandShortcut={true}
                        ref={editorRef}
                        onChange={() => {
                          // Track editor changes for blog content
                          if (activeTab === MediaType.Blogs) {
                            const editorInstance =
                              editorRef.current?.getInstance();
                            if (editorInstance) {
                              const currentContent = editorInstance.getHTML();

                              // Normalize content for comparison
                              const normalizeContent = (content: string) => {
                                if (!content) return "";

                                // More robust normalization to handle all edge cases
                                let normalizedContent = content
                                  .replace(/&nbsp;/g, " ") // Replace non-breaking spaces
                                  .replace(/&amp;/g, "&") // Replace HTML entities
                                  .replace(/&lt;/g, "<") // Replace HTML entities
                                  .replace(/&gt;/g, ">") // Replace HTML entities
                                  .replace(/&quot;/g, '"') // Replace HTML entities
                                  .replace(/&#39;/g, "'") // Replace HTML entities
                                  .replace(/\s+/g, " ") // Normalize whitespace
                                  .trim();

                                // Remove empty paragraphs and normalize structure
                                normalizedContent = normalizedContent
                                  .replace(/<p><\/p>/g, "") // Remove empty paragraphs
                                  .replace(/<p>\s*<\/p>/g, "") // Remove paragraphs with only whitespace
                                  .replace(/<br\s*\/?>/g, "") // Remove line breaks for comparison
                                  .replace(/\s+/g, " ") // Normalize whitespace again
                                  .trim();

                                // Simple image handling - just normalize to <img> tags
                                normalizedContent = normalizedContent
                                  .replace(/<img[^>]*>/gi, "<img>") // Replace all img tags with simple <img>
                                  .replace(/\s+/g, " ") // Normalize whitespace again
                                  .trim();

                                return normalizedContent;
                              };

                              const normalizedCurrent =
                                normalizeContent(currentContent);
                              const normalizedInitial =
                                normalizeContent(initialEditorContent);

                              // Simple comparison - just like text editing
                              const isDirty =
                                normalizedCurrent !== normalizedInitial;

                              // Debug logging
                              console.log("Editor content change detected:");
                              console.log("Current content:", currentContent);
                              console.log(
                                "Normalized current:",
                                normalizedCurrent
                              );
                              console.log(
                                "Initial content:",
                                initialEditorContent
                              );
                              console.log(
                                "Normalized initial:",
                                normalizedInitial
                              );
                              console.log("Is dirty:", isDirty);

                              // Simple logging for debugging
                              console.log("📊 Content comparison:");
                              console.log("Current:", normalizedCurrent);
                              console.log("Initial:", normalizedInitial);
                              console.log(
                                "Are they equal?",
                                normalizedCurrent === normalizedInitial
                              );

                              // Additional logging for original state detection
                              if (!isDirty) {
                                console.log(
                                  "✅ Content is back to original state - Update button should be disabled"
                                );
                                console.log(
                                  "📝 Content restoration detected: All changes have been reverted"
                                );

                                // Log image count for debugging
                                const currentImages = (
                                  normalizedCurrent.match(/<img>/g) || []
                                ).length;
                                const initialImages = (
                                  normalizedInitial.match(/<img>/g) || []
                                ).length;
                                console.log(
                                  `🖼️ Images - Current: ${currentImages}, Initial: ${initialImages}`
                                );
                              } else {
                                console.log(
                                  "🔄 Content has changes - Update button should be enabled"
                                );
                                console.log(
                                  "✏️ Content modification detected: Changes are present"
                                );

                                // Log what type of changes are detected
                                const currentImages = (
                                  normalizedCurrent.match(/<img>/g) || []
                                ).length;
                                const initialImages = (
                                  normalizedInitial.match(/<img>/g) || []
                                ).length;
                                if (currentImages !== initialImages) {
                                  console.log(
                                    `🖼️ Image count changed - Current: ${currentImages}, Initial: ${initialImages}`
                                  );
                                }
                              }

                              setIsEditorDirty(isDirty);
                            }
                          }
                        }}
                        hooks={{
                          addImageBlobHook: async (
                            blob: File,
                            callback: (url: string, altText: string) => void
                          ) => {
                            try {
                              const userId = localStorage.getItem("userId");
                              if (!userId) {
                                toast({
                                  variant: "destructive",
                                  title: "Error",
                                  description:
                                    "User ID not found. Please log in again.",
                                });
                                return false;
                              }

                              // Show loading indicator
                              const loadingImageToast = toast({
                                title: "Loading",
                                description: "Uploading image...",
                              });

                              // Call the upload image API
                              const imageUploadResponse =
                                await uploadImageMutation.mutateAsync({
                                  image: blob,
                                  user_id: userId,
                                });

                              // Get the image URL from the response
                              const imageUrl = imageUploadResponse.data.image;

                              // Dismiss the loading toast
                              loadingImageToast.dismiss();
                              toast({
                                title: "Success",
                                description: "Image uploaded successfully",
                              });

                              // Callback for the image URL - this will render the image in the editor
                              callback(imageUrl, blob.name);

                              // After the image is inserted, select it and add a style attribute
                              setTimeout(() => {
                                const editorInstance =
                                  editorRef.current?.getInstance();
                                if (editorInstance) {
                                  // Find the most recently added image and modify its HTML
                                  const content = editorInstance.getHTML();
                                  const newContent = content.replace(
                                    `<img src="${imageUrl}" alt="${blob.name}">`,
                                    `<img src="${imageUrl}" alt="${blob.name}" style="display: block; margin: 0 auto;">`
                                  );

                                  // Set the modified content back to the editor
                                  editorInstance.setHTML(newContent);
                                }
                              }, 100);

                              return true;
                            } catch (error) {
                              console.error(
                                "Error uploading blog image:",
                                error
                              );
                              toast({
                                variant: "destructive",
                                title: "Error",
                                description:
                                  "Failed to upload image. Please try again.",
                              });
                              return false;
                            }
                          },
                        }}
                      />
                      {errors.content && touched.content && (
                        <div className="text-red-500 text-sm">
                          {errors.content}
                        </div>
                      )}
                    </div>
                  )}

                  {activeTab === MediaType.Blogs && (
                    <div className="space-y-2">
                      <label className="text-sm font-medium">References</label>
                      <div className="space-y-3">
                        {values.references &&
                          values.references.map((url, index) => (
                            <div
                              key={index}
                              className="flex gap-2 items-center"
                            >
                              <span className="text-sm font-medium text-gray-600 w-6">
                                {index + 1}.
                              </span>
                              <Field
                                name={`references.${index}`}
                                className="flex-1 p-2 border rounded-md"
                                placeholder="Enter URL (e.g., https://www.example.com)"
                                onChange={(
                                  e: React.ChangeEvent<HTMLInputElement>
                                ) => {
                                  // Update the form field value first
                                  const newReferences = [
                                    ...(values.references || []),
                                  ];
                                  newReferences[index] = e.target.value;
                                  setFieldValue("references", newReferences);

                                  // Track references changes for blog content
                                  if (activeTab === MediaType.Blogs) {
                                    // Normalize references for comparison (remove empty strings)
                                    const normalizeReferences = (
                                      refs: string[]
                                    ) =>
                                      refs
                                        .filter((ref) => ref.trim() !== "")
                                        .map((ref) => ref.trim());

                                    const normalizedCurrent =
                                      normalizeReferences(newReferences);
                                    const normalizedInitial =
                                      normalizeReferences(initialReferences);

                                    const isDirty =
                                      JSON.stringify(normalizedCurrent) !==
                                      JSON.stringify(normalizedInitial);

                                    setIsReferencesDirty(isDirty);
                                  }
                                }}
                              />
                              <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  const newReferences =
                                    values.references.filter(
                                      (_, i) => i !== index
                                    );
                                  setFieldValue("references", newReferences);
                                  // Track references changes for blog content
                                  if (activeTab === MediaType.Blogs) {
                                    // Normalize references for comparison (remove empty strings)
                                    const normalizeReferences = (
                                      refs: string[]
                                    ) =>
                                      refs
                                        .filter((ref) => ref.trim() !== "")
                                        .map((ref) => ref.trim());

                                    const normalizedCurrent =
                                      normalizeReferences(newReferences);
                                    const normalizedInitial =
                                      normalizeReferences(initialReferences);

                                    const isDirty =
                                      JSON.stringify(normalizedCurrent) !==
                                      JSON.stringify(normalizedInitial);
                                    setIsReferencesDirty(isDirty);
                                  }
                                }}
                                className="text-red-500 hover:text-red-700"
                              >
                                <X size={16} />
                              </Button>
                            </div>
                          ))}
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            const newReferences = [
                              ...(values.references || []),
                              "",
                            ];
                            setFieldValue("references", newReferences);
                            // Track references changes for blog content
                            if (activeTab === MediaType.Blogs) {
                              // Normalize references for comparison (remove empty strings)
                              const normalizeReferences = (refs: string[]) =>
                                refs
                                  .filter((ref) => ref.trim() !== "")
                                  .map((ref) => ref.trim());

                              const normalizedCurrent =
                                normalizeReferences(newReferences);
                              const normalizedInitial =
                                normalizeReferences(initialReferences);

                              const isDirty =
                                JSON.stringify(normalizedCurrent) !==
                                JSON.stringify(normalizedInitial);
                              setIsReferencesDirty(isDirty);
                            }
                          }}
                          className="flex items-center gap-2"
                        >
                          <Plus size={16} />
                          Add Reference URL
                        </Button>
                      </div>
                      {errors.references && touched.references && (
                        <div className="text-red-500 text-sm">
                          {Array.isArray(errors.references)
                            ? errors.references.map((error, index) =>
                                error &&
                                values.references[index] &&
                                values.references[index].trim().length > 0 ? (
                                  <div key={index}>{error}</div>
                                ) : null
                              )
                            : errors.references}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Upload Progress Bar - Show when upload is in progress */}
                {uploadImageMutation.isPending &&
                  activeTab === MediaType.Reels && (
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="font-medium">Upload Progress</span>
                        <span>{uploadProgress}%</span>
                      </div>
                      <Progress value={uploadProgress} className="h-2" />
                    </div>
                  )}

                <div className="flex justify-end gap-3 pt-4 pb-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleModalClose}
                    disabled={isSubmitting}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={(() => {
                      const isDisabled =
                        isSubmitting ||
                        uploadReelsMutation.isPending ||
                        uploadImageMutation.isPending ||
                        (postToEdit &&
                          !dirty &&
                          !isEditorDirty &&
                          !isReferencesDirty) ||
                        (!postToEdit &&
                          activeTab === MediaType.Blogs &&
                          !isEditorDirty &&
                          !isReferencesDirty);

                      // Debug logging for button state
                      console.log("Button disabled state:", {
                        isSubmitting,
                        uploadReelsPending: uploadReelsMutation.isPending,
                        uploadImagePending: uploadImageMutation.isPending,
                        postToEdit: !!postToEdit,
                        dirty,
                        isEditorDirty,
                        isReferencesDirty,
                        activeTab,
                        isDisabled,
                      });

                      // Additional logging for original state
                      if (
                        postToEdit &&
                        !dirty &&
                        !isEditorDirty &&
                        !isReferencesDirty
                      ) {
                        console.log(
                          "🔒 Update button disabled: Content is in original state (no changes detected)"
                        );
                        console.log(
                          "📋 All content has been restored to its original state"
                        );
                      } else if (
                        postToEdit &&
                        (dirty || isEditorDirty || isReferencesDirty)
                      ) {
                        console.log(
                          "🔓 Update button enabled: Changes detected in content"
                        );
                        console.log(
                          "📝 Content modifications are present and need to be saved"
                        );
                      }

                      return isDisabled;
                    })()}
                  >
                    {uploadReelsMutation.isPending ||
                    uploadImageMutation.isPending
                      ? postToEdit
                        ? "Updating..."
                        : "Creating..."
                      : postToEdit
                      ? "Update"
                      : "Submit"}
                  </Button>
                </div>
              </Form>
            )}
          </Formik>
        </DialogContent>
      </Dialog>

      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete {getTabLabel(activeTab)}</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this{" "}
              {getTabLabel(activeTab).toLowerCase()}? This action cannot be
              undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowDeleteDialog(false);
                setPostToDelete(null);
              }}
              disabled={deleteMediaMutation.isPending}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleDeleteConfirm}
              disabled={deleteMediaMutation.isPending}
            >
              {deleteMediaMutation.isPending
                ? `Deleting...`
                : `Delete ${getTabLabel(activeTab)}`}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog
        open={viewModal.isOpen}
        onOpenChange={() =>
          setViewModal({ isOpen: false, post: null, isVideoPlaying: false })
        }
      >
        <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>View Post Details</DialogTitle>
          </DialogHeader>
          {viewModal.post && (
            <div className="space-y-4">
              {activeTab !== MediaType.Banners && (
                <>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Title</label>
                    <div className="p-2 border rounded-md bg-gray-50">
                      {viewModal.post.title ||
                        viewModal.post.caption ||
                        "Untitled"}
                    </div>
                  </div>
                  {activeTab !== MediaType.Reels && (
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Description</label>
                      <div className="p-2 border rounded-md bg-gray-50 min-h-[50px]">
                        {viewModal.post.description || "No description"}
                      </div>
                    </div>
                  )}
                </>
              )}

              {viewModal.post.image && (
                <div className="space-y-2">
                  <label className="text-sm font-medium">Media</label>
                  <div className="border rounded-md p-2">
                    {activeTab === MediaType.Reels ? (
                      !viewModal.isVideoPlaying ? (
                        <div
                          className="cursor-pointer relative"
                          onClick={handleViewThumbnailClick}
                          aria-label="Click to play video"
                        >
                          <img
                            src={
                              viewModal.post.thumbnail_url ||
                              "/video-placeholder.jpg"
                            }
                            alt="Video thumbnail"
                            className="w-full rounded max-h-[200px] object-contain"
                          />
                          <div className="absolute inset-0 flex items-center justify-center">
                            <div className="bg-black bg-opacity-30 p-3 rounded-full">
                              <Play size={24} className="text-white" />
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="pt-2 pb-6">
                          <video
                            ref={viewVideoRef}
                            src={
                              (viewModal.post as MediaPost).video_url ||
                              viewModal.post.image
                            }
                            poster={viewModal.post.thumbnail_url}
                            controls
                            className="w-full rounded max-h-[200px] object-contain"
                            preload="none"
                            autoPlay
                          />
                        </div>
                      )
                    ) : (
                      <img
                        src={viewModal.post.image}
                        alt={viewModal.post.title || "Media"}
                        className="w-full rounded max-h-[200px] object-contain"
                      />
                    )}
                  </div>
                </div>
              )}

              {activeTab === MediaType.Reels && (
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Likes</label>
                    <div className="p-2 border rounded-md bg-gray-50">
                      {viewModal.post.likes_count || "N/A"}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Comments</label>
                    <div className="p-2 border rounded-md bg-gray-50">
                      {viewModal.post.comments_count || "N/A"}
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <label className="text-sm font-medium">Date Created</label>
                <div className="p-2 border rounded-md bg-gray-50">
                  {(() => {
                    const date = new Date(viewModal.post.createdAt);
                    const day = date.getDate().toString().padStart(2, "0");
                    const month = (date.getMonth() + 1)
                      .toString()
                      .padStart(2, "0");
                    const year = date.getFullYear();
                    return `${day}-${month}-${year}`;
                  })()}
                </div>
              </div>
            </div>
          )}
          {(viewModal.post?.shoping_url || viewModal.post?.shoppingUrl) && (
            <div className="space-y-2">
              <label className="text-sm font-medium">Shopping URL</label>
              <div className="p-2 border rounded-md bg-gray-50 break-all text-blue-600">
                <a
                  href={
                    viewModal.post.shoping_url || viewModal.post.shoppingUrl
                  }
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:underline"
                >
                  {viewModal.post.shoping_url || viewModal.post.shoppingUrl}
                </a>
              </div>
            </div>
          )}
          {viewModal.post?.source_link && (
            <div className="space-y-2">
              <label className="text-sm font-medium">Source URL</label>
              <div className="p-2 border rounded-md bg-gray-50 break-all text-blue-600">
                <a
                  href={viewModal.post.source_link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:underline"
                >
                  {viewModal.post.source_link}
                </a>
              </div>
            </div>
          )}
          {viewModal.post?.references &&
            viewModal.post.references.length > 0 && (
              <div className="space-y-2">
                <label className="text-sm font-medium">References</label>
                <div className="p-2 border rounded-md bg-gray-50">
                  <ul className="list-decimal list-inside space-y-1">
                    {viewModal.post.references.map((url, index) => (
                      <li key={index} className="break-all text-blue-600">
                        <a
                          href={url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="hover:underline"
                        >
                          {url}
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

// Update the FileUpload component to add padding for better control visibility
const FileUpload: React.FC<
  FileUploadProps & { clearParentFileState?: () => void }
> = ({
  setFieldValue,
  file,
  existingImage,
  thumbnailUrl,
  accept,
  placeholder = "Upload your file",
  isVideo = false,
  clearParentFileState,
  onDeleteExisting,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [objectUrl, setObjectUrl] = useState<string | null>(null);
  // Track if we've explicitly deleted the existing image
  const [existingDeleted, setExistingDeleted] = useState(false);
  // New state to track if video is actively being viewed
  const [videoActive, setVideoActive] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      // Clean up previous object URL
      if (objectUrl) {
        URL.revokeObjectURL(objectUrl);
      }
      // Create new object URL for preview
      const newObjectUrl = URL.createObjectURL(selectedFile);
      setObjectUrl(newObjectUrl);
      setFieldValue(selectedFile);
      setExistingDeleted(false);
      setVideoActive(false);
    }
  };

  const handleButtonClick = () => {
    fileInputRef.current?.click();
  };

  const handleDeleteFile = () => {
    // Clean up object URL
    if (objectUrl) {
      URL.revokeObjectURL(objectUrl);
      setObjectUrl(null);
    }
    setFieldValue(null);
    setExistingDeleted(true);
    setVideoActive(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
    if (clearParentFileState) {
      clearParentFileState();
    }
    // Call onDeleteExisting if there's an existing image that hasn't been deleted yet
    if (existingImage && !existingDeleted && onDeleteExisting) {
      onDeleteExisting();
    }
  };

  // Cleanup effect for object URLs
  useEffect(() => {
    return () => {
      if (objectUrl) {
        URL.revokeObjectURL(objectUrl);
      }
    };
  }, [objectUrl]);

  // Function to handle video play events
  const handleVideoPlay = () => {
    setVideoActive(true);
  };

  // Function to handle thumbnail click
  const handleThumbnailClick = () => {
    setVideoActive(true);
    // Play video after ensuring it's loaded
    if (videoRef.current) {
      videoRef.current.load(); // Reload the video to ensure clean state
      videoRef.current.play().catch((err) => {
        console.error("Error playing video:", err);
      });
    }
  };

  const fileSize = file ? (file.size / (1024 * 1024)).toFixed(2) + " MB" : "";

  // Only show preview if we have a file or an existing image that hasn't been deleted
  const showPreview = file || (existingImage && !existingDeleted);

  // Add a key to force video re-render when switching between states
  const videoKey = file ? `new-${file.name}` : `existing-${existingImage}`;

  // Add state to track if video is in a stable state
  const [videoStable, setVideoStable] = useState(false);

  // Effect to manage video stability
  useEffect(() => {
    if (file || existingImage) {
      setVideoStable(false);
      // Set stable after a short delay to allow video to load
      const timer = setTimeout(() => {
        setVideoStable(true);
      }, 200);
      return () => clearTimeout(timer);
    }
  }, [file, existingImage]);

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-2">
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          accept={accept}
          className="hidden"
        />
        <Button
          type="button"
          onClick={handleButtonClick}
          className="flex items-center gap-2"
        >
          <Upload size={16} />
          {!showPreview ? placeholder : "Change file"}
        </Button>

        {file && (
          <div className="text-sm text-gray-500">
            Selected: {file.name} ({fileSize})
          </div>
        )}

        {existingImage && !file && !existingDeleted && (
          <div className="text-sm text-gray-500">Using existing file</div>
        )}
      </div>

      {/* Preview section - only show if we have something to preview */}
      {showPreview && (
        <div className="relative border rounded-md p-3 bg-gray-50">
          {/* Position the X button with higher z-index to ensure it's always on top */}
          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={handleDeleteFile}
            className="absolute top-2 right-2 h-6 w-6 rounded-full bg-gray-200 hover:bg-gray-300 z-10"
          >
            <X size={12} />
          </Button>

          <div className="flex items-center justify-center relative">
            {/* Loading indicator for video stability */}
            {isVideo && !videoStable && (
              <div className="absolute inset-0 flex items-center justify-center bg-gray-100 rounded z-5">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-600"></div>
              </div>
            )}
            {file ? (
              isVideo ? (
                <div className="pt-2 pb-6 w-full min-h-[200px] flex items-center justify-center">
                  <video
                    key={videoKey}
                    src={objectUrl || URL.createObjectURL(file)}
                    controls
                    className="max-h-[200px] max-w-full object-contain rounded"
                    preload="metadata"
                    onPlay={handleVideoPlay}
                    onLoadedData={() => setVideoStable(true)}
                    playsInline
                    muted={false}
                    style={{
                      minHeight: "150px",
                      maxHeight: "200px",
                      width: "auto",
                      height: "auto",
                    }}
                  />
                </div>
              ) : (
                <img
                  src={objectUrl || URL.createObjectURL(file)}
                  alt="Preview"
                  className="max-h-[200px] max-w-full object-contain rounded"
                />
              )
            ) : existingImage && !existingDeleted ? (
              isVideo ? (
                <div className="relative flex items-center justify-center w-full">
                  {!videoActive ? (
                    <div
                      className="cursor-pointer relative"
                      onClick={handleThumbnailClick}
                      aria-label="Click to play video"
                    >
                      <img
                        src={
                          thumbnailUrl ||
                          existingImage ||
                          "/video-placeholder.jpg"
                        }
                        alt="Video thumbnail"
                        className="max-h-[200px] max-w-full object-contain rounded"
                      />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="bg-black bg-opacity-30 p-3 rounded-full">
                          <Play size={24} className="text-white" />
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="pt-2 pb-6 w-full min-h-[200px] flex items-center justify-center">
                      <video
                        key={videoKey}
                        ref={videoRef}
                        src={existingImage}
                        controls
                        className="max-h-[200px] max-w-full object-contain rounded"
                        preload="metadata"
                        playsInline
                        muted={false}
                        onLoadedData={() => {
                          setVideoStable(true);
                          // Ensure video is ready before playing
                          if (videoRef.current) {
                            videoRef.current.play().catch((err) => {
                              console.error("Error auto-playing video:", err);
                            });
                          }
                        }}
                        style={{
                          minHeight: "150px",
                          maxHeight: "200px",
                          width: "auto",
                          height: "auto",
                        }}
                      />
                    </div>
                  )}
                </div>
              ) : (
                <img
                  src={existingImage}
                  alt="Current file"
                  className="max-h-[200px] max-w-full object-contain rounded"
                />
              )
            ) : null}
          </div>
        </div>
      )}
    </div>
  );
};

export default PostsPage;
