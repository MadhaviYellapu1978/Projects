import React, { useState } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import { useChangePassword } from "../services/api";
import { useToast } from "@/hooks/use-toast";
import { Eye, EyeOff } from "lucide-react"; // 👁️ Icons for show/hide password

const ForgetPassword = ({
  setShowPasswordModal,
}: {
  setShowPasswordModal: (show: boolean) => void;
}) => {
  const changePasswordMutation = useChangePassword();
  const { toast } = useToast();

  const [showOldPassword, setShowOldPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const validationSchema = Yup.object().shape({
    oldPassword: Yup.string().required("Old password is required"),
    newPassword: Yup.string()
      .required("Please enter a valid new password")
      .min(8, "Password must be at least 8 characters"),
    confirmPassword: Yup.string()
      .oneOf([Yup.ref("newPassword"), null], "Passwords must match")
      .required("Please confirm your password"),
  });

  const formik = useFormik({
    initialValues: {
      oldPassword: "",
      newPassword: "",
      confirmPassword: "",
    },
    validationSchema,
    onSubmit: async (values) => {
      try {
        const userId = localStorage.getItem("userId");
        if (!userId) {
          toast.error("User ID not found. Please login again.");
          return;
        }

        await changePasswordMutation.mutateAsync({
          old_password: values.oldPassword,
          new_password: values.newPassword,
          confirm_password: values.confirmPassword,
          user_id: userId,
        });

        toast({
          title: "Password changed successfully!",
        });
        formik.resetForm();
        setShowPasswordModal(false);
      } catch (error: any) {
        toast({
          title: error.response?.data?.message || "Failed to change password",
        });
      }
    },
  });

  return (
    <div className="max-w-md mx-auto p-6 bg-white rounded-lg shadow-md">
      <form onSubmit={formik.handleSubmit} className="space-y-4">
        {/* Old Password */}
        <div className="relative">
          <label htmlFor="oldPassword" className="block font-medium mb-1">
            Old Password*
          </label>
          <input
            id="oldPassword"
            name="oldPassword"
            type={showOldPassword ? "text" : "password"}
            className={`w-full px-3 py-2 border rounded focus:outline-none pr-10
              ${
                formik.touched.oldPassword && formik.errors.oldPassword
                  ? "border-red-500"
                  : "border-gray-300"
              }
            `}
            value={formik.values.oldPassword}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
          />
          {/* Eye Icon */}
          <div
            className="absolute right-3 top-[3rem] transform -translate-y-1/2 flex items-center cursor-pointer"
            onClick={() => setShowOldPassword((prev) => !prev)}
          >
            {showOldPassword ? (
              <EyeOff className="h-5 w-5 text-gray-500" />
            ) : (
              <Eye className="h-5 w-5 text-gray-500" />
            )}
          </div>
          {formik.touched.oldPassword && formik.errors.oldPassword && (
            <p className="mt-1 text-red-500 text-sm">
              {formik.errors.oldPassword}
            </p>
          )}
        </div>

        {/* New Password */}
        <div className="relative">
          <label htmlFor="newPassword" className="block font-medium mb-1">
            New Password*
          </label>
          <input
            id="newPassword"
            name="newPassword"
            type={showNewPassword ? "text" : "password"}
            className={`w-full px-3 py-2 border rounded focus:outline-none pr-10
              ${
                formik.touched.newPassword && formik.errors.newPassword
                  ? "border-red-500"
                  : "border-gray-300"
              }
            `}
            value={formik.values.newPassword}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
          />
          {/* Eye Icon */}
          <div
            className="absolute right-3 top-[3rem] transform -translate-y-1/2 flex items-center cursor-pointer"
            onClick={() => setShowNewPassword((prev) => !prev)}
          >
            {showNewPassword ? (
              <EyeOff className="h-5 w-5 text-gray-500" />
            ) : (
              <Eye className="h-5 w-5 text-gray-500" />
            )}
          </div>
          {formik.touched.newPassword && formik.errors.newPassword && (
            <p className="mt-1 text-red-500 text-sm">
              {formik.errors.newPassword}
            </p>
          )}
        </div>

        {/* Confirm Password */}
        <div className="relative">
          <label htmlFor="confirmPassword" className="block font-medium mb-1">
            Confirm Password*
          </label>
          <input
            id="confirmPassword"
            name="confirmPassword"
            type={showConfirmPassword ? "text" : "password"}
            className={`w-full px-3 py-2 border rounded focus:outline-none pr-10
              ${
                formik.touched.confirmPassword && formik.errors.confirmPassword
                  ? "border-red-500"
                  : "border-gray-300"
              }
            `}
            value={formik.values.confirmPassword}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
          />
          {/* Eye Icon */}
          <div
            className="absolute right-3 top-[3rem] transform -translate-y-1/2 flex items-center cursor-pointer"
            onClick={() => setShowConfirmPassword((prev) => !prev)}
          >
            {showConfirmPassword ? (
              <EyeOff className="h-5 w-5 text-gray-500" />
            ) : (
              <Eye className="h-5 w-5 text-gray-500" />
            )}
          </div>
          {formik.touched.confirmPassword && formik.errors.confirmPassword && (
            <p className="mt-1 text-red-500 text-sm">
              {formik.errors.confirmPassword}
            </p>
          )}
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          className={`w-full py-2 rounded text-white
            ${
              formik.isValid &&
              formik.dirty &&
              !changePasswordMutation.isPending
                ? "bg-blue-600 hover:bg-blue-700"
                : "bg-gray-400 cursor-not-allowed"
            }
          `}
          disabled={
            !formik.isValid || !formik.dirty || changePasswordMutation.isPending
          }
        >
          {changePasswordMutation.isPending
            ? "Changing Password..."
            : "Change Password"}
        </button>
      </form>
    </div>
  );
};

export default ForgetPassword;
