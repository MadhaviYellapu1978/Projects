import React, { useState, useRef } from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { mockData } from "../data/mockData";
import TabButton from "../components/ui/TabButton";
import EventCard from "../components/ui/EventCard";
import { CreateButton } from "../components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogClose,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { X, Upload, File } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface EventFormValues {
  title: string;
  description: string;
  date: string;
  type: string;
  location: string;
  image: File | null;
  maxParticipants: number;
  registrationDeadline: string;
  price: number;
}

const validationSchema = Yup.object().shape({
  title: Yup.string()
    .required("Title is required")
    .min(3, "Title must be at least 3 characters"),
  description: Yup.string()
    .required("Description is required")
    .min(50, "Description must be at least 50 characters"),
  date: Yup.string().required("Date is required"),
  type: Yup.string().required("Event type is required"),
  location: Yup.string().required("Location is required"),
  maxParticipants: Yup.number()
    .required("Maximum participants is required")
    .min(1, "Must have at least 1 participant"),
  registrationDeadline: Yup.string().required(
    "Registration deadline is required"
  ),
  price: Yup.number()
    .required("Price is required")
    .min(0, "Price cannot be negative"),
});

const initialValues: EventFormValues = {
  title: "",
  description: "",
  date: "",
  type: "",
  location: "",
  image: null,
  maxParticipants: 0,
  registrationDeadline: "",
  price: 0,
};

const CreateEventModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
}> = ({ isOpen, onClose }) => {
  const [image, setImage] = useState<File | null>(null);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setImage(e.target.files[0]);
    }
  };

  const handleRemoveFile = () => {
    setImage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleSubmit = async (
    values: EventFormValues,
    {
      setSubmitting,
      setFieldTouched,
    }: {
      setSubmitting: (isSubmitting: boolean) => void;
      setFieldTouched: (field: string, touched: boolean) => void;
    }
  ) => {
    try {
      // Touch all fields to show validation errors if any
      Object.keys(initialValues).forEach((field) => {
        setFieldTouched(field, true);
      });

      // Here you would typically upload the image and create the event
      console.log("Creating event with values:", values);

      toast({
        title: "Success",
        description: "Event created successfully",
        className: "bg-green-50 border-green-200",
      });
      onClose();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create event. Please try again.",
        className: "bg-red-50 border-red-200",
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">Create Event</DialogTitle>
        </DialogHeader>
        <DialogClose className="absolute right-4 top-4">
          <X className="h-4 w-4" />
          <span className="sr-only">Close</span>
        </DialogClose>

        <Formik
          initialValues={initialValues}
          validationSchema={validationSchema}
          validateOnChange={true}
          validateOnBlur={true}
          onSubmit={handleSubmit}
        >
          {({ isSubmitting, errors, touched }) => (
            <Form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block mb-2 font-medium">Event Title</label>
                  <Field
                    name="title"
                    placeholder="Enter event title"
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  />
                  <ErrorMessage
                    name="title"
                    component="div"
                    className="text-red-500 text-sm mt-1"
                  />
                </div>

                <div>
                  <label className="block mb-2 font-medium">Event Type</label>
                  <Field
                    as="select"
                    name="type"
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  >
                    <option value="">Select Event Type</option>
                    <option value="Events">Events</option>
                    <option value="Webinars">Webinars</option>
                    <option value="Workshops">Workshops</option>
                    <option value="Conferences">Conferences</option>
                  </Field>
                  <ErrorMessage
                    name="type"
                    component="div"
                    className="text-red-500 text-sm mt-1"
                  />
                </div>

                <div>
                  <label className="block mb-2 font-medium">Date</label>
                  <Field
                    name="date"
                    type="datetime-local"
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  />
                  <ErrorMessage
                    name="date"
                    component="div"
                    className="text-red-500 text-sm mt-1"
                  />
                </div>

                <div>
                  <label className="block mb-2 font-medium">Location</label>
                  <Field
                    name="location"
                    placeholder="Enter event location"
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  />
                  <ErrorMessage
                    name="location"
                    component="div"
                    className="text-red-500 text-sm mt-1"
                  />
                </div>

                <div>
                  <label className="block mb-2 font-medium">
                    Max Participants
                  </label>
                  <Field
                    name="maxParticipants"
                    type="number"
                    min="1"
                    placeholder="Enter maximum participants"
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  />
                  <ErrorMessage
                    name="maxParticipants"
                    component="div"
                    className="text-red-500 text-sm mt-1"
                  />
                </div>

                <div>
                  <label className="block mb-2 font-medium">
                    Registration Deadline
                  </label>
                  <Field
                    name="registrationDeadline"
                    type="datetime-local"
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  />
                  <ErrorMessage
                    name="registrationDeadline"
                    component="div"
                    className="text-red-500 text-sm mt-1"
                  />
                </div>

                <div>
                  <label className="block mb-2 font-medium">Price</label>
                  <Field
                    name="price"
                    type="number"
                    min="0"
                    step="1"
                    placeholder="Enter event price"
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  />
                  <ErrorMessage
                    name="price"
                    component="div"
                    className="text-red-500 text-sm mt-1"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block mb-2 font-medium">Description</label>
                  <Field
                    as="textarea"
                    name="description"
                    placeholder="Enter event description"
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-md min-h-[100px] focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  />
                  <ErrorMessage
                    name="description"
                    component="div"
                    className="text-red-500 text-sm mt-1"
                  />
                </div>

                <div>
                  <label className="block mb-2 font-medium">Event Image</label>
                  <div className="relative">
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileUpload}
                      accept="image/*"
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                    />
                    {image ? (
                      <div className="flex items-center justify-between px-4 py-3 bg-gray-50 border border-gray-200 rounded-md">
                        <div className="flex items-center gap-2">
                          <File className="h-5 w-5 text-primary" />
                          <span className="text-sm truncate max-w-[180px]">
                            {image.name}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={handleRemoveFile}
                          className="text-gray-500 hover:text-red-500"
                        >
                          <X size={16} />
                        </button>
                      </div>
                    ) : (
                      <div className="flex justify-between items-center px-4 py-3 bg-gray-50 border border-gray-200 rounded-md">
                        <span className="text-gray-500">
                          Upload Image (JPG, PNG)
                        </span>
                        <Upload className="h-5 w-5 text-gray-500" />
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <DialogFooter>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full md:w-auto bg-primary text-white px-8 py-2 rounded-md hover:bg-primary/90 disabled:opacity-50"
                >
                  {isSubmitting ? "Creating..." : "Create Event"}
                </button>
              </DialogFooter>
            </Form>
          )}
        </Formik>
      </DialogContent>
    </Dialog>
  );
};

const EventsPage = () => {
  const [activeTab, setActiveTab] = useState("Events");
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  const renderEventGrid = () => {
    let events;

    switch (activeTab) {
      case "Events":
        events = mockData.events;
        break;
      case "Webinars":
        events = mockData.webinars;
        break;
      case "Workshops":
        events = mockData.workshops;
        break;
      case "Conferences":
        events = mockData.conferences;
        break;
      default:
        events = mockData.events;
    }

    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {events.map((event, index) => (
          <EventCard
            key={index}
            image={event.image}
            title={event.title}
            date={event.date}
            type={event.type}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div className="flex space-x-4 overflow-x-auto">
          <TabButton
            label="Events"
            active={activeTab === "Events"}
            onClick={() => setActiveTab("Events")}
          />
          <TabButton
            label="Webinars"
            active={activeTab === "Webinars"}
            onClick={() => setActiveTab("Webinars")}
          />
          <TabButton
            label="Workshops"
            active={activeTab === "Workshops"}
            onClick={() => setActiveTab("Workshops")}
          />
          <TabButton
            label="Conferences"
            active={activeTab === "Conferences"}
            onClick={() => setActiveTab("Conferences")}
          />
        </div>
        <div className="flex gap-4">
          <button className="outline-button">Event Requests</button>
          <CreateButton
            variant="default"
            onClick={() => setIsCreateModalOpen(true)}
          >
            Create Event
          </CreateButton>
        </div>
      </div>

      {renderEventGrid()}

      <CreateEventModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
      />
    </div>
  );
};

export default EventsPage;
