/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState } from "react";
import { Edit2, Trash2 } from "lucide-react";
import DataTable from "../components/ui/DataTable";
import {
  useAllAdmins,
  useOnboardAdmin,
  useDeleteOnboardAdmin,
  useRolesWeb,
} from "../services/api";
import { useToast } from "../components/ui/use-toast";
import OnboardAdminModal from "../components/admins/OnboardAdminModal";
import DeleteConfirmationModal from "../components/admins/DeleteConfirmationModal";
import editicon from "../../public/lovable-uploads/edit bg.svg";
import deleteicon from "../../public/lovable-uploads/delete bg.svg";

interface AdminRecord {
  user_id: string;
  first_name: string;
  last_name: string;
  email: string;
  phoneNumber: string;
  role_name: string;
  role_id: number;
}

const Onboard: React.FC = () => {
  const { toast } = useToast();
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState<number | undefined>();
  const [showOnboardModal, setShowOnboardModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedAdmin, setSelectedAdmin] = useState<AdminRecord | null>(null);

  // Fetch roles using existing hook
  const { data: rolesData, isLoading: isRolesLoading } = useRolesWeb();

  const {
    data: adminsData,
    isLoading,
    refetch,
  } = useAllAdmins(
    page,
    pageSize,
    undefined, // Don't pass search term to API, use frontend filtering only
    roleFilter
  );

  // Frontend filtering for admin search to ensure email search works
  const filteredAdminsData = React.useMemo(() => {
    if (!searchTerm) {
      return adminsData?.result || [];
    }

    const searchTermLower = searchTerm.toLowerCase();
    const filtered = (adminsData?.result || []).filter((admin) => {
      const matches =
        (admin.first_name || "").toLowerCase().includes(searchTermLower) ||
        (admin.last_name || "").toLowerCase().includes(searchTermLower) ||
        (admin.email || "").toLowerCase().includes(searchTermLower) ||
        (admin.role_name || "").toLowerCase().includes(searchTermLower);

      // Debug individual admin matching
      if (searchTerm && admin.email) {
        console.log(
          `Admin ${admin.first_name} ${admin.last_name} (${admin.email}):`,
          {
            searchTerm: searchTermLower,
            email: admin.email.toLowerCase(),
            emailMatch: admin.email.toLowerCase().includes(searchTermLower),
            matches,
          }
        );
      }

      return matches;
    });

    console.log(
      `Frontend filtering: ${(adminsData?.result || []).length} total, ${
        filtered.length
      } filtered for "${searchTerm}"`
    );
    return filtered;
  }, [adminsData?.result, searchTerm]);

  // Frontend pagination for filtered results
  const paginatedAdminsData = React.useMemo(() => {
    if (!searchTerm) {
      return adminsData?.result || [];
    }

    const startIndex = (page - 1) * pageSize;
    const endIndex = startIndex + pageSize;
    return filteredAdminsData.slice(startIndex, endIndex);
  }, [filteredAdminsData, page, pageSize, searchTerm]);

  // Reset page to 1 when search term changes
  React.useEffect(() => {
    if (searchTerm) {
      setPage(1);
    }
  }, [searchTerm]);

  // Debug logging for admin search
  console.log("Admin Onboard Search Debug:", {
    searchTerm,
    roleFilter,
    totalResults: adminsData?.count,
    currentPageResults: adminsData?.result?.length,
    filteredResults: filteredAdminsData.length,
    paginatedResults: paginatedAdminsData.length,
    searchResults: adminsData?.result?.map((admin) => ({
      name: `${admin.first_name} ${admin.last_name}`,
      email: admin.email,
      role: admin.role_name,
    })),
    apiUrl: `GetAllAdmins?page=${page}&pageSize=${pageSize}&role_id=${roleFilter}`,
    usingFrontendFiltering: !!searchTerm,
  });

  const onboardMutation = useOnboardAdmin();
  const deleteMutation = useDeleteOnboardAdmin();

  const handleOnboardSubmit = async (data: any) => {
    try {
      await onboardMutation.mutateAsync({
        userId: selectedAdmin?.user_id || "",
        data: {
          ...data,
          role_Id: data.role_Id,
        },
      });
      toast({
        title: "Success",
        description: selectedAdmin
          ? "Admin updated successfully"
          : "Admin onboarded successfully",
      });
      setShowOnboardModal(false);
      setSelectedAdmin(null);
      refetch();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.response?.data?.message || "Failed to onboard admin",
        variant: "destructive",
      });
    }
  };

  const handleEdit = (admin: AdminRecord) => {
    setSelectedAdmin(admin);
    setShowOnboardModal(true);
  };

  const handleDelete = (admin: AdminRecord) => {
    setSelectedAdmin(admin);
    setShowDeleteModal(true);
  };

  const handleDeleteConfirm = async () => {
    try {
      await deleteMutation.mutateAsync(selectedAdmin?.user_id || "");
      toast({
        title: "Success",
        description: "Admin deleted successfully",
      });
      setShowDeleteModal(false);
      setSelectedAdmin(null);
      refetch();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.response?.data?.message || "Failed to delete admin",
        variant: "destructive",
      });
    }
  };

  const columns = [
    {
      header: "S.No.",
      accessor: "serial",
      cell: (_value: any, _row: AdminRecord, rowIndex: number) =>
        (page - 1) * pageSize + rowIndex + 1,
    },
    {
      header: "First Name",
      accessor: "first_name",
    },
    {
      header: "Last Name",
      accessor: "last_name",
    },
    {
      header: "Email",
      accessor: "email",
    },
    {
      header: "Phone Number",
      accessor: "phoneNumber",
    },
    {
      header: "Role Name",
      accessor: "role_name",
    },
    {
      header: "Edit",
      accessor: "edit",
      cell: (_value: any, row: AdminRecord) => (
        <button
          className="p-1 text-gray-500 hover:text-blue-600"
          onClick={(e) => {
            e.stopPropagation();
            handleEdit(row);
          }}
        >
          <img src={editicon} alt="edit" className="h-6 w-6" />
        </button>
      ),
    },
    {
      header: "Delete",
      accessor: "delete",
      cell: (_value: any, row: AdminRecord) => (
        <button
          className="p-1 text-gray-500 hover:text-red-600"
          onClick={(e) => {
            e.stopPropagation();
            handleDelete(row);
          }}
        >
          <img src={deleteicon} alt="delete" className="h-6 w-6" />
        </button>
      ),
    },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap">
        <div className="flex items-center gap-3">
          <button className="bg-blue-900 text-white px-4 py-2 rounded-lg">
            Admins ({adminsData?.count || 0})
          </button>
          <input
            type="text"
            placeholder="Search By Name, Email"
            className="border border-gray-300 rounded px-4 py-1"
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setPage(1); // Reset to first page when searching
            }}
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm("")}
              className="text-sm text-gray-500 hover:text-gray-700"
            >
              Clear
            </button>
          )}
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center space-x-2">
            <label className="whitespace-nowrap text-gray-700 font-medium">
              Role:
            </label>
            <select
              className="border border-gray-300 rounded px-2 py-1"
              value={roleFilter || ""}
              onChange={(e) =>
                setRoleFilter(
                  e.target.value ? Number(e.target.value) : undefined
                )
              }
            >
              <option value="">Select All</option>
              {rolesData?.map((role: any) => (
                <option key={role.role_id} value={role.role_id}>
                  {role.role_name}
                </option>
              ))}
            </select>
          </div>
          <button
            onClick={() => {
              setSelectedAdmin(null);
              setShowOnboardModal(true);
            }}
            className="bg-blue-900 text-white px-4 py-2 rounded-lg"
          >
            Onboard
          </button>
        </div>
      </div>

      <DataTable
        columns={columns}
        data={paginatedAdminsData}
        isLoading={isLoading}
        pagination={{
          currentPage: page,
          // Use backend count when no search, otherwise use filtered count
          totalPages: searchTerm
            ? Math.ceil((filteredAdminsData.length || 0) / pageSize)
            : Math.ceil((adminsData?.count || 0) / pageSize),
          pageSize: pageSize,
          // Use backend count when no search, otherwise use filtered count
          totalItems: searchTerm
            ? filteredAdminsData.length || 0
            : adminsData?.count || 0,
          onPageChange: (newPage) => setPage(newPage),
          onPageSizeChange: (newPageSize) => {
            setPageSize(newPageSize);
            setPage(1); // Reset to first page when changing page size
          },
        }}
      />

      {/* <div className="flex items-center justify-end space-x-3 text-sm text-gray-600">
        <div className="flex items-center space-x-1">
          <span>Items per page:</span>
          <select 
            className="border rounded px-2 py-1"
            value={pageSize}
            onChange={(e) => {
              setPageSize(Number(e.target.value));
              setPage(1);
            }}
          >
            <option value={5}>5</option>
            <option value={10}>10</option>
            <option value={25}>25</option>
          </select>
        </div>
        <span>
          {((page - 1) * pageSize) + 1} – {Math.min(page * pageSize, adminsData?.count || 0)} of {adminsData?.count || 0}
        </span>
      </div> */}

      <OnboardAdminModal
        isOpen={showOnboardModal}
        onClose={() => {
          setShowOnboardModal(false);
          setSelectedAdmin(null);
        }}
        onSubmit={handleOnboardSubmit}
        admin={selectedAdmin}
        roles={rolesData || []}
      />

      <DeleteConfirmationModal
        isOpen={showDeleteModal}
        onClose={() => {
          setShowDeleteModal(false);
          setSelectedAdmin(null);
        }}
        onConfirm={handleDeleteConfirm}
        adminName={`${selectedAdmin?.first_name} ${selectedAdmin?.last_name}`}
      />
    </div>
  );
};

export default Onboard;
