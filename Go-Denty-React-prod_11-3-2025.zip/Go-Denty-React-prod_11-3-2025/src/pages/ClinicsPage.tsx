/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState, useCallback, useMemo, memo } from "react";
import TabButton from "../components/ui/TabButton";
import DataTable from "../components/ui/DataTable";
import SearchInput from "../components/ui/SearchInput";
import { Button } from "@/components/ui/button";
import {
  Plus,
  Building2,
  Edit2,
  Trash2,
  Mail,
  Globe,
  Phone,
  MapPin,
  Users,
  Calendar,
  ExternalLink,
  User2,
  Info,
} from "lucide-react";
import editicon from "../../public/lovable-uploads/edit bg.svg";
import deleteicon from "../../public/lovable-uploads/delete bg.svg";
import CreateClinicModal from "../components/clinics/CreateClinicModal";
import RejectionReasonModal from "../components/clinics/RejectionReasonModal";
import { useToast } from "@/hooks/use-toast";
import {
  useAllClinics,
  useVerifyClinic,
  useDeleteClinic,
  useGetUserByPhone,
} from "@/services/api";
import StatusBadge from "../components/ui/StatusBadge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { EditClinicDialog } from "../components/clinics/EditClinicDialog";
import { DeleteClinicDialog } from "../components/clinics/DeleteClinicDialog";
import { DatePickerWithRange } from "@/components/ui/date-range";
import { useQueries } from "@tanstack/react-query";
import { api } from "@/services/api";

// Define a type for the verification status
type VerificationStatus = "Pending" | "Approved" | "Reject";

// Define a Clinic interface to avoid using 'any'
export interface Clinic {
  clinic_About: any;
  Clinic_id: string;
  Clinic_name: string;
  clinic_Address: string;
  Clinic_Contact_Number: string;
  Clinic_Website?: string;
  Clinic_lat?: string;
  Clinic_long?: string;
  Clinic_email: string;
  No_of_Dental_Chairs: number;
  Avg_per_month: number;
  is_Verified: VerificationStatus;
  user_id: string;
  owner_name: string;
  doctor_type: string;
}

// Memoized table component to prevent unnecessary rerenders
const ClinicTable = memo(
  ({
    columns,
    data,
    isLoading,
    pagination,
  }: {
    columns: any[];
    data: any[];
    isLoading: boolean;
    pagination: {
      currentPage: number;
      totalPages: number;
      pageSize: number;
      totalItems: number;
      onPageChange: (page: number) => void;
      onPageSizeChange: (pageSize: number) => void;
    };
  }) => {
    return (
      <DataTable
        columns={columns}
        data={data}
        isLoading={isLoading}
        pagination={pagination}
      />
    );
  }
);

ClinicTable.displayName = "ClinicTable";

// Memoized dialog component to prevent unnecessary rerenders
const StatusDialogContent = memo(
  ({
    clinic,
    onClose,
    onReject,
    onApprove,
    isProcessing = false,
  }: {
    clinic: Clinic | null;
    onClose: () => void;
    onReject: () => void;
    onApprove: () => void;
    isProcessing?: boolean;
  }) => {
    // Move hook before any conditional returns
    const { data: user, isLoading } = useGetUserByPhone(
      clinic?.Clinic_Contact_Number || ""
    );
    if (!clinic && !isLoading) return null;
    console.log(user, "isseea");

    return (
      <div className="py-4">
        {/* Main information section */}
        <div className="space-y-6">
          {/* Basic Information */}
          <div>
            <h3 className="text-lg font-medium mb-3 text-primary/80">
              Basic Information
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-start gap-3">
                <Building2 className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-sm text-muted-foreground">Clinic Name</p>
                  <p className="font-medium">{clinic.Clinic_name}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <User2 className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-sm text-muted-foreground">Owner Name</p>
                  <p className="font-medium">{user?.user_name || "N/A"}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Users className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-sm text-muted-foreground">Doctor Type</p>
                  <p className="font-medium">{user?.doctor_type || "N/A"}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Information */}
          <div>
            <h3 className="text-lg font-medium mb-3 text-primary/80">
              Contact Information
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-start gap-3">
                <Phone className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-sm text-muted-foreground">Phone Number</p>
                  <p className="font-medium">{clinic.Clinic_Contact_Number}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Mail className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-sm text-muted-foreground">Email</p>
                  <p className="font-medium">{clinic.Clinic_email}</p>
                </div>
              </div>

              {clinic.Clinic_Website ? (
                <div className="flex items-start gap-3">
                  <Globe className="h-5 w-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm text-muted-foreground">Website</p>
                    <a
                      href={
                        clinic.Clinic_Website.startsWith("http")
                          ? clinic.Clinic_Website
                          : `https://${clinic.Clinic_Website}`
                      }
                      target="_blank"
                      rel="noopener noreferrer"
                      className="font-medium text-primary flex items-center hover:underline"
                    >
                      {clinic.Clinic_Website}
                      <ExternalLink className="h-3 w-3 ml-1" />
                    </a>
                  </div>
                </div>
              ) : (
                <div className="flex items-start gap-3">
                  <Globe className="h-5 w-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm text-muted-foreground">Website</p>
                    <p className="font-medium">N/A</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Location */}
          <div>
            <h3 className="text-lg font-medium mb-3 text-primary/80">
              Location
            </h3>
            <div className="flex items-start gap-3">
              <MapPin className="h-5 w-5 text-muted-foreground mt-0.5" />
              <div>
                <p className="text-sm text-muted-foreground">Address</p>
                <p className="font-medium">{clinic.clinic_Address}</p>
              </div>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Info className="h-5 w-5 text-muted-foreground mt-0.5" />
            <div>
              <p className="text-sm text-muted-foreground">About Clinic</p>
              <p className="font-medium">
                {clinic.clinic_About ? clinic.clinic_About : "N/A"}
              </p>
            </div>
          </div>

          {/* Operational Details */}
          <div>
            <h3 className="text-lg font-medium mb-3 text-primary/80">
              Operational Details
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-start gap-3">
                <Users className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-sm text-muted-foreground">
                    Number of Dental Chairs
                  </p>
                  <p className="font-medium">{clinic.No_of_Dental_Chairs}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Calendar className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-sm text-muted-foreground">
                    Average Patients per Month
                  </p>
                  <p className="font-medium">{clinic.Avg_per_month}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-end space-x-2 mt-6 pt-4 border-t">
          {clinic.is_Verified === "Pending" ? (
            <>
              <Button
                variant="outline"
                onClick={onClose}
                disabled={isProcessing}
              >
                Cancel
              </Button>
              <Button
                variant="destructive"
                onClick={onReject}
                disabled={isProcessing}
              >
                Reject
              </Button>
              <Button onClick={onApprove} disabled={isProcessing}>
                {isProcessing ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Processing...
                  </>
                ) : (
                  "Approve"
                )}
              </Button>
            </>
          ) : (
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          )}
        </div>
      </div>
    );
  }
);

StatusDialogContent.displayName = "StatusDialogContent";

/**
 * Formats a date string to a consistent format (DD-MM-YYYY), handling various input formats
 * @param dateStr The date string to format
 * @returns Formatted date string or fallback text
 */
const formatDate = (dateStr: string): string => {
  if (!dateStr) return "-";

  // Try parsing different date formats
  const date = new Date(dateStr);

  // Check if the date is valid
  if (isNaN(date.getTime())) {
    // Try parsing DD-MM-YYYY format
    const [day, month, year] = dateStr.split("-").map(Number);
    if (day && month && year) {
      const parsedDate = new Date(year, month - 1, day);
      if (!isNaN(parsedDate.getTime())) {
        return `${day.toString().padStart(2, "0")}-${month
          .toString()
          .padStart(2, "0")}-${year}`;
      }
    }
    return "-";
  }

  // Format the date as DD-MM-YYYY
  const day = date.getDate().toString().padStart(2, "0");
  const month = (date.getMonth() + 1).toString().padStart(2, "0");
  const year = date.getFullYear();
  return `${day}-${month}-${year}`;
};

const ClinicsPage = () => {
  // State management
  const [activeTab, setActiveTab] = useState("Pending Approval");
  const [selectedClinic, setSelectedClinic] = useState<Clinic | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showReasonDialog, setShowReasonDialog] = useState(false);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [searchClinic, setSearchClinic] = useState("");
  const [status, setStatus] = useState<VerificationStatus | undefined>(
    "Pending"
  );

  // Add date range state
  const [dateRange, setDateRange] = useState<{
    from: Date | null;
    to: Date | null;
  }>({
    from: null,
    to: null,
  });

  const { toast } = useToast();
  const verifyMutation = useVerifyClinic();
  const [showStatusDialog, setShowStatusDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const deleteMutation = useDeleteClinic();

  // Queries for counts of each status - with date range
  const { data: pendingClinicsResponse } = useAllClinics(
    1,
    1,
    "",
    "Pending",
    dateRange.from,
    dateRange.to
  );
  const { data: approvedClinicsResponse } = useAllClinics(
    1,
    1,
    "",
    "Approved",
    dateRange.from,
    dateRange.to
  );
  const { data: rejectedClinicsResponse } = useAllClinics(
    1,
    1,
    "",
    "Reject",
    dateRange.from,
    dateRange.to
  );

  // Memoized clinic counts using the count from each response
  const counts = useMemo(
    () => ({
      pending: pendingClinicsResponse?.data?.count || 0,
      approved: approvedClinicsResponse?.data?.count || 0,
      rejected: rejectedClinicsResponse?.data?.count || 0,
    }),
    [pendingClinicsResponse, approvedClinicsResponse, rejectedClinicsResponse]
  );

  // Regular query for the current tab view with date range
  // When searching, fetch all results for frontend filtering; otherwise use pagination
  const { data: clinicsResponse, isLoading: isLoadingClinics } = useAllClinics(
    searchClinic ? 1 : page, // Use page 1 when searching to get all results
    searchClinic ? 10000 : pageSize, // Use large page size when searching
    searchClinic, // Pass search term to API for basic filtering
    status,
    dateRange.from,
    dateRange.to
  );

  // Debug logging to understand the search behavior
  console.log("ClinicsPage Debug:", {
    page,
    pageSize,
    searchClinic,
    status,
    totalResults: clinicsResponse?.data?.count,
    currentPageResults: clinicsResponse?.data?.result?.length,
    hasMorePages: clinicsResponse?.data?.count > page * pageSize,
  });

  // Memoized clinics data to prevent unnecessary rerenders
  const clinics = useMemo(
    () => clinicsResponse?.data?.result || [],
    [clinicsResponse]
  );

  // Fetch owner names for all clinics in the current page
  const ownerQueries = useQueries({
    queries: clinics.map((clinic) => ({
      queryKey: ["user", clinic.Clinic_Contact_Number],
      queryFn: () =>
        clinic.Clinic_Contact_Number
          ? api
              .getUserByPhone(clinic.Clinic_Contact_Number)
              .then((res) => res.data)
          : Promise.resolve(null),
      enabled: !!clinic.Clinic_Contact_Number,
    })),
  });

  const clinicsWithOwner = clinics.map((clinic, idx) => {
    const ownerName = ownerQueries[idx]?.data?.user_name || "";
    return {
      ...clinic,
      Clinic_Owner: ownerName,
    };
  });

  // Frontend filtering for owner name (since owner name is fetched separately)
  const filteredClinicsWithOwner = useMemo(() => {
    if (!searchClinic) {
      return clinicsWithOwner;
    }

    const searchTerm = searchClinic.toLowerCase();
    return clinicsWithOwner.filter((clinic) => {
      return (
        (clinic.Clinic_name || "").toLowerCase().includes(searchTerm) ||
        (clinic.Clinic_Contact_Number || "")
          .toLowerCase()
          .includes(searchTerm) ||
        (clinic.Clinic_email || "").toLowerCase().includes(searchTerm) ||
        (clinic.Clinic_Owner || "").toLowerCase().includes(searchTerm)
      );
    });
  }, [clinicsWithOwner, searchClinic]);

  // Since we're doing frontend filtering for owner name, we need to handle pagination differently
  const shouldUseFrontendPagination = searchClinic; // Always use frontend pagination when searching

  const paginatedClinics = useMemo(() => {
    if (shouldUseFrontendPagination) {
      // For search with frontend filtering, we need to get all results first, then paginate
      // This means we need to fetch all results when searching
      const startIndex = (page - 1) * pageSize;
      const endIndex = startIndex + pageSize;
      return filteredClinicsWithOwner.slice(startIndex, endIndex);
    }
    return clinicsResponse?.data?.result || [];
  }, [filteredClinicsWithOwner, page, pageSize, shouldUseFrontendPagination]);

  // Memoized table columns definition to prevent recreation
  const clinicColumns = useMemo(
    () => [
      {
        header: "S.NO",
        accessor: "serialNumber",
        cell: (_: string, __: any, rowIndex: number | undefined) => {
          return ((page - 1) * pageSize + (rowIndex ?? 0) + 1).toString();
        },
      },
      {
        header: "CLINIC NAME",
        accessor: "Clinic_name",
        cell: (value: string) => value || "-",
      },
      {
        header: "OWNER NAME",
        accessor: "Clinic_Owner",
        cell: (value: string) => value || "-",
      },
      {
        header: "PHONE NUMBER",
        accessor: "Clinic_Contact_Number",
        cell: (value: string) => value || "-",
      },
      {
        header: "EMAIL",
        accessor: "Clinic_email",
        cell: (value: string) => value || "-",
      },
      {
        header: "WEBSITE",
        accessor: "Clinic_Website",
        cell: (value: string) => value.split("/")[2] || "-",
      },
      {
        header: "REGISTRATION DATE",
        accessor: "Created_date",
        cell: (value: string) => formatDate(value),
      },
      {
        header: "STATUS",
        accessor: "is_Verified",
        cell: (value: string, row: Clinic) => (
          <div
            onClick={(e) => {
              e.stopPropagation(); // Prevent row click
              handleStatusBadgeClick(row);
            }}
          >
            <StatusBadge
              status={value as "Active" | "Inactive" | "Pending"}
              className="cursor-pointer hover:opacity-80"
            />
          </div>
        ),
      },
      {
        header: "ACTIONS",
        accessor: "actions",
        cell: (_: any, row: Clinic) => (
          <div className="flex gap-2">
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleEdit(row);
              }}
              className="text-blue-600 hover:text-blue-800"
            >
              <img src={editicon} alt="edit" className="h-6 w-6" />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleDelete(row);
              }}
              className="text-red-600 hover:text-red-800"
            >
              <img src={deleteicon} alt="delete" className="h-6 w-6" />
            </button>
          </div>
        ),
      },
    ],
    [page, pageSize]
  );

  // Event handlers with useCallback to maintain reference equality
  const handleSearchChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      setSearchClinic(e.target.value);
      setPage(1); // Reset to first page when search changes
    },
    []
  );

  const handleStatusChange = useCallback(
    (newStatus: "Pending" | "Approved" | "Reject" | undefined) => {
      setStatus(newStatus);
      setPage(1); // Reset to first page when filter changes
    },
    []
  );

  const handleTabChange = useCallback((tab: string) => {
    setActiveTab(tab);
    // Update status based on selected tab
    switch (tab) {
      case "Clinics":
        setStatus("Approved");
        break;
      case "Pending Approval":
        setStatus("Pending");
        break;
      case "Rejected":
        setStatus("Reject");
        break;
      default:
        setStatus(undefined);
    }
    setPage(1); // Reset to first page when tab changes
    setDateRange({ from: null, to: null }); // Reset date range when changing tabs
    setSearchClinic(""); // Reset search when changing tabs
  }, []);

  const handleApprove = useCallback(async () => {
    if (!selectedClinic || isProcessing) return;

    setIsProcessing(true);

    try {
      await verifyMutation.mutateAsync({
        Clinic_id: selectedClinic.Clinic_id,
        status: "Approved",
        body: "Clinic approved",
        user_id: selectedClinic.user_id,
      });

      toast({
        title: "Success",
        description: "Clinic has been approved successfully",
      });

      // Close dialogs
      setShowStatusDialog(false);
      setSelectedClinic(null);

      // If we're on the Pending tab, switch to Approved tab to show the newly approved clinic
      if (activeTab === "Pending Approval") {
        handleTabChange("Clinics");
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description:
          error.response?.data?.message || "Failed to approve clinic",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  }, [
    selectedClinic,
    verifyMutation,
    toast,
    activeTab,
    handleTabChange,
    isProcessing,
  ]);

  const handleReject = useCallback(
    async (reason: string) => {
      if (!selectedClinic || isProcessing) return;

      setIsProcessing(true);

      try {
        await verifyMutation.mutateAsync({
          Clinic_id: selectedClinic.Clinic_id,
          status: "Reject",
          body: reason,
          user_id: selectedClinic.user_id,
        });

        toast({
          title: "Success",
          description: "Clinic has been rejected",
        });
        setShowReasonDialog(false);
        setShowStatusDialog(false);
        setSelectedClinic(null);
      } catch (error: any) {
        toast({
          title: "Error",
          description:
            error.response?.data?.message || "Failed to reject clinic",
          variant: "destructive",
        });
      } finally {
        setIsProcessing(false);
      }
    },
    [selectedClinic, verifyMutation, toast, isProcessing]
  );

  const handleStatusBadgeClick = useCallback((clinic: Clinic) => {
    setSelectedClinic(clinic);
    setShowStatusDialog(true);
  }, []);

  const handleEdit = useCallback((clinic: Clinic) => {
    setSelectedClinic(clinic);
    setShowEditDialog(true);
  }, []);

  const handleDelete = useCallback((clinic: Clinic) => {
    setSelectedClinic(clinic);
    setShowDeleteDialog(true);
  }, []);

  const handleDeleteConfirm = useCallback(async () => {
    if (!selectedClinic) return;

    try {
      await deleteMutation.mutateAsync(selectedClinic.Clinic_id);

      toast({
        title: "Success",
        description: "Clinic deleted successfully",
      });
      setShowDeleteDialog(false);
      setSelectedClinic(null);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.response?.data?.message || "Failed to delete clinic",
        variant: "destructive",
      });
    }
  }, [selectedClinic, deleteMutation, toast]);

  const handleCloseStatusDialog = useCallback(() => {
    setShowStatusDialog(false);
    setSelectedClinic(null);
  }, []);

  const handleOpenReasonDialog = useCallback(() => {
    setShowReasonDialog(true);
  }, []);

  const handleCloseEditDialog = useCallback(() => {
    setShowEditDialog(false);
    setSelectedClinic(null);
  }, []);

  const handleCloseDeleteDialog = useCallback(() => {
    setShowDeleteDialog(false);
    setSelectedClinic(null);
  }, []);

  // Handle date range change
  const handleDateRangeChange = useCallback(
    (range: { from: Date | null; to: Date | null }) => {
      setDateRange(range);
      setPage(1); // Reset to first page when filter changes
    },
    []
  );

  // Memoized pagination data
  const paginationData = useMemo(() => {
    if (shouldUseFrontendPagination) {
      // For frontend pagination, use the total count of filtered results
      const totalFilteredResults = filteredClinicsWithOwner.length;
      return {
        currentPage: page,
        totalPages: Math.ceil(totalFilteredResults / pageSize),
        pageSize,
        totalItems: totalFilteredResults,
        onPageChange: setPage,
        onPageSizeChange: (newPageSize: number) => {
          setPageSize(newPageSize);
          setPage(1);
        },
      };
    } else {
      // For backend pagination, use the API count
      return {
        currentPage: page,
        totalPages: Math.ceil((clinicsResponse?.data?.count || 0) / pageSize),
        pageSize,
        totalItems: clinicsResponse?.data?.count || 0,
        onPageChange: setPage,
        onPageSizeChange: (newPageSize: number) => {
          setPageSize(newPageSize);
          setPage(1);
        },
      };
    }
  }, [
    page,
    pageSize,
    clinicsResponse,
    shouldUseFrontendPagination,
    filteredClinicsWithOwner.length,
  ]);

  // This returns different views based on the state
  const renderContent = () => {
    return (
      <div className="space-y-8">
        <div className="flex justify-between items-center">
          <div className="flex space-x-4 overflow-x-auto pb-2">
            <TabButton
              label={`Pending Approval (${counts.pending})`}
              active={activeTab === "Pending Approval"}
              onClick={() => handleTabChange("Pending Approval")}
            />
            <TabButton
              label={`Approved Clinics (${counts.approved})`}
              active={activeTab === "Clinics"}
              onClick={() => handleTabChange("Clinics")}
            />

            <TabButton
              label={`Rejected (${counts.rejected})`}
              active={activeTab === "Rejected"}
              onClick={() => handleTabChange("Rejected")}
            />
          </div>

          {/* Updated flex container to display "Status" dropdown and "Create Clinic" button side by side */}
          <div className="flex items-center gap-4 mb-4">
            {/* Add Date Range Picker */}
            <DatePickerWithRange
              onDateChange={handleDateRangeChange}
              value={dateRange}
            />

            {/* Create Clinic Button */}
            <Button
              className="flex items-center gap-2 bg-blue-900 hover:bg-blue-800"
              onClick={() => setShowCreateModal(true)}
            >
              <Plus size={18} />
              Create Clinic
            </Button>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div className="text-xl font-semibold flex items-center gap-2">
              {activeTab === "Clinics" && "Approved Clinics"}
              {activeTab === "Pending Approval" && "Pending Clinics"}
              {activeTab === "Rejected" && "Rejected Clinics"}
              <span className="text-gray-500">
                (
                {activeTab === "Clinics"
                  ? counts.approved
                  : activeTab === "Pending Approval"
                  ? counts.pending
                  : counts.rejected}
                )
              </span>
            </div>
            <div className="flex flex-wrap w-full sm:w-auto gap-4">
              <div className="w-full sm:w-96">
                <SearchInput
                  placeholder="Search by Clinic Name, Phone, Owner or Email"
                  onChange={handleSearchChange}
                  value={searchClinic}
                />
              </div>
            </div>
          </div>

          {filteredClinicsWithOwner.length === 0 ? (
            <div className="flex justify-center items-center py-12 text-lg text-gray-500 font-medium">
              {activeTab === "Clinics" && "No approved clinics found."}
              {activeTab === "Pending Approval" && "No pending clinics found."}
              {activeTab === "Rejected" && "No rejected clinics found."}
            </div>
          ) : (
            <ClinicTable
              columns={clinicColumns}
              data={paginatedClinics}
              isLoading={isLoadingClinics}
              pagination={paginationData}
            />
          )}
        </div>
      </div>
    );
  };

  return (
    <>
      {renderContent()}

      {/* Create Clinic Modal */}
      <CreateClinicModal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        onSuccess={() => {
          toast({
            title: "Success",
            description: "Clinic created successfully",
          });
        }}
      />

      {/* Status Dialog */}
      <Dialog
        open={showStatusDialog}
        onOpenChange={(open) => {
          if (!open) {
            handleCloseStatusDialog();
          }
        }}
      >
        <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
          <DialogHeader className="pb-2 border-b">
            <DialogTitle className="text-2xl flex items-center gap-2">
              <Building2 className="h-6 w-6 text-primary" />
              {selectedClinic?.Clinic_name}
              <StatusBadge
                status={
                  selectedClinic?.is_Verified as
                    | "Pending"
                    | "Approved"
                    | "Rejected"
                }
              />
            </DialogTitle>
            <div className="mt-1"></div>
          </DialogHeader>

          <StatusDialogContent
            clinic={selectedClinic}
            onClose={handleCloseStatusDialog}
            onReject={handleOpenReasonDialog}
            onApprove={handleApprove}
            isProcessing={isProcessing}
          />
        </DialogContent>
      </Dialog>

      {/* Rejection Reason Dialog */}
      <RejectionReasonModal
        isOpen={showReasonDialog}
        onClose={() => setShowReasonDialog(false)}
        onSubmit={handleReject}
      />

      {/* Edit Clinic Dialog */}
      <EditClinicDialog
        isOpen={showEditDialog}
        onClose={handleCloseEditDialog}
        clinic={selectedClinic}
      />

      <DeleteClinicDialog
        isOpen={showDeleteDialog}
        onClose={handleCloseDeleteDialog}
        onConfirm={handleDeleteConfirm}
        clinicName={selectedClinic?.Clinic_name || ""}
      />
    </>
  );
};

export default ClinicsPage;
