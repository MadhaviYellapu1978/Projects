import React, { useState, useEffect } from "react";
import { X, Upload, File, Eye, Info, Trash2 } from "lucide-react";
import { Formik, Form, Field, ErrorMessage, FormikProps } from "formik";
import * as Yup from "yup";
import DataTable from "../components/ui/DataTable";
import TabButton from "../components/ui/TabButton";
import { Input } from "@/components/ui/input";
import { ROLES } from "@/data/roles";
import { toast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from "@/components/ui/dialog";
import {
  useAllEvents,
  useAllEventTypes,
  usePostEvent,
  useVerifyEvent,
  useGetUserByPhone,
  useUploadImage,
  useDeleteEvent,
} from "@/services/api";
import { Switch } from "@/components/ui/switch";
import GooglePlacesAutocomplete from "react-google-places-autocomplete";
import { geocodeByPlaceId, getLatLng } from "react-google-places-autocomplete";
import { AxiosError } from "axios";
import { useQueryClient } from "@tanstack/react-query";
import editicon from "../../public/lovable-uploads/edit bg.svg";
import deleteicon from "../../public/lovable-uploads/delete bg.svg";

/**
 * Formats a date string to DD-MM-YYYY format
 * @param dateStr The date string to format
 * @returns Formatted date string or fallback text
 */
const formatDate = (dateStr: string): string => {
  if (!dateStr) return "-";

  // Try parsing different date formats
  const date = new Date(dateStr);

  // Check if the date is valid
  if (isNaN(date.getTime())) {
    // Try parsing DD-MM-YYYY format
    const [day, month, year] = dateStr.split("-").map(Number);
    if (day && month && year) {
      const parsedDate = new Date(year, month - 1, day);
      if (!isNaN(parsedDate.getTime())) {
        return `${day.toString().padStart(2, "0")}-${month
          .toString()
          .padStart(2, "0")}-${year}`;
      }
    }
    return "-";
  }

  // Format the date as DD-MM-YYYY
  const day = date.getDate().toString().padStart(2, "0");
  const month = (date.getMonth() + 1).toString().padStart(2, "0");
  const year = date.getFullYear();
  return `${day}-${month}-${year}`;
};

interface EventFormValues {
  name: string;
  type: string;
  startDate: string;
  endDate: string;
  startTime: string;
  endTime: string;
  phoneNumber: string;
  email: string;
  description: string;
  price: number;
  image?: File | null;
  thumbnail?: File | null;
  event_lat: number;
  event_long: number;
  event_address: string;
  event_location_address: string;
  is_paid: boolean;
  course_title: string;
  course_duration: string;
  pricingmode: string;
  course_preview: string;
  payment_link: string;
}

const getValidationSchema = (activeTab: string) =>
  Yup.object().shape({
    name: Yup.string()
      .required(`${activeTab} name is mandatory`)
      .min(3, "Name must be at least 3 characters")
      .test("no-first-space", "Name cannot start with a space", (value) => {
        if (!value) return true; // Allow empty values
        return !value.startsWith(" ");
      }),
    type: Yup.string().required(`${activeTab} type is mandatory`),
    startDate: Yup.string().required("Start date is mandatory"),
    endDate: Yup.string().when("type", {
      is: (type) => type !== "Webinars",
      then: () =>
        Yup.string()
          .required("End date is mandatory")
          .test(
            "is-after-start",
            "End date must be after start date",
            function (value) {
              const { startDate } = this.parent;
              if (!startDate || !value) return true;
              return new Date(value) >= new Date(startDate);
            }
          ),
      otherwise: () => Yup.string().notRequired(),
    }),
    startTime: Yup.string().required("Start time is mandatory"),
    endTime: Yup.string()
      .required("End time is mandatory")
      .test(
        "is-after-start",
        "End time must be after start time",
        function (value) {
          const { startDate, endDate, startTime, type } = this.parent;
          if (!startTime || !value) return true;
          if (type === "Webinars" || startDate === endDate) {
            return value > startTime;
          }
          return true;
        }
      ),
    phoneNumber: Yup.string()
      .matches(/^[0-9]{10}$/, "Phone number must be 10 digits")
      .required("Phone number is mandatory"),
    email: Yup.string()
      .email("Invalid email format")
      .required("Email is mandatory"),
    description: Yup.string()
      .required("Description is mandatory")
      .min(10, "Description must be at least 10 characters")
      .test(
        "no-first-space",
        "Description cannot start with a space",
        (value) => {
          if (!value) return true; // Allow empty values
          return !value.startsWith(" ");
        }
      ),
    price: Yup.number().when("is_paid", {
      is: true,
      then: () =>
        Yup.number()
          .required("Price is mandatory")
          .min(1, "Price must be greater than 0"),
      otherwise: () => Yup.number().notRequired(),
    }),
    payment_link: Yup.string()
      .url("Valid URL is required")
      .matches(/^https?:\/\/.+/, "URL must start with http:// or https://")
      .nullable()
      .transform((value) => (value === "" ? null : value)),
    event_location_address: Yup.string().when("type", {
      is: (type) => type !== "Webinars",
      then: () => Yup.string().required(`${activeTab} Address is mandatory`),
      otherwise: () => Yup.string().notRequired(),
    }),
    event_lat: Yup.number().nullable(),
    event_long: Yup.number().nullable(),
    is_paid: Yup.boolean(),
    course_title: Yup.string(),
    course_duration: Yup.string(),
    pricingmode: Yup.string().when("is_paid", {
      is: true,
      then: () => Yup.string(),
      otherwise: () => Yup.string().notRequired(),
    }),
    event_address: Yup.string().when("type", {
      is: (type) => type !== "Webinars",
      then: () => Yup.string().required(`${activeTab} location is mandatory`),
      otherwise: () => Yup.string().notRequired(),
    }),
    course_preview: Yup.string(),
    image: Yup.mixed()
      .required(`${activeTab} image is mandatory`)
      .test(
        "fileType",
        "Only JPG, PNG and JPEG files are accepted",
        (value) => {
          if (!value) return false;
          const supportedFormats = ["image/jpeg", "image/png", "image/jpg"];
          return supportedFormats.includes((value as File).type);
        }
      )
      .test("fileSize", "File size is too large (max 5MB)", (value) => {
        if (!value) return false;
        const maxSize = 5 * 1024 * 1024; // 5MB
        return (value as File).size <= maxSize;
      }),
    thumbnail: Yup.mixed()
      .required("Thumbnail is mandatory")
      .test(
        "fileType",
        "Only JPG, PNG and JPEG files are accepted",
        (value) => {
          if (!value) return false;
          const supportedFormats = ["image/jpeg", "image/png", "image/jpg"];
          return supportedFormats.includes((value as File).type);
        }
      )
      .test("fileSize", "File size is too large (max 5MB)", (value) => {
        if (!value) return false;
        const maxSize = 5 * 1024 * 1024; // 5MB
        return (value as File).size <= maxSize;
      }),
  });

interface GooglePlace {
  value: {
    place_id: string;
  };
  label: string;
}

interface FormikHelpers {
  setSubmitting: (isSubmitting: boolean) => void;
  setFieldValue: (field: string, value: string | number | null) => void;
  setFieldTouched: (field: string, touched: boolean) => void;
}

interface CreateEventModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddEvent: (event: EventFormValues) => void;
  activeTab: string;
}

const CreateEventModal = ({
  isOpen,
  onClose,
  onAddEvent,
  activeTab,
}: CreateEventModalProps) => {
  const [image, setImage] = useState<File | null>(null);
  const [thumbnail, setThumbnail] = useState<File | null>(null);
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const thumbnailInputRef = React.useRef<HTMLInputElement>(null);
  const [locationSelection, setLocationSelection] =
    useState<GooglePlace | null>(null);
  const { data: eventTypesData } = useAllEventTypes();
  const { mutate: postEvent } = usePostEvent();
  const { mutate: uploadImage } = useUploadImage();
  const [EnableLoading, setEnableLoading] = useState(false);
  const formikRef = React.useRef<FormikProps<EventFormValues>>(null);

  const { mutateAsync } = useDeleteEvent();

  const initialValues: EventFormValues = {
    name: "",
    type: activeTab,
    startDate: "",
    endDate: "",
    startTime: "",
    endTime: "",
    phoneNumber: "",
    email: "",
    description: "",
    price: 0,
    image: null,
    thumbnail: null,
    event_lat: 0,
    event_long: 0,
    event_address: "",
    event_location_address: "",
    is_paid: false,
    course_title: "",
    course_duration: "",
    pricingmode: "",
    course_preview: "",
    payment_link: "",
  };

  const {
    data: phoneUserData,
    isSuccess: isPhoneUserFound,
    error: phoneUserError,
  } = useGetUserByPhone(initialValues.phoneNumber);

  useEffect(() => {
    if (phoneUserError) {
      // TypeScript safe way to handle axios errors
      const axiosError = phoneUserError as AxiosError<{ message: string }>;
      const errorMessage =
        axiosError?.response?.data?.message || "Failed to verify phone number";
      if (errorMessage === "This Phone Number Is Not Avalible") {
        // Form reference to access inside useEffect
        if (formikRef.current) {
          formikRef.current.setFieldError("phoneNumber", errorMessage);
          // Touch the field to ensure error is displayed
          formikRef.current.setFieldTouched("phoneNumber", true, false);
        }
      }
    }
  }, [phoneUserError]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setImage(e.target.files[0]);
    }
  };

  const handleThumbnailUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setThumbnail(e.target.files[0]);
    }
  };

  const handleLocationChange = (selection: GooglePlace) => {
    setLocationSelection(selection);
  };

  const handleSubmit = async (
    values: EventFormValues,
    { setSubmitting, setFieldValue, setFieldTouched }: FormikHelpers
  ) => {
    try {
      setSubmitting(true);
      setEnableLoading(true);

      // Get user ID and role
      const userId = localStorage.getItem("userId");
      const userRole = localStorage.getItem("roleName");
      if (!userId) {
        toast({
          title: "Error",
          description: "User ID not found. Please login again.",
          variant: "destructive",
        });
        setSubmitting(false);
        return;
      }

      // Handle image upload if exists
      let imageUrl = "";
      let thumbnailUrl = "";

      if (image) {
        const uploadImageData = {
          image: image,
          user_id: userId,
        };
        try {
          const response = await new Promise<{ data: { image: string } }>(
            (resolve, reject) => {
              uploadImage(uploadImageData, {
                onSuccess: (data) => resolve(data),
                onError: (error) => reject(error),
              });
            }
          );

          imageUrl = response.data.image;
        } catch (error) {
          toast({
            title: "Error",
            description: "Failed to upload image. Please try again.",
            variant: "destructive",
          });
          console.error("Error uploading image:", error);
          setSubmitting(false);
          return;
        }
      }

      // Handle thumbnail upload if exists
      if (thumbnail) {
        const uploadThumbnailData = {
          image: thumbnail,
          user_id: userId,
        };
        try {
          const response = await new Promise<{ data: { image: string } }>(
            (resolve, reject) => {
              uploadImage(uploadThumbnailData, {
                onSuccess: (data) => resolve(data),
                onError: (error) => reject(error),
              });
            }
          );

          thumbnailUrl = response.data.image;
        } catch (error) {
          toast({
            title: "Error",
            description: "Failed to upload thumbnail. Please try again.",
            variant: "destructive",
          });
          console.error("Error uploading thumbnail:", error);
          setSubmitting(false);
          return;
        }
      }

      // Get event type
      const eventTypeObj = eventTypesData?.find(
        (type) => type.event_type_name === activeTab
      );

      if (!eventTypeObj) {
        toast({
          title: "Error",
          description: "Invalid event type selected.",
          variant: "destructive",
        });
        setSubmitting(false);
        return;
      }

      // Get location details for non-webinar events
      let locationData = {
        event_lat: null,
        event_long: null,
        event_address: null,
        event_location_address: null,
      };

      if (activeTab !== "Webinars" && locationSelection) {
        try {
          const results = await geocodeByPlaceId(
            locationSelection.value.place_id
          );
          const address = results[0].formatted_address;
          const latLng = await getLatLng(results[0]);

          locationData = {
            event_lat: latLng.lat,
            event_long: latLng.lng,
            event_address: address,
            event_location_address: values.event_location_address,
          };
        } catch (error) {
          toast({
            title: "Error",
            description: "Failed to get location details. Please try again.",
            variant: "destructive",
          });
          setSubmitting(false);
          return;
        }
      }

      // Set status based on user role
      const status = userRole === "Super Admin" ? "Approved" : "Pending";

      // Prepare event data
      const eventData = {
        user_id: userId,
        event_type: {
          event_type_id: eventTypeObj.event_type_id,
          event_type_name: activeTab,
        },
        Phone_number: values.phoneNumber,
        Email: values.email,
        description: values.description,
        is_admin: true,
        image: imageUrl,
        thumbnail: thumbnailUrl,
        start_date: values.startDate,
        end_date: activeTab === "Webinars" ? values.startDate : values.endDate,
        start_time: values.startTime,
        end_time: values.endTime,
        price: values.is_paid ? values.price : 0,
        name: values.name,
        course_title: values.course_title,
        course_duration: values.course_duration,
        pricingmode: values.is_paid ? values.pricingmode : "",
        course_preview: values.course_preview,
        payment_link: values.payment_link,
        event_lat: activeTab === "Webinars" ? 0.1 : locationData.event_lat || 0,
        event_long:
          activeTab === "Webinars" ? 0.1 : locationData.event_long || 0,
        event_address:
          activeTab === "Webinars"
            ? "Online"
            : locationData.event_address || "",
        event_location_address:
          activeTab === "Webinars"
            ? "Online"
            : locationData?.event_location_address || "",
        is_paid: values.is_paid,
        status: status,
      };
      // Submit event data
      postEvent(eventData, {
        onSuccess: () => {
          toast({
            title: "Success",
            description: "Event created successfully",
            className: "bg-green-50 border-green-200",
          });

          // Reset form
          setLocationSelection(null);
          setImage(null);
          setThumbnail(null);
          if (fileInputRef.current) {
            fileInputRef.current.value = "";
          }
          if (thumbnailInputRef.current) {
            thumbnailInputRef.current.value = "";
          }

          // Close modal
          onClose();
          setEnableLoading(false);
        },
        onError: (error) => {
          console.error("Error creating event:", error);
          toast({
            title: "Error",
            description: "Failed to create event. Please try again.",
            variant: "destructive",
          });
        },
        onSettled: () => {
          setSubmitting(false);
        },
      });
    } catch (error) {
      console.error("Error in handleSubmit:", error);
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
      setSubmitting(false);
    }
  };

  // Google Places styles with proper typing
  const googlePlacesStyles = {
    control: (provided: Record<string, unknown>) => ({
      ...provided,
      boxShadow: "none",
      minHeight: "40px",
      height: "40px",
    }),
    input: (provided: Record<string, unknown>) => ({
      ...provided,
      margin: "0px",
    }),
    option: (provided: Record<string, unknown>) => ({
      ...provided,
      color: "#000",
    }),
    singleValue: (provided: Record<string, unknown>) => ({
      ...provided,
      color: "#000",
    }),
    menuPortal: (base: Record<string, unknown>) => ({ ...base, zIndex: 9999 }),
    menu: (base: Record<string, unknown>) => ({ ...base, zIndex: 9999 }),
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-h-[90vh] overflow-y-auto w-[95vw] max-w-2xl mx-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle>{`Create ${activeTab}`}</DialogTitle>
            <DialogClose asChild>
              <button
                className="rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground"
                aria-label="Close"
              >
                <X className="h-4 w-4" />
              </button>
            </DialogClose>
          </div>
        </DialogHeader>

        <Formik
          initialValues={{
            ...initialValues,
            type: activeTab, // Set the type explicitly
          }}
          validationSchema={getValidationSchema(activeTab)}
          onSubmit={handleSubmit}
          innerRef={formikRef}
          context={{ activeTab }}
          validateOnSubmit={true}
          validateOnBlur={false}
          validateOnChange={false}
        >
          {({
            isSubmitting,
            values,
            setFieldValue,
            validateForm,
            setTouched,
            setSubmitting,
            submitForm,
          }) => (
            <Form className="space-y-4">
              <div>
                <label className="block mb-2 font-medium">
                  {activeTab === "Workshops"
                    ? "Workshop Name"
                    : activeTab === "Webinars"
                    ? "Webinar Name"
                    : "Event Name"}{" "}
                  <span className="text-red-500">*</span>
                </label>
                <Field
                  as={Input}
                  name="name"
                  placeholder={
                    activeTab === "Workshops"
                      ? "Enter workshop name"
                      : activeTab === "Webinars"
                      ? "Enter webinar name"
                      : "Enter event name"
                  }
                  className="w-full"
                />
                <ErrorMessage
                  name="name"
                  component="div"
                  className="text-red-500 text-sm mt-1"
                />
              </div>

              <div>
                <label className="block mb-2 font-medium">
                  {activeTab === "Workshops"
                    ? "Workshop Type"
                    : activeTab === "Webinars"
                    ? "Webinar Type"
                    : "Event Type"}{" "}
                  <span className="text-red-500">*</span>
                </label>
                <Field
                  as={Input}
                  name="type"
                  className="w-full p-2 border rounded"
                  disabled={true}
                />
                <ErrorMessage
                  name="type"
                  component="div"
                  className="text-red-500 text-sm mt-1"
                />
              </div>

              {activeTab === "Webinars" ? (
                <div>
                  <label className="block mb-2 font-medium">
                    Date <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <Field
                      as={Input}
                      name="startDate"
                      type="date"
                      placeholder="DD-MM-YYYY"
                      min={new Date().toISOString().split("T")[0]}
                      className="w-full date-input"
                      style={{
                        position: "relative",
                        appearance: "none",
                        paddingRight: "30px",
                      }}
                    />
                  </div>
                  <ErrorMessage
                    name="startDate"
                    component="div"
                    className="text-red-500 text-sm mt-1"
                  />
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block mb-2 font-medium">
                      Start Date <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <Field
                        as={Input}
                        name="startDate"
                        min={new Date().toISOString().split("T")[0]}
                        type="date"
                        placeholder="DD-MM-YYYY"
                        className="w-full date-input"
                        style={{
                          position: "relative",
                          appearance: "none",
                          paddingRight: "30px",
                        }}
                        onChange={(e) => {
                          setFieldValue("startDate", e.target.value);
                          if (
                            values.endDate &&
                            new Date(e.target.value) > new Date(values.endDate)
                          ) {
                            setFieldValue("endDate", "");
                          }
                        }}
                      />
                    </div>
                    <ErrorMessage
                      name="startDate"
                      component="div"
                      className="text-red-500 text-sm mt-1"
                    />
                  </div>

                  <div>
                    <label className="block mb-2 font-medium">
                      End Date <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <Field
                        as={Input}
                        name="endDate"
                        type="date"
                        placeholder="DD-MM-YYYY"
                        className="w-full date-input"
                        style={{
                          position: "relative",
                          appearance: "none",
                          paddingRight: "30px",
                        }}
                        disabled={!values.startDate}
                        min={
                          values.startDate ||
                          new Date().toISOString().split("T")[0]
                        }
                      />
                    </div>
                    <ErrorMessage
                      name="endDate"
                      component="div"
                      className="text-red-500 text-sm mt-1"
                    />
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block mb-2 font-medium">
                    Start Time <span className="text-red-500">*</span>
                  </label>
                  <Field
                    as={Input}
                    name="startTime"
                    type="time"
                    className="w-full"
                  />
                  <ErrorMessage
                    name="startTime"
                    component="div"
                    className="text-red-500 text-sm mt-1"
                  />
                </div>

                <div>
                  <label className="block mb-2 font-medium">
                    End Time <span className="text-red-500">*</span>
                  </label>
                  <Field
                    as={Input}
                    name="endTime"
                    type="time"
                    className="w-full"
                  />
                  <ErrorMessage
                    name="endTime"
                    component="div"
                    className="text-red-500 text-sm mt-1"
                  />
                </div>
              </div>

              <div>
                <label className="block mb-2 font-medium">
                  Phone Number <span className="text-red-500">*</span>
                </label>
                <Field name="phoneNumber">
                  {({ field, form }) => (
                    <Input
                      type="tel"
                      placeholder="Enter phone number"
                      className="w-full"
                      {...field}
                      value={field.value}
                      onChange={(e) => {
                        const value = e.target.value
                          .replace(/\D/g, "")
                          .slice(0, 10);
                        form.setFieldValue("phoneNumber", value);
                      }}
                      pattern="[0-9]*"
                      inputMode="numeric"
                      maxLength={10}
                    />
                  )}
                </Field>
                <ErrorMessage
                  name="phoneNumber"
                  component="div"
                  className="text-red-500 text-sm mt-1"
                />
              </div>

              <div>
                <label className="block mb-2 font-medium">
                  Email <span className="text-red-500">*</span>
                </label>
                <Field
                  as={Input}
                  name="email"
                  type="email"
                  placeholder="Enter email"
                  className="w-full"
                />
                <ErrorMessage
                  name="email"
                  component="div"
                  className="text-red-500 text-sm mt-1"
                />
              </div>

              <div>
                <label className="block mb-2 font-medium">
                  Description <span className="text-red-500">*</span>
                </label>
                <Field
                  as="textarea"
                  name="description"
                  placeholder="Enter workshop description"
                  className="w-full p-2 border rounded resize-y min-h-[100px]"
                  rows={4}
                />
                <ErrorMessage
                  name="description"
                  component="div"
                  className="text-red-500 text-sm mt-1"
                />
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  id="is_paid"
                  checked={values.is_paid}
                  onCheckedChange={(checked) => {
                    setFieldValue("is_paid", checked);
                    if (!checked) {
                      setFieldValue("price", 0);
                    }
                  }}
                />
                <label htmlFor="is_paid" className="font-medium">
                  Paid Event
                </label>
              </div>

              {values.is_paid && (
                <div>
                  <label className="block mb-2 font-medium">
                    Price <span className="text-red-500">*</span>
                  </label>
                  <Field
                    as={Input}
                    name="price"
                    type="number"
                    min="1"
                    placeholder="Enter price"
                    className="w-full"
                    onKeyDown={(e) => {
                      if (e.key === "." || e.key === ",") {
                        e.preventDefault();
                      }
                    }}
                  />
                  <ErrorMessage
                    name="price"
                    component="div"
                    className="text-red-500 text-sm mt-1"
                  />
                </div>
              )}

              <div>
                <label className="block mb-2 font-medium">
                  {values.is_paid ? "Payment Link" : "Organization Link"}
                </label>
                <Field
                  as={Input}
                  name="payment_link"
                  placeholder={
                    values.is_paid
                      ? "Enter payment link (optional)"
                      : "Enter organization link (optional)"
                  }
                  className="w-full"
                />
                <ErrorMessage
                  name="payment_link"
                  component="div"
                  className="text-red-500 text-sm mt-1"
                />
              </div>

              {activeTab !== "Webinars" && (
                <>
                  <div>
                    <label className="block mb-2 font-medium">
                      {activeTab === "Workshops"
                        ? "Workshop Location"
                        : "Event Location"}{" "}
                      <span className="text-red-500">*</span>
                    </label>
                    <div className="mb-2">
                      <GooglePlacesAutocomplete
                        apiKey={"AIzaSyCS0ObrXEKeubcJ1HsQERMfYaghfcNfFoM"}
                        selectProps={{
                          value: locationSelection,
                          onChange: (selection) => {
                            handleLocationChange(selection);
                            setFieldValue(
                              "event_address",
                              selection?.label || ""
                            );
                            setFieldValue(
                              "event_lat",
                              selection?.value?.geometry?.location?.lat || null
                            );
                            setFieldValue(
                              "event_long",
                              selection?.value?.geometry?.location?.lng || null
                            );
                          },
                          placeholder: "Please enter your address",
                          className: "z-50",
                          styles: googlePlacesStyles,
                        }}
                      />
                      <ErrorMessage
                        name="event_address"
                        component="div"
                        className="text-red-500 text-sm"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block mb-2 font-medium">
                      {activeTab === "Workshops"
                        ? "Workshop Address"
                        : "Event Address"}{" "}
                      <span className="text-red-500">*</span>
                    </label>
                    <Field
                      as="textarea"
                      name="event_location_address"
                      placeholder="Enter additional address details (building, floor, etc.)"
                      className="w-full p-2 border rounded resize-y"
                      rows={2}
                    />
                    <ErrorMessage
                      name="event_location_address"
                      component="div"
                      className="text-red-500 text-sm"
                    />
                  </div>
                </>
              )}

              <div>
                <label className="block mb-2 font-medium">
                  Image <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={(e) => {
                      handleFileUpload(e);
                      if (e.target.files && e.target.files.length > 0) {
                        setFieldValue("image", e.target.files[0]);
                      }
                    }}
                    accept="image/jpeg,image/png,image/jpg"
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                  />
                  {image ? (
                    <div className="flex items-center justify-between px-4 py-3 bg-gray-50 border border-gray-200 rounded-md">
                      <div className="flex items-center gap-2">
                        <File className="h-5 w-5 text-primary" />
                        <span className="text-sm truncate max-w-[180px]">
                          {image.name}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setImage(null);
                          setFieldValue("image", null);
                        }}
                        className="text-gray-500 hover:text-red-500"
                      >
                        <X size={16} />
                      </button>
                    </div>
                  ) : (
                    <div className="flex justify-between items-center px-4 py-3 bg-gray-50 border border-gray-200 rounded-md">
                      <span className="text-gray-500">
                        Upload Image (JPG, PNG)
                      </span>
                      <Upload className="h-5 w-5 text-gray-500" />
                    </div>
                  )}
                </div>
                <ErrorMessage
                  name="image"
                  component="div"
                  className="text-red-500 text-sm mt-1"
                />
              </div>

              <div>
                <label className="block mb-2 font-medium">
                  Thumbnail <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type="file"
                    ref={thumbnailInputRef}
                    onChange={(e) => {
                      handleThumbnailUpload(e);
                      if (e.target.files && e.target.files.length > 0) {
                        setFieldValue("thumbnail", e.target.files[0]);
                      }
                    }}
                    accept="image/jpeg,image/png,image/jpg"
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                  />
                  {thumbnail ? (
                    <div className="flex items-center justify-between px-4 py-3 bg-gray-50 border border-gray-200 rounded-md">
                      <div className="flex items-center gap-2">
                        <File className="h-5 w-5 text-primary" />
                        <span className="text-sm truncate max-w-[180px]">
                          {thumbnail.name}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setThumbnail(null);
                          setFieldValue("thumbnail", null);
                        }}
                        className="text-gray-500 hover:text-red-500"
                      >
                        <X size={16} />
                      </button>
                    </div>
                  ) : (
                    <div className="flex justify-between items-center px-4 py-3 bg-gray-50 border border-gray-200 rounded-md">
                      <span className="text-gray-500">
                        Upload Thumbnail (JPG, PNG)
                      </span>
                      <Upload className="h-5 w-5 text-gray-500" />
                    </div>
                  )}
                </div>
                <ErrorMessage
                  name="thumbnail"
                  component="div"
                  className="text-red-500 text-sm mt-1"
                />
              </div>

              <button
                type="button"
                disabled={EnableLoading || isSubmitting}
                className="w-full bg-blue-900 text-white p-2 rounded hover:bg-blue-800 disabled:opacity-50"
                onClick={async () => {
                  try {
                    // First validate the form to get all errors
                    const errors = await validateForm();

                    // Touch all fields to show validation errors
                    const touchedFields = Object.keys(initialValues).reduce(
                      (acc, field) => {
                        acc[field] = true;
                        return acc;
                      },
                      {} as Record<string, boolean>
                    );

                    // Set all fields as touched to show errors
                    setTouched(touchedFields, false);

                    // If no errors, submit the form
                    if (Object.keys(errors).length === 0) {
                      submitForm();
                    }
                  } catch (error) {
                    console.error("Validation error:", error);
                  }
                }}
              >
                {EnableLoading || isSubmitting
                  ? "Creating..."
                  : activeTab === "Workshops"
                  ? "Add Workshop"
                  : activeTab === "Webinars"
                  ? "Add Webinar"
                  : "Add Events"}
              </button>
            </Form>
          )}
        </Formik>
      </DialogContent>
    </Dialog>
  );
};

/**
 * Custom hook for reverse geocoding coordinates to address
 * @param lat - Latitude coordinate
 * @param lng - Longitude coordinate
 * @returns {Object} The resolved address and loading state
 */
const useReverseGeocode = (lat?: number | null, lng?: number | null) => {
  const [address, setAddress] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchAddress = async () => {
      if (!lat || !lng || lat === 0 || lng === 0) {
        setAddress("");
        return;
      }

      setLoading(true);
      setError(null);

      try {
        const response = await fetch(
          `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=AIzaSyBLrdxlllPwd61wy8Hs5MZG_7pq4KAShg0`
        );
        const data = await response.json();

        if (data.status === "OK" && data.results && data.results.length > 0) {
          setAddress(data.results[0].formatted_address);
        } else {
          setError("Could not retrieve address");
          setAddress("");
        }
      } catch (err) {
        setError("Failed to get location data");
        console.error("Reverse geocoding error:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchAddress();
  }, [lat, lng]);

  return { address, loading, error };
};

interface DeleteConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  isLoading: boolean;
}

const DeleteConfirmationModal = ({
  isOpen,
  onClose,
  onConfirm,
  isLoading,
}: DeleteConfirmationModalProps) => {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md w-[95vw] mx-auto">
        <DialogHeader>
          <DialogTitle>Confirm Delete</DialogTitle>
        </DialogHeader>
        <div className="py-4">
          <p className="text-gray-600">
            Are you sure you want to delete this event? This action cannot be
            undone.
          </p>
        </div>
        <div className="flex justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 text-gray-600 bg-gray-100 rounded-md hover:bg-gray-200"
            disabled={isLoading}
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            disabled={isLoading}
            className="px-4 py-2 text-white bg-red-600 rounded-md hover:bg-red-700 disabled:opacity-50"
          >
            {isLoading ? "Deleting..." : "Delete"}
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

interface Event {
  event_id: number;
  name: string;
  event_type_name: string;
  Email: string;
  Phone_number: string;
  start_date: string;
  end_date: string;
  start_time: string;
  end_time: string;
  price: number;
  status: string;
  image: string;
  description: string;
  event_address: string;
  event_location_address: string;
  event_lat: number;
  event_long: number;
  user_id: string;
}

const CommunityPage = () => {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("Workshops");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const userRole = ROLES.ADMIN;
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [eventToDelete, setEventToDelete] = useState<Event | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [pageConfig, setPageConfig] = useState({
    page: 1,
    pageSize: 10,
    event_type_id: 1,
  });

  const { mutate: verifyEvent } = useVerifyEvent();
  const { mutateAsync: deleteEventMutation } = useDeleteEvent();

  const handleDelete = async () => {
    if (!eventToDelete) return;

    setIsDeleting(true);
    try {
      // Convert event_id to string as required by the API
      const eventId =
        typeof eventToDelete.event_id === "number"
          ? eventToDelete.event_id.toString()
          : eventToDelete.event_id;

      await deleteEventMutation(eventId);

      // Invalidate and refetch queries
      await queryClient.invalidateQueries({ queryKey: ["events"] });
      await queryClient.invalidateQueries({ queryKey: ["eventTypes"] });

      toast({
        title: "Success",
        description: "Event deleted successfully",
        className: "bg-green-50 border-green-200",
      });
      setIsDeleteModalOpen(false);
      setEventToDelete(null);
    } catch (error) {
      console.error("Error deleting event:", error);
      toast({
        title: "Error",
        description: "Failed to delete event. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsDeleting(false);
    }
  };

  const { data: eventTypesData } = useAllEventTypes();

  // Find the event type ID based on active tab
  const activeEventTypeId =
    eventTypesData?.find((type) => type.event_type_name === activeTab)
      ?.event_type_id || 1;
  console.log(activeTab, "activeTab");
  const { data: eventsData } = useAllEvents(
    pageConfig.page,
    pageConfig.pageSize,
    activeEventTypeId,
    searchQuery,
    true
  );

  const tabs =
    eventTypesData
      ?.filter((type) => type.event_type_name !== "Courses")
      .map((type) => type.event_type_name) || [];
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isImageModalOpen, setIsImageModalOpen] = useState(false);

  const eventColumns = [
    {
      header: "S.No.",
      accessor: "serial",
      cell: (_value, _row, rowIndex) =>
        rowIndex !== undefined
          ? (pageConfig.page - 1) * pageConfig.pageSize + rowIndex + 1
          : "-",
    },
    {
      header: "Event Name",
      accessor: "name",
    },
    {
      header: "Event Type",
      accessor: "event_type_name",
      cell: (value) => value || "N/A",
    },
    {
      header: "Email",
      accessor: "Email",
    },
    {
      header: "Phone Number",
      accessor: "Phone_number",
    },
    {
      header: "Start Date",
      accessor: "start_date",
      cell: (value: string) => {
        if (!value) return <span className="text-gray-400">-</span>;
        const date = new Date(value);
        const day = date.getDate().toString().padStart(2, "0");
        const month = (date.getMonth() + 1).toString().padStart(2, "0");
        const year = date.getFullYear();
        return (
          <div className="text-left whitespace-nowrap min-w-[100px]">
            {`${day}-${month}-${year}`}
          </div>
        );
      },
    },
    {
      header: "End Date",
      accessor: "end_date",
      cell: (value: string) => {
        if (!value) return <span className="text-gray-400">-</span>;
        const date = new Date(value);
        const day = date.getDate().toString().padStart(2, "0");
        const month = (date.getMonth() + 1).toString().padStart(2, "0");
        const year = date.getFullYear();
        return (
          <div className="text-left whitespace-nowrap min-w-[100px]">
            {`${day}-${month}-${year}`}
          </div>
        );
      },
    },
    {
      header: "Start Time",
      accessor: "start_time",
    },
    {
      header: "End Time",
      accessor: "end_time",
    },
    {
      header: "Price",
      accessor: "price",
      cell: (value) => (value === 0 ? "Free" : `₹${value}`),
    },
    {
      header: "Status",
      accessor: "status",
      cell: (value, row) => (
        <button
          onClick={() => {
            setSelectedEvent(row);
            setIsViewModalOpen(true);
          }}
          className={`px-3 py-1 rounded focus:outline-none ${
            value === "Approved"
              ? "bg-green-100 text-green-600"
              : value === "Pending"
              ? "bg-yellow-100 text-yellow-600"
              : "bg-red-100 text-red-600"
          }`}
        >
          {value}
        </button>
      ),
    },
    {
      header: "Image",
      accessor: "image",
      cell: (value) =>
        value ? (
          <button
            onClick={() => {
              setSelectedImage(value);
              setIsImageModalOpen(true);
            }}
            className="text-blue-600 hover:text-blue-800"
            title="View Image"
          >
            <Eye className="w-5 h-5" />
          </button>
        ) : (
          <span className="text-gray-400">No image</span>
        ),
    },
    {
      header: "Actions",
      accessor: "actions",
      cell: (_, row) => (
        <div className="flex items-center gap-2">
          {/* <button
            onClick={() => {
              setSelectedEvent(row);
              setIsViewModalOpen(true);
            }}
            className="text-blue-600 hover:text-blue-800 p-1 rounded-full hover:bg-blue-50"
            title="View Details"
          >
            <Eye className="w-4 h-4" />
          </button> */}
          <button
            onClick={() => {
              setEventToDelete(row);
              setIsDeleteModalOpen(true);
            }}
            className="text-red-600 hover:text-red-800 p-1 rounded-full hover:bg-red-50"
            title="Delete Event"
          >
            <img src={deleteicon} alt="delete" className="h-6 w-6" />
          </button>
        </div>
      ),
    },
  ];

  const webinarColumns = [
    {
      header: "S.No.",
      accessor: "serial",
      cell: (_value, _row, rowIndex) =>
        rowIndex !== undefined
          ? (pageConfig.page - 1) * pageConfig.pageSize + rowIndex + 1
          : "-",
    },
    {
      header: "Webinar Name",
      accessor: "name",
    },
    {
      header: "Event Type",
      accessor: "event_type_name",
      cell: (value) => value || "N/A",
    },
    {
      header: "Email",
      accessor: "Email",
    },
    {
      header: "Phone Number",
      accessor: "Phone_number",
    },
    {
      header: "Date",
      accessor: "start_date",
      cell: (value: string) => {
        if (!value) return <span className="text-gray-400">-</span>;
        const date = new Date(value);
        const day = date.getDate().toString().padStart(2, "0");
        const month = (date.getMonth() + 1).toString().padStart(2, "0");
        const year = date.getFullYear();
        return (
          <div className="text-left whitespace-nowrap min-w-[100px]">
            {`${day}-${month}-${year}`}
          </div>
        );
      },
    },
    {
      header: "Start Time",
      accessor: "start_time",
    },
    {
      header: "End Time",
      accessor: "end_time",
    },
    {
      header: "Price",
      accessor: "price",
      cell: (value) => (value === 0 ? "Free" : `₹${value}`),
    },
    {
      header: "Status",
      accessor: "status",
      cell: (value, row) => (
        <button
          onClick={() => {
            setSelectedEvent(row);
            setIsViewModalOpen(true);
          }}
          className={`px-3 py-1 rounded focus:outline-none ${
            value === "Approved"
              ? "bg-green-100 text-green-600"
              : value === "Pending"
              ? "bg-yellow-100 text-yellow-600"
              : "bg-red-100 text-red-600"
          }`}
        >
          {value}
        </button>
      ),
    },
    {
      header: "Image",
      accessor: "image",
      cell: (value) =>
        value ? (
          <button
            onClick={() => {
              setSelectedImage(value);
              setIsImageModalOpen(true);
            }}
            className="text-blue-600 hover:text-blue-800"
            title="View Image"
          >
            <Eye className="w-5 h-5" />
          </button>
        ) : (
          <span className="text-gray-400">No image</span>
        ),
    },
    {
      header: "Actions",
      accessor: "actions",
      cell: (_, row) => (
        <div className="flex items-center gap-2">
          {/* <button
            onClick={() => {
              setSelectedEvent(row);
              setIsViewModalOpen(true);
            }}
            className="text-blue-600 hover:text-blue-800 p-1 rounded-full hover:bg-blue-50"
            title="View Details"
          >
            <Eye className="w-4 h-4" />
          </button> */}
          <button
            onClick={() => {
              setEventToDelete(row);
              setIsDeleteModalOpen(true);
            }}
            className="text-red-600 hover:text-red-800 p-1 rounded-full hover:bg-red-50"
            title="Delete Event"
          >
            <img src={deleteicon} alt="delete" className="h-6 w-6" />
          </button>
        </div>
      ),
    },
  ];

  const workshopColumns = [
    {
      header: "S.No.",
      accessor: "serial",
      cell: (_value, _row, rowIndex) =>
        rowIndex !== undefined
          ? (pageConfig.page - 1) * pageConfig.pageSize + rowIndex + 1
          : "-",
    },
    {
      header: "Workshop Name",
      accessor: "name",
    },
    {
      header: "Event Type",
      accessor: "event_type_name",
      cell: (value) => value || "N/A",
    },
    {
      header: "Email",
      accessor: "Email",
    },
    {
      header: "Phone Number",
      accessor: "Phone_number",
    },
    {
      header: "Start Date",
      accessor: "start_date",
      cell: (value: string) => {
        if (!value) return <span className="text-gray-400">-</span>;
        const date = new Date(value);
        const day = date.getDate().toString().padStart(2, "0");
        const month = (date.getMonth() + 1).toString().padStart(2, "0");
        const year = date.getFullYear();
        return (
          <div className="text-left whitespace-nowrap min-w-[100px]">
            {`${day}-${month}-${year}`}
          </div>
        );
      },
    },
    {
      header: "End Date",
      accessor: "end_date",
      cell: (value: string) => {
        if (!value) return <span className="text-gray-400">-</span>;
        const date = new Date(value);
        const day = date.getDate().toString().padStart(2, "0");
        const month = (date.getMonth() + 1).toString().padStart(2, "0");
        const year = date.getFullYear();
        return (
          <div className="text-left whitespace-nowrap min-w-[100px]">
            {`${day}-${month}-${year}`}
          </div>
        );
      },
    },
    {
      header: "Start Time",
      accessor: "start_time",
    },
    {
      header: "End Time",
      accessor: "end_time",
    },
    {
      header: "Price",
      accessor: "price",
      cell: (value) => (value === 0 ? "Free" : `₹${value}`),
    },
    {
      header: "Status",
      accessor: "status",
      cell: (value, row) => (
        <button
          onClick={() => {
            setSelectedEvent(row);
            setIsViewModalOpen(true);
          }}
          className={`px-3 py-1 rounded focus:outline-none ${
            value === "Approved"
              ? "bg-green-100 text-green-600"
              : value === "Pending"
              ? "bg-yellow-100 text-yellow-600"
              : "bg-red-100 text-red-600"
          }`}
        >
          {value}
        </button>
      ),
    },
    {
      header: "Image",
      accessor: "image",
      cell: (value) =>
        value ? (
          <button
            onClick={() => {
              setSelectedImage(value);
              setIsImageModalOpen(true);
            }}
            className="text-blue-600 hover:text-blue-800"
            title="View Image"
          >
            <Eye className="w-5 h-5" />
          </button>
        ) : (
          <span className="text-gray-400">No image</span>
        ),
    },
    {
      header: "Actions",
      accessor: "actions",
      cell: (_, row) => (
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setEventToDelete(row);
              setIsDeleteModalOpen(true);
            }}
            className="text-red-600 hover:text-red-800 p-1 rounded-full hover:bg-red-50"
            title="Delete Event"
          >
            <img src={deleteicon} alt="delete" className="h-6 w-6" />
          </button>
        </div>
      ),
    },
  ];

  const getColumns = () => {
    switch (activeTab) {
      case "Webinars":
        return webinarColumns;
      case "Workshops":
        return workshopColumns;
      default:
        return eventColumns;
    }
  };

  const getSearchPlaceholder = () => {
    switch (activeTab) {
      case "Webinars":
        return "Search by Name, Email, Phone Number";
      case "Workshops":
        return "Search by Name, Email, Phone Number";
      default:
        return "Search by Name, Email, Phone Number";
    }
  };

  const columns = getColumns();

  const handleAddEvent = (newEvent) => {
    const eventToAdd = {
      ...newEvent,
      id: eventsData?.result?.length ? eventsData.result.length + 1 : 1,
      status: "Approved",
      images: newEvent.image ? true : false,
    };
  };

  const ImagePreviewModal = ({ imageUrl, isOpen, onClose }) => {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-md w-[95vw] mx-auto">
          <DialogHeader></DialogHeader>
          {imageUrl ? (
            <img
              src={imageUrl}
              alt="Event"
              className="w-[80%] h-auto rounded shadow mx-auto"
            />
          ) : (
            <p className="text-center text-gray-500">No image available.</p>
          )}
        </DialogContent>
      </Dialog>
    );
  };
  const ViewEventModal = ({ event, isOpen, onClose, userRole }) => {
    const [showRejectReason, setShowRejectReason] = useState(false);
    const [rejectReason, setRejectReason] = useState("");
    const [isLoading, setIsLoading] = useState(false);
    const { address: resolvedLocation, loading: locationLoading } =
      useReverseGeocode(event?.event_lat, event?.event_long);

    console.log(event, "event");
    if (!event) return null;

    const handleApprove = () => {
      setIsLoading(true);
      verifyEvent(
        {
          event_id: event.event_id,
          status: "Approved",
          body: "",
          user_id: event.user_id,
        },
        {
          onSuccess: () => {
            toast({
              title: "Success",
              description: "Event has been approved successfully",
              className: "bg-green-50 border-green-200",
            });
            onClose();
          },
          onError: (error) => {
            toast({
              title: "Error",
              description: "Failed to approve event. Please try again.",
              variant: "destructive",
            });
            console.error("Error approving event:", error);
          },
          onSettled: () => {
            setIsLoading(false);
          },
        }
      );
    };

    const handleReject = () => {
      if (!rejectReason.trim()) {
        toast({
          title: "Rejection reason required",
          description: "Please provide a reason for rejection.",
          variant: "destructive",
        });
        return;
      }

      // Count only alphabetic characters using regex
      const alphabetCount = (rejectReason.match(/[a-zA-Z]/g) || []).length;

      if (alphabetCount < 3) {
        toast({
          title: "Rejection reason too short",
          description:
            "Please provide at least 3 alphabetic characters in your reason.",
          variant: "destructive",
        });
        return;
      }

      setIsLoading(true);

      verifyEvent(
        {
          event_id: event.event_id,
          status: "Reject" as const,
          body: rejectReason,
          user_id: event.user_id,
        },
        {
          onSuccess: (response) => {
            toast({
              title: "Success",
              description: "Event has been rejected successfully",
              className: "bg-yellow-50 border-yellow-200",
            });
            onClose();
          },
          onError: (error: AxiosError) => {
            console.error("Full error object:", error);
            const errorMessage =
              (error as AxiosError<{ message: string }>)?.response?.data
                ?.message || "Failed to reject event. Please try again.";
            toast({
              title: "Error",
              description: errorMessage,
              variant: "destructive",
            });
          },
          onSettled: () => {
            setIsLoading(false);
          },
        }
      );
    };

    const role = localStorage.getItem("roleName");
    const showActionButtons =
      event.status === "Pending" &&
      userRole === ROLES.ADMIN &&
      role !== "Events Admin";
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-[700px] mx-auto max-h-[85vh] overflow-hidden">
          <DialogHeader>
            <h3 className="text-xl font-bold">
              {event.event_type_name === "Workshops"
                ? "Workshop Details"
                : event.event_type_name === "Webinars"
                ? "Webinar Details"
                : "Event Details"}
            </h3>
          </DialogHeader>
          <div className="space-y-3 overflow-y-auto pr-4 max-h-[calc(85vh-120px)]">
            <p>
              <strong>Name:</strong> {event.name}
            </p>
            <p>
              <strong>Type:</strong> {event.event_type_name || "N/A"}
            </p>
            <p>
              <strong>Email:</strong> {event.Email}
            </p>
            <p>
              <strong>Phone:</strong> {event.Phone_number}
            </p>
            <p>
              <strong>Date:</strong> {formatDate(event.start_date)}
            </p>
            <p>
              <strong>Start Time:</strong> {event.start_time}
            </p>
            <p>
              <strong>End Time:</strong> {event.end_time}
            </p>
            <p>
              <strong>Price:</strong>{" "}
              {event.price === 0 ? "Free" : `₹${event.price}`}
            </p>
            <p className="flex items-center gap-2">
              <strong>Status:</strong>
              <span
                className={`px-2 py-1 rounded text-sm font-medium ${
                  event.status === "Approved"
                    ? "bg-green-100 text-green-700"
                    : event.status === "Pending"
                    ? "bg-yellow-100 text-yellow-700"
                    : "bg-red-100 text-red-700"
                }`}
              >
                {event.status}
              </span>
            </p>

            <p>
              <strong>Description:</strong>
              <span title={event.description}>
                {event.description.length > 45
                  ? event.description.slice(0, 45) + "..."
                  : event.description}
              </span>
            </p>
            {event.event_address && (
              <p>
                <strong>Event Address:</strong>
                <span title={event.event_address}>
                  {typeof event.event_address === "string" &&
                  event.event_address.length > 45
                    ? event.event_address.slice(0, 45) + "..."
                    : event.event_address}
                </span>
              </p>
            )}

            {event.event_location_address && (
              <p>
                <strong>Event Address:</strong>{" "}
                <span title={event.event_location_address}>
                  {event.event_location_address.length > 15
                    ? `${event.event_location_address.slice(0, 15)}...`
                    : event.event_location_address}
                </span>
              </p>
            )}

            {event.event_lat &&
              event.event_long &&
              event.event_lat !== 0.1 &&
              event.event_long !== 0.1 && (
                <p>
                  <strong>Map Location:</strong>{" "}
                  <span title={resolvedLocation}>
                    {locationLoading
                      ? "Loading location..."
                      : resolvedLocation
                      ? resolvedLocation.length > 30
                        ? `${resolvedLocation.slice(0, 30)}...`
                        : resolvedLocation
                      : `${event.event_lat}, ${event.event_long}`}
                  </span>
                  {resolvedLocation && (
                    <a
                      href={`https://www.google.com/maps?q=${event.event_lat},${event.event_long}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="ml-2 text-blue-600 hover:underline text-sm"
                    >
                      View on map
                    </a>
                  )}
                </p>
              )}

            {/* Only show action buttons if user is an admin AND event status is Pending */}
            {showActionButtons && (
              <div className="pt-4 space-y-2">
                {!showRejectReason ? (
                  <div className="flex gap-4">
                    <button
                      className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed"
                      onClick={handleApprove}
                      disabled={isLoading}
                    >
                      {isLoading ? "Approving..." : "Approve"}
                    </button>
                    <button
                      className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed"
                      onClick={() => setShowRejectReason(true)}
                      disabled={isLoading}
                    >
                      Reject
                    </button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <textarea
                      className="w-full p-2 border border-gray-300 rounded"
                      rows={3}
                      placeholder="Enter rejection reason..."
                      value={rejectReason}
                      onChange={(e) => setRejectReason(e.target.value)}
                      disabled={isLoading}
                    />
                    <div className="flex justify-end gap-2">
                      <button
                        className="bg-gray-300 px-4 py-2 rounded disabled:opacity-50 disabled:cursor-not-allowed"
                        onClick={() => setShowRejectReason(false)}
                        disabled={isLoading}
                      >
                        Cancel
                      </button>
                      <button
                        className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed"
                        onClick={handleReject}
                        disabled={isLoading}
                      >
                        {isLoading ? "Submitting..." : "Submit Rejection"}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    );
  };

  return (
    <div className="p-4">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 gap-4">
        <div className="overflow-x-auto pb-2 hide-scrollbar w-full sm:w-auto">
          <div className="flex gap-2 min-w-min">
            {tabs.map((tab) => (
              <TabButton
                key={tab}
                label={tab}
                active={activeTab === tab}
                onClick={() => {
                  setActiveTab(tab);
                  setSearchQuery(""); // Reset search when changing tabs
                }}
              />
            ))}
          </div>
        </div>

        <div className="flex gap-4 items-center">
          <div className="relative">
            <input
              type="text"
              placeholder={getSearchPlaceholder()}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full sm:w-80 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                <X size={16} />
              </button>
            )}
          </div>
          <button
            className="bg-blue-900 text-white px-4 py-2 rounded-lg whitespace-nowrap"
            onClick={() => setIsModalOpen(true)}
          >
            {`+ Create ${activeTab}`}
          </button>
        </div>
      </div>

      {/* Add a style element to hide scrollbars on certain browsers while maintaining functionality */}
      <style>
        {`
        .hide-scrollbar::-webkit-scrollbar {
          display: none; /* Safari and Chrome */
        }
        .hide-scrollbar {
          -ms-overflow-style: none;  /* IE and Edge */
          scrollbar-width: none;  /* Firefox */
        }
        `}
      </style>

      {activeTab === "Courses" ? (
        <div className="flex flex-col items-center justify-center py-12 md:py-20 bg-gray-50 rounded-lg">
          <div className="mb-6 md:mb-8">
            <svg
              width="100"
              height="100"
              viewBox="0 0 200 200"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-auto"
            >
              <circle
                cx="100"
                cy="100"
                r="96"
                stroke="#DDE1E6"
                strokeWidth="8"
              />
              <path
                d="M100 44V156"
                stroke="#0F2557"
                strokeWidth="12"
                strokeLinecap="round"
              />
              <path
                d="M156 100H44"
                stroke="#0F2557"
                strokeWidth="12"
                strokeLinecap="round"
              />
            </svg>
          </div>
          <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-blue-900 mb-3 text-center">
            Courses Coming Soon!
          </h2>
          <p className="text-gray-600 text-base md:text-lg text-center max-w-xl px-4">
            We're working hard to bring you high-quality dental courses. Stay
            tuned for exciting learning opportunities.
          </p>
        </div>
      ) : eventsData?.result?.length > 0 ? (
        <div className="overflow-x-auto">
          <DataTable
            columns={columns}
            data={eventsData?.result || []}
            pagination={{
              currentPage: pageConfig.page,
              totalPages: Math.ceil(
                (eventsData?.count || 0) / pageConfig.pageSize
              ),
              pageSize: pageConfig.pageSize,
              totalItems: eventsData?.count || 0,
              onPageChange: (page) =>
                setPageConfig((prev) => ({ ...prev, page })),
              onPageSizeChange: (pageSize) =>
                setPageConfig((prev) => ({ ...prev, pageSize, page: 1 })),
            }}
          />
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-12 bg-gray-50 rounded-lg">
          <p className="text-gray-500 text-lg">No data available</p>
          <p className="text-gray-400 text-sm mt-2 text-center px-4">
            There are no events to display at this time.
          </p>
        </div>
      )}

      <CreateEventModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onAddEvent={handleAddEvent}
        activeTab={activeTab}
      />
      <ViewEventModal
        event={selectedEvent}
        isOpen={isViewModalOpen}
        onClose={() => setIsViewModalOpen(false)}
        userRole={userRole} // Now this will be properly defined
      />

      <ImagePreviewModal
        imageUrl={selectedImage}
        isOpen={isImageModalOpen}
        onClose={() => setIsImageModalOpen(false)}
      />

      <DeleteConfirmationModal
        isOpen={isDeleteModalOpen}
        onClose={() => {
          setIsDeleteModalOpen(false);
          setEventToDelete(null);
        }}
        onConfirm={handleDelete}
        isLoading={isDeleting}
      />
    </div>
  );
};

export default CommunityPage;
