import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Search, Plus, ChevronLeft, ChevronRight, Trash2 } from "lucide-react";
import CreateJobModal from "@/components/modals/CreateJobModal";
import DeleteConfirmationModal from "@/components/modals/DeleteConfirmationModal";
import { useJobs, useDeleteJob } from "@/services/api";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/components/ui/use-toast";
import TablePagination from "@/components/ui/TablePagination";
import editicon from "../../public/lovable-uploads/edit bg.svg";
import deleteicon from "../../public/lovable-uploads/delete bg.svg";

interface Job {
  job_type: number;
  Clinic_id: string;
  Clinic_name: string;
  Clinic_address: string;
  job_id: string;
  user_id: string;
  job_title: string;
  eligibility: "MDS Doctor" | "BDS Doctor";
  type: "Full Time" | "Part Time";
  skills: string;
  Responsibilities: string;
  minimum_req_experience: string;
  monthly_scalary_range: number;
  working_hours: string;
  working_timings: string;
  holidays: string;
  other_info: string;
  job_description: string;
  is_saved: boolean;
  is_applied: boolean;
  job_applied_count: number;
  Created_at: string;
}

interface Consultation {
  job_type: number;
  Clinic_id: string;
  job_id: string;
  user_id: string;
  job_title: string;
  job_description: string;
  special_required: string;
  skills: string;
  date: string;
  time: string;
  case_description: string;
  payment: string;
  is_saved: boolean;
  is_applied: boolean;
  job_applied_count: number;
  Clinic_name: string;
  Clinic_address: string;
  eligibility: "MDS Doctor" | "BDS Doctor";
  Created_at: string;
}

interface JobsResponse {
  jobs: {
    recomended_jobs: Job[];
    top_pick_jobs: Job[];
  };
  is_verified: boolean;
  totalCount: number;
}

interface ConsultationsResponse {
  consultations: Consultation[];
  is_verified: boolean;
  totalCount: number;
}

const JobPostingsPage = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [searchQuery, setSearchQuery] = useState("");
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("jobs");
  const [deleteItemId, setDeleteItemId] = useState<string | null>(null);
  const { toast } = useToast();

  const {
    data: response,
    isLoading,
    error,
  } = useJobs(
    activeTab === "jobs" ? 1 : 2,
    currentPage - 1,
    pageSize,
    searchQuery
  );

  const responseData = response?.data;

  // For jobs tab, use a single array approach instead of combining two arrays
  const jobs: Job[] =
    responseData &&
    "jobs" in responseData &&
    typeof responseData.jobs === "object" &&
    "recomended_jobs" in responseData.jobs
      ? (responseData.jobs as { recomended_jobs: Job[] }).recomended_jobs
      : [];

  // For consultations tab, use a single array approach
  const consultations: Consultation[] =
    responseData &&
    "consultations" in responseData &&
    responseData.consultations &&
    typeof responseData.consultations === "object" &&
    "recomended_jobs" in responseData.consultations
      ? (responseData.consultations as { recomended_jobs: Consultation[] })
          .recomended_jobs
      : [];

  const totalCount = response?.data?.totalCount || 0;

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const day = date.getDate().toString().padStart(2, "0");
    const month = (date.getMonth() + 1).toString().padStart(2, "0");
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;
  };

  const formatSalary = (salary: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(salary);
  };

  const deleteJob = useDeleteJob();

  const handleDelete = (itemId: string) => {
    setDeleteItemId(itemId);
  };

  const handleConfirmDelete = async () => {
    if (deleteItemId) {
      try {
        await deleteJob.mutateAsync(deleteItemId);
        toast({
          title: "Success",
          description: "Job deleted successfully",
          variant: "success",
        });
        setDeleteItemId(null);

        // Check if current page becomes empty after deletion and adjust if needed
        const currentItems = activeTab === "jobs" ? jobs : consultations;

        const filteredItems = searchQuery
          ? currentItems.filter(
              (item: Job | Consultation) =>
                item.job_title
                  ?.toLowerCase()
                  .includes(searchQuery.toLowerCase()) ||
                item.Clinic_name?.toLowerCase().includes(
                  searchQuery.toLowerCase()
                )
            )
          : currentItems;

        // If after deletion this page would be empty, go to previous page
        if (filteredItems.length <= 1 && currentPage > 1) {
          setCurrentPage(currentPage - 1);
        }
      } catch (error) {
        console.error("Error deleting job:", error);
        toast({
          title: "Error",
          description: "Failed to delete job",
          variant: "destructive",
        });
      }
    }
  };

  const renderJobRow = (job: Job, index: number) => (
    <TableRow key={job.job_id}>
      <TableCell className="text-center font-medium">
        {(currentPage - 1) * pageSize + index + 1}
      </TableCell>
      <TableCell className="font-medium">{job.job_title}</TableCell>
      <TableCell>{job.Clinic_name}</TableCell>
      <TableCell>{job.eligibility}</TableCell>
      <TableCell>{job.minimum_req_experience}</TableCell>
      <TableCell>
        <Badge variant={job.type === "Full Time" ? "success" : "secondary"}>
          {job.type}
        </Badge>
      </TableCell>
      <TableCell>{formatSalary(job.monthly_scalary_range)}</TableCell>
      <TableCell>{formatDate(job.Created_at)}</TableCell>
      <TableCell>
        <Button
          variant="ghost"
          size="icon"
          className="text-destructive hover:text-destructive hover:bg-destructive/10"
          onClick={() => handleDelete(job.job_id)}
        >
          <img src={deleteicon} alt="delete" className="h-6 w-6" />
        </Button>
      </TableCell>
    </TableRow>
  );

  const renderConsultationRow = (consultation: Consultation, index: number) => (
    <TableRow key={consultation.job_id}>
      <TableCell className="text-center font-medium">
        {(currentPage - 1) * pageSize + index + 1}
      </TableCell>
      <TableCell className="font-medium">{consultation.job_title}</TableCell>
      <TableCell>{consultation.Clinic_name}</TableCell>
      <TableCell>
        {consultation.skills || consultation.special_required}
      </TableCell>
      <TableCell>
        {formatConsultationDateTime(consultation.date, consultation.time)}
      </TableCell>
      <TableCell>{consultation.eligibility}</TableCell>
      <TableCell>{formatSalary(parseInt(consultation.payment))}</TableCell>
      <TableCell>{formatDate(consultation.Created_at)}</TableCell>
      <TableCell>
        <Button
          variant="ghost"
          size="icon"
          className="text-destructive hover:text-destructive hover:bg-destructive/10"
          onClick={() => handleDelete(consultation.job_id)}
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </TableCell>
    </TableRow>
  );

  const formatConsultationDateTime = (date: string, time: string) => {
    return `${date} ${time}`;
  };

  return (
    <div className="container mx-auto py-6 space-y-4">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <div className="flex justify-between items-center mb-4">
          <TabsList>
            <TabsTrigger value="jobs">Jobs</TabsTrigger>
            <TabsTrigger value="consultation">Consultations</TabsTrigger>
          </TabsList>

          <div className="flex items-center gap-4">
            <div className="relative w-80">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder={
                  activeTab === "jobs"
                    ? "Search By Job Title, Clinic Name"
                    : "Search By Case Title, Clinic Name"
                }
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1); // Reset to first page when searching
                }}
                className="pl-8 w-full"
              />
            </div>
          </div>
        </div>

        <TabsContent value="jobs" className="mt-0">
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>S.No</TableHead>
                  <TableHead>Job Title</TableHead>
                  <TableHead>Clinic Name</TableHead>
                  <TableHead>Eligibility</TableHead>
                  <TableHead>Experience</TableHead>
                  <TableHead>Job Type</TableHead>
                  <TableHead>Salary</TableHead>
                  <TableHead>Posted Date</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={9} className="text-center py-4">
                      Loading...
                    </TableCell>
                  </TableRow>
                ) : error ? (
                  <TableRow>
                    <TableCell
                      colSpan={9}
                      className="text-center py-4 text-red-500"
                    >
                      Error loading jobs
                    </TableCell>
                  </TableRow>
                ) : (
                  (() => {
                    const filteredItems = searchQuery
                      ? jobs.filter(
                          (job: Job) =>
                            job.job_title
                              .toLowerCase()
                              .includes(searchQuery.toLowerCase()) ||
                            job.Clinic_name.toLowerCase().includes(
                              searchQuery.toLowerCase()
                            )
                        )
                      : jobs;

                    if (
                      !Array.isArray(filteredItems) ||
                      filteredItems.length === 0
                    ) {
                      return (
                        <TableRow>
                          <TableCell colSpan={9} className="text-center py-4">
                            No jobs found
                          </TableCell>
                        </TableRow>
                      );
                    }

                    return filteredItems.map((job: Job, index: number) =>
                      renderJobRow(job, index)
                    );
                  })()
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="consultation" className="mt-0">
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>S.No</TableHead>
                  <TableHead>Case Title</TableHead>
                  <TableHead>Clinic Name</TableHead>
                  <TableHead>Specialization</TableHead>
                  <TableHead>Date & Time</TableHead>
                  <TableHead>Eligibility</TableHead>
                  <TableHead>Payment</TableHead>
                  <TableHead>Posted Date</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={9} className="text-center py-4">
                      Loading...
                    </TableCell>
                  </TableRow>
                ) : error ? (
                  <TableRow>
                    <TableCell
                      colSpan={9}
                      className="text-center py-4 text-red-500"
                    >
                      Error loading consultations
                    </TableCell>
                  </TableRow>
                ) : (
                  (() => {
                    const filteredItems = searchQuery
                      ? consultations.filter(
                          (consultation: Consultation) =>
                            consultation.job_title
                              .toLowerCase()
                              .includes(searchQuery.toLowerCase()) ||
                            consultation.Clinic_name.toLowerCase().includes(
                              searchQuery.toLowerCase()
                            )
                        )
                      : consultations;

                    if (
                      !Array.isArray(filteredItems) ||
                      filteredItems.length === 0
                    ) {
                      return (
                        <TableRow>
                          <TableCell colSpan={9} className="text-center py-4">
                            No consultations found
                          </TableCell>
                        </TableRow>
                      );
                    }

                    return filteredItems.map(
                      (consultation: Consultation, index: number) =>
                        renderConsultationRow(consultation, index)
                    );
                  })()
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
      </Tabs>

      <TablePagination
        currentPage={currentPage}
        pageSize={pageSize}
        totalItems={totalCount}
        onPageChange={setCurrentPage}
        onPageSizeChange={(newPageSize) => {
          setPageSize(newPageSize);
          setCurrentPage(1);
        }}
      />

      <CreateJobModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        jobType={activeTab === "jobs" ? 1 : 2}
      />

      <DeleteConfirmationModal
        isOpen={!!deleteItemId}
        onClose={() => setDeleteItemId(null)}
        onConfirm={handleConfirmDelete}
        itemType={activeTab === "jobs" ? "job" : "consultation"}
      />
    </div>
  );
};

export default JobPostingsPage;
