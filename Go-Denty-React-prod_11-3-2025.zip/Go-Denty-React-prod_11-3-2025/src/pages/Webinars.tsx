import React, { useState } from "react";
import { usePostEvent, useAllEvents } from "@/services/api";
import { toast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface FormData {
  title: string;
  description: string;
  date: string;
  startTime: string;
  endTime: string;
  speakerName: string;
  speakerBio: string;
  registrationLink: string;
  category: string;
  isPaid: boolean;
  price: string;
}

interface FormErrors {
  title?: string;
  description?: string;
  date?: string;
  startTime?: string;
  endTime?: string;
  speakerName?: string;
  speakerBio?: string;
  registrationLink?: string;
  category?: string;
  price?: string;
}

const initialFormState: FormData = {
  title: "",
  description: "",
  date: "",
  startTime: "",
  endTime: "",
  speakerName: "",
  speakerBio: "",
  registrationLink: "",
  category: "",
  isPaid: false,
  price: "0",
};

/**
 * Webinars component for managing webinar events
 * @returns Webinars management interface
 */
function Webinars() {
  const { mutate: postEvent } = usePostEvent();
  const [isLoading, setIsLoading] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState<FormData>(initialFormState);
  const [errors, setErrors] = useState<FormErrors>({});
  const [showErrors, setShowErrors] = useState(false);

  const handleChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const validateForm = (data: FormData): FormErrors => {
    const errors: FormErrors = {};
    const currentDate = new Date();

    if (!data.title.trim()) {
      errors.title = "Webinar title is required";
    }

    if (!data.description.trim()) {
      errors.description = "Description is required";
    } else if (data.description.length < 50) {
      errors.description = "Description must be at least 50 characters long";
    }

    if (!data.date) {
      errors.date = "Date is required";
    } else {
      const selectedDate = new Date(data.date);
      if (selectedDate < currentDate) {
        errors.date = "Date cannot be in the past";
      }
    }

    if (!data.startTime) {
      errors.startTime = "Start time is required";
    }

    if (!data.endTime) {
      errors.endTime = "End time is required";
    } else if (data.startTime && data.endTime <= data.startTime) {
      errors.endTime = "End time must be after start time";
    }

    if (!data.speakerName.trim()) {
      errors.speakerName = "Speaker name is required";
    }

    if (!data.speakerBio.trim()) {
      errors.speakerBio = "Speaker bio is required";
    }

    if (!data.registrationLink.trim()) {
      errors.registrationLink = "Registration link is required";
    } else {
      try {
        new URL(data.registrationLink);
      } catch {
        errors.registrationLink = "Please enter a valid URL";
      }
    }

    if (!data.category) {
      errors.category = "Category is required";
    }

    if (data.isPaid && (!data.price.trim() || Number(data.price) <= 0)) {
      errors.price = "Please enter a valid price for paid webinars";
    }

    return errors;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const validationErrors = validateForm(formData);
    setErrors(validationErrors);
    setShowErrors(true);

    if (Object.keys(validationErrors).length === 0) {
      setIsLoading(true);
      try {
        const userRole = localStorage.getItem("roleName");
        const status = userRole === "Super Admin" ? "Approved" : "Pending";

        const eventData = {
          name: formData.title,
          description: formData.description,
          start_date: formData.date,
          end_date: formData.date,
          start_time: formData.startTime,
          end_time: formData.endTime,
          speaker_name: formData.speakerName,
          speaker_bio: formData.speakerBio,
          registration_link: formData.registrationLink,
          category: formData.category,
          is_paid: formData.isPaid,
          price: formData.isPaid ? Number(formData.price) : 0,
          event_type: {
            event_type_id: 2, // Webinar event type ID
            event_type_name: "Webinars",
          },
          status: status,
          Phone_number: "",
          Email: "",
          image: "",
          course_title: formData.title,
          course_duration: "",
          course_preview: "",
          event_lat: 0,
          event_long: 0,
          event_address: "Online",
          pricingmode: formData.isPaid ? "paid" : "free",
          is_admin: true,
        };

        postEvent(eventData, {
          onSuccess: () => {
            toast({
              title: "Success",
              description: `Webinar ${
                status === "Approved"
                  ? "created and approved"
                  : "submitted for approval"
              }`,
            });
            setIsModalOpen(false);
            resetForm();
          },
          onError: (error) => {
            toast({
              title: "Error",
              description: "Failed to create webinar. Please try again.",
              variant: "destructive",
            });
          },
        });
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to create webinar. Please try again.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    }
  };

  const resetForm = () => {
    setFormData(initialFormState);
    setErrors({});
    setShowErrors(false);
  };

  return (
    <div className="container mx-auto p-6">
      <Dialog
        open={isModalOpen}
        onOpenChange={(open) => {
          if (!open) resetForm();
          setIsModalOpen(open);
        }}
      >
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create New Webinar</DialogTitle>
            <DialogDescription>
              Fill in the details below to create a new webinar
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-6">
            {showErrors && Object.keys(errors).length > 0 && (
              <Alert variant="destructive" className="mb-6">
                <AlertDescription>
                  <ul className="list-disc pl-4">
                    {Object.entries(errors).map(([field, error]) => (
                      <li key={field} className="text-sm">
                        {error}
                      </li>
                    ))}
                  </ul>
                </AlertDescription>
              </Alert>
            )}

            <div className="grid gap-4">
              <div className="space-y-2">
                <Label htmlFor="title">
                  Webinar Title <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="title"
                  name="title"
                  value={formData.title}
                  onChange={handleChange}
                  className={errors.title ? "border-red-500" : ""}
                />
                {errors.title && (
                  <p className="text-sm text-red-500">{errors.title}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">
                  Description <span className="text-red-500">*</span>
                </Label>
                <Textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  className={errors.description ? "border-red-500" : ""}
                  rows={4}
                />
                {errors.description && (
                  <p className="text-sm text-red-500">{errors.description}</p>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="date">
                    Date <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="date"
                    name="date"
                    type="date"
                    min={new Date().toISOString().split("T")[0]}
                    value={formData.date}
                    onChange={handleChange}
                    className={errors.date ? "border-red-500" : ""}
                  />
                  {errors.date && (
                    <p className="text-sm text-red-500">{errors.date}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="category">
                    Category <span className="text-red-500">*</span>
                  </Label>
                  <Select
                    name="category"
                    value={formData.category}
                    onValueChange={(value) => {
                      setFormData((prev) => ({ ...prev, category: value }));
                      if (errors.category) {
                        setErrors((prev) => ({ ...prev, category: undefined }));
                      }
                    }}
                  >
                    <SelectTrigger
                      className={errors.category ? "border-red-500" : ""}
                    >
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="GENERAL DENTISTRY">
                        General Dentistry
                      </SelectItem>
                      <SelectItem value="ENDODONTICS">Endodontics</SelectItem>
                      <SelectItem value="PROSTHODONTICS">
                        Prosthodontics
                      </SelectItem>
                      <SelectItem value="ORTHODONTICS">Orthodontics</SelectItem>
                      <SelectItem value="PERIODONTICS">Periodontics</SelectItem>
                      <SelectItem value="PEDODONTICS">Pedodontics</SelectItem>
                      <SelectItem value="ORAL PATHOLOGY">
                        Oral Pathology
                      </SelectItem>
                      <SelectItem value="OMR">OMR</SelectItem>
                      <SelectItem value="OMFS">OMFS</SelectItem>
                    </SelectContent>
                  </Select>
                  {errors.category && (
                    <p className="text-sm text-red-500">{errors.category}</p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="startTime">
                    Start Time <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="startTime"
                    name="startTime"
                    type="time"
                    value={formData.startTime}
                    onChange={handleChange}
                    className={errors.startTime ? "border-red-500" : ""}
                  />
                  {errors.startTime && (
                    <p className="text-sm text-red-500">{errors.startTime}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="endTime">
                    End Time <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="endTime"
                    name="endTime"
                    type="time"
                    value={formData.endTime}
                    onChange={handleChange}
                    className={errors.endTime ? "border-red-500" : ""}
                  />
                  {errors.endTime && (
                    <p className="text-sm text-red-500">{errors.endTime}</p>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="speakerName">
                  Speaker Name <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="speakerName"
                  name="speakerName"
                  value={formData.speakerName}
                  onChange={handleChange}
                  className={errors.speakerName ? "border-red-500" : ""}
                />
                {errors.speakerName && (
                  <p className="text-sm text-red-500">{errors.speakerName}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="speakerBio">
                  Speaker Bio <span className="text-red-500">*</span>
                </Label>
                <Textarea
                  id="speakerBio"
                  name="speakerBio"
                  value={formData.speakerBio}
                  onChange={handleChange}
                  className={errors.speakerBio ? "border-red-500" : ""}
                  rows={3}
                />
                {errors.speakerBio && (
                  <p className="text-sm text-red-500">{errors.speakerBio}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="registrationLink">
                  Registration Link <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="registrationLink"
                  name="registrationLink"
                  type="url"
                  value={formData.registrationLink}
                  onChange={handleChange}
                  className={errors.registrationLink ? "border-red-500" : ""}
                  placeholder="https://example.com/register"
                />
                {errors.registrationLink && (
                  <p className="text-sm text-red-500">
                    {errors.registrationLink}
                  </p>
                )}
              </div>

              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="isPaid"
                    checked={formData.isPaid}
                    onChange={(e) => {
                      setFormData((prev) => ({
                        ...prev,
                        isPaid: e.target.checked,
                        price: e.target.checked ? prev.price : "0",
                      }));
                    }}
                    className="h-4 w-4 rounded border-gray-300"
                  />
                  <Label htmlFor="isPaid">This is a paid webinar</Label>
                </div>

                {formData.isPaid && (
                  <div className="space-y-2">
                    <Label htmlFor="price">
                      Price (₹) <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="price"
                      name="price"
                      type="number"
                      min="0"
                      value={formData.price}
                      onChange={handleChange}
                      className={errors.price ? "border-red-500" : ""}
                    />
                    {errors.price && (
                      <p className="text-sm text-red-500">{errors.price}</p>
                    )}
                  </div>
                )}
              </div>
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setIsModalOpen(false);
                  resetForm();
                }}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading ? "Creating..." : "Create Webinar"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default Webinars;
