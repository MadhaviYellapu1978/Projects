
import React, { useState } from 'react';
import { mockData } from '../data/mockData';
import TabButton from '../components/ui/TabButton';
import DataTable from '../components/ui/DataTable';
import SearchInput from '../components/ui/SearchInput';
import { CreateButton } from '../components/ui/button';

const ShopManagementPage = () => {
  const [activeTab, setActiveTab] = useState('Vendors');

  const vendorColumns = [
    { header: 'ID', accessor: 'id' },
    { header: 'VENDOR NAME', accessor: 'vendorName' },
    { header: 'PHONE NUMBER', accessor: 'phone' },
    { header: 'EMAIL', accessor: 'email' },
    { header: 'WEBSITE', accessor: 'website' },
    { header: 'ADDRESS', accessor: 'address' },
    { 
      header: 'STATUS', 
      accessor: 'status',
      cell: (value: any) => (
        <span className="status-badge status-badge-active">Active</span>
      ),
    },
  ];

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div className="flex space-x-4">
          <TabButton 
            label="Vendors" 
            active={activeTab === 'Vendors'} 
            onClick={() => setActiveTab('Vendors')} 
          />
          <TabButton 
            label="Categories" 
            active={activeTab === 'Categories'} 
            onClick={() => setActiveTab('Categories')} 
          />
        </div>
        <CreateButton 
          variant="default" 
          onClick={() => console.log('Create Vendor clicked')}
        >
          Create Vendor
        </CreateButton>
      </div>
      
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="text-xl font-semibold flex items-center gap-2">
            Vendors <span className="text-gray-500">(100)</span>
          </div>
          <div className="w-full sm:w-64">
            <SearchInput placeholder="Search..." />
          </div>
        </div>

        <DataTable 
          columns={vendorColumns} 
          data={mockData.vendors.slice(0, 8)}
        />
      </div>
    </div>
  );
};

export default ShopManagementPage;
