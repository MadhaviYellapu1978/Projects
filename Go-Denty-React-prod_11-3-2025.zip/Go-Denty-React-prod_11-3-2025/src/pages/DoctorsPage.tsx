/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState, useEffect, useMemo, useCallback } from "react";
import { mockData } from "../data/mockData";
import TabButton from "../components/ui/TabButton";
import DataTable from "../components/ui/DataTable";
import SearchInput from "../components/ui/SearchInput";
import SelectDropdown from "../components/ui/SelectDropdown";
import StatCard from "../components/ui/StatCard";
import { CreateButton } from "../components/ui/button-custom";
import { CalendarDays, Plus, User2, Edit2, Trash2 } from "lucide-react";
import DoctorDetailsModal from "../components/doctors/DoctorDetailsModal";
import { Button } from "@/components/ui/button";
import CreateDoctorModal from "../components/doctors/CreateDoctorModal";
import { useAllUsers } from "@/services/api";
import debounce from "lodash/debounce";
import axios from "axios";
import { QueryClient, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { EditDoctorDialog } from "@/components/doctors/EditDoctorDialog";
import { DeleteDoctorDialog } from "@/components/doctors/DeleteDoctorDialog";
import { useDeleteProfileInfo } from "@/services/api";
import { Clinic } from "./ClinicsPage";
import StatusBadge from "@/components/ui/StatusBadge";
import { DatePickerWithRange } from "@/components/ui/date-range";
import deleteicon from "../../public/lovable-uploads/delete bg.svg";
import editicon from "../../public/lovable-uploads/edit bg.svg";
import { baseURL } from "@/services/axios";

/**
 * Formats a date string to a consistent format (DD-MM-YYYY), handling various input formats
 * @param dateStr The date string to format
 * @returns Formatted date string or fallback text
 */
const formatDate = (dateStr: string): string => {
  if (!dateStr) return "-";

  // Try parsing different date formats
  const date = new Date(dateStr);

  // Check if the date is valid
  if (isNaN(date.getTime())) {
    // Try parsing DD-MM-YYYY format
    const [day, month, year] = dateStr.split("-").map(Number);
    if (day && month && year) {
      const parsedDate = new Date(year, month - 1, day);
      if (!isNaN(parsedDate.getTime())) {
        return `${day.toString().padStart(2, "0")}-${month
          .toString()
          .padStart(2, "0")}-${year}`;
      }
    }
    return "-";
  }

  // Format the date as DD-MM-YYYY
  const day = date.getDate().toString().padStart(2, "0");
  const month = (date.getMonth() + 1).toString().padStart(2, "0");
  const year = date.getFullYear();
  return `${day}-${month}-${year}`;
};

const DoctorsPage = () => {
  const [activeTab, setActiveTab] = useState("Pending Approval");
  const [selectedDoctor, setSelectedDoctor] = useState<any>(null);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  // Add missing state variables
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [searchUser, setSearchUser] = useState("");
  const [roleId, setRoleId] = useState<string>("");
  const [doctorType, setDoctorType] = useState<string>("");

  // Add date range state
  const [dateRange, setDateRange] = useState<{
    from: Date | null;
    to: Date | null;
  }>({
    from: null,
    to: null,
  });

  // Add total count state
  const [totalCount, setTotalCount] = useState(0);

  // Get counts for each status with search applied
  const { data: approvedData } = useAllUsers(
    1,
    1,
    activeTab === "Doctors" ? searchUser : undefined,
    roleId,
    dateRange.from,
    "Approved",
    dateRange.to
  );

  const { data: pendingData } = useAllUsers(
    1,
    1,
    activeTab === "Pending Approval" ? searchUser : undefined,
    roleId,
    dateRange.from,
    "Pending",
    dateRange.to
  );

  const { data: rejectedData } = useAllUsers(
    1,
    1,
    activeTab === "Rejected" ? searchUser : undefined,
    roleId,
    dateRange.from,
    "Reject",
    dateRange.to
  );

  // Main query for current active tab data
  const { data: usersResponse, isLoading } = useAllUsers(
    page,
    pageSize,
    searchUser,
    roleId,
    dateRange.from,
    activeTab === "Doctors"
      ? "Approved"
      : activeTab === "Pending Approval"
      ? "Pending"
      : activeTab === "Rejected"
      ? "Reject"
      : undefined,
    dateRange.to
  );

  // Update useEffect to set total count when data changes
  useEffect(() => {
    if (usersResponse) {
      setTotalCount(usersResponse.count || 0);
    }
  }, [usersResponse]);

  // Calculate total pages
  const totalPages = Math.ceil(totalCount / pageSize);

  // Handle page change
  const handlePageChange = (newPage: number) => {
    setPage(newPage);
  };

  // Update counts calculation
  const counts = React.useMemo(() => {
    if (!usersResponse?.result) return { approved: 0, pending: 0, rejected: 0 };

    return {
      approved: usersResponse.count,
      pending: usersResponse.count,
      rejected: usersResponse.count,
    };
  }, [usersResponse]);

  // Update doctor type options with role_id
  const doctorTypeOptions = [
    { value: "", label: "All Types" },
    { value: "1", label: "MDS Doctor" },
    { value: "2", label: "BDS Doctor" },
  ];

  // Update the handler to use roleId
  const handleDoctorTypeChange = (value: string) => {
    setRoleId(value);
    setPage(1); // Reset to first page when filter changes
  };

  // Filter and transform user data based on active tab
  const filteredData = React.useMemo(() => {
    if (!usersResponse?.result) return [];

    let filtered = usersResponse.result;

    // Filter by doctor type if selected
    if (doctorType) {
      filtered = filtered.filter((user) => user.doctor_type === doctorType);
    }

    // Filter by verification status based on active tab
    switch (activeTab) {
      case "Doctors":
        return filtered.filter((user) => user.is_Verified === "Approved");
      case "Pending Approval":
        return filtered.filter((user) => user.is_Verified === "Pending");
      case "Rejected":
        return filtered.filter((user) => user.is_Verified === "Reject");
      default:
        return filtered;
    }
  }, [usersResponse, activeTab, doctorType]);

  // Add new function to handle status update
  const handleStatusUpdate = async (
    userId: string,
    newStatus: "Approved" | "Reject"
  ) => {
    try {
      const response = await axios.post(
        `${baseURL}/postVerifiedDoctors`,
        null,
        {
          params: {
            user_id: userId,
            status: newStatus,
            body: "",
          },
        }
      );

      if (response.data) {
        toast.success(`Doctor status updated to ${newStatus}`);

        // ✅ Immediately refetch relevant data
        const queryClient = new QueryClient();
        queryClient.invalidateQueries({
          queryKey: [
            "users",
            page,
            pageSize,
            searchUser,
            roleId,
            dateRange.from,
            dateRange.to,
            activeTab,
          ],
        });

        setShowDetailsModal(false);
      }
    } catch (error) {
      console.error("Error updating status:", error);
      toast.error("Failed to update status. Please try again.");
    }
  };

  // Update the doctorColumns definition
  const doctorColumns = [
    {
      header: "S.NO",
      accessor: "serialNumber",
      cell: (_: string, __: any, rowIndex: number | undefined) => {
        return ((page - 1) * pageSize + (rowIndex ?? 0) + 1).toString();
      },
    },
    {
      header: "DOCTOR NAME",
      accessor: "user_name",
      cell: (value: string) => value || "-",
    },
    {
      header: "PHONE NUMBER",
      accessor: "phoneNumber",
      cell: (value: string | null) => value || "-",
    },
    {
      header: "EMAIL",
      accessor: "user_email",
      cell: (value: string) => value || "-",
    },
    {
      header: "EXPERIENCE",
      accessor: "experience",
      cell: (value: string) => value || "-",
    },
    {
      header: "WORK TYPE",
      accessor: "work_type",
      cell: (value: string) => value || "-",
    },
    {
      header: "ROLE",
      accessor: "doctor_type",
      cell: (value: string) => value || "-",
    },
    {
      header: "REGISTRATION DATE",
      accessor: "created_date",
      cell: (value: string) => formatDate(value),
    },
    {
      header: "STATUS",
      accessor: "is_Verified",
      cell: (value: string) => (
        <StatusBadge status={value as "Active" | "Inactive" | "Pending"} />
      ),
    },
    {
      header: "ACTIONS",
      accessor: "actions",
      cell: (_: any, row: any) => (
        <div className="flex">
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              handleEdit(row);
            }}
            className="hover:bg-gray-100 p-1"
          >
            <img src={editicon} alt="edit" className="h-6 w-6" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              handleDelete(row);
            }}
            className="hover:bg-gray-100 p-1"
          >
            <img src={deleteicon} alt="delete" className="h-6 w-6" />
          </Button>
        </div>
      ),
    },
  ];

  // Replace with direct search handler
  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPage(1);
    setSearchUser(e.target.value);
  };

  // Update the SearchInput component's onChange handler
  <SearchInput
    placeholder={`Search in ${activeTab}...`}
    onChange={handleSearch} // Changed from debouncedSearch
    value={searchUser}
    key={`search-${activeTab}`}
  />;

  // Reset search when changing tabs
  const handleTabChange = (newTab: string) => {
    setSearchUser("");
    setRoleId(""); // Reset roleId when changing tabs
    setActiveTab(newTab);
    setPage(1);
  };

  const handleRowClick = (doctor: any) => {
    console.log(doctor, "initialData3");
    setSelectedDoctor(doctor);
    setShowDetailsModal(true);
  };

  // Get the appropriate count based on tab and loading state
  const getTabCount = (tab: string) => {
    if (isLoading) return "...";

    switch (tab) {
      case "Doctors":
        return approvedData?.count || 0;
      case "Pending Approval":
        return pendingData?.count || 0;
      case "Rejected":
        return rejectedData?.count || 0;
      default:
        return 0;
    }
  };
  const queryClient = useQueryClient();
  const deleteProfileMutation = useDeleteProfileInfo();

  const handleEdit = useCallback((doctor: any) => {
    // Transform the doctor data to match the expected format
    const formattedDoctor = {
      user_id: doctor.user_id,
      role_id: doctor.role_id || 2, // Default to 2 for doctors
      user_name: doctor.user_name,
      user_email: doctor.user_email,
      profile_pic: doctor.profile_pic || "",
      other_specialization: doctor.other_specialization || "",
      joined_Date: doctor.joined_Date || "",
      Departure: doctor.Departure || "",
      PersonalInfo: {
        profile_name: doctor.user_name,
        profile_email_id: doctor.user_email,
        profile_phone_number: doctor.phoneNumber || "",
        specialization: doctor.specialization || [],
      },
      Education: {
        state: doctor.state || "",
        collage_name: doctor.collage_name || "",
        passed_out_year: doctor.passed_out_year || "",
        state_councel_reg_number: doctor.state_councel_reg_number || "",
        state_councel_certificate: doctor.state_councel_certificate || "",
      },
      Work: {
        work_type: doctor.work_type || "",
        designation: doctor.designation || "",
        expertise_in: doctor.expertise_in || "",
        experience: doctor.experience || "",
        clinic_name: doctor.clinic_name || "",
        created_date: doctor.created_date || "",
        Departure: doctor.Departure || "",
      },
    };
    setSelectedDoctor(formattedDoctor);
    setShowEditDialog(true);
  }, []);

  const handleDelete = useCallback((doctor: any) => {
    setSelectedDoctor(doctor);
    setShowDeleteDialog(true);
  }, []);

  const handleDeleteConfirm = useCallback(async () => {
    if (!selectedDoctor) return;

    try {
      await deleteProfileMutation.mutateAsync(selectedDoctor.user_id);
      toast.success("Doctor deleted successfully");
      setShowDeleteDialog(false);
      setSelectedDoctor(null);
      // Refresh the data
      queryClient.invalidateQueries({
        predicate: (query) => query.queryKey[0] === "getAllUsers",
      });
    } catch (error: any) {
      toast.error(error.response?.data?.message || "Failed to delete doctor");
    }
  }, [selectedDoctor, deleteProfileMutation, queryClient]);

  const handleCloseEditDialog = useCallback(() => {
    setShowEditDialog(false);
    setSelectedDoctor(null);
  }, []);

  const handleCloseDeleteDialog = useCallback(() => {
    setShowDeleteDialog(false);
    setSelectedDoctor(null);
  }, []);

  // Handle date range change
  const handleDateRangeChange = (range: {
    from: Date | null;
    to: Date | null;
  }) => {
    setDateRange(range);
    setPage(1); // Reset to first page when filter changes
  };

  // Update useEffect for tab change to reset date range
  useEffect(() => {
    setSearchUser("");
    setRoleId("");
    setDateRange({ from: null, to: null });
    setPage(1);
  }, [activeTab]);

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div className="flex space-x-4">
          <TabButton
            label={`Pending Approval (${getTabCount("Pending Approval")})`}
            active={activeTab === "Pending Approval"}
            onClick={() => handleTabChange("Pending Approval")}
          />
          <TabButton
            label={`Approved Doctors (${getTabCount("Doctors")})`}
            active={activeTab === "Doctors"}
            onClick={() => handleTabChange("Doctors")}
          />
          <TabButton
            label={`Rejected (${getTabCount("Rejected")})`}
            active={activeTab === "Rejected"}
            onClick={() => handleTabChange("Rejected")}
          />
        </div>
        <div className="flex items-center gap-4">
          <DatePickerWithRange
            onDateChange={handleDateRangeChange}
            value={dateRange}
          />
          <Button
            className="flex items-center gap-2 bg-blue-900 hover:bg-blue-800"
            onClick={() => setShowCreateModal(true)}
          >
            <Plus size={18} />
            Create Doctor
          </Button>
        </div>
      </div>
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="text-xl font-semibold flex items-center gap-2">
            <span>
              {activeTab === "Doctors" && "Doctors"}
              {activeTab === "Pending Approval" && "Pending Approval"}
              {activeTab === "Rejected" && "Rejected Doctor's"}
            </span>
            <span className="text-gray-500">({getTabCount(activeTab)})</span>
          </div>
          <div className="flex flex-wrap w-full sm:w-auto gap-4">
            <div className="w-full sm:w-72 relative">
              <SearchInput
                placeholder={`Search By Name, Phone Number`}
                onChange={handleSearch}
                value={searchUser}
                key={`search-${activeTab}`}
                className="text-sm "
              />
              {isLoading && (
                <div className="absolute right-10 top-1/2 transform -translate-y-1/2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-500"></div>
                </div>
              )}
            </div>
            <div className="w-full sm:w-48">
              <SelectDropdown
                label="Doctor Type"
                options={doctorTypeOptions}
                value={roleId}
                onChange={handleDoctorTypeChange}
                key={`type-${activeTab}`}
              />
            </div>
          </div>
        </div>

        {/* Show active filters */}
        {(searchUser || roleId) && (
          <div className="flex flex-wrap gap-2">
            {searchUser && (
              <div className="flex items-center gap-2 px-3 py-1 bg-blue-100 rounded-full text-sm">
                Search: {searchUser}
                <button
                  onClick={() => setSearchUser("")}
                  className="hover:text-blue-700"
                >
                  ×
                </button>
              </div>
            )}
            {roleId && (
              <div className="flex items-center gap-2 px-3 py-1 bg-blue-100 rounded-full text-sm">
                Type:{" "}
                {doctorTypeOptions.find((opt) => opt.value === roleId)?.label}
                <button
                  onClick={() => handleDoctorTypeChange("")}
                  className="hover:text-blue-700"
                >
                  ×
                </button>
              </div>
            )}
          </div>
        )}

        {/* Show loading state during search */}
        {isLoading && (
          <div className="text-center text-gray-500">Searching...</div>
        )}

        {/* Show no results message */}

        <DataTable
          columns={doctorColumns}
          data={usersResponse?.result || []}
          onRowClick={handleRowClick}
          isLoading={isLoading}
          pagination={{
            currentPage: page,
            totalPages: Math.ceil((usersResponse?.count || 0) / pageSize),
            pageSize: pageSize,
            totalItems: usersResponse?.count || 0,
            onPageChange: setPage,
            onPageSizeChange: (newPageSize) => {
              setPageSize(newPageSize);
              setPage(1);
            },
          }}
        />
        {!isLoading && usersResponse?.result.length === 0 && (
          <div className="text-center py-4 text-gray-500">
            No doctors found
            {searchUser && ` matching "${searchUser}"`}
            {roleId &&
              ` with type "${
                doctorTypeOptions.find((opt) => opt.value === roleId)?.label
              }"`}
            {` for ${activeTab}`}
          </div>
        )}
      </div>

      {/* Doctor Details Modal */}
      {showDetailsModal && selectedDoctor && (
        <DoctorDetailsModal
          isOpen={showDetailsModal}
          onClose={() => {
            setShowDetailsModal(false);
            // Optionally refresh the data here if needed
            setPage(1); // This will trigger a data refresh
          }}
          doctor={selectedDoctor}
          isPendingApproval={activeTab === "Pending Approval"}
        />
      )}

      {/* Create Doctor Modal */}
      {showCreateModal && (
        <CreateDoctorModal
          isOpen={showCreateModal}
          onClose={() => setShowCreateModal(false)}
          onDoctorCreated={() => {
            setShowCreateModal(false);
            setActiveTab("Pending Approval");
            queryClient.invalidateQueries({
              predicate: (query) => query.queryKey[0] === "getAllUsers",
            });
          }}
        />
      )}

      <EditDoctorDialog
        isOpen={showEditDialog}
        onClose={handleCloseEditDialog}
        doctor={selectedDoctor}
      />

      <DeleteDoctorDialog
        isOpen={showDeleteDialog}
        onClose={handleCloseDeleteDialog}
        onConfirm={handleDeleteConfirm}
        doctorName={
          selectedDoctor?.PersonalInfo?.profile_name ||
          selectedDoctor?.profile_name ||
          ""
        }
      />
    </div>
  );
};

export default DoctorsPage;
