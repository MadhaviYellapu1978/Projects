import React from "react";
import logo from "/lovable-uploads/logo.png";
const Logo = () => {
  return <img src={logo} alt="logo" />;
};

export default Logo;
