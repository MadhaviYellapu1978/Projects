import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";

interface CertificateViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  certificateUrl: string;
  certificateName: string;
}

export const CertificateViewerModal = ({
  isOpen,
  onClose,
  certificateUrl,
  certificateName,
}: CertificateViewerModalProps) => {
  // Function to fix S3 URLs that might have redirect issues
  const fixS3Url = (url: string): string => {
    if (!url) return url;

    console.log("Original URL:", url);

    // Handle URLs that start with a dot (like .s3.amazonaws.com)
    if (url.startsWith(".s3.amazonaws.com")) {
      const key = url.replace(".s3.amazonaws.com/", "");
      const fixedUrl = `https://certificates.s3.amazonaws.com/${key}`;
      console.log("Fixed dot URL:", fixedUrl);
      return fixedUrl;
    }

    // Handle URLs that start with s3.amazonaws.com (missing bucket)
    if (url.startsWith("s3.amazonaws.com/")) {
      const key = url.replace("s3.amazonaws.com/", "");
      const fixedUrl = `https://certificates.s3.amazonaws.com/${key}`;
      console.log("Fixed missing bucket URL:", fixedUrl);
      return fixedUrl;
    }

    // Check if it's an S3 URL that might need fixing
    if (url.includes("s3.amazonaws.com") || url.includes("amazonaws.com")) {
      // Handle URLs that are missing https://
      if (!url.startsWith("http://") && !url.startsWith("https://")) {
        if (url.includes("s3.amazonaws.com")) {
          const fixedUrl = `https://${url}`;
          console.log("Added https to URL:", fixedUrl);
          return fixedUrl;
        }
      }

      // Extract bucket and key from the URL
      const urlParts = url.split("/");
      const bucketIndex = urlParts.findIndex((part) =>
        part.includes("s3.amazonaws.com")
      );

      if (bucketIndex === -1) {
        // Try to extract bucket and key from malformed URL
        const match = url.match(/([^/]+)\.s3\.amazonaws\.com\/(.+)/);
        if (match) {
          const bucket = match[1];
          const key = match[2];
          const fixedUrl = `https://${bucket}.s3.amazonaws.com/${key}`;
          console.log("Fixed regex match URL:", fixedUrl);
          return fixedUrl;
        }
        console.log("No bucket found, returning original URL");
        return url;
      }

      const bucket = urlParts[bucketIndex - 1];
      const key = urlParts.slice(bucketIndex + 1).join("/");

      // Return virtual-hosted style URL
      const fixedUrl = `https://${bucket}.s3.amazonaws.com/${key}`;
      console.log("Fixed virtual-hosted URL:", fixedUrl);
      return fixedUrl;
    }

    console.log("No S3 URL detected, returning original URL");
    return url;
  };

  const fixedUrl = fixS3Url(certificateUrl);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] p-0">
        <DialogHeader className="p-6 pb-4">
          <DialogTitle className="flex items-center justify-between">
            <span>{certificateName}</span>
            <div className="flex items-center gap-2">
              {/* Show buttons for PDFs */}
              {(fixedUrl.toLowerCase().includes(".pdf") ||
                fixedUrl.toLowerCase().includes("application/pdf")) && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    // Open PDF in new window/tab with specific features using fixed URL
                    const newWindow = window.open(
                      fixedUrl,
                      "_blank",
                      "noopener,noreferrer,width=1200,height=800,scrollbars=yes,resizable=yes"
                    );

                    // Ensure the window opened successfully
                    if (
                      !newWindow ||
                      newWindow.closed ||
                      typeof newWindow.closed == "undefined"
                    ) {
                      // Fallback: try opening with a different approach
                      const link = document.createElement("a");
                      link.href = fixedUrl;
                      link.target = "_blank";
                      link.rel = "noopener noreferrer";
                      link.click();
                    }
                  }}
                  className="flex items-center gap-2"
                >
                  <svg
                    className="h-4 w-4"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                    ></path>
                  </svg>
                  View in New Tab
                </Button>
              )}

              <Button
                variant="outline"
                size="sm"
                onClick={onClose}
                className="flex items-center gap-2"
              >
                <X className="h-4 w-4" />
                Close
              </Button>
            </div>
          </DialogTitle>
        </DialogHeader>

        <div className="px-6 pb-6">
          <div className="border rounded-lg overflow-hidden bg-gray-50">
            {/* Check if the certificate is a PDF */}
            {fixedUrl.toLowerCase().includes(".pdf") ||
            fixedUrl.toLowerCase().includes("application/pdf") ? (
              <div className="w-full h-[70vh] border-0 bg-gray-100 flex items-center justify-center">
                <div className="text-center">
                  <div className="mb-4">
                    <svg
                      className="mx-auto h-12 w-12 text-gray-400"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                      ></path>
                    </svg>
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    PDF Certificate
                  </h3>
                  <p className="text-sm text-gray-500 mb-4">
                    Click "View in New Tab" to open the PDF certificate
                  </p>
                  <div className="flex gap-2 justify-center">
                    <button
                      onClick={() => {
                        console.log("Opening PDF with fixed URL:", fixedUrl);
                        // Open PDF in new window/tab with specific features using fixed URL
                        const newWindow = window.open(
                          fixedUrl,
                          "_blank",
                          "noopener,noreferrer,width=1200,height=800,scrollbars=yes,resizable=yes"
                        );

                        // Ensure the window opened successfully
                        if (
                          !newWindow ||
                          newWindow.closed ||
                          typeof newWindow.closed == "undefined"
                        ) {
                          console.log("Popup blocked, trying fallback method");
                          // Fallback: try opening with a different approach
                          const link = document.createElement("a");
                          link.href = fixedUrl;
                          link.target = "_blank";
                          link.rel = "noopener noreferrer";
                          link.click();
                        } else {
                          console.log("PDF opened successfully in new window");
                        }
                      }}
                      className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90"
                    >
                      <svg
                        className="h-4 w-4"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                        ></path>
                      </svg>
                      View PDF in New Tab
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <img
                src={fixedUrl}
                alt={certificateName}
                className="w-full h-auto max-h-[70vh] object-contain"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.style.display = "none";
                  const errorDiv = document.createElement("div");
                  errorDiv.className =
                    "flex items-center justify-center h-64 text-gray-500";
                  errorDiv.innerHTML = `
                    <div class="text-center">
                      <p class="text-lg font-medium">Unable to display certificate</p>
                      <p class="text-sm mt-2">The certificate file may not be an image, may be corrupted, or the URL may be incorrect.</p>
                      <p class="text-xs mt-1 text-red-500">Original URL: ${certificateUrl}</p>
                      <p class="text-xs mt-1 text-blue-500">Fixed URL: ${fixedUrl}</p>
                      <div class="flex gap-2 mt-4 justify-center">
                        <a href="${fixedUrl}" 
                           target="_blank" 
                           rel="noopener noreferrer"
                           class="inline-flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90">
                          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path>
                          </svg>
                          Try Fixed URL
                        </a>
                        <a href="${certificateUrl}" 
                           target="_blank" 
                           rel="noopener noreferrer"
                           class="inline-flex items-center gap-2 px-4 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600">
                          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path>
                          </svg>
                          Try Original URL
                        </a>
                      </div>
                    </div>
                  `;
                  target.parentNode?.insertBefore(errorDiv, target.nextSibling);
                }}
              />
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
