import React from "react";
import CreateDoctorModal from "./CreateDoctorModal";

interface EditDoctorDialogProps {
  isOpen: boolean;
  onClose: () => void;
  doctor: any;
}

export const EditDoctorDialog: React.FC<EditDoctorDialogProps> = ({
  isOpen,
  onClose,
  doctor,
}) => {
  console.log("initialData2", doctor);
  return (
    <CreateDoctorModal
      isOpen={isOpen}
      onClose={onClose}
      initialData={doctor}
      isEditing={true}
    />
  );
};
