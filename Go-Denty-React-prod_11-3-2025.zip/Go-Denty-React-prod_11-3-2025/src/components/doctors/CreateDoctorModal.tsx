/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState, useRef, useEffect, useMemo } from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogClose,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import LoadingSpinner from "@/components/ui/LoadingSpinner";
import { X, Upload, X as XIcon, File, ChevronDown, Check } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import {
  usePostProfileInfo,
  useRolesMobile,
  useUploadImage,
  useStates,
} from "@/services/api";
import { PostProfileInfoRequest } from "@/services/api";

interface CreateDoctorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDoctorCreated?: () => void;
  initialData?: any;
  isEditing?: boolean;
}

// Update the PostProfileInfoRequest to include agreementChecked
interface ExtendedProfileRequest extends PostProfileInfoRequest {
  agreementChecked: boolean;
}

// Interface for new doctor creation (user_id is optional)
interface CreateDoctorRequest extends Omit<PostProfileInfoRequest, "user_id"> {
  user_id?: string;
  is_edited?: boolean;
}

interface Specialization {
  specialization_id: number;
  specialization_name: string;
}

interface Role {
  role_id: number;
  role_name: string;
  specialization: Specialization[];
}

// Create a function that returns the validation schema based on hasWorkExperience
const getValidationSchema = (hasWorkExperience: boolean) =>
  Yup.object().shape({
    PersonalInfo: Yup.object().shape({
      profile_name: Yup.string()
        .required("Name is required")
        .min(2, "Name must be at least 2 characters")
        .test("no-first-space", "Name cannot start with a space", (value) => {
          if (!value) return true; // Allow empty values
          return !value.startsWith(" ");
        }),
      profile_email_id: Yup.string()
        .email("Invalid email format")
        .required("Email is required"),
      profile_phone_number: Yup.string()
        .matches(/^[0-9]{10}$/, "Contact number must be 10 digits")
        .required("Contact number is required"),
      specialization: Yup.array().test(
        "specialization-required",
        "Please select at least one specialization",
        function (value) {
          const { role_name } = this.options.context || {};
          if (!role_name) return true; // No role selected yet

          if (role_name === "MDS Doctor") {
            if (!value || value.length === 0) {
              return this.createError({
                message: "Please select one specialization",
              });
            }
            if (value.length > 1) {
              return this.createError({
                message: "MDS Doctor can only have one specialization",
              });
            }
          } else {
            if (!value || value.length === 0) {
              return this.createError({
                message: "Please select at least one specialization",
              });
            }
          }
          return true;
        }
      ),
    }),
    Education: Yup.object().shape({
      state: Yup.string().required("State is required"),
      collage_name: Yup.string()
        .required("College name is required")
        .test(
          "no-first-space",
          "College name cannot start with a space",
          (value) => {
            if (!value) return true; // Allow empty values
            return !value.startsWith(" ");
          }
        ),
      passed_out_year: Yup.string()
        .matches(/^[0-9]{4}$/, "Year must be 4 digits")
        .required("Passed out year is required"),
      state_councel_reg_number: Yup.string()
        .required("Registration number is required")
        .test(
          "no-first-space",
          "Registration number cannot start with a space",
          (value) => {
            if (!value) return true; // Allow empty values
            return !value.startsWith(" ");
          }
        ),
      state_councel_certificate: Yup.string().required(
        "Certificate is required"
      ),
    }),
    Work: Yup.object().shape({
      work_type: hasWorkExperience
        ? Yup.string().required("Work type is required")
        : Yup.string().notRequired(),
      designation: hasWorkExperience
        ? Yup.string().required("Designation is required")
        : Yup.string().notRequired(),
      experience: hasWorkExperience
        ? Yup.string().required("Experience is required")
        : Yup.string().notRequired(),
      clinic_name: hasWorkExperience
        ? Yup.string().required("Clinic name is required")
        : Yup.string().notRequired(),
      joined_Date: hasWorkExperience
        ? Yup.string().required("Joined date is required")
        : Yup.string().notRequired(),
      Departure: hasWorkExperience
        ? Yup.string()
            .required("End date is required")
            .test(
              "is-after-start",
              "End date must be after start date",
              function (value) {
                const startDate = this.parent.joined_Date;
                if (!startDate || !value) return true;
                return new Date(value) > new Date(startDate);
              }
            )
        : Yup.string().notRequired(),
    }),
    role_id: Yup.number()
      .notOneOf([0], "Doctor type is required")
      .required("Doctor type is required"),
    agreementChecked: Yup.boolean().oneOf(
      [true],
      "You must agree to the terms to continue"
    ),
  });

const initialValues: ExtendedProfileRequest = {
  user_id: "",
  role_id: 0,
  user_name: "",
  user_email: "",
  profile_pic: "",
  other_specialization: "",
  is_work_experience: false,
  is_Verified: "Pending",
  PersonalInfo: {
    profile_name: "",
    profile_email_id: "",
    profile_phone_number: "",
    specialization: [],
  },
  Education: {
    state: "",
    collage_name: "",
    passed_out_year: "",
    state_councel_reg_number: "",
    state_councel_certificate: "",
  },
  Work: {
    work_type: "",
    designation: "",
    expertise_in: "",
    experience: "",
    clinic_name: "",
    joined_Date: "",
    Departure: "",
    is_experience: false,
  },
  agreementChecked: false,
};

// Helper function to convert various date formats to YYYY-MM-DD for date input
const convertDateFormat = (dateString: string): string => {
  if (!dateString) return "";

  // Check if date is in DD-MM-YYYY format
  const ddmmyyyyPattern = /^(\d{2})-(\d{2})-(\d{4})$/;
  const ddmmMatch = dateString.match(ddmmyyyyPattern);

  if (ddmmMatch) {
    const [, day, month, year] = ddmmMatch;
    return `${year}-${month}-${day}`;
  }

  // Check if date is already in YYYY-MM-DD format
  const yyyymmddPattern = /^(\d{4})-(\d{2})-(\d{2})$/;
  const yyyymmMatch = dateString.match(yyyymmddPattern);

  if (yyyymmMatch) {
    return dateString; // Already in correct format
  }

  // Try to parse as ISO date and convert
  try {
    const date = new Date(dateString);
    if (!isNaN(date.getTime())) {
      return date.toISOString().split("T")[0]; // Returns YYYY-MM-DD
    }
  } catch (error) {
    console.warn("Failed to parse date:", dateString);
  }

  // If all else fails, return original string
  return dateString;
};

const CreateDoctorModal: React.FC<CreateDoctorModalProps> = ({
  isOpen,
  onClose,
  onDoctorCreated,
  initialData,
  isEditing = false,
}) => {
  const { mutateAsync: postProfileInfo } = usePostProfileInfo();
  const { data: rolesData, isLoading: isLoadingRoles } = useRolesMobile();
  const { data: statesData, isLoading: isLoadingStates } = useStates();

  const [selectedRole, setSelectedRole] = useState<Role | null>(null);
  const [selectedSpecialties, setSelectedSpecialties] = useState<string[]>([]);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const dropdownRef = useRef<HTMLDivElement>(null);
  const [certificate, setCertificate] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const uploadImageMutation = useUploadImage();
  const formikRef = useRef<any>(null);
  const [submitAttempted, setSubmitAttempted] = useState(false);
  const [hasWorkExperience, setHasWorkExperience] = useState(false);

  // Memoize validation schema to prevent form reset when toggling work section
  const validationSchema = useMemo(
    () => getValidationSchema(hasWorkExperience),
    [hasWorkExperience]
  );

  // Handle work experience checkbox toggle
  const handleWorkExperienceToggle = (checked: boolean, setFieldValue: any) => {
    setHasWorkExperience(checked);
    setFieldValue("Work.is_experience", checked);

    // If unchecking, clear work experience fields
    if (!checked) {
      setFieldValue("Work.work_type", "");
      setFieldValue("Work.designation", "");
      setFieldValue("Work.experience", "");
      setFieldValue("Work.clinic_name", "");
      setFieldValue("Work.joined_Date", "");
      setFieldValue("Work.Departure", "");
    } else {
      // If checking and we have initial data, restore the original values
      if (initialData?.Work) {
        setFieldValue(
          "Work.work_type",
          initialData.Work.work_type || initialData.work_type || ""
        );
        setFieldValue("Work.designation", initialData.Work.designation || "");
        setFieldValue(
          "Work.experience",
          initialData.Work.experience || initialData.experience || ""
        );
        setFieldValue("Work.clinic_name", initialData.Work.clinic_name || "");
        setFieldValue(
          "Work.joined_Date",
          convertDateFormat(
            initialData.Work.joined_Date || initialData.joined_Date || ""
          )
        );
        setFieldValue(
          "Work.Departure",
          convertDateFormat(
            initialData.Work.Departure || initialData.Departure || ""
          )
        );
      }
    }

    // Trigger validation after state change to update validation rules
    if (formikRef.current) {
      setTimeout(() => {
        formikRef.current.validateForm();
      }, 100);
    }
  };

  // Transform initialData to match form structure
  const getInitialValues = () => {
    if (!initialData) return initialValues;

    return {
      user_id: initialData.user_id || "",
      role_id: initialData.role_id || 0,
      user_name: initialData.user_name || "",
      user_email: initialData.user_email || "",
      profile_pic: initialData.profile_pic || "",
      other_specialization:
        initialData.other_specialization ||
        initialData.PersonalInfo?.other_specialization ||
        "",
      is_work_experience: initialData.is_work_experience || false,
      is_Verified: initialData.is_Verified || "Pending",
      PersonalInfo: {
        profile_name:
          initialData.PersonalInfo?.profile_name || initialData.user_name || "",
        profile_email_id:
          initialData.PersonalInfo?.profile_email_id ||
          initialData.user_email ||
          "",
        profile_phone_number:
          initialData.PersonalInfo?.profile_phone_number || "",
        specialization: initialData.PersonalInfo?.specialization || [],
        other_specialization:
          initialData.PersonalInfo?.other_specialization || "",
      },
      Education: {
        state: initialData.Education?.state || "",
        collage_name: initialData.Education?.collage_name || "",
        passed_out_year: initialData.Education?.passed_out_year || "",
        state_councel_reg_number:
          initialData.Education?.state_councel_reg_number || "",
        state_councel_certificate:
          initialData.Education?.state_councel_certificate || "",
      },
      Work: {
        work_type: initialData.Work?.work_type || initialData.work_type || "",
        designation: initialData.Work?.designation || "",
        expertise_in: initialData.Work?.expertise_in || "",
        experience:
          initialData.Work?.experience || initialData.experience || "",
        clinic_name: initialData.Work?.clinic_name || "",
        joined_Date: convertDateFormat(
          initialData.Work?.joined_Date || initialData.joined_Date || ""
        ),
        Departure: convertDateFormat(
          initialData.Work?.Departure || initialData.Departure || ""
        ),
        is_experience: initialData.Work?.is_experience || false,
      },
      agreementChecked: !!(
        isEditing && initialData?.Education?.state_councel_certificate
      ),
    };
  };

  // Set initial certificate if editing
  useEffect(() => {
    if (isEditing && initialData?.Education?.state_councel_certificate) {
      const certUrl = initialData.Education.state_councel_certificate;
      let certName = certUrl.split("/").pop() || "Existing Certificate.pdf";
      // Remove prefix before first '-' or '_' if present
      if (certName.includes("-")) {
        certName = certName.substring(certName.indexOf("-") + 1);
      } else if (certName.includes("_")) {
        certName = certName.substring(certName.indexOf("_") + 1);
      }
      setCertificate({ name: certName } as File);
    }
  }, [isEditing, initialData]);

  // Set initial specialties if editing
  useEffect(() => {
    if (isEditing && initialData?.PersonalInfo?.specialization) {
      setSelectedSpecialties(
        initialData.PersonalInfo.specialization.map(
          (spec: Specialization) => spec.specialization_name
        )
      );
    }
  }, [isEditing, initialData]);

  // Set initial role if editing
  useEffect(() => {
    if (isEditing && initialData?.role_id && rolesData) {
      const role = rolesData.find(
        (r: Role) => r.role_id === initialData.role_id
      );
      setSelectedRole(role || null);
    }
  }, [isEditing, initialData, rolesData]);

  // Set initial work experience state if editing
  useEffect(() => {
    if (isEditing && initialData?.Work?.is_experience) {
      setHasWorkExperience(initialData.Work.is_experience);
    }
  }, [isEditing, initialData]);

  // Update validation context when selectedRole changes
  useEffect(() => {
    if (formikRef.current && selectedRole) {
      formikRef.current.setFieldValue("role_id", selectedRole.role_id);
      // Trigger validation for specialization field
      setTimeout(() => {
        formikRef.current?.validateField("PersonalInfo.specialization");
      }, 0);
    }
  }, [selectedRole]);

  const handleRoleChange = (
    e: React.ChangeEvent<HTMLSelectElement>,
    setFieldValue: any
  ) => {
    const selectedRoleId = parseInt(e.target.value);
    const role = rolesData?.find((r: Role) => r.role_id === selectedRoleId);
    setSelectedRole(role || null);
    setSelectedSpecialties([]);
    setSearchTerm("");
    setFieldValue("role_id", selectedRoleId);
    // Clear the specialization field when role changes
    setFieldValue("PersonalInfo.specialization", []);
    // Trigger validation for the specialization field after a short delay
    setTimeout(() => {
      if (formikRef.current) {
        formikRef.current.validateField("PersonalInfo.specialization");
      }
    }, 0);
  };

  // First, update the handleSpecialtyToggle function
  const handleSpecialtyToggle = (specialty: string, setFieldValue: any) => {
    setSelectedSpecialties((prev) => {
      let newSpecialties;

      // If MDS Doctor is selected, only allow one selection
      if (selectedRole?.role_name === "MDS Doctor") {
        // Replace the current selection with the new one
        newSpecialties = [specialty];
      } else {
        // For other doctor types (like BDS), toggle as before
        newSpecialties = prev.includes(specialty)
          ? prev.filter((item) => item !== specialty)
          : [...prev, specialty];
      }

      // Update the formik field value
      setFieldValue(
        "PersonalInfo.specialization",
        newSpecialties.map((name) => ({
          specialization_id:
            selectedRole?.specialization.find(
              (s) => s.specialization_name === name
            )?.specialization_id || 0,
          specialization_name: name,
        }))
      );

      return newSpecialties;
    });
  };

  const handleFileUpload = async (
    e: React.ChangeEvent<HTMLInputElement>,
    setFieldValue: any
  ) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];

      if (file.type !== "application/pdf") {
        toast({
          title: "Invalid File",
          description: "Only PDF files are allowed.",
          variant: "destructive",
        });
        handleRemoveFile();
        return;
      }

      setCertificate(file);

      try {
        const response = await uploadImageMutation.mutateAsync({
          image: file,
          user_id: "temp", // Replace with actual user ID if available
        });

        setFieldValue(
          "Education.state_councel_certificate",
          response.data.image
        );

        toast({
          title: "Success",
          description: "Certificate uploaded successfully",
          className: "bg-green-50 border-green-200",
        });
      } catch (error) {
        console.error("Upload error:", error);
        toast({
          title: "Error",
          description: "Failed to upload certificate. Please try again.",
          className: "bg-red-50 border-red-200",
        });
        handleRemoveFile();
      }
    }
  };

  const handleRemoveFile = () => {
    setCertificate(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleSubmit = async (
    values: ExtendedProfileRequest,
    { setSubmitting }: any
  ) => {
    console.log("🎯 handleSubmit function called!");
    console.log("📝 Form values received:", values);
    console.log("🔍 Selected role:", selectedRole);
    console.log("📋 Specializations:", values.PersonalInfo.specialization);
    console.log("🔧 isEditing:", isEditing);
    console.log("📊 submitAttempted:", submitAttempted);

    setSubmitAttempted(true);

    // Additional validation for specializations
    if (
      selectedRole &&
      (!values.PersonalInfo.specialization ||
        values.PersonalInfo.specialization.length === 0)
    ) {
      console.log("❌ Validation failed: No specializations selected");
      toast({
        title: "Validation Error",
        description: "Please select at least one specialization",
        variant: "destructive",
      });
      setSubmitting(false);
      return;
    }

    console.log("✅ Validation passed, proceeding with API call...");

    // Check if form is valid before proceeding
    if (formikRef.current) {
      const errors = formikRef.current.errors;
      const touched = formikRef.current.touched;
      console.log("🔍 Form errors:", errors);
      console.log("🔍 Form touched:", touched);

      if (Object.keys(errors).length > 0) {
        console.log(
          "❌ Form has validation errors, not proceeding with API call"
        );
        toast({
          title: "Validation Error",
          description: "Please fix all validation errors before submitting",
          variant: "destructive",
        });
        setSubmitting(false);
        return;
      }
    }

    try {
      // Create submit values matching the exact payload structure provided
      const submitValues: CreateDoctorRequest = {
        // For new doctors, don't include user_id - let backend generate it
        ...(isEditing && values.user_id ? { user_id: values.user_id } : {}),
        role_id: values.role_id || selectedRole?.role_id || 0,
        other_specialization: values.other_specialization || "",
        user_name: values.PersonalInfo?.profile_name || "", // Map from PersonalInfo.profile_name
        user_email: values.PersonalInfo?.profile_email_id || "", // Map from PersonalInfo.profile_email_id
        profile_pic: values.profile_pic || "",
        is_work_experience: values.Work?.is_experience || false,
        is_Verified: isEditing
          ? values.is_Verified || "Pending"
          : localStorage.getItem("roleName") === "Super Admin"
          ? "Approved"
          : "Pending",
        PersonalInfo: {
          profile_name: values.PersonalInfo?.profile_name || "",
          profile_email_id: values.PersonalInfo?.profile_email_id || "",
          profile_phone_number: values.PersonalInfo?.profile_phone_number || "",
          specialization: values.PersonalInfo?.specialization || [],
        },
        Education: {
          state: values.Education?.state || "",
          collage_name: values.Education?.collage_name || "",
          passed_out_year: values.Education?.passed_out_year || "",
          state_councel_reg_number:
            values.Education?.state_councel_reg_number || "",
          state_councel_certificate:
            values.Education?.state_councel_certificate || "",
        },
        Work: {
          work_type: values.Work?.work_type || "",
          designation: values.Work?.designation || "",
          expertise_in: values.Work?.expertise_in || "",
          experience: values.Work?.experience || "",
          is_experience: values.Work?.is_experience || false,
          clinic_name: values.Work?.clinic_name || "",
          joined_Date: values.Work?.joined_Date || "",
          Departure: values.Work?.Departure || "",
        },
        is_edited: isEditing,
      };

      console.log("🔍 Form values being used:", {
        user_id: values.user_id,
        isEditing: isEditing,
        role_id: values.role_id,
        selectedRole: selectedRole?.role_id,
        profile_name: values.PersonalInfo?.profile_name,
        profile_email_id: values.PersonalInfo?.profile_email_id,
        other_specialization: values.other_specialization,
      });

      console.log(
        "🚀 Submitting doctor data with exact payload structure:",
        submitValues
      );
      console.log("📋 Payload structure matches provided format:", {
        user_id: submitValues.user_id,
        role_id: submitValues.role_id,
        other_specialization: submitValues.other_specialization,
        user_name: submitValues.user_name,
        user_email: submitValues.user_email,
        profile_pic: submitValues.profile_pic,
        is_work_experience: submitValues.is_work_experience,
        is_Verified: submitValues.is_Verified,
        PersonalInfo: submitValues.PersonalInfo,
        Education: submitValues.Education,
        Work: submitValues.Work,
        is_edited: submitValues.is_edited,
      });

      console.log("🚀 About to call postProfileInfo API...");
      console.log("📡 API call starting with payload:", submitValues);

      try {
        // Check if current user is super admin
        const currentUserRole = localStorage.getItem("roleName");
        const isSuperAdmin = currentUserRole === "Super Admin";

        // Convert to PostProfileInfoRequest format for API call
        const apiPayload: PostProfileInfoRequest = {
          ...submitValues,
          user_id: submitValues.user_id || "", // Provide empty string if not present
          ...(isEditing && { is_edited: true }), // Add is_edited flag when editing
          ...(isEditing && isSuperAdmin && { is_Verified: "Approved" }), // Set to Approved when super admin edits
        };

        console.log("📡 API payload with user_id handling:", apiPayload);
        console.log("📡 Calling postProfileInfo with is_edited:", isEditing);
        const result = await postProfileInfo({
          ...apiPayload,
          is_edited: isEditing,
        });
        console.log("✅ PostProfileInfo API call successful:", result);

        // Extract success message from API response
        let successMessage = isEditing
          ? "Doctor updated successfully"
          : "Doctor created successfully";

        if (result?.message) {
          successMessage = result.message;
          console.log("✅ Using API response message:", successMessage);
        } else if (result?.data?.message) {
          successMessage = result.data.message;
          console.log("✅ Using API response data.message:", successMessage);
        } else {
          console.log("⚠️ Using fallback success message:", successMessage);
        }

        toast({
          title: "Success",
          description: successMessage,
          className: "bg-green-50 border-green-200",
        });
      } catch (apiError: any) {
        console.error("❌ PostProfileInfo API call failed:", apiError);
        console.error("❌ API Error details:", {
          message: apiError.message,
          status: apiError.response?.status,
          data: apiError.response?.data,
        });
        console.error("❌ Full error object:", apiError);
        console.error("❌ Error response data:", apiError.response?.data);

        // Extract error message from API response
        let errorMessage = `Failed to ${
          isEditing ? "update" : "create"
        } doctor`;

        console.log("🔍 Checking error message extraction:");
        console.log(
          "🔍 apiError.response?.data?.message:",
          apiError.response?.data?.message
        );
        console.log(
          "🔍 apiError.response?.data?.error:",
          apiError.response?.data?.error
        );
        console.log("🔍 apiError.response?.data:", apiError.response?.data);
        console.log("🔍 apiError.message:", apiError.message);
        console.log("🔍 apiError.response?.status:", apiError.response?.status);

        // Try to extract error message from various possible locations
        if (apiError.response?.data?.message) {
          errorMessage = apiError.response.data.message;
          console.log("✅ Using response.data.message:", errorMessage);
        } else if (apiError.response?.data?.error) {
          errorMessage = apiError.response.data.error;
          console.log("✅ Using response.data.error:", errorMessage);
        } else if (
          apiError.response?.data &&
          typeof apiError.response.data === "string"
        ) {
          errorMessage = apiError.response.data;
          console.log("✅ Using response.data as string:", errorMessage);
        } else if (
          apiError.response?.data &&
          Object.keys(apiError.response.data).length > 0
        ) {
          // If response.data is an object but doesn't have message/error fields, try to extract any string value
          const dataValues = Object.values(apiError.response.data);
          const stringValue = dataValues.find((val) => typeof val === "string");
          if (stringValue) {
            errorMessage = stringValue;
            console.log(
              "✅ Using extracted string from response.data:",
              errorMessage
            );
          }
        } else if (
          apiError.message &&
          !apiError.message.includes("Request failed with status code")
        ) {
          errorMessage = apiError.message;
          console.log("✅ Using apiError.message:", errorMessage);
        } else {
          console.log("⚠️ Using fallback message:", errorMessage);
        }

        toast({
          title: "Error",
          description: errorMessage,
          variant: "destructive",
        });
        return; // Exit early to prevent outer catch block from executing
      }

      if (onDoctorCreated) {
        onDoctorCreated();
      } else {
        onClose();
      }
    } catch (error: any) {
      console.error("❌ Outer catch block - handleSubmit failed:", error);
      console.error("❌ Error details:", {
        message: error.message,
        stack: error.stack,
        response: error.response,
        status: error.response?.status,
        data: error.response?.data,
      });

      // Extract error message from API response
      let errorMessage = `Failed to ${
        isEditing ? "update" : "add"
      } the doctor. Please try again.`;

      if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error.response?.data?.error) {
        errorMessage = error.response.data.error;
      } else if (
        error.message &&
        !error.message.includes("Request failed with status code")
      ) {
        errorMessage = error.message;
      }

      toast({
        title: "Error",
        description: errorMessage,
        className: "bg-red-50 border-red-200",
      });
    } finally {
      console.log(
        "🏁 handleSubmit finally block - setting setSubmitting(false)"
      );
      setSubmitting(false);
    }
  };

  if (isLoadingRoles || isLoadingStates) return <>Loading...</>;
  const handleDropdownToggle = () => {
    if (!dropdownOpen) {
      setDropdownOpen(true);
      document.addEventListener("mousedown", handleClickOutsideDropdown);
    } else {
      setDropdownOpen(false);
      document.removeEventListener("mousedown", handleClickOutsideDropdown);
    }
  };

  const handleClickOutsideDropdown = (event: MouseEvent) => {
    if (
      dropdownRef.current &&
      !dropdownRef.current.contains(event.target as Node)
    ) {
      setDropdownOpen(false);
      document.removeEventListener("mousedown", handleClickOutsideDropdown);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">
            {isEditing ? "Edit" : "Create"} Doctor
          </DialogTitle>
        </DialogHeader>
        <DialogClose className="absolute right-4 top-4">
          <X className="h-4 w-4" />
          <span className="sr-only">Close</span>
        </DialogClose>

        <Formik
          initialValues={getInitialValues()}
          validationSchema={validationSchema}
          onSubmit={handleSubmit}
          enableReinitialize
          validateOnChange={true}
          validateOnBlur={true}
          context={{ role_name: selectedRole?.role_name }}
          innerRef={formikRef}
        >
          {({
            setFieldValue,
            isSubmitting,
            values,
            touched,
            errors,
            dirty,
          }) => (
            <Form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Basic Information */}
                <div>
                  <label className="block mb-2 font-medium">
                    Full Name <span className="text-red-500">*</span>
                  </label>
                  <Field
                    as={Input}
                    name="PersonalInfo.profile_name"
                    placeholder="Enter doctor's name"
                    className="w-full"
                  />
                  <ErrorMessage
                    name="PersonalInfo.profile_name"
                    component="div"
                    className="text-red-500 text-sm mt-1"
                  />
                </div>

                <div>
                  <label className="block mb-2 font-medium">
                    Mobile Number<span className="text-red-500">*</span>
                  </label>
                  <Field
                    as={Input}
                    name="PersonalInfo.profile_phone_number"
                    placeholder="Enter 10-digit mobile number"
                    className="w-full"
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                      // Only allow digits and limit to 10 characters
                      const value = e.target.value
                        .replace(/\D/g, "")
                        .slice(0, 10);
                      setFieldValue("PersonalInfo.profile_phone_number", value);
                    }}
                    pattern="[0-9]{10}"
                    maxLength={10}
                  />
                  <ErrorMessage
                    name="PersonalInfo.profile_phone_number"
                    component="div"
                    className="text-red-500 text-sm mt-1"
                  />
                  {/* {values.PersonalInfo.profile_phone_number.length > 0 &&
                    values.PersonalInfo.profile_phone_number.length !== 10 && (
                      <p className="text-red-500 text-xs mt-1">
                        Phone number must be exactly 10 digits
                      </p>
                    )} */}
                </div>

                <div>
                  <label className="block mb-2 font-medium">
                    Email ID <span className="text-red-500">*</span>
                  </label>
                  <Field
                    as={Input}
                    name="PersonalInfo.profile_email_id"
                    placeholder="Enter email address"
                    className="w-full"
                  />
                  <ErrorMessage
                    name="PersonalInfo.profile_email_id"
                    component="div"
                    className="text-red-500 text-sm mt-1"
                  />
                </div>

                <div>
                  <label className="block mb-2 font-medium">
                    College Name <span className="text-red-500">*</span>
                  </label>
                  <Field
                    as={Input}
                    name="Education.collage_name"
                    placeholder="Enter college name"
                    className="w-full"
                  />
                  <ErrorMessage
                    name="Education.collage_name"
                    component="div"
                    className="text-red-500 text-sm mt-1"
                  />
                </div>

                <div>
                  <label className="block mb-2 font-medium">
                    Year of Passing <span className="text-red-500">*</span>
                  </label>
                  <Field
                    as={Input}
                    name="Education.passed_out_year"
                    placeholder="Enter year of passing"
                    className="w-full"
                  />
                  <ErrorMessage
                    name="Education.passed_out_year"
                    component="div"
                    className="text-red-500 text-sm mt-1"
                  />
                </div>

                <div>
                  <label className="block mb-2 font-medium">
                    Select State Dental Council{" "}
                    <span className="text-red-500">*</span>
                  </label>
                  <select
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-md"
                    value={values.Education.state}
                    onChange={(e) =>
                      setFieldValue("Education.state", e.target.value)
                    }
                  >
                    <option value="">Select State</option>
                    {statesData?.result?.map((state) => (
                      <option key={state.code} value={state.name}>
                        {state.name}
                      </option>
                    ))}
                  </select>
                  <ErrorMessage
                    name="Education.state"
                    component="div"
                    className="text-red-500 text-sm mt-1"
                  />
                </div>

                <div>
                  <label className="block mb-2 font-medium">
                    State Council Reg Number{" "}
                    <span className="text-red-500">*</span>
                  </label>
                  <Field
                    as={Input}
                    name="Education.state_councel_reg_number"
                    placeholder="Enter registration number"
                    className="w-full"
                  />
                  <ErrorMessage
                    name="Education.state_councel_reg_number"
                    component="div"
                    className="text-red-500 text-sm mt-1"
                  />
                </div>

                <div>
                  <label className="block mb-2 font-medium">
                    Any Other Specializations (Optional)
                  </label>
                  <Field
                    as={Input}
                    name="other_specialization"
                    placeholder="Enter additional specializations"
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="block mb-2 font-medium">
                    Doctor Type <span className="text-red-500">*</span>
                  </label>
                  <select
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-md"
                    value={values.role_id}
                    onChange={(e) => handleRoleChange(e, setFieldValue)}
                    disabled={isLoadingRoles}
                  >
                    <option value="0">Select Doctor Type</option>
                    {rolesData?.map((role: Role) => (
                      <option key={role.role_id} value={role.role_id}>
                        {role.role_name}
                      </option>
                    ))}
                  </select>
                  {submitAttempted && !values.role_id && (
                    <div className="text-red-500 text-sm mt-1">
                      Doctor type is required
                    </div>
                  )}
                </div>

                {selectedRole && (
                  <div>
                    <label className="block mb-2 font-medium">
                      {selectedRole.role_name === "MDS Doctor"
                        ? "Specialization For MDS "
                        : "Expertise In BDS"}{" "}
                      <span className="text-red-500">*</span>
                    </label>
                    <div className="relative" ref={dropdownRef}>
                      {/* Selected items display */}
                      <div
                        className="w-full min-h-[46px] px-3 py-2 bg-gray-50 border border-gray-200 rounded-md cursor-pointer flex flex-wrap gap-1 items-center"
                        onClick={handleDropdownToggle}
                      >
                        {selectedSpecialties.length === 0 ? (
                          <span className="text-gray-400">
                            Select specializations...
                          </span>
                        ) : (
                          <>
                            {selectedSpecialties.map((specialty) => (
                              <div
                                key={specialty}
                                className="bg-primary/10 text-primary text-sm px-2 py-1 rounded-md flex items-center"
                              >
                                {specialty}
                                <button
                                  type="button"
                                  onClick={(e) =>
                                    handleSpecialtyToggle(
                                      specialty,
                                      setFieldValue
                                    )
                                  }
                                  className="ml-1 hover:text-primary/80"
                                >
                                  <XIcon size={14} />
                                </button>
                              </div>
                            ))}
                          </>
                        )}
                        <div className="ml-auto">
                          <ChevronDown size={18} />
                        </div>
                      </div>

                      {/* Dropdown */}
                      {dropdownOpen && (
                        <div className="absolute z-10 w-full mt-1 bg-white border border-gray-200 shadow-lg rounded-md max-h-60 overflow-y-auto">
                          <div className="p-2 border-b">
                            <input
                              type="text"
                              placeholder="Search specializations..."
                              value={searchTerm}
                              onChange={(e) => setSearchTerm(e.target.value)}
                              className="w-full px-3 py-2 border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-primary/20"
                            />
                          </div>
                          {selectedRole?.specialization.map((spec) => (
                            <div
                              key={spec.specialization_id}
                              onClick={() =>
                                handleSpecialtyToggle(
                                  spec.specialization_name,
                                  setFieldValue
                                )
                              }
                              className={`
                                flex items-center gap-2 p-3 cursor-pointer
                                ${
                                  selectedSpecialties.includes(
                                    spec.specialization_name
                                  )
                                    ? "bg-primary/10"
                                    : "hover:bg-gray-50"
                                }
                              `}
                            >
                              <div
                                className={`
                                  w-5 h-5 rounded border flex items-center justify-center
                                  ${
                                    selectedSpecialties.includes(
                                      spec.specialization_name
                                    )
                                      ? "bg-primary border-primary"
                                      : "border-gray-300"
                                  }
                                `}
                              >
                                {selectedSpecialties.includes(
                                  spec.specialization_name
                                ) && <Check className="h-3 w-3 text-white" />}
                              </div>
                              <span>{spec.specialization_name}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    <p className="mt-1 text-xs text-gray-500">
                      {selectedRole?.role_name === "MDS Doctor"
                        ? ""
                        : `Selected: ${selectedSpecialties.length} specializations`}
                    </p>
                    {submitAttempted &&
                      selectedRole &&
                      selectedSpecialties.length === 0 && (
                        <p className="text-red-500 text-sm mt-1">
                          Please select at least one specialization
                        </p>
                      )}
                    {submitAttempted &&
                      selectedRole?.role_name === "MDS Doctor" &&
                      selectedSpecialties.length > 1 && (
                        <p className="text-red-500 text-sm mt-1">
                          MDS Doctor can only have one specialization
                        </p>
                      )}
                  </div>
                )}

                {/* Work Experience Checkbox */}
                <div className="col-span-1 md:col-span-2">
                  <div className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center gap-3 mb-4">
                      <Field
                        type="checkbox"
                        name="Work.is_experience"
                        checked={hasWorkExperience}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                          handleWorkExperienceToggle(
                            e.target.checked,
                            setFieldValue
                          )
                        }
                        className="w-4 h-4 text-primary bg-gray-100 border-gray-300 rounded focus:ring-primary focus:ring-2"
                      />
                      <label className="text-lg font-medium text-gray-900 cursor-pointer">
                        Work Experience
                      </label>
                    </div>

                    {/* Work Experience Fields - Only show when checkbox is checked */}
                    {hasWorkExperience && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <label className="block mb-2 font-medium">
                            Work Type <span className="text-red-500">*</span>
                          </label>
                          <select
                            className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-md"
                            value={values.Work.work_type}
                            onChange={(e) =>
                              setFieldValue("Work.work_type", e.target.value)
                            }
                          >
                            <option value="">Select Work Type</option>
                            <option value="Full Time">Full Time</option>
                            <option value="Part Time">Part Time</option>
                          </select>
                          <ErrorMessage
                            name="Work.work_type"
                            component="div"
                            className="text-red-500 text-sm mt-1"
                          />
                        </div>

                        <div>
                          <label className="block mb-2 font-medium">
                            Designation <span className="text-red-500">*</span>
                          </label>
                          <Field
                            as={Input}
                            name="Work.designation"
                            placeholder="Enter designation"
                            className="w-full"
                          />
                          <ErrorMessage
                            name="Work.designation"
                            component="div"
                            className="text-red-500 text-sm mt-1"
                          />
                        </div>

                        <div>
                          <label className="block mb-2 font-medium">
                            Experience Level
                            <span className="text-red-500">*</span>
                          </label>
                          <Field
                            as="select"
                            name="Work.experience"
                            className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-md"
                            placeholder="Select years of experience"
                          >
                            <option value="" disabled selected hidden>
                              Select years of experience
                            </option>
                            <option value="0">No Experience</option>
                            <option value="0-1 Years">0-1 Years</option>
                            <option value="1-2 Years">1-2 Years</option>
                            <option value="2-4 Years">2-4 Years</option>
                            <option value="4+ Years">4+ Years</option>
                          </Field>

                          <ErrorMessage
                            name="Work.experience"
                            component="div"
                            className="text-red-500 text-sm mt-1"
                          />
                        </div>

                        <div>
                          <label className="block mb-2 font-medium">
                            Clinic Name <span className="text-red-500">*</span>
                          </label>
                          <Field
                            as={Input}
                            name="Work.clinic_name"
                            placeholder="Enter clinic name"
                            className="w-full"
                          />
                          <ErrorMessage
                            name="Work.clinic_name"
                            component="div"
                            className="text-red-500 text-sm mt-1"
                          />
                        </div>

                        <div>
                          <label className="block mb-2 font-medium">
                            Joined Date <span className="text-red-500">*</span>
                          </label>
                          <Field
                            as={Input}
                            name="Work.joined_Date"
                            type="date"
                            className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-md"
                            onChange={(e) => {
                              setFieldValue("Work.joined_Date", e.target.value);
                              // Reset end date if start date changes and is after end date
                              if (
                                values.Work.Departure &&
                                new Date(e.target.value) >
                                  new Date(values.Work.Departure)
                              ) {
                                setFieldValue("Work.Departure", "");
                              }
                            }}
                          />
                          <ErrorMessage
                            name="Work.joined_Date"
                            component="div"
                            className="text-red-500 text-sm mt-1"
                          />
                        </div>

                        <div>
                          <label className="block mb-2 font-medium">
                            End Date <span className="text-red-500">*</span>
                          </label>
                          <Field
                            as={Input}
                            name="Work.Departure"
                            type="date"
                            className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-md"
                            disabled={!values.Work.joined_Date}
                            min={values.Work.joined_Date || undefined}
                          />
                          <ErrorMessage
                            name="Work.Departure"
                            component="div"
                            className="text-red-500 text-sm mt-1"
                          />
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Certificate Upload */}
                <div>
                  <label className="block mb-2 font-medium">
                    State Council Reg Certificate{" "}
                    <span className="text-red-500">*</span>
                  </label>
                  <div
                    className={`relative ${
                      !values.agreementChecked
                        ? "opacity-50 cursor-not-allowed"
                        : ""
                    }`}
                    onClick={() => {
                      if (!values.agreementChecked) {
                        toast({
                          title: "Error",
                          description:
                            "Please check the agreement checkbox to enable file upload.",
                          variant: "destructive",
                        });
                        return;
                      }
                    }}
                  >
                    <input
                      type="file"
                      id="certificate"
                      ref={fileInputRef}
                      onChange={(e) => handleFileUpload(e, setFieldValue)}
                      accept="application/pdf"
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                      disabled={!values.agreementChecked}
                    />

                    {certificate ? (
                      <div className="flex items-center justify-between px-4 py-3 bg-gray-50 border border-gray-200 rounded-md">
                        <div className="flex items-center gap-2">
                          <File className="h-5 w-5 text-primary" />
                          {initialData?.Education?.state_councel_certificate ? (
                            <a
                              href={
                                initialData.Education.state_councel_certificate
                              }
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-sm truncate max-w-[180px] underline"
                            >
                              {certificate.name}
                            </a>
                          ) : (
                            <span className="text-sm truncate max-w-[180px]">
                              {certificate.name}
                            </span>
                          )}
                        </div>
                        <button
                          type="button"
                          onClick={handleRemoveFile}
                          className="text-gray-500 hover:text-red-500"
                        >
                          <XIcon size={16} />
                        </button>
                      </div>
                    ) : (
                      <div className="flex justify-between items-center px-4 py-3 bg-gray-50 border border-gray-200 rounded-md">
                        <span className="text-gray-500">
                          Upload Document ( PDF Only )
                        </span>
                        <Upload className="h-5 w-5 text-gray-500" />
                      </div>
                    )}
                  </div>
                  <ErrorMessage
                    name="Education.state_councel_certificate"
                    component="div"
                    className="text-red-500 text-sm mt-1"
                  />
                  <div className="mt-2">
                    <label className="flex items-center gap-2 text-gray-500 text-sm">
                      <Field
                        type="checkbox"
                        name="agreementChecked"
                        className="rounded border-gray-300"
                      />
                      I agree to share my state dental council registration with
                      Godenty for identity verification purposes.
                    </label>
                  </div>
                </div>
              </div>

              <DialogFooter>
                <Button
                  type="submit"
                  disabled={isSubmitting || (isEditing && !dirty)}
                  onClick={() => {
                    console.log("🖱️ Submit button clicked!");
                    console.log("🔧 isSubmitting:", isSubmitting);
                    console.log("🔧 isEditing:", isEditing);
                    console.log("🔧 dirty:", dirty);
                    console.log(
                      "🔧 Button disabled:",
                      isSubmitting || (isEditing && !dirty)
                    );
                    setSubmitAttempted(true);
                  }}
                  className="w-full md:w-auto bg-primary text-white px-8"
                >
                  {isSubmitting ? (
                    <div className="flex items-center gap-2">
                      <LoadingSpinner size="sm" />
                      Submitting...
                    </div>
                  ) : (
                    "Submit"
                  )}
                </Button>
              </DialogFooter>
            </Form>
          )}
        </Formik>
      </DialogContent>
    </Dialog>
  );
};

export default CreateDoctorModal;
