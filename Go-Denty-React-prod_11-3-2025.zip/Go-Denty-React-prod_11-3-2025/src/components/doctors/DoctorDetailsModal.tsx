/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogClose,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  ArrowLeft,
  Calendar,
  FileText,
  Mail,
  Phone,
  User,
  Briefcase,
  Star,
  GraduationCap,
  Building,
  MapPin,
  Clock,
  Award,
  CheckCircle,
  XCircle,
  ExternalLink,
  ChevronRight,
  Download,
} from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { toast } from "@/hooks/use-toast";
import { useVerifyDoctor } from "@/services/api";
import RejectionReasonModal from "./RejectionReasonModal";
import { CertificateViewerModal } from "./CertificateViewerModal";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface DoctorDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  doctor: any;
  isPendingApproval: boolean;
  onStatusUpdate?: () => void;
}

interface Specialization {
  specialization_id: number;
  specialization_name: string;
}

// Helper function to safely render specializations
const renderSpecializations = (specialization: any): React.ReactNode => {
  // If it's null or undefined
  if (!specialization) {
    return <p>No specializations listed</p>;
  }

  // If it's an array
  if (Array.isArray(specialization)) {
    if (specialization.length === 0) {
      return <p>No specializations listed</p>;
    }

    return (
      <div className="flex flex-wrap gap-2">
        {specialization.map((spec: any) => (
          <Badge
            key={
              typeof spec === "object"
                ? spec.specialization_id || spec.id || Math.random()
                : Math.random()
            }
            variant="secondary"
            className="px-3 py-1"
          >
            {typeof spec === "object"
              ? spec.specialization_name || spec.name || "Unknown"
              : spec.toString()}
          </Badge>
        ))}
      </div>
    );
  }

  // If it's a single object
  if (typeof specialization === "object" && specialization !== null) {
    return (
      <Badge variant="secondary" className="px-3 py-1">
        {specialization.specialization_name || specialization.name || "Unknown"}
      </Badge>
    );
  }

  // If it's a string or other primitive
  return (
    <Badge variant="secondary" className="px-3 py-1">
      {String(specialization)}
    </Badge>
  );
};

const DoctorDetailsModal = ({
  isOpen,
  onClose,
  doctor,
  onStatusUpdate,
}: DoctorDetailsModalProps) => {
  const [activeTab, setActiveTab] = useState("profile");
  const [showRejectionReasonModal, setShowRejectionReasonModal] =
    useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showCertificateModal, setShowCertificateModal] = useState(false);
  const [certificateUrl, setCertificateUrl] = useState("");
  const [certificateName, setCertificateName] = useState("");
  const verifyDoctorMutation = useVerifyDoctor();

  const handleStatusUpdate = async (
    status: "Approved" | "Reject",
    reason?: string
  ) => {
    // Prevent multiple clicks
    if (isProcessing) return;

    setIsProcessing(true);

    try {
      await verifyDoctorMutation.mutateAsync({
        user_id: doctor.user_id,
        status: status,
        body: status === "Reject" ? reason : "Doctor approved",
      });

      toast({
        title: "Success",
        description:
          status === "Approved"
            ? "Doctor has been approved successfully"
            : "Doctor has been rejected",
      });

      // Update the doctor's status immediately
      doctor.is_Verified = status;

      // Trigger data refresh in parent component
      onStatusUpdate?.();
      onClose();
    } catch (error: any) {
      console.error("Error updating status:", error);
      toast({
        title: "Error",
        description:
          error.response?.data?.message ||
          "Failed to update status. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleReject = (reason: string) => {
    handleStatusUpdate("Reject", reason);
    setShowRejectionReasonModal(false);
  };

  const handleViewCertificate = (url: string, name: string) => {
    setCertificateUrl(url);
    setCertificateName(name);
    setShowCertificateModal(true);
  };

  // Enhanced download handler for certificate files
  const handleDownloadCertificate = async (url: string, filename: string) => {
    try {
      // Fix S3 URL if needed - convert to virtual-hosted style
      const fixedUrl = (() => {
        if (
          !url.includes("s3.amazonaws.com") &&
          !url.includes("amazonaws.com")
        ) {
          return url;
        }

        // Handle URLs that start with a dot (like .s3.amazonaws.com)
        if (url.startsWith(".s3.amazonaws.com")) {
          const key = url.replace(".s3.amazonaws.com/", "");
          return `https://certificates.s3.amazonaws.com/${key}`;
        }

        // Handle URLs that start with s3.amazonaws.com (missing bucket)
        if (url.startsWith("s3.amazonaws.com/")) {
          const key = url.replace("s3.amazonaws.com/", "");
          return `https://certificates.s3.amazonaws.com/${key}`;
        }

        // Extract bucket and key from the URL
        const urlParts = url.split("/");
        const bucketIndex = urlParts.findIndex((part) =>
          part.includes("s3.amazonaws.com")
        );

        if (bucketIndex === -1) {
          // Try to extract bucket and key from malformed URL
          const match = url.match(/([^/]+)\.s3\.amazonaws\.com\/(.+)/);
          if (match) {
            const bucket = match[1];
            const key = match[2];
            return `https://${bucket}.s3.amazonaws.com/${key}`;
          }
          return url;
        }

        const bucket = urlParts[bucketIndex - 1];
        const key = urlParts.slice(bucketIndex + 1).join("/");

        // Return virtual-hosted style URL
        return `https://${bucket}.s3.amazonaws.com/${key}`;
      })();

      // First, try to fetch the file with proper headers
      const response = await fetch(fixedUrl, {
        method: "GET",
        headers: {
          Accept: "application/pdf,application/octet-stream,*/*",
        },
      });

      if (!response.ok) {
        throw new Error(
          `Failed to fetch file: ${response.status} ${response.statusText}`
        );
      }

      // Get the blob from the response
      const blob = await response.blob();

      // Create a temporary URL for the blob
      const blobUrl = window.URL.createObjectURL(blob);

      // Create a temporary anchor element and trigger download
      const link = document.createElement("a");
      link.href = blobUrl;
      link.download = filename || "certificate.pdf";
      document.body.appendChild(link);
      link.click();

      // Clean up
      document.body.removeChild(link);
      window.URL.revokeObjectURL(blobUrl);
    } catch (error) {
      console.error("Download error:", error);

      // Fallback: try direct download
      try {
        const link = document.createElement("a");
        link.href = url;
        link.download = filename || "certificate.pdf";
        link.target = "_blank";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } catch (fallbackError) {
        console.error("Fallback error:", fallbackError);
        // Final fallback: open in new tab
        window.open(url, "_blank");
      }
    }
  };

  // Status badge styling
  const getStatusStyle = (status: string) => {
    const styles = {
      Approved: "bg-green-100 text-green-800 border-green-200",
      Pending: "bg-yellow-100 text-yellow-800 border-yellow-200",
      Reject: "bg-red-100 text-red-800 border-red-200",
    };
    return styles[status] || "";
  };

  // Safe access to doctor specializations
  const specializations =
    doctor && doctor.specialization ? doctor.specialization : [];

  return (
    <>
      <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
        <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto p-0">
          <DialogHeader className="px-6 pt-6 pb-2 sticky top-0 bg-white z-10 border-b">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-full flex items-center justify-center text-white text-xl font-semibold shadow-md">
                  {doctor.user_name?.charAt(0)?.toUpperCase() || "D"}
                </div>
                <div>
                  <DialogTitle className="text-2xl font-bold">
                    {doctor.user_name}
                  </DialogTitle>
                  <p className="text-gray-500">{doctor.doctor_type}</p>
                </div>
              </div>
              <Badge
                variant="outline"
                className={`px-3 py-1 text-sm font-medium border ${getStatusStyle(
                  doctor.is_Verified
                )}`}
              >
                {doctor.is_Verified}
              </Badge>
            </div>
          </DialogHeader>

          <Tabs
            defaultValue="profile"
            className="w-full"
            onValueChange={setActiveTab}
          >
            <div className="border-b">
              <TabsList className="px-6 h-14 bg-white w-full justify-start gap-8 rounded-none">
                <TabsTrigger
                  value="profile"
                  className={`h-full data-[state=active]:border-b-2 data-[state=active]:border-indigo-600 data-[state=active]:shadow-none rounded-none px-2 text-base font-medium ${
                    activeTab === "profile"
                      ? "text-indigo-700"
                      : "text-gray-600"
                  }`}
                >
                  <User
                    className={`h-4 w-4 mr-2 ${
                      activeTab === "profile"
                        ? "text-indigo-600"
                        : "text-gray-500"
                    }`}
                  />
                  Profile
                </TabsTrigger>
                <TabsTrigger
                  value="education"
                  className={`h-full data-[state=active]:border-b-2 data-[state=active]:border-indigo-600 data-[state=active]:shadow-none rounded-none px-2 text-base font-medium ${
                    activeTab === "education"
                      ? "text-indigo-700"
                      : "text-gray-600"
                  }`}
                >
                  <GraduationCap
                    className={`h-4 w-4 mr-2 ${
                      activeTab === "education"
                        ? "text-indigo-600"
                        : "text-gray-500"
                    }`}
                  />
                  Education
                </TabsTrigger>
                <TabsTrigger
                  value="work"
                  className={`h-full data-[state=active]:border-b-2 data-[state=active]:border-indigo-600 data-[state=active]:shadow-none rounded-none px-2 text-base font-medium ${
                    activeTab === "work" ? "text-indigo-700" : "text-gray-600"
                  }`}
                >
                  <Briefcase
                    className={`h-4 w-4 mr-2 ${
                      activeTab === "work" ? "text-indigo-600" : "text-gray-500"
                    }`}
                  />
                  Work History
                </TabsTrigger>
              </TabsList>
            </div>

            <div className="px-6 py-4">
              <TabsContent value="profile" className="mt-0 space-y-6">
                {/* Personal Information */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg font-medium flex items-center">
                      <User className="h-5 w-5 mr-2 text-indigo-600" />
                      Personal Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="flex items-center gap-3">
                        <div className="flex-shrink-0 h-9 w-9 bg-indigo-100 rounded-full flex items-center justify-center">
                          <Phone className="h-4 w-4 text-indigo-600" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-500">Phone Number</p>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <p className="font-medium truncate max-w-[200px]">
                                  {doctor.phoneNumber || "N/A"}
                                </p>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>{doctor.phoneNumber || "N/A"}</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="flex-shrink-0 h-9 w-9 bg-indigo-100 rounded-full flex items-center justify-center">
                          <Mail className="h-4 w-4 text-indigo-600" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-500">Email</p>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <p className="font-medium truncate max-w-[200px]">
                                  {doctor.user_email || "N/A"}
                                </p>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>{doctor.user_email || "N/A"}</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="flex-shrink-0 h-9 w-9 bg-indigo-100 rounded-full flex items-center justify-center">
                          <Briefcase className="h-4 w-4 text-indigo-600" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-500">Work Type</p>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <p className="font-medium truncate max-w-[200px]">
                                  {doctor.work_type || "N/A"}
                                </p>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>{doctor.work_type || "N/A"}</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="flex-shrink-0 h-9 w-9 bg-indigo-100 rounded-full flex items-center justify-center">
                          <Star className="h-4 w-4 text-indigo-600" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-500">Experience</p>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <p className="font-medium truncate max-w-[200px]">
                                  {doctor.experience || "N/A"}
                                </p>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>{doctor.experience || "N/A"}</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Specializations */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg font-medium flex items-center">
                      <Award className="h-5 w-5 mr-2 text-indigo-600" />
                      Specializations
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {renderSpecializations(specializations)}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="education" className="mt-0 space-y-6">
                {/* Education Details */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg font-medium flex items-center">
                      <GraduationCap className="h-5 w-5 mr-2 text-indigo-600" />
                      Education Details
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="flex items-center gap-3">
                        <div className="flex-shrink-0 h-9 w-9 bg-indigo-100 rounded-full flex items-center justify-center">
                          <Building className="h-4 w-4 text-indigo-600" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-500">College Name</p>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <p className="font-medium truncate max-w-[200px]">
                                  {doctor.collage_name || "N/A"}
                                </p>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>{doctor.collage_name || "N/A"}</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="flex-shrink-0 h-9 w-9 bg-indigo-100 rounded-full flex items-center justify-center">
                          <Calendar className="h-4 w-4 text-indigo-600" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-500">
                            Passed Out Year
                          </p>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <p className="font-medium truncate max-w-[200px]">
                                  {doctor.passed_out_year || "N/A"}
                                </p>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>{doctor.passed_out_year || "N/A"}</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="flex-shrink-0 h-9 w-9 bg-indigo-100 rounded-full flex items-center justify-center">
                          <MapPin className="h-4 w-4 text-indigo-600" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-500">State</p>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <p className="font-medium truncate max-w-[200px]">
                                  {doctor.state || "N/A"}
                                </p>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>{doctor.state || "N/A"}</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="flex-shrink-0 h-9 w-9 bg-indigo-100 rounded-full flex items-center justify-center">
                          <FileText className="h-4 w-4 text-indigo-600" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-500">
                            Registration Number
                          </p>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <p className="font-medium truncate max-w-[200px]">
                                  {doctor.state_councel_reg_number || "N/A"}
                                </p>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>
                                  {doctor.state_councel_reg_number || "N/A"}
                                </p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      </div>
                    </div>

                    {/* Certificate info - without view/download buttons */}
                    {doctor.state_councel_certificate && (
                      <div className="mt-4 pt-4 border-t">
                        <h4 className="text-sm font-medium text-gray-700 mb-3">
                          Certificate
                        </h4>
                        <div className="flex items-start gap-3">
                          <FileText className="h-5 w-5 text-muted-foreground mt-0.5" />
                          <div className="w-full">
                            <p className="text-sm text-muted-foreground">
                              State Council Certificate
                            </p>
                            <div className="flex justify-between mt-1">
                              <button
                                onClick={() =>
                                  handleViewCertificate(
                                    doctor.state_councel_certificate,
                                    "State Council Certificate"
                                  )
                                }
                                className="font-medium text-primary flex items-center hover:underline"
                              >
                                View Certificate
                                <ExternalLink className="h-3 w-3 ml-1" />
                              </button>
                              <div className="flex items-center gap-2">
                                <button
                                  onClick={() => {
                                    const filename = `state_council_certificate_${
                                      doctor.user_name || "doctor"
                                    }_${new Date().getTime()}.pdf`;
                                    handleDownloadCertificate(
                                      doctor.state_councel_certificate,
                                      filename
                                    );
                                  }}
                                  className="flex items-center gap-1 text-primary hover:text-primary/80 transition-colors bg-primary/10 hover:bg-primary/20 px-3 py-1.5 rounded-md text-sm font-medium"
                                >
                                  <Download className="h-4 w-4" />
                                  Download
                                </button>
                              </div>
                            </div>
                            <p className="text-xs text-muted-foreground mt-2 truncate">
                              {doctor.state_councel_certificate
                                .split("/")
                                .pop()
                                ?.substring(0, 15)}
                              ...
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="work" className="mt-0 space-y-6">
                {/* Work History */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg font-medium flex items-center">
                      <Briefcase className="h-5 w-5 mr-2 text-indigo-600" />
                      Work Experience
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="flex items-center gap-3">
                        <div className="flex-shrink-0 h-9 w-9 bg-indigo-100 rounded-full flex items-center justify-center">
                          <Building className="h-4 w-4 text-indigo-600" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-500">Clinic Name</p>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <p className="font-medium truncate max-w-[200px]">
                                  {doctor.clinic_name || "N/A"}
                                </p>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>{doctor.clinic_name || "N/A"}</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="flex-shrink-0 h-9 w-9 bg-indigo-100 rounded-full flex items-center justify-center">
                          <Briefcase className="h-4 w-4 text-indigo-600" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-500">Designation</p>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <p className="font-medium truncate max-w-[200px]">
                                  {doctor.designation || "N/A"}
                                </p>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>{doctor.designation || "N/A"}</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="flex-shrink-0 h-9 w-9 bg-indigo-100 rounded-full flex items-center justify-center">
                          <Clock className="h-4 w-4 text-indigo-600" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-500">Duration</p>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <p className="font-medium truncate max-w-[200px]">
                                  {(() => {
                                    const formatDate = (dateStr: string) => {
                                      if (!dateStr) return "N/A";
                                      const date = new Date(dateStr);
                                      const day = date
                                        .getDate()
                                        .toString()
                                        .padStart(2, "0");
                                      const month = (date.getMonth() + 1)
                                        .toString()
                                        .padStart(2, "0");
                                      const year = date.getFullYear();
                                      return `${day}-${month}-${year}`;
                                    };
                                    return `${formatDate(
                                      doctor.joined_Date
                                    )} - ${
                                      doctor.Departure
                                        ? formatDate(doctor.Departure)
                                        : "Present"
                                    }`;
                                  })()}
                                </p>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>
                                  {(() => {
                                    const formatDate = (dateStr: string) => {
                                      if (!dateStr) return "N/A";
                                      const date = new Date(dateStr);
                                      const day = date
                                        .getDate()
                                        .toString()
                                        .padStart(2, "0");
                                      const month = (date.getMonth() + 1)
                                        .toString()
                                        .padStart(2, "0");
                                      const year = date.getFullYear();
                                      return `${day}-${month}-${year}`;
                                    };
                                    return `${formatDate(
                                      doctor.joined_Date
                                    )} - ${
                                      doctor.Departure
                                        ? formatDate(doctor.Departure)
                                        : "Present"
                                    }`;
                                  })()}
                                </p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      </div>

                      {doctor.expertise_in && (
                        <div className="flex items-center gap-3">
                          <div className="flex-shrink-0 h-9 w-9 bg-indigo-100 rounded-full flex items-center justify-center">
                            <Star className="h-4 w-4 text-indigo-600" />
                          </div>
                          <div>
                            <p className="text-sm text-gray-500">
                              Expertise In
                            </p>
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <p className="font-medium truncate max-w-[200px]">
                                    {doctor.expertise_in}
                                  </p>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>{doctor.expertise_in}</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* About Clinic */}
                {doctor.clinic_About && (
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg font-medium flex items-center">
                        <Building className="h-5 w-5 mr-2 text-indigo-600" />
                        About Clinic
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-700 leading-relaxed">
                        {doctor.clinic_About}
                      </p>
                    </CardContent>
                  </Card>
                )}

                {/* System Information */}
                {/* <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg font-medium flex items-center">
                      <ChevronRight className="h-5 w-5 mr-2 text-indigo-600" />
                      System Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">User ID</p>
                    <p className="font-medium text-xs">{doctor.user_id}</p>
                  </CardContent>
                </Card> */}
              </TabsContent>
            </div>
          </Tabs>

          {/* Approval Buttons - Only show for Pending status */}
          {doctor.is_Verified === "Pending" && (
            <div className="p-6 pt-2 border-t mt-4 flex justify-end gap-3">
              <Button
                variant="outline"
                onClick={onClose}
                disabled={isProcessing}
              >
                Cancel
              </Button>
              <Button
                variant="destructive"
                onClick={() => setShowRejectionReasonModal(true)}
                className="flex items-center"
                disabled={isProcessing}
              >
                <XCircle className="mr-2 h-4 w-4" /> Reject
              </Button>
              <Button
                onClick={() => handleStatusUpdate("Approved")}
                className="flex items-center bg-blue-900 hover:bg-blue-950"
                disabled={isProcessing}
              >
                {isProcessing ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Processing...
                  </>
                ) : (
                  <>
                    <CheckCircle className="mr-2 h-4 w-4" /> Approve
                  </>
                )}
              </Button>
            </div>
          )}
          {doctor.is_Verified !== "Pending" && (
            <div className="p-6 pt-2 border-t mt-4 flex justify-end gap-3">
              <Button variant="outline" onClick={onClose}>
                Close
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <RejectionReasonModal
        isOpen={showRejectionReasonModal}
        onClose={() => setShowRejectionReasonModal(false)}
        onSubmit={handleReject}
      />

      <CertificateViewerModal
        isOpen={showCertificateModal}
        onClose={() => setShowCertificateModal(false)}
        certificateUrl={certificateUrl}
        certificateName={certificateName}
      />
    </>
  );
};

export default DoctorDetailsModal;
