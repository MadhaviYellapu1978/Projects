/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Calendar,
  FileText,
  Mail,
  Phone,
  User,
  Briefcase,
  Star,
  GraduationCap,
  Building,
  MapPin,
  Clock,
  Award,
  ExternalLink,
  ChevronRight,
  X,
  Download,
} from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { CertificateViewerModal } from "./CertificateViewerModal";

interface ReadOnlyDoctorDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  doctor: any;
}

const renderSpecializations = (specialization: any): React.ReactNode => {
  if (
    !specialization ||
    (Array.isArray(specialization) && specialization.length === 0)
  ) {
    return <p>No specializations listed</p>;
  }
  return (
    <div className="flex flex-wrap gap-2">
      {(Array.isArray(specialization) ? specialization : [specialization]).map(
        (spec: any) => (
          <Badge
            key={
              typeof spec === "object"
                ? spec.specialization_id || spec.id || Math.random()
                : Math.random()
            }
            variant="secondary"
            className="px-3 py-1"
          >
            {typeof spec === "object"
              ? spec.specialization_name || spec.name || "Unknown"
              : spec.toString()}
          </Badge>
        )
      )}
    </div>
  );
};

const ReadOnlyDoctorDetailsModal = ({
  isOpen,
  onClose,
  doctor,
}: ReadOnlyDoctorDetailsModalProps) => {
  const [activeTab, setActiveTab] = useState("profile");
  const [showCertificateModal, setShowCertificateModal] = useState(false);
  const [certificateUrl, setCertificateUrl] = useState("");
  const [certificateName, setCertificateName] = useState("");

  useEffect(() => {
    if (isOpen) {
      setActiveTab("profile");
    }
  }, [isOpen]);

  const getStatusStyle = (status: string) => {
    const styles = {
      Approved: "bg-green-100 text-green-800 border-green-200",
      Pending: "bg-yellow-100 text-yellow-800 border-yellow-200",
      Reject: "bg-red-100 text-red-800 border-red-200",
    };
    return styles[status] || "";
  };

  const specializations = doctor?.specialization || [];

  const handleViewCertificate = (url: string, name: string) => {
    console.log("Certificate URL:", url);
    console.log("Certificate Name:", name);
    console.log("Doctor data:", doctor);

    // Set certificate data and show modal
    setCertificateUrl(url);
    setCertificateName(name);
    setShowCertificateModal(true);
  };

  // Comprehensive download handler for both PDFs and images
  const handleDownload = async (
    fileUrl: string,
    options: {
      filename?: string;
      authHeaders?: Record<string, string>;
      onError?: (error: string) => void;
      onSuccess?: (message: string) => void;
    } = {}
  ) => {
    console.log("🔽 handleDownload called with:", { fileUrl, options });
    const { filename, authHeaders, onError, onSuccess } = options;

    try {
      // Determine file type
      const isPDF =
        fileUrl.toLowerCase().includes(".pdf") ||
        fileUrl.toLowerCase().includes("application/pdf");
      const isImage = /\.(jpg|jpeg|png|gif|webp|bmp|svg)$/i.test(fileUrl);

      console.log("📁 File type detection:", { isPDF, isImage, fileUrl });

      if (isPDF) {
        console.log("📄 Processing PDF file - Opening in new tab");
        // For PDFs: Open in new tab for viewing
        try {
          // Open PDF directly in new tab
          const newWindow = window.open(
            fileUrl,
            "_blank",
            "noopener,noreferrer,width=1200,height=800,scrollbars=yes,resizable=yes"
          );

          if (
            !newWindow ||
            newWindow.closed ||
            typeof newWindow.closed == "undefined"
          ) {
            console.log("❌ Popup blocked, trying alternative method");
            // Fallback: create a link and open in new tab
            const link = document.createElement("a");
            link.href = fileUrl;
            link.target = "_blank";
            link.rel = "noopener noreferrer";
            link.style.display = "none";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            console.log("✅ PDF opened in new tab (fallback method)");
          } else {
            console.log("✅ PDF opened in new tab successfully");
            newWindow.focus();
          }

          onSuccess?.("PDF opened in new tab successfully");
        } catch (error) {
          console.log("❌ PDF open failed:", error);
          // Final fallback: direct link
          const link = document.createElement("a");
          link.href = fileUrl;
          link.target = "_blank";
          link.rel = "noopener noreferrer";
          link.style.display = "none";
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          console.log("✅ PDF opened in new tab (final fallback)");

          onSuccess?.("PDF opened in new tab (fallback)");
        }
      } else if (isImage) {
        // For Images: Direct download
        try {
          const response = await fetch(fileUrl, {
            method: "GET",
            headers: {
              ...authHeaders,
              Accept: "image/*,*/*",
            },
          });

          if (!response.ok) {
            throw new Error(
              `Failed to fetch image: ${response.status} ${response.statusText}`
            );
          }

          // Get filename from Content-Disposition header or use provided filename
          let downloadFilename = filename || "certificate";
          const contentDisposition = response.headers.get(
            "Content-Disposition"
          );
          if (contentDisposition) {
            const filenameMatch = contentDisposition.match(
              /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/
            );
            if (filenameMatch && filenameMatch[1]) {
              downloadFilename = filenameMatch[1].replace(/['"]/g, "");
            }
          }

          // Ensure proper file extension
          if (!downloadFilename.includes(".")) {
            const urlLower = fileUrl.toLowerCase();
            if (urlLower.includes(".jpg") || urlLower.includes(".jpeg")) {
              downloadFilename += ".jpg";
            } else if (urlLower.includes(".png")) {
              downloadFilename += ".png";
            } else if (urlLower.includes(".gif")) {
              downloadFilename += ".gif";
            } else if (urlLower.includes(".webp")) {
              downloadFilename += ".webp";
            } else {
              downloadFilename += ".jpg"; // default
            }
          }

          // Create blob and download
          const blob = await response.blob();
          const blobUrl = URL.createObjectURL(blob);

          const link = document.createElement("a");
          link.href = blobUrl;
          link.download = downloadFilename;
          link.style.display = "none";
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);

          // Clean up blob URL
          setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);

          onSuccess?.("Image downloaded successfully");
        } catch (fetchError) {
          // Fallback: direct download
          const link = document.createElement("a");
          link.href = fileUrl;
          link.download = filename || "certificate";
          link.style.display = "none";
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);

          onSuccess?.("Image download initiated");
        }
      } else {
        // For other file types: direct download
        const link = document.createElement("a");
        link.href = fileUrl;
        link.download = filename || "certificate";
        link.target = "_blank";
        link.style.display = "none";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        onSuccess?.("File download initiated");
      }
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : "Download failed";
      console.error("❌ Download error:", error);
      console.error("❌ Error details:", { error, errorMessage });
      onError?.(errorMessage);
    }
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
        <DialogContent className="sm:max-w-4xl min-h-[55vh] max-h-[90vh] overflow-y-auto p-0">
          <DialogHeader className="px-6 pr-16 pt-6 pb-2 sticky top-0 bg-white z-10 border-b relative">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-full flex items-center justify-center text-white text-xl font-semibold shadow-md">
                  {doctor.user_name?.charAt(0)?.toUpperCase() || "D"}
                </div>
                <div>
                  <DialogTitle className="text-2xl font-bold">
                    {doctor.user_name}
                  </DialogTitle>
                  <p className="text-gray-500">{doctor.doctor_type}</p>
                </div>
              </div>
              <Badge
                variant="outline"
                className={`px-3 py-1 text-sm font-medium border ${getStatusStyle(
                  doctor.is_Verified
                )}`}
              >
                {doctor.is_Verified}
              </Badge>
            </div>
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 rounded-full hover:bg-gray-100 "
              aria-label="Close"
              type="button"
            >
              <X className="w-4 h-4 text-gray-500" />
            </button>
          </DialogHeader>

          <Tabs
            defaultValue="profile"
            className="w-full"
            onValueChange={setActiveTab}
          >
            <div className="border-b">
              <TabsList className="px-6 h-14 bg-white w-full justify-start gap-8 rounded-none">
                <TabsTrigger
                  value="profile"
                  className={`h-full px-2 text-base font-medium border-b-2 ${
                    activeTab === "profile"
                      ? "text-indigo-700 border-indigo-600"
                      : "text-gray-600 border-transparent"
                  }`}
                >
                  <User
                    className={`h-4 w-4 mr-2 ${
                      activeTab === "profile"
                        ? "text-indigo-600"
                        : "text-gray-500"
                    }`}
                  />
                  Profile
                </TabsTrigger>
                <TabsTrigger
                  value="education"
                  className={`h-full px-2 text-base font-medium border-b-2 ${
                    activeTab === "education"
                      ? "text-indigo-700 border-indigo-600"
                      : "text-gray-600 border-transparent"
                  }`}
                >
                  <GraduationCap
                    className={`h-4 w-4 mr-2 ${
                      activeTab === "education"
                        ? "text-indigo-600"
                        : "text-gray-500"
                    }`}
                  />
                  Education
                </TabsTrigger>
                <TabsTrigger
                  value="work"
                  className={`h-full px-2 text-base font-medium border-b-2 ${
                    activeTab === "work"
                      ? "text-indigo-700 border-indigo-600"
                      : "text-gray-600 border-transparent"
                  }`}
                >
                  <Briefcase
                    className={`h-4 w-4 mr-2 ${
                      activeTab === "work" ? "text-indigo-600" : "text-gray-500"
                    }`}
                  />
                  Work History
                </TabsTrigger>
              </TabsList>
            </div>

            <div className="px-6 py-4">
              <TabsContent value="profile" className="mt-0 space-y-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg font-medium flex items-center">
                      <User className="h-5 w-5 mr-2 text-indigo-600" />
                      Personal Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <InfoField
                        icon={<Phone />}
                        label="Contact Number"
                        value={doctor.phoneNumber}
                      />
                      <InfoField
                        icon={<Mail />}
                        label="Email"
                        value={doctor.user_email}
                      />
                      <InfoField
                        icon={<Briefcase />}
                        label="Work Type"
                        value={doctor.work_type || "N/A"}
                      />
                      <InfoField
                        icon={<Star />}
                        label="Experience"
                        value={doctor.experience || "N/A"}
                      />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg font-medium flex items-center">
                      <Award className="h-5 w-5 mr-2 text-indigo-600" />
                      Specializations
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {renderSpecializations(specializations)}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="education" className="mt-0 space-y-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg font-medium flex items-center">
                      <GraduationCap className="h-5 w-5 mr-2 text-indigo-600" />
                      Education Details
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <InfoField
                        icon={<Building />}
                        label="College Name"
                        value={doctor.collage_name || "N/A"}
                      />
                      <InfoField
                        icon={<Calendar />}
                        label="Passed Out Year"
                        value={doctor.passed_out_year || "N/A"}
                      />
                      <InfoField
                        icon={<MapPin />}
                        label="State"
                        value={doctor.state || "N/A"}
                      />
                      <InfoField
                        icon={<FileText />}
                        label="Registration Number"
                        value={doctor.state_councel_reg_number || "N/A"}
                      />
                    </div>
                  </CardContent>
                </Card>

                {(doctor.state_councel_certificate ||
                  doctor.Education?.state_councel_certificate) && (
                  <div className="mt-4 pt-4 border-t">
                    <h4 className="text-sm font-medium text-gray-700 mb-3">
                      Certificate
                    </h4>
                    <div className="flex items-start gap-3">
                      <FileText className="h-5 w-5 text-muted-foreground mt-0.5" />
                      <div className="w-full">
                        <p className="text-sm text-muted-foreground">
                          State Council Certificate
                        </p>
                        <div className="flex justify-between mt-1">
                          <button
                            onClick={() =>
                              handleViewCertificate(
                                doctor.state_councel_certificate ||
                                  doctor.Education?.state_councel_certificate,
                                "State Council Certificate"
                              )
                            }
                            className="font-medium text-primary flex items-center hover:underline"
                          >
                            View Certificate
                            <ExternalLink className="h-3 w-3 ml-1" />
                          </button>
                          <div className="flex items-center gap-2">
                            <button
                              onClick={async () => {
                                const certificateUrl =
                                  doctor.state_councel_certificate ||
                                  doctor.Education?.state_councel_certificate;

                                if (!certificateUrl) {
                                  alert("No certificate file available");
                                  return;
                                }

                                try {
                                  // Direct download implementation
                                  const response = await fetch(certificateUrl);
                                  if (!response.ok) {
                                    throw new Error(
                                      `Failed to fetch file: ${response.status}`
                                    );
                                  }

                                  const blob = await response.blob();
                                  const blobUrl = URL.createObjectURL(blob);

                                  // Get filename from URL or use default
                                  const urlParts = certificateUrl.split("/");
                                  const originalFilename =
                                    urlParts[urlParts.length - 1];
                                  const filename =
                                    originalFilename ||
                                    `state_council_certificate_${
                                      doctor.user_name || "doctor"
                                    }.pdf`;

                                  const link = document.createElement("a");
                                  link.href = blobUrl;
                                  link.download = filename;
                                  link.style.display = "none";
                                  document.body.appendChild(link);
                                  link.click();
                                  document.body.removeChild(link);

                                  // Clean up blob URL
                                  setTimeout(
                                    () => URL.revokeObjectURL(blobUrl),
                                    1000
                                  );
                                } catch (error) {
                                  console.error("Download failed:", error);
                                  alert("Download failed. Please try again.");
                                }
                              }}
                              className="flex items-center gap-1 text-primary hover:text-primary/80 transition-colors bg-primary/10 hover:bg-primary/20 px-3 py-1.5 rounded-md text-sm font-medium"
                            >
                              <Download className="h-4 w-4" />
                              Download
                            </button>
                          </div>
                        </div>
                        <p className="text-xs text-muted-foreground mt-2 truncate">
                          {(() => {
                            const certificateUrl =
                              doctor.state_councel_certificate ||
                              doctor.Education?.state_councel_certificate;
                            if (!certificateUrl) return "No certificate file";
                            const fileName =
                              certificateUrl.split("/").pop() || "certificate";
                            return fileName.length > 30
                              ? `${fileName.substring(0, 30)}...`
                              : fileName;
                          })()}
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="work" className="mt-0 space-y-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg font-medium flex items-center">
                      <Briefcase className="h-5 w-5 mr-2 text-indigo-600" />
                      Work Experience
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <InfoField
                        icon={<Building />}
                        label="Clinic Name"
                        value={doctor.clinic_name || "N/A"}
                      />
                      <InfoField
                        icon={<Briefcase />}
                        label="Designation"
                        value={doctor.designation || "N/A"}
                      />
                      <InfoField
                        icon={<Clock />}
                        label="Duration"
                        value={(() => {
                          const formatDate = (dateStr: string) => {
                            if (!dateStr) return "N/A";
                            const date = new Date(dateStr);
                            const day = date
                              .getDate()
                              .toString()
                              .padStart(2, "0");
                            const month = (date.getMonth() + 1)
                              .toString()
                              .padStart(2, "0");
                            const year = date.getFullYear();
                            return `${day}-${month}-${year}`;
                          };
                          return `${formatDate(doctor.joined_Date)} - ${
                            doctor.Departure
                              ? formatDate(doctor.Departure)
                              : "Present"
                          }`;
                        })()}
                      />
                      {doctor.expertise_in && (
                        <InfoField
                          icon={<Star />}
                          label="Expertise In"
                          value={doctor.expertise_in}
                        />
                      )}
                    </div>
                  </CardContent>
                </Card>
                {/* <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg font-medium flex items-center">
                    <ChevronRight className="h-5 w-5 mr-2 text-indigo-600" />
                    System Information
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-500">User ID</p>
                  <p className="font-medium text-xs">{doctor.user_id}</p>
                </CardContent>
              </Card> */}
              </TabsContent>
            </div>
          </Tabs>
        </DialogContent>
      </Dialog>

      {/* Certificate Viewer Modal */}
      <CertificateViewerModal
        isOpen={showCertificateModal}
        onClose={() => setShowCertificateModal(false)}
        certificateUrl={certificateUrl}
        certificateName={certificateName}
      />
    </>
  );
};

const InfoField = ({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
}) => (
  <div className="flex items-center gap-3">
    <div className="flex-shrink-0 h-9 w-9 bg-indigo-100 rounded-full flex items-center justify-center">
      {icon}
    </div>
    <div>
      <p className="text-sm text-gray-500">{label}</p>
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <p className="font-medium cursor-pointer">
              {value?.length > 20 ? `${value.substring(0, 20)}...` : value}
            </p>
          </TooltipTrigger>
          <TooltipContent>
            <p>{value}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    </div>
  </div>
);

export default ReadOnlyDoctorDetailsModal;
