import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Phone,
  Mail,
  Globe,
  MapPin,
  FileText,
  ExternalLink,
  Download,
  User2,
  ChevronRight,
  Calendar,
  Users,
} from "lucide-react";
import { Button } from "@/components/ui/button";

// Define a proper type for clinic instead of using 'any'
interface ClinicData {
  Clinic_id: string;
  Clinic_name: string;
  clinic_Address: string;
  Clinic_Contact_Number: string;
  Clinic_Website?: string;
  Clinic_Geolaction?: string;
  No_of_Dental_Chairs: number;
  Avg_per_month: number;
  Clinic_certificate?: string;
  is_Verified: "Approved" | "Pending" | "Reject";
  user_id: string;
  Clinic_email: string;
  owner_name?: string;
  doctor_type?: string;
}

interface ReadOnlyClinicDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  clinic: ClinicData;
}

const ReadOnlyClinicDetailsModal = ({
  isOpen,
  onClose,
  clinic,
}: ReadOnlyClinicDetailsModalProps) => {
  if (!clinic) return null;

  const getStatusStyle = (status: string) => {
    const styles = {
      Approved: "bg-green-100 text-green-800",
      Pending: "bg-yellow-100 text-yellow-800",
      Reject: "bg-red-100 text-red-800",
    };
    return styles[status] || "bg-gray-100 text-gray-800";
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader className="border-b pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <FileText className="text-blue-700" />
              <DialogTitle className="text-2xl font-bold">
                {clinic.Clinic_name || "Clinic Details"}
              </DialogTitle>
            </div>
            <span
              className={`text-sm font-medium px-3 py-1 rounded-full border ${getStatusStyle(
                clinic.is_Verified
              )}`}
            >
              {clinic.is_Verified}
            </span>
          </div>
        </DialogHeader>

        <div className="space-y-8 py-4">
          <section>
            <h3 className="text-lg font-semibold text-primary/80 mb-3">
              Contact Information
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex gap-3">
                <Phone className="text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-sm text-muted-foreground">Phone Number</p>
                  <p className="font-medium">{clinic.Clinic_Contact_Number}</p>
                </div>
              </div>
              <div className="flex gap-3">
                <Mail className="text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-sm text-muted-foreground">Email</p>
                  <p className="font-medium">{clinic.Clinic_email}</p>
                </div>
              </div>
              <div className="flex gap-3">
                <User2 className="text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-sm text-muted-foreground">Owner Name</p>
                  <p className="font-medium">{clinic.owner_name || "N/A"}</p>
                </div>
              </div>
              <div className="flex gap-3">
                <Users className="text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-sm text-muted-foreground">Doctor Type</p>
                  <p className="font-medium">{clinic.doctor_type || "N/A"}</p>
                </div>
              </div>
              {clinic.Clinic_Website && (
                <div className="flex gap-3">
                  <Globe className="text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm text-muted-foreground">Website</p>
                    <a
                      href={
                        clinic.Clinic_Website.startsWith("http")
                          ? clinic.Clinic_Website
                          : `https://${clinic.Clinic_Website}`
                      }
                      target="_blank"
                      rel="noopener noreferrer"
                      className="font-medium text-primary flex items-center hover:underline"
                      title={clinic.Clinic_Website}
                    >
                      {clinic.Clinic_Website.slice(0, 20) + "..."}
                      <ExternalLink className="h-3 w-3 ml-1" />
                    </a>
                  </div>
                </div>
              )}
              {/* <div className="flex gap-3">
                <User2 className="text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-sm text-muted-foreground">Owner ID</p>
                  <p className="font-medium">{clinic.user_id}</p>
                </div>
              </div> */}
            </div>
          </section>

          <section>
            <h3 className="text-lg font-semibold text-primary/80 mb-3">
              Location
            </h3>
            <div className="flex gap-3">
              <MapPin className="text-muted-foreground mt-0.5" />
              <div>
                <p className="text-sm text-muted-foreground">Address</p>
                <p className="font-medium">{clinic.clinic_Address}</p>
              </div>
            </div>
          </section>

          <section>
            <h3 className="text-lg font-semibold text-primary/80 mb-3">
              Operational Details
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex gap-3">
                <Users className="text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-sm text-muted-foreground">
                    Number of Dental Chairs
                  </p>
                  <p className="font-medium">{clinic.No_of_Dental_Chairs}</p>
                </div>
              </div>
              <div className="flex gap-3">
                <Calendar className="text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-sm text-muted-foreground">
                    Average Patients per Month
                  </p>
                  <p className="font-medium">{clinic.Avg_per_month}</p>
                </div>
              </div>
            </div>
          </section>

          {/* <section>
            <h3 className="text-lg font-semibold text-primary/80 mb-3">
              System Information
            </h3>
            <div className="flex gap-3">
              <ChevronRight className="text-muted-foreground mt-0.5" />
              <div>
                <p className="text-sm text-muted-foreground">Clinic ID</p>
                <p className="font-medium text-xs">{clinic.Clinic_id}</p>
              </div>
            </div>
          </section> */}

          <div className="text-right pt-6">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ReadOnlyClinicDetailsModal;
