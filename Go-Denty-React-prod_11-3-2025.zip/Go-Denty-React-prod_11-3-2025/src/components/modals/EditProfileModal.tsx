import React, { useState, useEffect } from "react";
import { X } from "lucide-react";
import { Button } from "../ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { usePostProfileInfo, useUploadImage } from "../../services/api";

interface EditProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void; // Add callback for successful updates
  userData: {
    userId: string;
    firstName: string;
    lastName: string;
    email: string;
    phoneNumber: string;
    profilePic: string;
  };
}

const EditProfileModal: React.FC<EditProfileModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  userData,
}) => {
  const { toast } = useToast();
  const postProfileInfo = usePostProfileInfo();
  const uploadImage = useUploadImage();
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    phoneNumber: "",
    profilePic: "",
  });
  const [errors, setErrors] = useState({
    phoneNumber: "",
    firstName: "",
    lastName: "",
  });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>("");
  const [isUploadingImage, setIsUploadingImage] = useState(false);

  useEffect(() => {
    // Use userData prop directly (which comes from backend API) instead of localStorage
    const firstName = userData.firstName || "";
    const lastName = userData.lastName || "";
    const phoneNumber = userData.phoneNumber || "";
    const profilePic = userData.profilePic || "";

    console.log("EditProfileModal - Loading data from backend:", {
      firstName,
      lastName,
      phoneNumber,
      profilePic,
      fullUserData: userData,
    });

    setFormData({
      firstName,
      lastName,
      phoneNumber,
      profilePic,
    });

    // Set preview URL for display
    setPreviewUrl(profilePic);

    console.log("EditProfileModal - Final formData:", {
      firstName,
      lastName,
      phoneNumber,
      profilePic,
    });
  }, [userData]);

  const validatePhoneNumber = (phoneNumber: string) => {
    // Remove any non-digit characters
    const digitsOnly = phoneNumber.replace(/\D/g, "");

    // Check if it's exactly 10 digits
    if (digitsOnly.length !== 10) {
      return "Phone number must be exactly 10 digits";
    }

    // Check if it starts with a valid digit (not 0)
    if (digitsOnly[0] === "0") {
      return "Phone number cannot start with 0";
    }

    return "";
  };

  const validateNoFirstSpace = (value: string, fieldName: string) => {
    if (!value) return ""; // Allow empty values
    if (value.startsWith(" ")) {
      return `${fieldName} cannot start with a space`;
    }
    return "";
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, files } = e.target;

    if (name === "profilePicFile" && files && files[0]) {
      // Handle file selection - store the file for upload
      const file = files[0];
      setSelectedFile(file);

      // Create a preview URL for immediate display (separate from the form data)
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setPreviewUrl(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    } else if (name === "phoneNumber") {
      // Handle phone number validation
      // Only allow digits and limit to 10 characters
      const digitsOnly = value.replace(/\D/g, "").slice(0, 10);
      setFormData((prev) => ({
        ...prev,
        [name]: digitsOnly,
      }));

      // Validate phone number
      const error = validatePhoneNumber(digitsOnly);
      setErrors((prev) => ({
        ...prev,
        phoneNumber: error,
      }));
    } else if (name === "firstName" || name === "lastName") {
      // Handle first name and last name validation
      setFormData((prev) => ({
        ...prev,
        [name]: value,
      }));

      // Validate for first space
      const fieldName = name === "firstName" ? "First name" : "Last name";
      const error = validateNoFirstSpace(value, fieldName);
      setErrors((prev) => ({
        ...prev,
        [name]: error,
      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        [name]: value,
      }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    console.log("🚀 handleSubmit called - EditProfileModal");
    e.preventDefault();

    // Validate phone number before submission
    const phoneError = validatePhoneNumber(formData.phoneNumber);
    console.log("🔍 Phone validation result:", phoneError);
    if (phoneError) {
      console.log("❌ Phone validation failed, returning early");
      setErrors((prev) => ({
        ...prev,
        phoneNumber: phoneError,
      }));
      return;
    }

    // Validate first name and last name for first spaces
    const firstNameError = validateNoFirstSpace(
      formData.firstName,
      "First name"
    );
    const lastNameError = validateNoFirstSpace(formData.lastName, "Last name");

    console.log("🔍 Name validation results:", {
      firstNameError,
      lastNameError,
    });
    if (firstNameError || lastNameError) {
      console.log("❌ Name validation failed, returning early");
      setErrors((prev) => ({
        ...prev,
        firstName: firstNameError,
        lastName: lastNameError,
      }));
      return;
    }

    console.log("✅ All validations passed, entering try block");
    try {
      let profilePicUrl = formData.profilePic;

      // If a new file was selected, upload it first
      if (selectedFile) {
        setIsUploadingImage(true);
        try {
          const uploadResponse = await uploadImage.mutateAsync({
            image: selectedFile,
            user_id: userData.userId,
          });

          // Extract the image URL from the response
          if (uploadResponse.data && uploadResponse.data.image) {
            profilePicUrl = uploadResponse.data.image;
          } else if (uploadResponse.data && uploadResponse.data.imageUrl) {
            profilePicUrl = uploadResponse.data.imageUrl;
          } else if (uploadResponse.data && uploadResponse.data.image_url) {
            profilePicUrl = uploadResponse.data.image_url;
          } else if (uploadResponse.data && uploadResponse.data.url) {
            profilePicUrl = uploadResponse.data.url;
          }

          console.log("Image upload response:", uploadResponse.data);
          console.log("Using profile pic URL:", profilePicUrl);

          // Update preview URL with the uploaded URL
          setPreviewUrl(profilePicUrl);
        } catch (uploadError) {
          console.error("Image upload failed:", uploadError);
          toast({
            title: "Upload Error",
            description: "Failed to upload profile image. Please try again.",
            variant: "destructive",
          });
          return;
        } finally {
          setIsUploadingImage(false);
        }
      } else {
        // If no new file selected, use existing profile pic from current form data
        profilePicUrl = formData.profilePic || userData.profilePic || "";
      }

      // Get current user role information from localStorage
      const roleId = parseInt(localStorage.getItem("roleId") || "3");

      // Email is not required for profile updates, proceed without it
      console.log("ℹ️ Proceeding with profile update without email field");

      // Prepare the profile update data
      const profileData = {
        user_id: userData.userId,
        role_id: roleId,
        other_specialization: "",
        user_name: `${formData.firstName} ${formData.lastName}`,
        user_email:
          userData.email ||
          localStorage.getItem("email") ||
          "not-provided@example.com",
        profile_pic: profilePicUrl,
        is_work_experience: false,
        is_Verified: "Pending", // This will be overridden in the API call based on role
        PersonalInfo: {
          profile_name: `${formData.firstName} ${formData.lastName}`,
          profile_email_id:
            userData.email ||
            localStorage.getItem("email") ||
            "not-provided@example.com",
          profile_phone_number: formData.phoneNumber,
          specialization: [],
        },
        Education: {
          state: "",
          collage_name: "",
          passed_out_year: "",
          state_councel_reg_number: "",
          state_councel_certificate: "",
        },
        Work: {
          work_type: "",
          designation: "",
          expertise_in: "",
          experience: "",
          is_experience: false,
          clinic_name: "",
          joined_Date: "",
          Departure: "",
        },
      };

      console.log("Profile update payload:", profileData);

      console.log("Calling postProfileInfo API with data:", {
        ...profileData,
        is_edited: true,
      });

      console.log("📡 About to call postProfileInfo.mutateAsync");
      const response = await postProfileInfo.mutateAsync({
        ...profileData,
        is_edited: true,
      });
      console.log("✅ postProfileInfo.mutateAsync completed successfully");

      console.log("Profile update response:", response);

      // Update localStorage with the data that was successfully sent to backend
      localStorage.setItem("firstName", formData.firstName);
      localStorage.setItem("lastName", formData.lastName);
      localStorage.setItem("phoneNumber", formData.phoneNumber);
      localStorage.setItem(
        "user_name",
        `${formData.firstName} ${formData.lastName}`
      );
      // Only store the URL, not base64 data
      if (profilePicUrl && !profilePicUrl.startsWith("data:")) {
        localStorage.setItem("profilePic", profilePicUrl);
      }

      console.log("Updated localStorage with:", {
        firstName: formData.firstName,
        lastName: formData.lastName,
        phoneNumber: formData.phoneNumber,
        user_name: `${formData.firstName} ${formData.lastName}`,
        profilePic: profilePicUrl,
      });

      // Dispatch custom event to notify other components of changes
      window.dispatchEvent(new Event("localStorageUpdate"));

      toast({
        title: "Profile Updated",
        description: "Your profile has been updated successfully.",
      });

      // Call success callback to trigger refetch in parent component
      if (onSuccess) {
        onSuccess();
      }

      // Reset selected file and preview
      setSelectedFile(null);
      setPreviewUrl("");
      onClose();
    } catch (error: unknown) {
      console.error("Profile update failed:", error);
      toast({
        title: "Error",
        description: "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">Edit Profile</DialogTitle>
        </DialogHeader>
        <DialogClose className="absolute right-4 top-4">
          <X className="h-4 w-4" />
          <span className="sr-only">Close</span>
        </DialogClose>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Profile Picture Section */}
          <div className="flex flex-col items-center mb-6">
            <div className="relative mb-4">
              <div className="h-20 w-20 rounded-full overflow-hidden border-4 border-white shadow-md bg-gray-200 flex items-center justify-center">
                {previewUrl || formData.profilePic ? (
                  <img
                    src={previewUrl || formData.profilePic}
                    alt="Profile"
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <div className="h-full w-full bg-gray-300 flex items-center justify-center text-gray-600 text-xl font-medium">
                    {formData.firstName.charAt(0).toUpperCase()}
                  </div>
                )}
              </div>
            </div>
            <div className="w-full space-y-3">
              <div>
                <label className="block text-gray-500 text-sm mb-1">
                  Upload Profile Picture
                </label>
                <input
                  type="file"
                  name="profilePicFile"
                  accept="image/*"
                  onChange={handleChange}
                  className="border border-gray-200 rounded p-3 w-full"
                />
                {/* Display current profile picture name or selected file name */}
                <div className="mt-2 text-sm text-gray-600">
                  {selectedFile ? (
                    <span
                      className="text-blue-600 cursor-help"
                      title={selectedFile.name}
                    >
                      Selected:{" "}
                      {selectedFile.name.length > 30
                        ? `${selectedFile.name.substring(0, 30)}...`
                        : selectedFile.name}
                    </span>
                  ) : userData.profilePic ? (
                    <span
                      className="text-green-600 cursor-help"
                      title={
                        userData.profilePic.split("/").pop() ||
                        "Profile Picture"
                      }
                    >
                      Current:{" "}
                      {(() => {
                        const fileName =
                          userData.profilePic.split("/").pop() ||
                          "Profile Picture";
                        return fileName.length > 30
                          ? `${fileName.substring(0, 30)}...`
                          : fileName;
                      })()}
                    </span>
                  ) : (
                    <span className="text-gray-500">No file chosen</span>
                  )}
                </div>
              </div>
              {/* <div className="text-center text-gray-400 text-sm">or</div>
              <div>
                <label className="block text-gray-500 text-sm mb-1">
                  Profile Picture URL
                </label>
                <input
                  type="url"
                  name="profilePic"
                  value={formData.profilePic}
                  onChange={handleChange}
                  className="border border-gray-200 rounded p-3 w-full"
                  placeholder="Enter image URL"
                />
              </div> */}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-gray-500 text-sm mb-1">
                First Name
              </label>
              <input
                type="text"
                name="firstName"
                value={formData.firstName}
                onChange={handleChange}
                className={`border rounded p-3 w-full ${
                  errors.firstName ? "border-red-500" : "border-gray-200"
                }`}
                required
              />
              {errors.firstName && (
                <p className="text-red-500 text-sm mt-1">{errors.firstName}</p>
              )}
            </div>
            <div>
              <label className="block text-gray-500 text-sm mb-1">
                Last Name
              </label>
              <input
                type="text"
                name="lastName"
                value={formData.lastName}
                onChange={handleChange}
                className={`border rounded p-3 w-full ${
                  errors.lastName ? "border-red-500" : "border-gray-200"
                }`}
                required
              />
              {errors.lastName && (
                <p className="text-red-500 text-sm mt-1">{errors.lastName}</p>
              )}
            </div>
          </div>
          <div>
            <label className="block text-gray-500 text-sm mb-1">
              Phone Number
            </label>
            <input
              type="tel"
              name="phoneNumber"
              value={formData.phoneNumber}
              onChange={handleChange}
              className={`border rounded p-3 w-full ${
                errors.phoneNumber ? "border-red-500" : "border-gray-200"
              }`}
              placeholder="Enter 10-digit phone number"
              required
            />
            {errors.phoneNumber && (
              <p className="text-red-500 text-sm mt-1">{errors.phoneNumber}</p>
            )}
          </div>
          <div className="flex justify-end space-x-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button
              type="submit"
              variant="default"
              disabled={postProfileInfo.isPending || isUploadingImage}
              onClick={() => console.log("🔘 Save Changes button clicked")}
            >
              {isUploadingImage
                ? "Uploading Image..."
                : postProfileInfo.isPending
                ? "Saving..."
                : "Save Changes"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default EditProfileModal;
