import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import MultiSelectDropdown from "@/components/ui/MultiSelectDropdown";
import { Textarea } from "@/components/ui/textarea";
import { useFormik } from "formik";
import * as Yup from "yup";

interface CreateJobModalProps {
  isOpen: boolean;
  onClose: () => void;
  jobType: number;
}

const jobValidationSchema = Yup.object({
  jobTitle: Yup.string().required("Job title is required"),
  jobType: Yup.array()
    .of(Yup.string())
    .min(1, "Please select at least one job type")
    .required("Job type is required"),
  eligibility: Yup.array()
    .of(Yup.string())
    .min(1, "Please select at least one eligibility option")
    .required("Eligibility is required"),
  minExperience: Yup.array()
    .of(Yup.string())
    .min(1, "Please select at least one experience level")
    .required("Minimum experience is required"),
  jobDescription: Yup.string().required("Job description is required"),
  responsibilities: Yup.string().required("Responsibilities are required"),
  workingTimings: Yup.string().required("Working timings are required"),
  holidays: Yup.string().required("Holidays information is required"),
  monthlySalary: Yup.string().required("Monthly salary is required"),
});

const consultationValidationSchema = Yup.object({
  jobTitle: Yup.string().required("Consultation title is required"),
  specialization: Yup.array()
    .of(Yup.string())
    .min(1, "Please select at least one specialization")
    .required("Specialization is required"),
  eligibility: Yup.array()
    .of(Yup.string())
    .min(1, "Please select at least one eligibility option")
    .required("Eligibility is required"),
  date: Yup.string().required("Date is required"),
  time: Yup.string().required("Time is required"),
  caseDescription: Yup.string().required("Case description is required"),
  payment: Yup.string().required("Payment is required"),
});

const CreateJobModal: React.FC<CreateJobModalProps> = ({
  isOpen,
  onClose,
  jobType,
}) => {
  const isConsultation = jobType === 2;

  const formik = useFormik({
    initialValues: isConsultation
      ? {
          jobTitle: "",
          specialization: [],
          eligibility: [],
          date: "",
          time: "",
          caseDescription: "",
          payment: "",
        }
      : {
          jobTitle: "",
          jobType: [],
          eligibility: [],
          minExperience: [],
          jobDescription: "",
          responsibilities: "",
          workingTimings: "",
          holidays: "",
          monthlySalary: "",
        },
    validationSchema: isConsultation
      ? consultationValidationSchema
      : jobValidationSchema,
    onSubmit: (values) => {
      console.log(values);
      onClose();
    },
  });

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-hidden flex flex-col">
        <DialogHeader className="z-50 pb-4 border-b">
          <DialogTitle>
            {isConsultation ? "Post New Consultation" : "Post New Job"}
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto py-4">
          <form onSubmit={formik.handleSubmit} className="space-y-4">
            <div className="space-y-4 px-1">
              <div>
                <Label htmlFor="jobTitle">
                  {isConsultation ? "Consultation Title" : "Job Title"}
                </Label>
                <Input
                  id="jobTitle"
                  placeholder="Type Here"
                  {...formik.getFieldProps("jobTitle")}
                  className={
                    formik.errors.jobTitle && formik.touched.jobTitle
                      ? "border-red-500"
                      : ""
                  }
                />
                {formik.touched.jobTitle && formik.errors.jobTitle && (
                  <div className="text-red-500 text-sm">
                    {formik.errors.jobTitle}
                  </div>
                )}
              </div>

              {isConsultation ? (
                <>
                  <div>
                    <Label htmlFor="specialization">
                      Specialization Required{" "}
                      <span className="text-red-500">*</span>
                    </Label>
                    <MultiSelectDropdown
                      options={[
                        { value: "RESTORATIONS", label: "RESTORATIONS" },
                        { value: "SCALINGS", label: "SCALINGS" },
                        { value: "EXTRACTIONS", label: "EXTRACTIONS" },
                        { value: "ENDODONTICS", label: "ENDODONTICS" },
                        { value: "PERIODONTICS", label: "PERIODONTICS" },
                        { value: "OMR", label: "OMR" },
                      ]}
                      value={formik.values.specialization}
                      onChange={(value) =>
                        formik.setFieldValue("specialization", value)
                      }
                      placeholder="Select specializations"
                      error={
                        !!(
                          formik.errors.specialization &&
                          formik.touched.specialization
                        )
                      }
                    />
                    {formik.touched.specialization &&
                      formik.errors.specialization && (
                        <div className="text-red-500 text-sm">
                          {Array.isArray(formik.errors.specialization)
                            ? formik.errors.specialization.join(", ")
                            : formik.errors.specialization}
                        </div>
                      )}
                  </div>

                  <div>
                    <Label htmlFor="date">Date</Label>
                    <Input
                      id="date"
                      type="date"
                      {...formik.getFieldProps("date")}
                      className={
                        formik.errors.date && formik.touched.date
                          ? "border-red-500"
                          : ""
                      }
                    />
                    {formik.touched.date && formik.errors.date && (
                      <div className="text-red-500 text-sm">
                        {formik.errors.date}
                      </div>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="time">Time</Label>
                    <Input
                      id="time"
                      type="time"
                      {...formik.getFieldProps("time")}
                      className={
                        formik.errors.time && formik.touched.time
                          ? "border-red-500"
                          : ""
                      }
                    />
                    {formik.touched.time && formik.errors.time && (
                      <div className="text-red-500 text-sm">
                        {formik.errors.time}
                      </div>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="caseDescription">Case Description</Label>
                    <Textarea
                      id="caseDescription"
                      placeholder="Type Here"
                      {...formik.getFieldProps("caseDescription")}
                      className={
                        formik.errors.caseDescription &&
                        formik.touched.caseDescription
                          ? "border-red-500"
                          : ""
                      }
                    />
                    {formik.touched.caseDescription &&
                      formik.errors.caseDescription && (
                        <div className="text-red-500 text-sm">
                          {formik.errors.caseDescription}
                        </div>
                      )}
                  </div>

                  <div>
                    <Label htmlFor="payment">Payment</Label>
                    <Input
                      id="payment"
                      type="number"
                      placeholder="Enter amount"
                      {...formik.getFieldProps("payment")}
                      className={
                        formik.errors.payment && formik.touched.payment
                          ? "border-red-500"
                          : ""
                      }
                    />
                    {formik.touched.payment && formik.errors.payment && (
                      <div className="text-red-500 text-sm">
                        {formik.errors.payment}
                      </div>
                    )}
                  </div>
                </>
              ) : (
                <>
                  <div>
                    <Label htmlFor="jobType">
                      Job Type <span className="text-red-500">*</span>
                    </Label>
                    <MultiSelectDropdown
                      options={[
                        { value: "full-time", label: "Full Time" },
                        { value: "part-time", label: "Part Time" },
                      ]}
                      value={formik.values.jobType}
                      onChange={(value) =>
                        formik.setFieldValue("jobType", value)
                      }
                      placeholder="Select job types"
                      error={
                        !!(formik.errors.jobType && formik.touched.jobType)
                      }
                    />
                    {formik.touched.jobType && formik.errors.jobType && (
                      <div className="text-red-500 text-sm">
                        {Array.isArray(formik.errors.jobType)
                          ? formik.errors.jobType.join(", ")
                          : formik.errors.jobType}
                      </div>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="minExperience">
                      Min Experience <span className="text-red-500">*</span>
                    </Label>
                    <MultiSelectDropdown
                      options={[
                        { value: "no-experience", label: "No Experience" },
                        { value: "0-1", label: "0-1 Year" },
                        { value: "1-2", label: "1-2 Years" },
                        { value: "2-4", label: "2-4 Years" },
                        { value: "4+", label: "4+ Years" },
                      ]}
                      value={formik.values.minExperience}
                      onChange={(value) =>
                        formik.setFieldValue("minExperience", value)
                      }
                      placeholder="Select experience levels"
                      error={
                        !!(
                          formik.errors.minExperience &&
                          formik.touched.minExperience
                        )
                      }
                    />
                    {formik.touched.minExperience &&
                      formik.errors.minExperience && (
                        <div className="text-red-500 text-sm">
                          {Array.isArray(formik.errors.minExperience)
                            ? formik.errors.minExperience.join(", ")
                            : formik.errors.minExperience}
                        </div>
                      )}
                  </div>

                  <div>
                    <Label htmlFor="monthlySalary">Monthly Salary</Label>
                    <Input
                      id="monthlySalary"
                      type="number"
                      placeholder="Enter amount"
                      {...formik.getFieldProps("monthlySalary")}
                      className={
                        formik.errors.monthlySalary &&
                        formik.touched.monthlySalary
                          ? "border-red-500"
                          : ""
                      }
                    />
                    {formik.touched.monthlySalary &&
                      formik.errors.monthlySalary && (
                        <div className="text-red-500 text-sm">
                          {formik.errors.monthlySalary}
                        </div>
                      )}
                  </div>

                  <div>
                    <Label htmlFor="jobDescription">Job Description</Label>
                    <Textarea
                      id="jobDescription"
                      placeholder="Type Here"
                      {...formik.getFieldProps("jobDescription")}
                      className={
                        formik.errors.jobDescription &&
                        formik.touched.jobDescription
                          ? "border-red-500"
                          : ""
                      }
                    />
                    {formik.touched.jobDescription &&
                      formik.errors.jobDescription && (
                        <div className="text-red-500 text-sm">
                          {formik.errors.jobDescription}
                        </div>
                      )}
                  </div>

                  <div>
                    <Label htmlFor="responsibilities">Responsibilities</Label>
                    <Textarea
                      id="responsibilities"
                      placeholder="Type Here"
                      {...formik.getFieldProps("responsibilities")}
                      className={
                        formik.errors.responsibilities &&
                        formik.touched.responsibilities
                          ? "border-red-500"
                          : ""
                      }
                    />
                    {formik.touched.responsibilities &&
                      formik.errors.responsibilities && (
                        <div className="text-red-500 text-sm">
                          {formik.errors.responsibilities}
                        </div>
                      )}
                  </div>

                  <div>
                    <Label htmlFor="workingTimings">Working Timings</Label>
                    <Input
                      id="workingTimings"
                      placeholder="Type Here"
                      {...formik.getFieldProps("workingTimings")}
                      className={
                        formik.errors.workingTimings &&
                        formik.touched.workingTimings
                          ? "border-red-500"
                          : ""
                      }
                    />
                    {formik.touched.workingTimings &&
                      formik.errors.workingTimings && (
                        <div className="text-red-500 text-sm">
                          {formik.errors.workingTimings}
                        </div>
                      )}
                  </div>

                  <div>
                    <Label htmlFor="holidays">Holidays</Label>
                    <Input
                      id="holidays"
                      placeholder="Type Here"
                      {...formik.getFieldProps("holidays")}
                      className={
                        formik.errors.holidays && formik.touched.holidays
                          ? "border-red-500"
                          : ""
                      }
                    />
                    {formik.touched.holidays && formik.errors.holidays && (
                      <div className="text-red-500 text-sm">
                        {formik.errors.holidays}
                      </div>
                    )}
                  </div>
                </>
              )}

              <div>
                <Label htmlFor="eligibility">
                  Eligibility <span className="text-red-500">*</span>
                </Label>
                <MultiSelectDropdown
                  options={[
                    { value: "mds", label: "MDS Doctor" },
                    { value: "bds", label: "BDS Doctor" },
                  ]}
                  value={formik.values.eligibility}
                  onChange={(value) =>
                    formik.setFieldValue("eligibility", value)
                  }
                  placeholder="Select eligibility options"
                  error={
                    !!(formik.errors.eligibility && formik.touched.eligibility)
                  }
                />
                {formik.touched.eligibility && formik.errors.eligibility && (
                  <div className="text-red-500 text-sm">
                    {Array.isArray(formik.errors.eligibility)
                      ? formik.errors.eligibility.join(", ")
                      : formik.errors.eligibility}
                  </div>
                )}
              </div>
            </div>
          </form>
        </div>

        <div className="flex justify-end space-x-2 bg-white py-4 border-t">
          <Button variant="outline" onClick={onClose} type="button">
            Cancel
          </Button>
          <Button onClick={() => formik.handleSubmit()}>
            {isConsultation ? "Post Consultation" : "Post Job"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default CreateJobModal;
