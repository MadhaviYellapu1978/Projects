import React, { useEffect, useRef } from "react";
import { Formik, Form, Field } from "formik";
import * as Yup from "yup";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import MultiSelectDropdown from "@/components/ui/MultiSelectDropdown";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { usePostNotification, useStates } from "@/services/api";
import { useToast } from "@/components/ui/use-toast";

interface NotificationError extends Error {
  message: string;
}

/**
 * NotificationModal component for sending notifications to users
 * @param {boolean} isOpen - Controls whether the modal is open
 * @param {function} onOpenChange - Function to handle open/close state changes
 */
interface NotificationModalProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}

/**
 * Form values interface
 */
interface NotificationFormValues {
  title: string;
  message: string;
  selectedRoleId: string[];
  state: string[];
}

/**
 * Validation schema using Yup
 */
const validationSchema = Yup.object().shape({
  title: Yup.string()
    .required("Title is required")
    .min(3, "Title must be at least 3 characters long")
    .max(100, "Title cannot exceed 100 characters")
    .test("no-first-space", "Title cannot start with a space", (value) => {
      if (!value) return true; // Allow empty values
      return !value.startsWith(" ");
    }),
  message: Yup.string()
    .required("Message is required")
    .min(10, "Message must be at least 10 characters long")
    .max(500, "Message cannot exceed 500 characters")
    .test("no-first-space", "Message cannot start with a space", (value) => {
      if (!value) return true; // Allow empty values
      return !value.startsWith(" ");
    }),
  selectedRoleId: Yup.array()
    .of(Yup.string())
    .min(1, "Please select at least one recipient type")
    .required("Please select a recipient type"),
  state: Yup.array()
    .of(Yup.string())
    .min(1, "Please select at least one state")
    .required("Please select a state"),
});

/**
 * Initial form values
 */
const initialValues: NotificationFormValues = {
  title: "",
  message: "",
  selectedRoleId: [],
  state: [],
};

const NotificationModal: React.FC<NotificationModalProps> = ({
  isOpen,
  onOpenChange,
}) => {
  const { toast } = useToast();
  const { mutate: postNotification, isPending } = usePostNotification();
  const { data: statesData, isLoading: isLoadingStates } = useStates();
  const firstFieldRef = useRef<HTMLDivElement>(null);

  // Focus on the first field when modal opens
  useEffect(() => {
    if (isOpen && firstFieldRef.current) {
      // Small delay to ensure modal is fully rendered
      setTimeout(() => {
        // Find the first focusable element (MultiSelectDropdown with tabIndex)
        const firstFocusable = firstFieldRef.current?.querySelector(
          '[tabindex="0"]'
        ) as HTMLElement;
        if (firstFocusable) {
          firstFocusable.focus();
        }
      }, 300);
    }
  }, [isOpen]);
  /**
   * Handles form submission
   */
  const handleSubmit = (values: NotificationFormValues) => {
    let roleIds: number[] = [];
    const isAllSelected = values.selectedRoleId.includes("all");
    const isClinicSelected = values.selectedRoleId.includes("clinic");
    const isEventSelected = values.selectedRoleId.includes("5");
    const isAllStatesSelected = values.state.includes("all");

    if (isAllSelected) {
      // When "Select All" is chosen, use only the remaining selected roles
      roleIds = values.selectedRoleId
        .filter((id) => id !== "all" && id !== "clinic")
        .map((id) => parseInt(id));
    } else if (
      isClinicSelected &&
      !isEventSelected &&
      values.selectedRoleId.filter((id) => id !== "clinic").length === 0
    ) {
      // When ONLY clinics are selected (no other roles), send empty role_id array
      roleIds = [];
    } else if (isEventSelected) {
      // When events are selected, send [0,1,2]
      roleIds = [0, 1, 2];
    } else {
      // Handle mixed selections (roles + clinics, roles + events, etc.)
      roleIds = values.selectedRoleId
        .filter((id) => id !== "clinic" && id !== "5")
        .map((id) => parseInt(id));
    }

    // Prepare payload
    const payload: {
      title: string;
      message: string;
      role_id: number[];
      notification_id: string;
      user_id: string;
      is_clinic: boolean;
      is_event: boolean;
      is_selected_all: boolean;
      state: string[];
    } = {
      title: values.title,
      message: values.message,
      role_id: roleIds,
      notification_id: "",
      user_id: localStorage.getItem("userId") || "",
      is_clinic: isAllSelected || isClinicSelected,
      is_event: false,
      is_selected_all: isAllSelected, // True when "all" is selected in roles
      state: isAllStatesSelected
        ? statesData?.result?.map((state) => state.name) || []
        : values.state.filter((state) => state !== "all"),
    };

    postNotification(payload, {
      onSuccess: () => {
        toast({
          title: "Success",
          description: "Notification sent successfully",
          variant: "success",
        });
        onOpenChange(false);
      },
      onError: (error: NotificationError) => {
        let errorMessage = "Failed to send notification";
        if (error?.message?.includes("No device tokens found")) {
          errorMessage =
            "No devices found for the selected recipients in this state";
        } else if (error instanceof Error) {
          errorMessage = error.message;
        }

        toast({
          title: "Error",
          description: errorMessage,
          variant: "destructive",
        });
      },
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Send Notification</DialogTitle>
        </DialogHeader>

        <Formik
          initialValues={initialValues}
          validationSchema={validationSchema}
          onSubmit={handleSubmit}
          enableReinitialize={true}
        >
          {({ errors, touched, setFieldValue, values, isSubmitting }) => (
            <Form>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2" ref={firstFieldRef}>
                  <Label htmlFor="selectedRoleId">
                    Select Recipient Type{" "}
                    <span className="text-red-500">*</span>
                  </Label>
                  <MultiSelectDropdown
                    options={[
                      { value: "all", label: "Select All" },
                      { value: "1", label: "MDS Doctor" },
                      { value: "2", label: "BDS Doctor" },
                      { value: "clinic", label: "Clinics" },
                      { value: "0", label: "Unregistered Users" },
                      { value: "7", label: "Guest User" },
                    ]}
                    value={values.selectedRoleId}
                    onChange={(value) => {
                      if (
                        value.includes("all") &&
                        !values.selectedRoleId.includes("all")
                      ) {
                        // Select All was just checked - select all options
                        setFieldValue("selectedRoleId", [
                          "all",
                          "1",
                          "2",
                          "clinic",
                          "0",
                          "7",
                        ]);
                      } else if (
                        !value.includes("all") &&
                        values.selectedRoleId.includes("all")
                      ) {
                        // Select All was just unchecked - clear all selections
                        setFieldValue("selectedRoleId", []);
                      } else if (
                        value.length > 0 &&
                        value.length < 6 &&
                        value.includes("all")
                      ) {
                        // Some individual options were unchecked - remove "all" from selection
                        const filteredValue = value.filter((v) => v !== "all");
                        setFieldValue("selectedRoleId", filteredValue);
                      } else if (value.length === 5 && !value.includes("all")) {
                        // All individual options are selected - add "all" automatically
                        setFieldValue("selectedRoleId", [...value, "all"]);
                      } else {
                        setFieldValue("selectedRoleId", value);
                      }
                    }}
                    placeholder="Select recipient types"
                    error={!!(errors.selectedRoleId && touched.selectedRoleId)}
                  />
                  {touched.selectedRoleId && errors.selectedRoleId && (
                    <div className="text-red-500 text-sm mt-1">
                      {errors.selectedRoleId}
                    </div>
                  )}
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="state">
                    Select State <span className="text-red-500">*</span>
                  </Label>
                  <MultiSelectDropdown
                    options={[
                      { value: "all", label: "Select All States" },
                      ...(statesData?.result?.map((state) => ({
                        value: state.name,
                        label: state.name,
                      })) || []),
                    ]}
                    value={values.state}
                    onChange={(value) => {
                      const allStateNames =
                        statesData?.result?.map((state) => state.name) || [];
                      const totalStates = allStateNames.length + 1; // +1 for "all" option

                      if (
                        value.includes("all") &&
                        !values.state.includes("all")
                      ) {
                        // Select All was just checked - select all states
                        setFieldValue("state", ["all", ...allStateNames]);
                      } else if (
                        !value.includes("all") &&
                        values.state.includes("all")
                      ) {
                        // Select All was just unchecked - clear all selections
                        setFieldValue("state", []);
                      } else if (
                        value.length > 0 &&
                        value.length < totalStates &&
                        value.includes("all")
                      ) {
                        // Some individual states were unchecked - remove "all" from selection
                        const filteredValue = value.filter((v) => v !== "all");
                        setFieldValue("state", filteredValue);
                      } else if (
                        value.length === allStateNames.length &&
                        !value.includes("all")
                      ) {
                        // All individual states are selected - add "all" automatically
                        setFieldValue("state", [...value, "all"]);
                      } else {
                        setFieldValue("state", value);
                      }
                    }}
                    placeholder="Select states"
                    error={!!(errors.state && touched.state)}
                    disabled={isLoadingStates}
                  />
                  {touched.state && errors.state && (
                    <div className="text-red-500 text-sm mt-1">
                      {errors.state}
                    </div>
                  )}
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="country">Country</Label>
                  <Select value="India" onValueChange={() => {}}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a country" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="India">India</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="title">
                    Title <span className="text-red-500">*</span>
                  </Label>
                  <Field
                    as={Textarea}
                    id="title"
                    name="title"
                    placeholder="Enter notification title"
                    rows={2}
                    className={
                      errors.title && touched.title ? "border-red-500" : ""
                    }
                  />
                  {touched.title && errors.title && (
                    <div className="text-red-500 text-sm mt-1">
                      {errors.title}
                    </div>
                  )}
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="message">
                    Message <span className="text-red-500">*</span>
                  </Label>
                  <Field
                    as={Textarea}
                    id="message"
                    name="message"
                    placeholder="Enter notification message"
                    rows={4}
                    className={
                      errors.message && touched.message ? "border-red-500" : ""
                    }
                  />
                  {touched.message && errors.message && (
                    <div className="text-red-500 text-sm mt-1">
                      {errors.message}
                    </div>
                  )}
                </div>
              </div>

              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => onOpenChange(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={isSubmitting || isPending || isLoadingStates}
                >
                  {isPending ? "Sending..." : "Submit"}
                </Button>
              </DialogFooter>
            </Form>
          )}
        </Formik>
      </DialogContent>
    </Dialog>
  );
};

export default NotificationModal;
