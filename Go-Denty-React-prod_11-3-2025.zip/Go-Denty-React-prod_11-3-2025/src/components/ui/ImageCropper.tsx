import React, { useRef, useState, useCallback } from 'react';
import ReactCrop, { Crop, PixelCrop } from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';
import { Button } from './button';

interface ImageCropperProps {
  src: string;
  aspect?: number;
  onComplete: (croppedBlob: Blob) => void;
  onCancel: () => void;
}

export const ImageCropper: React.FC<ImageCropperProps> = ({ src, aspect, onComplete, onCancel }) => {
  const imgRef = useRef<HTMLImageElement | null>(null);
  const [crop, setCrop] = useState<Crop>({ unit: '%', x: 0, y: 0, width: 100, height: 100 });
  const [completedCrop, setCompletedCrop] = useState<PixelCrop | null>(null);
  const [cropping, setCropping] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);

  const onImageLoaded = useCallback((img: HTMLImageElement) => {
    imgRef.current = img;
    setImageLoaded(true);
    
    // Set initial crop to cover most of the image
    setCrop({ unit: '%', x: 5, y: 5, width: 90, height: 90 });
  }, []);

  const getCroppedImg = async () => {
    if (!imgRef.current || !completedCrop) return;
    
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const scaleX = imgRef.current.naturalWidth / imgRef.current.width;
    const scaleY = imgRef.current.naturalHeight / imgRef.current.height;

    // Use the actual crop dimensions (not forced to square)
    canvas.width = completedCrop.width;
    canvas.height = completedCrop.height;

    // Calculate the crop area
    const cropX = completedCrop.x * scaleX;
    const cropY = completedCrop.y * scaleY;
    const cropWidth = completedCrop.width * scaleX;
    const cropHeight = completedCrop.height * scaleY;

    // Draw the cropped image
    ctx.drawImage(
      imgRef.current,
      cropX,
      cropY,
      cropWidth,
      cropHeight,
      0,
      0,
      completedCrop.width,
      completedCrop.height
    );

    return new Promise<Blob>((resolve) => {
      canvas.toBlob((blob) => {
        if (blob) resolve(blob);
      }, 'image/jpeg', 0.95);
    });
  };

  const handleCrop = async () => {
    setCropping(true);
    try {
      const croppedBlob = await getCroppedImg();
      if (croppedBlob) {
        onComplete(croppedBlob);
      }
    } catch (error) {
      console.error('Error cropping image:', error);
    } finally {
      setCropping(false);
    }
  };

  const handleCropChange = (crop: Crop, percentCrop: Crop) => {
    setCrop(percentCrop);
  };

  const handleCropComplete = (crop: PixelCrop) => {
    setCompletedCrop(crop);
  };

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="relative">
        <ReactCrop
          crop={crop}
          onChange={handleCropChange}
          onComplete={handleCropComplete}
          aspect={aspect}
          minWidth={50}
          minHeight={50}
          keepSelection
          className="max-w-full"
        >
          <img
            ref={imgRef}
            src={src}
            alt="Crop preview"
            style={{ 
              maxHeight: 400, 
              maxWidth: '100%',
              display: 'block'
            }}
            onLoad={(e) => onImageLoaded(e.currentTarget)}
            crossOrigin="anonymous"
          />
        </ReactCrop>
      </div>
      
      <div className="flex flex-col items-center gap-2">
        <p className="text-sm text-muted-foreground text-center">
          Drag to adjust the crop area. You can resize and move the selection to crop your image.
        </p>
        <div className="flex gap-2">
          <Button variant="outline" onClick={onCancel} disabled={cropping}>
            Cancel
          </Button>
          <Button 
            onClick={handleCrop} 
            disabled={!completedCrop || cropping || !imageLoaded}
          >
            {cropping ? 'Cropping...' : 'Crop & Upload'}
          </Button>
        </div>
      </div>
    </div>
  );
}; 