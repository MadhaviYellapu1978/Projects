import React from "react";
import { Heart } from "lucide-react";

interface StatCardProps {
  title: string;
  value: number;
  icon: React.ReactNode;
  isLoading?: boolean;
}

const StatCard = ({ title, value, icon, isLoading = false }: StatCardProps) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <div className="flex justify-between items-center">
        <div className="space-y-2">
          {isLoading ? (
            <>
              <div className="h-4 w-24 bg-gray-200 rounded animate-pulse"></div>
              <div className="h-8 w-16 bg-gray-200 rounded animate-pulse"></div>
            </>
          ) : (
            <>
              <p className="text-sm text-gray-500">{title}</p>
              <p className="text-2xl font-semibold">{value}</p>
            </>
          )}
        </div>
        {isLoading ? (
          <div className="h-8 w-8 bg-gray-200 rounded animate-pulse"></div>
        ) : (
          icon
        )}
      </div>
    </div>
  );
};

export default StatCard;
