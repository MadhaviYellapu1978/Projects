// /components/ui/Modal.tsx

import React from 'react';
import ReactDOM from 'react-dom';

interface ModalProps {
  onClose: () => void;
  title?: string;
  children?: React.ReactNode;
}

// A simple Modal using a React Portal:
const Modal: React.FC<ModalProps> = ({ onClose, title, children }) => {
  // Make sure to return null on server-side if using Next.js,
  // but on the client, render a portal into document.body.
  if (typeof window === 'undefined') {
    return null;
  }

  return ReactDOM.createPortal(
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center 
                 bg-black bg-opacity-50" 
      onClick={onClose}
    >
      {/* Click outside the white box to close modal */}
      <div 
        className="relative bg-white p-6 rounded shadow-md w-1/2" 
        onClick={(e) => e.stopPropagation()} 
      >
        <button 
          type="button" 
          className="absolute top-3 right-3 text-gray-600" 
          onClick={onClose}
        >
          X
        </button>
        {title && <h2 className="font-bold text-lg mb-4">{title}</h2>}
        {children}
      </div>
    </div>,
    document.body
  );
};

export default Modal;
