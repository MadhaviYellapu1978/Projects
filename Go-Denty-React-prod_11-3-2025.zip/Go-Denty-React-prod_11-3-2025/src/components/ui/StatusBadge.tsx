import React from "react";
import { cn } from "@/lib/utils";

interface StatusBadgeProps {
  status:
    | "Approved"
    | "Inactive"
    | "Pending"
    | "Active"
    | "Rejected"
    | "Reject";
  className?: string;
}

/**
 * StatusBadge component for consistent status display across the application
 * @param status - The status to display
 * @param className - Additional CSS classes
 * @returns A properly aligned status badge
 */
const StatusBadge: React.FC<StatusBadgeProps> = ({ status, className }) => {
  const normalizedStatus = status === "Reject" ? "Rejected" : status;

  return (
    <div className="flex items-center justify-center">
      <span
        className={cn(
          "inline-flex items-center justify-center px-2.5 py-0.5 rounded-full text-xs font-medium whitespace-nowrap",
          {
            "bg-green-100 text-green-800":
              status === "Approved" || status === "Active",
            "bg-yellow-100 text-yellow-800": status === "Pending",
            "bg-red-100 text-red-800":
              status === "Rejected" ||
              status === "Reject" ||
              status === "Inactive",
          },
          className
        )}
      >
        {normalizedStatus}
      </span>
    </div>
  );
};

export default StatusBadge;
