
import React from 'react';

interface EventCardProps {
  image: string;
  title: string;
  date: string;
  type: string;
}

const EventCard: React.FC<EventCardProps> = ({ image, title, date, type }) => {
  return (
    <div className="event-card">
      <div className="relative h-48 w-full">
        <img src={image} alt={title} className="h-full w-full object-cover" />
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/70 to-transparent">
          <div className="flex flex-col gap-2">
            <span className="event-label w-fit">{type} {type === 'Dental Event' ? title : ''}</span>
            <span className="text-white text-sm">{date}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EventCard;
