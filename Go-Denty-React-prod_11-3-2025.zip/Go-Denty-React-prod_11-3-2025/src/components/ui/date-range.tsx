"use client";

import * as React from "react";
import { addDays, format } from "date-fns";
import { Calendar as CalendarIcon } from "lucide-react";
import { DateRange } from "react-day-picker";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

interface DatePickerWithRangeProps
  extends React.HTMLAttributes<HTMLDivElement> {
  onDateChange?: (range: { from: Date | null; to: Date | null }) => void;
  value?: { from: Date | null; to: Date | null };
}

export function DatePickerWithRange({
  className,
  onDateChange,
  value,
}: DatePickerWithRangeProps) {
  const [date, setDate] = React.useState<DateRange | undefined>(undefined);

  // Reset internal state when external value changes
  React.useEffect(() => {
    if (value && value.from === null && value.to === null) {
      setDate(undefined);
    } else if (value && value.from && value.to) {
      setDate({
        from: value.from,
        to: value.to,
      });
    }
  }, [value]);

  const handleDateChange = (newDate: DateRange | undefined) => {
    setDate(newDate);
    onDateChange?.({
      from: newDate?.from || null,
      to: newDate?.to || null,
    });
  };

  return (
    <div className={cn("grid gap-2", className)}>
      <Popover>
        <PopoverTrigger asChild>
          <Button
            id="date"
            variant={"outline"}
            className={cn(
              "w-[180px] md:w-[240px] justify-start text-left font-normal text-sm",
              !date && "text-muted-foreground"
            )}
          >
            <CalendarIcon className="mr-2 h-4 w-4" />
            {date?.from ? (
              date.to ? (
                <>
                  {(() => {
                    const fromDate = date.from;
                    const toDate = date.to;
                    const formatDate = (d: Date) => {
                      const day = d.getDate().toString().padStart(2, "0");
                      const month = (d.getMonth() + 1)
                        .toString()
                        .padStart(2, "0");
                      const year = d.getFullYear();
                      return `${day}-${month}-${year}`;
                    };
                    return `${formatDate(fromDate)} - ${formatDate(toDate)}`;
                  })()}
                </>
              ) : (
                (() => {
                  const d = date.from;
                  const day = d.getDate().toString().padStart(2, "0");
                  const month = (d.getMonth() + 1).toString().padStart(2, "0");
                  const year = d.getFullYear();
                  return `${day}-${month}-${year}`;
                })()
              )
            ) : (
              <span>Select Date Range </span>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <Calendar
            initialFocus
            mode="range"
            defaultMonth={date?.from}
            selected={date}
            onSelect={handleDateChange}
            numberOfMonths={1}
            className="rounded-md border"
          />
        </PopoverContent>
      </Popover>
    </div>
  );
}
