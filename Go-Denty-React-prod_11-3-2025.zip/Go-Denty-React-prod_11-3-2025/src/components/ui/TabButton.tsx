import React from 'react';

interface TabButtonProps {
  label: string;
  active?: boolean;
  onClick?: () => void;
}

const TabButton: React.FC<TabButtonProps> = ({ label, active = false, onClick }) => {
  return (
    <button
      className={`py-2 px-4 text-sm font-medium rounded-md transition-colors border ${
        active 
          ? 'bg-primary text-white border-primary'  
          : 'text-gray-600 border-gray-300 hover:bg-gray-100 hover:border-gray-400' 
      }`}
      onClick={onClick}
    >
      {label}
    </button>
  );
};

export default TabButton;
