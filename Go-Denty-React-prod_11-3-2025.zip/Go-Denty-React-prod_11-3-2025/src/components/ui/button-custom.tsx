
import React from 'react';
import { Plus } from 'lucide-react';

type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'view';

interface ButtonProps {
  children: React.ReactNode;
  variant?: ButtonVariant;
  icon?: React.ReactNode;
  onClick?: () => void;
  type?: 'button' | 'submit' | 'reset';
}

const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  icon,
  onClick,
  type = 'button',
}) => {
  const getButtonClass = () => {
    switch (variant) {
      case 'primary':
        return 'primary-button';
      case 'secondary':
        return 'secondary-button';
      case 'outline':
        return 'outline-button';
      case 'view':
        return 'view-button';
      default:
        return 'primary-button';
    }
  };

  return (
    <button type={type} className={getButtonClass()} onClick={onClick}>
      {icon}
      {children}
    </button>
  );
};

export const CreateButton: React.FC<Omit<ButtonProps, 'icon'>> = (props) => {
  return <Button {...props} icon={<Plus size={18} />} />;
};

export default Button;
