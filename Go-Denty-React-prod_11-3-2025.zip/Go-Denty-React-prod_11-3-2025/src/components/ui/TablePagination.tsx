import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ChevronFirst,
  ChevronLast,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";

/**
 * Props for the TablePagination component
 */
export interface TablePaginationProps {
  /** Current page number (1-indexed) */
  currentPage: number;
  /** Number of items per page */
  pageSize: number;
  /** Total number of items */
  totalItems: number;
  /** Callback when page changes */
  onPageChange: (page: number) => void;
  /** Callback when page size changes */
  onPageSizeChange: (pageSize: number) => void;
  /** Available page size options */
  pageSizeOptions?: number[];
  /** Show page size selector */
  showPageSizeSelector?: boolean;
  /** Show item range display */
  showItemRange?: boolean;
  /** Show page navigation controls */
  showPageNavigation?: boolean;
  /** Additional CSS classes */
  className?: string;
}

/**
 * A comprehensive pagination component with rows per page selector,
 * item range display, and navigation controls
 */
export const TablePagination: React.FC<TablePaginationProps> = ({
  currentPage,
  pageSize,
  totalItems,
  onPageChange,
  onPageSizeChange,
  pageSizeOptions = [5, 10, 20, 50, 100],
  showPageSizeSelector = true,
  showItemRange = true,
  showPageNavigation = true,
  className = "",
}) => {
  const totalPages = Math.ceil(totalItems / pageSize);
  const startItem = totalItems > 0 ? (currentPage - 1) * pageSize + 1 : 0;
  const endItem = Math.min(currentPage * pageSize, totalItems);

  const handlePageInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (value > 0 && value <= totalPages) {
      onPageChange(value);
    }
  };

  return (
    <div
      className={`flex flex-col sm:flex-row items-center justify-between px-2 py-4 space-y-3 sm:space-y-0 ${className}`}
    >
      {/* Left side: Rows per page and item range */}
      <div className="flex items-center space-x-4 text-sm text-muted-foreground">
        {showPageSizeSelector && (
          <div className="flex items-center space-x-2">
            <span>Rows per page:</span>
            <Select
              value={pageSize.toString()}
              onValueChange={(value) => onPageSizeChange(Number(value))}
            >
              <SelectTrigger className="h-8 w-[70px]">
                <SelectValue placeholder={pageSize} />
              </SelectTrigger>
              <SelectContent side="top">
                {pageSizeOptions.map((size) => (
                  <SelectItem key={size} value={size.toString()}>
                    {size}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {showItemRange && (
          <div>
            {totalItems > 0
              ? `${startItem}-${endItem} of ${totalItems}`
              : "No items"}
          </div>
        )}
      </div>

      {/* Right side: Page navigation */}
      {showPageNavigation && totalPages > 0 && (
        <div className="flex items-center space-x-2">
          {/* First page button */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => onPageChange(1)}
            disabled={currentPage === 1}
            aria-label="Go to first page"
          >
            <ChevronFirst className="h-4 w-4" />
          </Button>

          {/* Previous page button */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => onPageChange(currentPage - 1)}
            disabled={currentPage === 1}
            aria-label="Go to previous page"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>

          {/* Page input and total pages */}
          <div className="flex items-center gap-1">
            <div className="text-sm font-medium">Page</div>
            <div className="flex items-center gap-1">
              <Input
                type="number"
                min={1}
                max={totalPages}
                value={currentPage}
                onChange={handlePageInputChange}
                className="h-8 w-[50px] text-center"
              />
              <div className="text-sm text-muted-foreground">
                of {totalPages}
              </div>
            </div>
          </div>

          {/* Next page button */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => onPageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
            aria-label="Go to next page"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>

          {/* Last page button */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => onPageChange(totalPages)}
            disabled={currentPage === totalPages}
            aria-label="Go to last page"
          >
            <ChevronLast className="h-4 w-4" />
          </Button>
        </div>
      )}
    </div>
  );
};

export default TablePagination;
