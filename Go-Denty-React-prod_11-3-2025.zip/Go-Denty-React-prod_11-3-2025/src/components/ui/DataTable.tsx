import React, { useState } from "react";
import TablePagination from "./TablePagination";

interface Column<T> {
  header: string;
  accessor: keyof T | string;
  cell?: (value: T[keyof T], row: T, rowIndex?: number) => React.ReactNode;
}

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  pageSize: number;
  totalItems: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (pageSize: number) => void;
}

interface DataTableProps<T extends { [key: string]: unknown }> {
  columns: Column<T>[];
  data: T[];
  onRowClick?: (row: T) => void;
  isLoading?: boolean;
  pagination?: PaginationProps;
}

const DataTable = <T extends { [key: string]: unknown }>({
  columns,
  data,
  onRowClick,
  isLoading = false,
  pagination,
}: DataTableProps<T>) => {
  const [hoveredRow, setHoveredRow] = useState<number | null>(null);

  if (isLoading) {
    return (
      <div className="w-full h-64 flex items-center justify-center border rounded-lg">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  return (
    <div className="w-full overflow-x-auto border rounded-lg">
      <table className="w-full">
        <thead>
          <tr>
            {columns?.map((column, index) => (
              <th key={index} className="table-header text-left">
                {column.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data?.map((row, rowIndex) => (
            <tr
              key={rowIndex}
              className={`table-row ${
                hoveredRow === rowIndex ? "hover:bg-gray-50" : ""
              } ${onRowClick ? "cursor-pointer" : ""}`}
              onMouseEnter={() => setHoveredRow(rowIndex)}
              onMouseLeave={() => setHoveredRow(null)}
              onClick={() => onRowClick?.(row)}
            >
              {columns?.map((column, colIndex) => (
                <td key={colIndex} className="table-cell">
                  {column.cell
                    ? column.cell(
                        row[column.accessor as keyof T],
                        row,
                        rowIndex
                      )
                    : (row[column.accessor as keyof T] as React.ReactNode)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>

      {pagination && (
        <TablePagination
          currentPage={pagination.currentPage}
          pageSize={pagination.pageSize}
          totalItems={pagination.totalItems}
          onPageChange={pagination.onPageChange}
          onPageSizeChange={pagination.onPageSizeChange}
        />
      )}
    </div>
  );
};

export default DataTable;
