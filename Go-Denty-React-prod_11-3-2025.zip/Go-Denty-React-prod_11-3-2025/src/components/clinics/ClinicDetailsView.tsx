/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState } from "react";
import {
  ArrowLeft,
  FileText,
  Phone,
  Mail,
  Globe,
  MapPin,
  Download,
  ExternalLink,
  User2,
  Calendar,
  Users,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useUpdateClinic } from "@/services/api";
import { useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

interface ClinicDetailsViewProps {
  clinic: any;
  onBack: () => void;
}

const ClinicDetailsView: React.FC<ClinicDetailsViewProps> = ({
  clinic: initialClinic,
  onBack,
}) => {
  const queryClient = useQueryClient();
  const updateClinicMutation = useUpdateClinic();
  const navigate = useNavigate();

  // Add local state to manage clinic data
  const [clinic, setClinic] = useState(initialClinic);

  if (!clinic) return null;

  const getStatusStyles = (status: string) => {
    switch (status) {
      case "Pending":
        return "bg-orange-100 text-orange-700";
      case "Approved":
        return "bg-green-100 text-green-700";
      case "Reject":
        return "bg-red-100 text-red-700";
      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  const handleStatusUpdate = async (newStatus: string) => {
    try {
      // Update local state immediately
      setClinic((prev) => ({
        ...prev,
        is_Verified: newStatus,
      }));

      // Optimistically update the cache
      queryClient.setQueryData(["clinics"], (old: any) => {
        if (!old) return old;
        return {
          ...old,
          data: {
            ...old.data,
            result: old.data.result.map((item: any) =>
              item.Clinic_id === clinic.Clinic_id
                ? { ...item, is_Verified: newStatus }
                : item
            ),
          },
        };
      });

      await updateClinicMutation.mutateAsync({
        clinicId: clinic.Clinic_id,
        data: {
          ...clinic,
          is_Verified: newStatus,
        },
      });

      // Show success toaster
      toast.success("Clinic status updated successfully", {
        position: "top-right",
        style: {
          background: "#10B981",
          color: "white",
        },
      });

      // Invalidate and refetch all clinic queries
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["clinics"] }),
        queryClient.refetchQueries({
          queryKey: ["clinics", 1, 10, undefined, "Pending"],
          exact: false,
        }),
        queryClient.refetchQueries({
          queryKey: ["clinics", 1, 10, undefined, "Approved"],
          exact: false,
        }),
        queryClient.refetchQueries({
          queryKey: ["clinics", 1, 10, undefined, "Reject"],
          exact: false,
        }),
      ]);

      // Short delay before navigation to ensure UI updates are visible
      setTimeout(() => {
        navigate("/clinics");
      }, 500);
    } catch (error) {
      // Revert local state on error
      setClinic(initialClinic);

      console.error("Error updating clinic status:", error);
      toast.error("Failed to update clinic status", {
        position: "top-right",
      });
    }
  };

  return (
    <div className="space-y-6 p-6 bg-white rounded-lg shadow-sm">
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          className="border rounded-full"
          onClick={onBack}
        >
          <ArrowLeft size={18} />
        </Button>
        <h2 className="text-xl font-semibold">{clinic.Clinic_name}</h2>
        <span
          className={`ml-auto px-3 py-1 rounded-full text-sm ${getStatusStyles(
            clinic.is_Verified
          )}`}
        >
          {clinic.is_Verified}
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="flex items-start gap-3">
          <Phone className="text-muted-foreground mt-0.5" />
          <div>
            <p className="text-sm text-muted-foreground">Phone Number</p>
            <p className="font-medium">{clinic.Clinic_Contact_Number}</p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <Mail className="text-muted-foreground mt-0.5" />
          <div>
            <p className="text-sm text-muted-foreground">Email</p>
            <p className="font-medium">{clinic.Clinic_email}</p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <Globe className="text-muted-foreground mt-0.5" />
          <div>
            <p className="text-sm text-muted-foreground">Website</p>
            <a
              href={clinic.Clinic_Website}
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium text-blue-600 hover:underline flex items-center"
            >
              {clinic.Clinic_Website.split("/")[2]}
              <ExternalLink className="h-4 w-4 ml-1" />
            </a>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <User2 className="text-muted-foreground mt-0.5" />
          <div>
            <p className="text-sm text-muted-foreground">Owner Name</p>
            <p className="font-medium">{clinic.Clinic_Owner}</p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <MapPin className="text-muted-foreground mt-0.5" />
          <div>
            <p className="text-sm text-muted-foreground">Address</p>
            <p className="font-medium">{clinic.clinic_Address}</p>
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium mt-6 mb-4 text-primary">
          Operational Details
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="flex items-start gap-3">
            <Users className="text-muted-foreground mt-0.5" />
            <div>
              <p className="text-sm text-muted-foreground">
                No. of Dental Chairs
              </p>
              <p className="font-medium">{clinic.No_of_Dental_Chairs}</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <Calendar className="text-muted-foreground mt-0.5" />
            <div>
              <p className="text-sm text-muted-foreground">
                Avg. Patients Per Month
              </p>
              <p className="font-medium">{clinic.Avg_per_month}</p>
            </div>
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium mt-6 mb-3 text-primary">
          Documentation
        </h3>
        <div className="flex items-start gap-3">
          <FileText className="text-muted-foreground mt-0.5" />
          <div className="w-full">
            <p className="text-sm text-muted-foreground">Clinic Certificate</p>
            <div className="flex justify-between mt-1">
              <a
                href={clinic.Clinic_certificate}
                target="_blank"
                rel="noopener noreferrer"
                className="font-medium text-blue-600 hover:underline flex items-center"
              >
                View Certificate
                <ExternalLink className="h-3 w-3 ml-1" />
              </a>
              <a
                href={clinic.Clinic_certificate}
                download="clinic_certificate"
                className="flex items-center gap-1 text-primary hover:text-primary/80 transition-colors bg-primary/10 hover:bg-primary/20 px-3 py-1.5 rounded-md text-sm font-medium"
              >
                <Download className="h-4 w-4" />
                Download
              </a>
            </div>
            <p className="text-xs text-muted-foreground mt-2 truncate">
              {clinic.Clinic_certificate?.split("/").pop()?.substring(0, 25)}...
            </p>
          </div>
        </div>
      </div>
      {/* 
      <div>
        <h3 className="text-lg font-medium mt-6 mb-3 text-primary">System Information</h3>
        <div className="flex items-start gap-3">
          <ChevronRight className="text-muted-foreground mt-0.5" />
          <div>
            <p className="text-sm text-muted-foreground">Clinic ID</p>
            <p className="font-medium text-xs">{clinic.Clinic_id}</p>
          </div>
        </div>
      </div> */}

      <div className="text-right pt-4 flex justify-end gap-3">
        {clinic.is_Verified === "Pending" && (
          <Button
            variant="outline"
            className="bg-green-100 text-green-700 hover:bg-green-200 hover:text-green-800"
            onClick={() => handleStatusUpdate("Approved")}
          >
            Approve
          </Button>
        )}
        {clinic.is_Verified === "Pending" && (
          <Button
            variant="outline"
            className="bg-red-100 text-red-700 hover:bg-red-200 hover:text-red-800"
            onClick={() => handleStatusUpdate("Reject")}
          >
            Reject
          </Button>
        )}
        <Button variant="outline" onClick={onBack}>
          Close
        </Button>
      </div>
    </div>
  );
};

export default ClinicDetailsView;
