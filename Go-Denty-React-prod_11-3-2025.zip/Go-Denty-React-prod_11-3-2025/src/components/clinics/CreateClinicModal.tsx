/* eslint-disable @typescript-eslint/no-explicit-any */

import React, { useEffect, useRef, useState, useCallback, memo } from "react";
import { Formik, Form, Field } from "formik";
import * as Yup from "yup";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Label } from "@/components/ui/label";
import {
  useGetUserByPhone,
  useRolesMobile,
  useUploadImage,
  useOnboardClinic,
  useStates,
} from "@/services/api";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import GooglePlacesAutocomplete from "react-google-places-autocomplete";
import { geocodeByPlaceId, getLatLng } from "react-google-places-autocomplete";
import { useDropzone } from "react-dropzone";
import { Upload, X } from "lucide-react";

// Add Google Places types
declare global {
  interface Window {
    google: any;
  }
}

interface CreateClinicModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

interface ClinicFormData {
  user_id: string;
  owner_name: string;
  doctor_type: string;
  Clinic_name: string;
  clinic_About: string;
  clinic_Address: string;
  google_map_location: string;
  Clinic_Contact_Number: string;
  clinic_contact_number: string;
  clinic_state: string;
  Clinic_Website: string;
  Clinic_lat: number;
  Clinic_long: number;
  Clinic_email: string;
  No_of_Dental_Chairs: number | "";
  Avg_per_month: number | "";
  is_Verified: string;
}

// Pre-compile validation schema - moved outside component to prevent recreation
const validationSchema = Yup.object().shape({
  Clinic_name: Yup.string()
    .transform((value) => (typeof value === "string" ? value.trim() : value))
    .required("Clinic name is mandatory")
    .min(3, "Clinic name must be at least 3 characters long")
    .max(100, "Clinic name cannot exceed 100 characters"),
  clinic_About: Yup.string()
    .required("About clinic is mandatory")
    .min(10, "About clinic must be at least 10 characters long")
    .max(500, "About clinic cannot exceed 500 characters")
    .test(
      "no-first-space",
      "About clinic cannot start with a space",
      (value) => {
        if (!value) return true; // Allow empty values
        return !value.startsWith(" ");
      }
    ),
  Clinic_email: Yup.string()
    .email("Valid email address is required")
    .required("Email address is mandatory"),
  Clinic_Contact_Number: Yup.string()
    .required("Owner number is mandatory")
    .matches(/^\d{10}$/, "Phone number must be exactly 10 digits"),
  clinic_contact_number: Yup.string()
    .required("Clinic contact number is mandatory")
    .matches(/^\d{10}$/, "Phone number must be exactly 10 digits"),
  clinic_state: Yup.string()
    .required("Clinic state is mandatory")
    .min(2, "State name must be at least 2 characters long")
    .max(50, "State name cannot exceed 50 characters"),
  clinic_Address: Yup.string()
    .required("Clinic address is mandatory")
    .min(5, "Address is too short")
    .max(500, "Address is too long")
    .test(
      "no-first-space",
      "Clinic address cannot start with a space",
      (value) => {
        if (!value) return true; // Allow empty values
        return !value.startsWith(" ");
      }
    ),
  google_map_location: Yup.string().required(
    "Google Map location is mandatory"
  ),
  Clinic_lat: Yup.number()
    .required("Location coordinates are mandatory")
    .not([0], "Valid location must be selected"),
  Clinic_long: Yup.number()
    .required("Location coordinates are mandatory")
    .not([0], "Valid location must be selected"),
  No_of_Dental_Chairs: Yup.number()
    .transform((value) => (isNaN(value) ? undefined : value))
    .required("Number of dental chairs is mandatory")
    .integer("Whole number is required"),
  Avg_per_month: Yup.number()
    .transform((value) => (isNaN(value) ? undefined : value))
    .required("Average patients per month is mandatory")
    .min(1, "Value must be at least 1 patient per month")
    .max(10000, "Number seems too high, verification needed")
    .integer("Whole number is required"),
  doctor_type: Yup.string().required("Doctor type is mandatory"),
  Clinic_Website: Yup.string()
    .nullable()
    .transform((value) => (value === "" ? null : value))
    .test("isUrl", "Valid website URL is required", function (value) {
      if (!value) return true; // Optional field

      // Check if the value is a valid URL
      try {
        // Add http:// if missing to make URL validation work
        const urlToTest = value.startsWith("http") ? value : `http://${value}`;
        new URL(urlToTest);
        return true;
      } catch (error) {
        return false;
      }
    }),
});

// Initial values defined as a constant outside component
const initialFormValues: ClinicFormData = {
  user_id: "",
  owner_name: "",
  doctor_type: "",
  Clinic_name: "",
  clinic_About: "",
  clinic_Address: "",
  google_map_location: "",
  Clinic_Contact_Number: "",
  clinic_contact_number: "",
  clinic_state: "",
  Clinic_Website: "",
  Clinic_lat: 0,
  Clinic_long: 0,
  Clinic_email: "",
  No_of_Dental_Chairs: "",
  Avg_per_month: "",
  is_Verified: "Approved",
};

// Define the FileDropzoneProps interface before using it with memo
interface FileDropzoneProps {
  setFieldValue: (file: File | null) => void;
  file: File | null;
  fieldName: string;
  accept?: Record<string, string[]>;
  placeholder?: string;
  height?: string;
}

// Memoized FileDropzone component to prevent unnecessary rerenders
const FileDropzone = memo<FileDropzoneProps>(
  ({
    setFieldValue,
    file,
    fieldName,
    accept = {
      "application/pdf": [".pdf"],
      "application/msword": [".doc"],
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
        [".docx"],
    },
    placeholder = "Drag & Drop your file here",
    height = "h-32",
  }) => {
    const onDrop = useCallback(
      (acceptedFiles: File[]) => {
        if (acceptedFiles.length > 0) {
          const selectedFile = acceptedFiles[0];
          setFieldValue(selectedFile);
        }
      },
      [setFieldValue]
    );

    const handleCancel = useCallback(
      (e: React.MouseEvent) => {
        e.stopPropagation();
        setFieldValue(null);
      },
      [setFieldValue]
    );

    const { getRootProps, getInputProps, isDragActive } = useDropzone({
      onDrop,
      accept,
      maxFiles: 1,
      multiple: false,
    });

    return (
      <div
        {...getRootProps()}
        className={`border-2 border-dashed border-gray-300 rounded-lg p-4 flex flex-col items-center justify-center bg-white cursor-pointer hover:border-primary/50 transition-colors relative ${height}`}
      >
        <input {...getInputProps()} />
        {file ? (
          <>
            <div className="absolute top-2 right-2">
              <button
                onClick={handleCancel}
                className="p-1 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
              >
                <X size={16} />
              </button>
            </div>
            <div className="w-full h-full flex items-center justify-center">
              <div className="flex flex-col items-center">
                <div className="bg-purple-100 p-3 rounded-full mb-3">
                  <Upload className="text-purple-500" size={20} />
                </div>
                <p className="text-gray-700 text-sm font-medium mb-1">
                  {file.name}
                </p>
                <p className="text-gray-500 text-xs">
                  {(file.size / 1024).toFixed(2)} KB
                </p>
              </div>
            </div>
          </>
        ) : (
          <>
            <div className="bg-purple-100 p-3 rounded-full mb-3">
              <Upload className="text-purple-500" size={20} />
            </div>
            {isDragActive ? (
              <p className="text-gray-700 text-sm font-medium">Drop here...</p>
            ) : (
              <>
                <p className="text-gray-700 text-sm font-medium mb-1 text-center">
                  {placeholder}
                </p>
                <p className="text-gray-500 text-xs text-center">
                  Supports PDF, DOC, DOCX
                </p>
              </>
            )}
          </>
        )}
      </div>
    );
  }
);

FileDropzone.displayName = "FileDropzone";

const CreateClinicModal: React.FC<CreateClinicModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const { data: rolesData } = useRolesMobile();
  const { data: statesData } = useStates();
  const [phoneNumber, setPhoneNumber] = useState("");
  const { data: userData, isLoading } = useGetUserByPhone(phoneNumber);
  const { toast } = useToast();
  const formikRef = useRef<any>(null);
  const [locationSelection, setLocationSelection] = useState<any>(null);
  const uploadImageMutation = useUploadImage();
  const onboardClinicMutation = useOnboardClinic();
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Function to reset the form - optimized with useCallback to maintain reference
  const resetForm = useCallback(() => {
    if (formikRef.current) {
      formikRef.current.resetForm();
    }
    setPhoneNumber("");
    setLocationSelection(null);
  }, []);

  // Memoized handle modal close function
  const handleModalClose = useCallback(() => {
    resetForm();
    onClose();
  }, [onClose, resetForm]);

  // Debounced phone number change handler
  const handlePhoneNumberChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const value = e.target.value;
      // Allow only digits and limit to 10 characters
      if (/^\d*$/.test(value) && value.length <= 10) {
        setPhoneNumber(value);

        // Clear form values if phone number is incomplete
        if (value.length < 10 && formikRef.current) {
          formikRef.current.setFieldValue("user_id", "");
          formikRef.current.setFieldValue("owner_name", "");
          formikRef.current.setFieldValue("doctor_type", "");
        }
      }
    },
    []
  );

  // Update form values when userData changes
  useEffect(() => {
    if (!userData && phoneNumber.length === 10 && !isLoading) {
      toast({
        variant: "destructive",
        title: "User Not Found",
        description: "No registered user found with this contact number",
      });
      if (formikRef.current) {
        formikRef.current.setFieldValue("user_id", "");
        formikRef.current.setFieldValue("owner_name", "");
        formikRef.current.setFieldValue("doctor_type", "");
      }
      return;
    }

    if (!userData || !formikRef.current) return;

    formikRef.current.setFieldValue("user_id", userData.user_id);
    formikRef.current.setFieldValue("owner_name", userData.user_name);
    formikRef.current.setFieldValue("doctor_type", userData.doctor_type);
    formikRef.current.setFieldValue("Clinic_Contact_Number", phoneNumber);
  }, [userData, phoneNumber, isLoading, toast]);

  // Handle location selection with useCallback to prevent unnecessary recreations
  const handleLocationChange = useCallback((selection: any) => {
    setLocationSelection(selection);
  }, []);

  // Effect for geocoding - optimized with early return
  useEffect(() => {
    if (!locationSelection || !formikRef.current) return;

    // Get the place details
    geocodeByPlaceId(locationSelection.value.place_id)
      .then((results) => {
        const address = results[0].formatted_address;
        formikRef.current.setFieldValue("google_map_location", address);

        // Get latitude and longitude
        return getLatLng(results[0]);
      })
      .then((latLng) => {
        formikRef.current.setFieldValue("Clinic_lat", latLng.lat);
        formikRef.current.setFieldValue("Clinic_long", latLng.lng);
      })
      .catch((error) => {
        console.error("Error fetching location details:", error);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to get location details",
        });
      });
  }, [locationSelection, toast]);

  // Memoized form submission handler
  const handleSubmit = useCallback(
    async (values: ClinicFormData) => {
      // Validation before API calls
      if (
        !values.google_map_location ||
        !values.Clinic_lat ||
        !values.Clinic_long
      ) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Valid location must be selected",
        });
        return;
      }

      try {
        setIsSubmitting(true);

        // Create the clinic with the data - using more efficient object creation
        const { clinic_contact_number, clinic_state, ...restValues } = values;
        const clinicData = {
          ...restValues,
          Clinic_Contact_Number: clinic_contact_number, // Map clinic_contact_number to Clinic_Contact_Number
          Clinic_state: clinic_state, // Map clinic_state to Clinic_state with capital C
          Clinic_Website: values.Clinic_Website || "",
          No_of_Dental_Chairs:
            values.No_of_Dental_Chairs === ""
              ? 0
              : parseInt(String(values.No_of_Dental_Chairs)),
          Avg_per_month:
            values.Avg_per_month === ""
              ? 0
              : parseInt(String(values.Avg_per_month)),
          is_Verified: "Approved",
        };

        // Onboard the clinic with the data
        await onboardClinicMutation.mutateAsync(clinicData);

        toast({
          title: "Success",
          description: "Clinic created successfully!",
        });

        // Call onSuccess callback if provided
        if (onSuccess) {
          onSuccess();
        }

        // Reset form and close modal
        resetForm();
        onClose();
      } catch (error) {
        console.error("Error creating clinic:", error);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to create clinic. Please try again.",
        });
      } finally {
        setIsSubmitting(false);
      }
    },
    [onboardClinicMutation, toast, onSuccess, resetForm, onClose]
  );

  // Simple Google Places styles without conditional styling based on validation state
  const googlePlacesStyles = {
    control: (provided: any) => ({
      ...provided,
      boxShadow: "none",
      minHeight: "40px",
      height: "40px",
    }),
    input: (provided: any) => ({
      ...provided,
      margin: "0px",
    }),
    option: (provided: any) => ({
      ...provided,
      color: "#000",
    }),
    singleValue: (provided: any) => ({
      ...provided,
      color: "#000",
    }),
    menuPortal: (base: any) => ({ ...base, zIndex: 9999 }),
    menu: (base: any) => ({ ...base, zIndex: 9999 }),
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleModalClose}>
      <DialogContent className=" max-w-[50vw] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold flex justify-between items-center">
            <span>Create Clinic</span>
          </DialogTitle>
        </DialogHeader>

        <Formik
          innerRef={formikRef}
          initialValues={initialFormValues}
          validationSchema={validationSchema}
          onSubmit={handleSubmit}
          enableReinitialize={false} // Prevents unnecessary reinitialization
        >
          {({ errors, touched, handleChange, values, setFieldValue }) => (
            <Form className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>
                    Owner Number <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    value={phoneNumber}
                    onChange={handlePhoneNumberChange}
                    placeholder="Enter 10-digit phone number"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    maxLength={10}
                    name="Clinic_Contact_Number"
                  />
                  {errors.Clinic_Contact_Number &&
                    touched.Clinic_Contact_Number && (
                      <div className="text-red-500 text-sm">
                        {errors.Clinic_Contact_Number}
                      </div>
                    )}
                </div>
                <div>
                  <Label>Owner Name</Label>
                  <Input
                    value={values.owner_name}
                    disabled
                    placeholder="Owner name will appear here"
                  />
                </div>
                <div>
                  <Label>
                    Clinic Contact Number{" "}
                    <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    value={values.clinic_contact_number}
                    onChange={handleChange}
                    placeholder="Enter 10-digit clinic contact number"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    maxLength={10}
                    name="clinic_contact_number"
                  />
                  {errors.clinic_contact_number &&
                    touched.clinic_contact_number && (
                      <div className="text-red-500 text-sm">
                        {errors.clinic_contact_number}
                      </div>
                    )}
                </div>
                <div>
                  <Label>
                    Doctor Type <span className="text-red-500">*</span>
                  </Label>
                  <Select
                    value={values.doctor_type}
                    onValueChange={(value) =>
                      setFieldValue("doctor_type", value)
                    }
                    disabled
                  >
                    <SelectTrigger className="[&>svg]:hidden [&>span]:text-gray-400">
                      <SelectValue placeholder="Doctor type will appear here" />
                    </SelectTrigger>
                    <SelectContent>
                      {rolesData?.map((role) => (
                        <SelectItem key={role.role_id} value={role.role_name}>
                          {role.role_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.doctor_type && touched.doctor_type && (
                    <div className="text-red-500 text-sm">
                      {errors.doctor_type}
                    </div>
                  )}
                </div>
                <div>
                  <Label>
                    Clinic State <span className="text-red-500">*</span>
                  </Label>
                  <Select
                    value={values.clinic_state}
                    onValueChange={(value) =>
                      setFieldValue("clinic_state", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select State" />
                    </SelectTrigger>
                    <SelectContent>
                      {statesData?.result?.map((state) => (
                        <SelectItem key={state.code} value={state.name}>
                          {state.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.clinic_state && touched.clinic_state && (
                    <div className="text-red-500 text-sm">
                      {errors.clinic_state}
                    </div>
                  )}
                </div>
                <div>
                  <Label>
                    Clinic Name <span className="text-red-500">*</span>
                  </Label>
                  <Field
                    as={Input}
                    name="Clinic_name"
                    onChange={handleChange}
                    placeholder="Enter clinic name"
                  />
                  {errors.Clinic_name && touched.Clinic_name && (
                    <div className="text-red-500 text-sm">
                      {errors.Clinic_name}
                    </div>
                  )}
                </div>

                <div>
                  <Label>
                    Clinic Email <span className="text-red-500">*</span>
                  </Label>
                  <Field
                    as={Input}
                    type="email"
                    name="Clinic_email"
                    onChange={handleChange}
                    placeholder="Enter email address"
                  />
                  {errors.Clinic_email && touched.Clinic_email && (
                    <div className="text-red-500 text-sm">
                      {errors.Clinic_email}
                    </div>
                  )}
                </div>
                <div>
                  <Label>
                    Clinic Website{" "}
                    <span className="text-xs text-gray-500">(optional)</span>
                  </Label>
                  <Field
                    as={Input}
                    name="Clinic_Website"
                    onChange={handleChange}
                    placeholder="www.example.com"
                  />
                  {errors.Clinic_Website && touched.Clinic_Website && (
                    <div className="text-red-500 text-sm">
                      {errors.Clinic_Website}
                    </div>
                  )}
                </div>
                <div>
                  <Label>
                    Geo Location Address <span className="text-red-500">*</span>
                  </Label>
                  <div className="z-50 border rounded-md border-input">
                    <GooglePlacesAutocomplete
                      apiKey={"AIzaSyCS0ObrXEKeubcJ1HsQERMfYaghfcNfFoM"}
                      selectProps={{
                        value: locationSelection,
                        onChange: handleLocationChange,
                        className: "z-50",
                        components: {
                          DropdownIndicator: () => null,
                        },
                        styles: googlePlacesStyles,
                      }}
                    />
                  </div>
                  {errors.google_map_location &&
                    touched.google_map_location && (
                      <div className="text-red-500 text-sm">
                        {errors.google_map_location}
                      </div>
                    )}
                  {(errors.Clinic_lat || errors.Clinic_long) &&
                    (touched.Clinic_lat || touched.Clinic_long) && (
                      <div className="text-red-500 text-sm">
                        Valid location must be selected from the dropdown
                      </div>
                    )}
                </div>
                <div>
                  <Label>
                    Number of Dental Chairs{" "}
                    <span className="text-red-500">*</span>
                  </Label>
                  <Field
                    as={Input}
                    type="number"
                    name="No_of_Dental_Chairs"
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                      const value = e.target.value;
                      if (value === "" || /^\d+$/.test(value)) {
                        handleChange(e);
                      }
                    }}
                    placeholder="Enter number of chairs"
                    min="1"
                  />
                  {errors.No_of_Dental_Chairs &&
                    touched.No_of_Dental_Chairs && (
                      <div className="text-red-500 text-sm">
                        {errors.No_of_Dental_Chairs}
                      </div>
                    )}
                </div>
                <div>
                  <Label>
                    Average No.of Patients Per Month{" "}
                    <span className="text-red-500">*</span>
                  </Label>
                  <Field
                    as={Input}
                    type="number"
                    name="Avg_per_month"
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                      const value = e.target.value;
                      if (value === "" || /^\d+$/.test(value)) {
                        handleChange(e);
                      }
                    }}
                    placeholder="Enter average patients per month"
                    min="1"
                    max="10000"
                  />
                  {errors.Avg_per_month && touched.Avg_per_month && (
                    <div className="text-red-500 text-sm">
                      {errors.Avg_per_month}
                    </div>
                  )}
                </div>
                <div className="col-span-2">
                  <Label>
                    Clinic Address <span className="text-red-500">*</span>
                  </Label>
                  <Field
                    as={Textarea}
                    name="clinic_Address"
                    onChange={handleChange}
                    placeholder="Enter detailed clinic address"
                  />
                  {errors.clinic_Address && touched.clinic_Address && (
                    <div className="text-red-500 text-sm">
                      {errors.clinic_Address}
                    </div>
                  )}
                </div>
                <div className="col-span-2">
                  <Label>
                    About Clinic <span className="text-red-500">*</span>
                  </Label>
                  <Field
                    as={Textarea}
                    name="clinic_About"
                    onChange={handleChange}
                    placeholder="Enter a brief description about the clinic"
                    rows={3}
                  />
                  {errors.clinic_About && touched.clinic_About && (
                    <div className="text-red-500 text-sm">
                      {errors.clinic_About}
                    </div>
                  )}
                </div>
              </div>

              <div className="flex justify-end space-x-2">
                <Button
                  variant="outline"
                  type="button"
                  onClick={handleModalClose}
                  disabled={isSubmitting}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="bg-gradient-to-r from-[#002846] to-[#244e77] text-white hover:from-[#244e77] hover:to-[#002846]"
                >
                  {isSubmitting ? "Creating..." : "Create Clinic"}
                </Button>
              </div>
            </Form>
          )}
        </Formik>
      </DialogContent>
    </Dialog>
  );
};

export default memo(CreateClinicModal);
