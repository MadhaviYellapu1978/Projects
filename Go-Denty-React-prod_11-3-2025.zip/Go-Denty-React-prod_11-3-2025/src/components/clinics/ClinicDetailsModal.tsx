/* eslint-disable @typescript-eslint/no-explicit-any */

import React from "react";
import { X, FileText, Phone, Mail, Globe, MapPin } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

interface ClinicDetailsProps {
  isOpen: boolean;
  onClose: () => void;
  clinic: any;
  onApprove: () => void;
  onReject: () => void;
  showRejectedInfo?: boolean;
  rejectionReason?: string;
}

const ClinicDetailsModal: React.FC<ClinicDetailsProps> = ({
  isOpen,
  onClose,
  clinic,
  onApprove,
  onReject,
  showRejectedInfo = false,
  rejectionReason = "",
}) => {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold flex justify-between items-center">
            <span>Details</span>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <div className="flex gap-4 items-center">
            <div className="h-20 w-20 bg-blue-900 rounded-full flex items-center justify-center text-white text-2xl font-bold">
              {clinic?.clinicName?.charAt(0).toUpperCase()}
            </div>
            <div>
              <h3 className="text-xl font-medium">
                {clinic?.clinicName || "Clinic Name"}
              </h3>
              {showRejectedInfo && (
                <span className="text-red-500 text-sm">Rejected</span>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex items-center gap-3">
              <div className="bg-blue-900 rounded-full p-2">
                <FileText className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="text-gray-500 text-sm">Owner Name</p>
                <p className="font-medium">
                  {clinic?.ownerName || "Owner Name"}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="bg-blue-900 rounded-full p-2">
                <Phone className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="text-gray-500 text-sm">Phone Number</p>
                <p className="font-medium">
                  {clinic?.phone || "+91 9123456789"}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="bg-blue-900 rounded-full p-2">
                <Mail className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="text-gray-500 text-sm">Email Address</p>
                <p className="font-medium">
                  {clinic?.email || "clinic@gmail.com"}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="bg-blue-900 rounded-full p-2">
                <Globe className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="text-gray-500 text-sm">Website</p>
                <p className="font-medium">
                  {clinic?.website || "Website name"}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="bg-blue-900 rounded-full p-2">
                <MapPin className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="text-gray-500 text-sm">Address</p>
                <p className="font-medium">{clinic?.address || "Madhapur"}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="bg-blue-900 rounded-full p-2">
                <MapPin className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="text-gray-500 text-sm">Google Map Location</p>
                <p className="font-medium">
                  {clinic?.googleMapLocation || "Madhapur"}
                </p>
              </div>
            </div>
          </div>

          {showRejectedInfo && rejectionReason && (
            <div className="space-y-2">
              <h4 className="font-medium text-lg">Reason</h4>
              <p className="text-gray-600">{rejectionReason}</p>
            </div>
          )}

          <div className="border border-gray-200 rounded-md p-3 flex items-center gap-2">
            <FileText className="h-5 w-5 text-gray-600" />
            <span>Licence.pdf</span>
          </div>

          {!showRejectedInfo && (
            <div className="flex gap-4 justify-center pt-4">
              <Button
                className="bg-orange-400 hover:bg-orange-500 text-white px-10"
                onClick={onApprove}
              >
                Approve
              </Button>
              <Button
                className="bg-red-500 hover:bg-red-600 text-white px-10"
                onClick={onReject}
              >
                Reject
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ClinicDetailsModal;
