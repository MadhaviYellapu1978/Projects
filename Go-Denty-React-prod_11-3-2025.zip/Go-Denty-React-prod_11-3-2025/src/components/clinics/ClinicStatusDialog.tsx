import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../ui/dialog";
import { Button } from "../ui/button";
import { Label } from "../ui/label";
import StatusBadge from "../ui/StatusBadge";


interface ClinicStatusDialogProps {
  isOpen: boolean;
  onClose: () => void;
  clinic: {
    is_Verified: "Pending" | "Approved" | "Reject";
    Clinic_name: string;
    Clinic_Contact_Number: string;
    clinic_Address: string;
    Clinic_Website?: string;
  } | null;
  onApprove?: () => void;
  onReject?: () => void;
}

export const ClinicStatusDialog = ({
  isOpen,
  onClose,
  clinic,
  onApprove,
  onReject
}: ClinicStatusDialogProps) => {
  if (!clinic) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>
            {clinic.is_Verified === "Pending" && "Pending Approval"}
            {clinic.is_Verified === "Approved" && "Approved Clinic"}
            {clinic.is_Verified === "Reject" && "Rejected Clinic"}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Clinic Name</Label>
              <div>{clinic.Clinic_name}</div>
            </div>
            <div>
              <Label>Contact Number</Label>
              <div>{clinic.Clinic_Contact_Number}</div>
            </div>
            <div>
              <Label>Address</Label>
              <div>{clinic.clinic_Address}</div>
            </div>
            <div>
              <Label>Website</Label>
              <div>{clinic.Clinic_Website || "N/A"}</div>
            </div>
            <div>
              <Label>Status</Label>
              <div>
                <StatusBadge status={clinic.is_Verified === "Reject" ? "Rejected" : clinic.is_Verified} />
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-2">
            {clinic.is_Verified === "Pending" ? (
              <>
                <Button variant="outline" onClick={onClose}>
                  Cancel
                </Button>
                {onReject && (
                  <Button variant="destructive" onClick={onReject}>
                    Reject
                  </Button>
                )}
                {onApprove && (
                  <Button onClick={onApprove}>
                    Approve
                  </Button>
                )}
              </>
            ) : (
              <Button variant="outline" onClick={onClose}>
                Close
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}; 