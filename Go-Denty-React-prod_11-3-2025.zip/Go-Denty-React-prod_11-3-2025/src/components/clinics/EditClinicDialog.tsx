import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../ui/dialog";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { useState, useEffect, useCallback, memo } from "react";
import {
  useUpdateClinic,
  useGetUserByPhone,
  UpdateClinicRequest,
} from "../../services/api";
import { useToast } from "../ui/use-toast";
import { Upload, X } from "lucide-react";
import { useDropzone } from "react-dropzone";
import { Clinic as ClinicType } from "../../pages/ClinicsPage";

interface EditClinicDialogProps {
  isOpen: boolean;
  onClose: () => void;
  clinic: ClinicType | null;
}

export const EditClinicDialog = ({
  isOpen,
  onClose,
  clinic,
}: EditClinicDialogProps) => {
  const { toast } = useToast();
  const updateMutation = useUpdateClinic();
  const { data: userData } = useGetUserByPhone(
    clinic?.Clinic_Contact_Number || ""
  );

  const [formData, setFormData] = useState<
    Omit<UpdateClinicRequest, "Clinic_lat" | "Clinic_long">
  >({
    user_id: "",
    Clinic_name: "",
    clinic_Address: "",
    Clinic_Contact_Number: "",
    Clinic_Website: "",
    Clinic_email: "",
    No_of_Dental_Chairs: 0,
    Avg_per_month: 0,
    is_Verified: "",
    clinic_About: "",
  });
  const [initialFormData, setInitialFormData] =
    useState<UpdateClinicRequest | null>(null);

  useEffect(() => {
    if (clinic) {
      const newFormData: UpdateClinicRequest = {
        user_id: clinic.user_id,
        Clinic_name: clinic.Clinic_name,
        clinic_Address: clinic.clinic_Address,
        Clinic_Contact_Number: clinic.Clinic_Contact_Number,
        Clinic_Website: clinic.Clinic_Website || "",
        Clinic_email: clinic.Clinic_email,
        No_of_Dental_Chairs: clinic.No_of_Dental_Chairs,
        Avg_per_month: clinic.Avg_per_month,
        is_Verified: clinic.is_Verified,
        clinic_About: clinic.clinic_About || "",
      };
      setFormData(newFormData);
      setInitialFormData(newFormData);
    }
  }, [clinic]);

  useEffect(() => {
    if (userData) {
      setFormData((prev) => ({
        ...prev,
        user_id: userData.user_id || prev.user_id,
      }));
    }
  }, [userData]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!clinic) return;

    try {
      const updatedFormData = {
        ...formData,
        is_Verified: "Approved",
      } as UpdateClinicRequest;

      await updateMutation.mutateAsync({
        clinicId: clinic.Clinic_id,
        data: updatedFormData,
      });

      toast({
        title: "Success",
        description: "Clinic updated successfully",
      });
      onClose();
    } catch (error: unknown) {
      const errorMessage =
        error instanceof Error ? error.message : "Failed to update clinic";
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    }
  };

  // Utility to check if form is dirty
  const isDirty = () => {
    if (!initialFormData) return false;
    return (Object.keys(formData) as (keyof UpdateClinicRequest)[]).some(
      (key) => formData[key] !== initialFormData[key]
    );
  };

  if (!clinic) return null;
  interface FileDropzoneProps {
    setFieldValue: (file: File | null, fileUrl?: string | null) => void;
    file: File | null;
    fileUrl?: string | null;
    fieldName: string;
    accept?: Record<string, string[]>;
    placeholder?: string;
    height?: string;
  }

  const FileDropzone: React.FC<FileDropzoneProps> = ({
    setFieldValue,
    file,
    fileUrl,
    fieldName,
    accept = {
      "application/pdf": [".pdf"],
      "application/msword": [".doc"],
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
        [".docx"],
      "image/png": [".png"],
      "image/jpeg": [".jpeg", ".jpg"],
    },
    placeholder = "Drag & Drop your file here",
    height = "h-32",
  }) => {
    const [previewUrl, setPreviewUrl] = useState<string | null>(null);

    // Handle file drop
    const onDrop = useCallback(
      (acceptedFiles: File[]) => {
        if (acceptedFiles.length > 0) {
          const selectedFile = acceptedFiles[0];

          // Convert image to a preview URL
          if (selectedFile.type.startsWith("image/")) {
            const reader = new FileReader();
            reader.onload = () => setPreviewUrl(reader.result as string);
            reader.readAsDataURL(selectedFile);
          }

          setFieldValue(selectedFile, null);
        }
      },
      [setFieldValue]
    );

    // Convert Base64 to an image preview
    useEffect(() => {
      if (fileUrl && fileUrl.startsWith("data:image")) {
        setPreviewUrl(fileUrl);
      } else {
        setPreviewUrl(null);
      }
    }, [fileUrl]);

    const handleCancel = useCallback(
      (e: React.MouseEvent) => {
        e.stopPropagation();
        setFieldValue(null, null);
        setPreviewUrl(null);
      },
      [setFieldValue]
    );

    const { getRootProps, getInputProps, isDragActive } = useDropzone({
      onDrop,
      accept,
      maxFiles: 1,
      multiple: false,
    });

    return (
      <div
        {...getRootProps()}
        className={`border-2 border-dashed border-gray-300 rounded-lg p-4 flex flex-col items-center justify-center bg-white cursor-pointer hover:border-primary/50 transition-colors relative ${height}`}
      >
        <input {...getInputProps()} />
        {file || fileUrl ? (
          <>
            <div className="absolute top-2 right-2">
              <button
                onClick={handleCancel}
                className="p-1 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
              >
                <X size={16} />
              </button>
            </div>
            <div className="w-full h-full flex items-center justify-center">
              {previewUrl ? (
                <img
                  src={previewUrl}
                  alt="Uploaded"
                  className="max-h-28 rounded-lg shadow"
                />
              ) : (
                <div className="flex flex-col items-center">
                  <div className="bg-purple-100 p-3 rounded-full mb-3">
                    <Upload className="text-purple-500" size={20} />
                  </div>
                  <p className="text-gray-700 text-sm font-medium mb-1">
                    {file
                      ? file.name.length > 20
                        ? `${file.name.slice(0, 20)}...`
                        : file.name
                      : fileUrl
                      ? (fileUrl.split("/").pop() || "").length > 20
                        ? `${fileUrl.split("/").pop()?.slice(0, 20) || ""}...`
                        : fileUrl.split("/").pop()
                      : ""}
                  </p>

                  {file ? (
                    <p className="text-gray-500 text-xs">
                      {(file.size / 1024).toFixed(2)} KB
                    </p>
                  ) : (
                    <a
                      href={fileUrl!}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-500 text-xs underline"
                    >
                      View File
                    </a>
                  )}
                </div>
              )}
            </div>
          </>
        ) : (
          <>
            <div className="bg-purple-100 p-3 rounded-full mb-3">
              <Upload className="text-purple-500" size={20} />
            </div>
            {isDragActive ? (
              <p className="text-gray-700 text-sm font-medium">Drop here...</p>
            ) : (
              <>
                <p className="text-gray-700 text-sm font-medium mb-1 text-center">
                  {placeholder}
                </p>
                <p className="text-gray-500 text-xs text-center">
                  Supports PDF, DOC, DOCX, PNG, JPG
                </p>
              </>
            )}
          </>
        )}
      </div>
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edit Clinic</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Clinic Name</Label>
              <Input
                value={formData.Clinic_name}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    Clinic_name: e.target.value,
                  }))
                }
                required
              />
            </div>
            <div>
              <Label>Contact Number</Label>
              <Input
                value={formData.Clinic_Contact_Number}
                onChange={(e) => {
                  // Only allow digits and limit to 10 characters
                  const value = e.target.value.replace(/\D/g, "").slice(0, 10);
                  setFormData((prev) => ({
                    ...prev,
                    Clinic_Contact_Number: value,
                  }));
                }}
                pattern="[0-9]{10}"
                title="Please enter exactly 10 digits"
                required
              />
              {formData.Clinic_Contact_Number.length > 0 &&
                formData.Clinic_Contact_Number.length !== 10 && (
                  <p className="text-red-500 text-xs mt-1">
                    Phone number must be exactly 10 digits
                  </p>
                )}
            </div>
            <div>
              <Label>Owner Name</Label>
              <Input
                value={userData?.user_name || ""}
                disabled
                className="bg-gray-50"
              />
            </div>
            <div>
              <Label>Doctor Type</Label>
              <Input
                value={userData?.doctor_type || ""}
                disabled
                className="bg-gray-50"
              />
            </div>
            <div className="col-span-2">
              <Label>Address</Label>
              <Input
                value={formData.clinic_Address}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    clinic_Address: e.target.value,
                  }))
                }
                required
              />
            </div>
            <div className="col-span-2">
              <Label>Clinic Description</Label>
              <textarea
                value={formData.clinic_About}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    clinic_About: e.target.value,
                  }))
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                rows={4}
                placeholder="Enter clinic description..."
              />
            </div>
            <div>
              <Label>Website</Label>
              <Input
                value={formData.Clinic_Website}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    Clinic_Website: e.target.value,
                  }))
                }
              />
            </div>
            <div>
              <Label>Email</Label>
              <Input
                type="email"
                value={formData.Clinic_email}
                disabled
                className="bg-gray-50"
              />
            </div>
            <div>
              <Label>Number of Dental Chairs</Label>
              <Input
                type="number"
                value={formData.No_of_Dental_Chairs}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    No_of_Dental_Chairs: parseInt(e.target.value),
                  }))
                }
                required
              />
            </div>
            <div>
              <Label>Average Patients per Month</Label>
              <Input
                type="number"
                value={formData.Avg_per_month}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    Avg_per_month: parseInt(e.target.value),
                  }))
                }
                required
              />
            </div>
          </div>

          <div className="flex justify-end space-x-2">
            <Button variant="outline" type="button" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={!isDirty()}>
              Save Changes
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
