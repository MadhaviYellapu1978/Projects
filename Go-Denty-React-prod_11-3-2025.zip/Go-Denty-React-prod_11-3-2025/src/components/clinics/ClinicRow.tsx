/* eslint-disable @typescript-eslint/no-explicit-any */

import React from "react";

interface ClinicRowProps {
  clinic: any;
  onView: () => void;
}

const ClinicRow: React.FC<ClinicRowProps> = ({ clinic, onView }) => {
  return (
    <tr className="border-t border-gray-100">
      <td className="table-cell">{clinic.id || "#214314"}</td>
      <td className="table-cell">{clinic.clinicName}</td>
      <td className="table-cell">{clinic.phone}</td>
      <td className="table-cell">{clinic.email}</td>
      <td className="table-cell">{clinic.website}</td>
      <td className="table-cell">{clinic.address}</td>
      <td className="table-cell">
        <button className="view-button" onClick={onView}>
          View
        </button>
      </td>
    </tr>
  );
};

export default ClinicRow;
