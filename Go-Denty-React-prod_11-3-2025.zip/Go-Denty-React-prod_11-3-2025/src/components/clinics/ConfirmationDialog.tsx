
import React from 'react';
import { Check } from 'lucide-react';
import { 
  AlertDialog,
  AlertDialogContent,
  AlertDialogTitle,
  AlertDialogDescription 
} from "@/components/ui/alert-dialog";

interface ConfirmationDialogProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  message: string;
  variant: 'success' | 'error';
}

const ConfirmationDialog: React.FC<ConfirmationDialogProps> = ({
  isOpen,
  onClose,
  title,
  message,
  variant = 'success'
}) => {
  return (
    <AlertDialog open={isOpen} onOpenChange={onClose}>
      <AlertDialogContent className="max-w-md text-center py-10">
        <div className="flex flex-col items-center gap-4">
          {variant === 'success' ? (
            <div className="h-24 w-24 rounded-full bg-green-100 flex items-center justify-center">
              <div className="h-16 w-16 rounded-full border-4 border-green-500 flex items-center justify-center">
                <Check className="h-8 w-8 text-green-500" />
              </div>
            </div>
          ) : (
            <AlertDialogTitle className="text-2xl font-bold text-red-500">{title}</AlertDialogTitle>
          )}
          
          {variant === 'success' && (
            <AlertDialogTitle className="text-2xl font-bold text-green-500">{title}</AlertDialogTitle>
          )}
          
          <AlertDialogDescription className="text-gray-600 text-lg">
            {message}
          </AlertDialogDescription>
        </div>
      </AlertDialogContent>
    </AlertDialog>
  );
};

export default ConfirmationDialog;
