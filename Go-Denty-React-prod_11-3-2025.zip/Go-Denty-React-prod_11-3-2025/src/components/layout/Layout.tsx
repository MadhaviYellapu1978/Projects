import React from "react";
import Sidebar from "./Sidebar";
import Navbar from "./Navbar";
import { Navigate, Outlet } from "react-router-dom";

const Layout = () => {
  const isLoggedIn = localStorage.getItem("userId") !== null;
  if (!isLoggedIn) {
    return <Navigate to="/login" />;
  }
  return (
    <div className="flex h-screen overflow-hidden bg-gray-50">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar />
        <main className="flex-1 overflow-x-hidden p-6">
          <div className="animate-fade-in">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
};

export default Layout;
