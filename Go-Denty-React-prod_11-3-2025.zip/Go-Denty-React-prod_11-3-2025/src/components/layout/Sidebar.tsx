import React, { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import {
  Home,
  User,
  Building2,
  FileVideo,
  Stethoscope,
  Book,
  Users,
  LogOut,
  Menu,
  X,
  Bell,
  MessageSquare,
  Briefcase,
  UserPlus,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import Navbar from "./Navbar";
import NotificationModal from "../modals/NotificationModal";
import { UserRole, hasAccess } from "@/utils/roleAccess";

interface SidebarItem {
  name: string;
  icon: React.ReactNode;
  path: string;
}

interface SidebarContentProps {
  location: ReturnType<typeof useLocation>;
  sidebarItems: SidebarItem[];
  setShowLogoutModal: (show: boolean) => void;
  setIsNotificationModalOpen: (open: boolean) => void;
  isNotificationModalOpen: boolean;
  role: string | null;
}

const Sidebar = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showLogoutModal, setShowLogoutModal] = useState(false);
  const [isNotificationModalOpen, setIsNotificationModalOpen] = useState(false);
  const role = localStorage.getItem("roleName");

  const allItems = [
    {
      name: "Dashboard",
      icon: <Home size={20} />,
      path: "/",
      access: "dashboard",
    },
    {
      name: "Doctors",
      icon: <User size={20} />,
      path: "/doctors",
      access: "doctors",
    },
    {
      name: "Clinics",
      icon: <Building2 size={20} />,
      path: "/clinics",
      access: "clinics",
    },
    {
      name: "Godenty Posts",
      icon: <FileVideo size={20} />,
      path: "/posts",
      access: "posts",
    },
    {
      name: "Courses",
      icon: <Book size={20} />,
      path: "/courses",
      access: "courses",
    },
    {
      name: "CDE Zone",
      icon: <Users size={20} />,
      path: "/community",
      access: "community",
    },
    {
      name: "Job Postings",
      icon: <Briefcase size={20} />,
      path: "/jobs",
      access: "jobs",
    },
    {
      name: "Enquiries",
      icon: <MessageSquare size={20} />,
      path: "/enquiries",
      access: "enquiries",
    },
    // {
    //   name: "Notifications",
    //   icon: <Bell size={20} />,
    //   path: "/notifications",
    //   access: "notifications",
    // },
    {
      name: "Admin Onboard",
      icon: <UserPlus size={20} />,
      path: "/onboard",
      access: "onboard",
    },
  ];

  const sidebarItems = allItems.filter((item) =>
    hasAccess((role as UserRole) || UserRole.SUPER_ADMIN, item.access)
  );

  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);

  const confirmLogout = () => {
    localStorage.removeItem("userId");
    localStorage.removeItem("roleName");
    navigate("/login");
  };

  return (
    <>
      <button
        className="lg:hidden fixed top-4 left-4 z-50 bg-white p-2 rounded-md shadow-md"
        onClick={toggleMobileMenu}
      >
        {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      <div
        className={`hidden lg:flex flex-col w-64 bg-white border-r border-gray-100 h-screen sticky top-0 transition-all duration-300 ease-in-out`}
      >
        <SidebarContent
          location={location}
          sidebarItems={sidebarItems}
          setShowLogoutModal={setShowLogoutModal}
          setIsNotificationModalOpen={setIsNotificationModalOpen}
          isNotificationModalOpen={isNotificationModalOpen}
          role={role}
        />
      </div>

      {isMobileMenuOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-40"
          onClick={toggleMobileMenu}
        >
          <div
            className="w-64 bg-white h-screen overflow-y-auto animate-slide-in"
            onClick={(e) => e.stopPropagation()}
          >
            <SidebarContent
              location={location}
              sidebarItems={sidebarItems}
              setShowLogoutModal={setShowLogoutModal}
              setIsNotificationModalOpen={setIsNotificationModalOpen}
              isNotificationModalOpen={isNotificationModalOpen}
              role={role}
            />
          </div>
        </div>
      )}
      <Dialog open={showLogoutModal} onOpenChange={setShowLogoutModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Logout</DialogTitle>
          </DialogHeader>
          <p>Are you sure you want to logout?</p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowLogoutModal(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={confirmLogout}>
              Yes, Logout
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <NotificationModal
        isOpen={isNotificationModalOpen}
        onOpenChange={setIsNotificationModalOpen}
      />
    </>
  );
};

const SidebarContent: React.FC<SidebarContentProps> = ({
  location,
  sidebarItems,
  setShowLogoutModal,
  setIsNotificationModalOpen,
  isNotificationModalOpen,
  role,
}) => (
  <>
    <div className="p-6">
      <Link to="/" className="flex items-center">
        <img
          src="/lovable-uploads/logo.png"
          alt="Godenty Logo"
          className="h-10"
        />
      </Link>
    </div>
    <nav className="flex-1 px-4 mt-6">
      <ul className="space-y-1">
        {sidebarItems.map((item) => (
          <li key={item.name}>
            <Link
              to={item.path}
              className={`sidebar-item ${
                location.pathname === item.path && !isNotificationModalOpen
                  ? "active"
                  : ""
              }`}
            >
              {item.icon}
              <span>{item.name}</span>
            </Link>
          </li>
        ))}
      </ul>
    </nav>
    <div className="p-4 mt-auto space-y-2 border-t border-gray-100">
      {hasAccess(
        (role as UserRole) || UserRole.SUPER_ADMIN,
        "notifications"
      ) && (
        <button
          className={`sidebar-item w-full ${
            isNotificationModalOpen ? "active" : ""
          }`}
          onClick={() => setIsNotificationModalOpen(true)}
        >
          <Bell size={20} />
          <span>Notifications</span>
        </button>
      )}
      <button
        className="sidebar-item text-destructive"
        onClick={() => setShowLogoutModal(true)}
      >
        <LogOut size={20} />
        <span>Logout</span>
      </button>
    </div>
  </>
);

export default Sidebar;
