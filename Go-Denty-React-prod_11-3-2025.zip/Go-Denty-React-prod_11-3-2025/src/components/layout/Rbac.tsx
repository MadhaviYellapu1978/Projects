import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { hasAccess, UserRole } from "@/utils/roleAccess";

interface RbacProps {
  children: React.ReactNode;
  requiredAccess: string;
}

// Define all available sidebar items with their access requirements and paths
const sidebarItems = [
  { path: "/", access: "dashboard" },
  { path: "/doctors", access: "doctors" },
  { path: "/clinics", access: "clinics" },
  { path: "/posts", access: "posts" },
  { path: "/courses", access: "courses" },
  { path: "/community", access: "community" },
  { path: "/jobs", access: "jobs" },
  { path: "/enquiries", access: "enquiries" },
  { path: "/onboard", access: "onboard" },
];

/**
 * Role-Based Access Control component that protects routes based on user role
 * @param children - The child components to render if access is granted
 * @param requiredAccess - The required access level for the route
 * @returns JSX.Element
 */
const Rbac: React.FC<RbacProps> = ({ children, requiredAccess }) => {
  const role = localStorage.getItem("roleName");
  const navigate = useNavigate();

  useEffect(() => {
    // If user doesn't have access to current route, redirect to first accessible route
    if (!role || !hasAccess(role as UserRole, requiredAccess)) {
      // Find the first sidebar item the user has access to
      const firstAccessibleItem = sidebarItems.find((item) =>
        hasAccess(role as UserRole, item.access)
      );

      if (firstAccessibleItem) {
        navigate(firstAccessibleItem.path, { replace: true });
      } else {
        // If no accessible items found, redirect to login
        localStorage.removeItem("userId");
        localStorage.removeItem("roleName");
        navigate("/login", { replace: true });
      }
    }
  }, [role, requiredAccess, navigate]);

  if (!role || !hasAccess(role as UserRole, requiredAccess)) {
    // Show loading or nothing while redirecting
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-500">Redirecting...</div>
      </div>
    );
  }

  return <>{children}</>;
};

export default Rbac;
