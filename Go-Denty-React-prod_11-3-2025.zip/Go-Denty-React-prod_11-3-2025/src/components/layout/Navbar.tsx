import React, { useState, useEffect, useMemo } from "react";
import { Link } from "react-router-dom";
import { useGetProfileByUserId } from "../../services/api";

/**
 * Navbar component that displays user profile information from backend API
 * @returns JSX.Element
 */
const Navbar = () => {
  // Get user ID from localStorage (only thing we need from localStorage)
  const userId =
    localStorage.getItem("userId") || localStorage.getItem("user_id") || "";

  // Fetch profile data using the API
  const { data: profileData, isLoading, error } = useGetProfileByUserId(userId);

  // Transform API data for display
  const userInfo = useMemo(() => {
    if (!profileData) {
      // Fallback to localStorage while API is loading
      return {
        firstName: localStorage.getItem("firstName") || "",
        lastName: localStorage.getItem("lastName") || "",
        roleName: localStorage.getItem("roleName") || "",
        profilePic: localStorage.getItem("profilePic") || "",
      };
    }

    const nameParts = profileData.user_name?.split(" ") || [];
    const firstName = nameParts[0] || "";
    const lastName = nameParts.slice(1).join(" ") || "";

    return {
      firstName,
      lastName,
      roleName: localStorage.getItem("roleName") || "User", // Role name not in API response
      profilePic: profileData.profile_pic || "",
    };
  }, [profileData]);

  console.log("Navbar - API profileData:", profileData);
  console.log("Navbar - transformed userInfo:", userInfo);

  return (
    <div className="bg-white border-b border-gray-100 py-3 px-6 flex items-center justify-between sticky top-0 z-10">
      <div></div>
      <div className="flex items-center gap-4">
        <Link to="/profile" className="flex items-center gap-3">
          <div className="flex flex-col items-end">
            <p className="font-medium text-gray-800">
              {userInfo.firstName + " " + userInfo.lastName}
            </p>
            <p className="text-sm text-gray-500">{userInfo.roleName}</p>
          </div>
          <div className="h-10 w-10 rounded-full overflow-hidden bg-gray-200 flex items-center justify-center">
            {userInfo.profilePic ? (
              <img
                src={userInfo.profilePic}
                alt="User Avatar"
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="h-full w-full bg-gray-300 flex items-center justify-center text-gray-600 text-sm font-medium">
                {userInfo.firstName.charAt(0).toUpperCase()}
              </div>
            )}
          </div>
        </Link>
      </div>
    </div>
  );
};

export default Navbar;
