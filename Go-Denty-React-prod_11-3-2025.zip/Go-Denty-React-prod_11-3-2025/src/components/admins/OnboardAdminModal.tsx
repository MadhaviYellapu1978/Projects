import React, { useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "../ui/dialog";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import { useRolesWeb } from "../../services/api";
import { useToast } from "../ui/use-toast";
import { useFormik } from "formik";
import * as Yup from "yup";

interface OnboardAdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: any) => void;
  admin?: {
    user_id: string;
    first_name: string;
    last_name: string;
    email: string;
    phoneNumber: string;
    role_id: number;
  } | null;
}

const OnboardAdminModal: React.FC<OnboardAdminModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  admin,
}) => {
  const { toast } = useToast();
  const { data: rolesData } = useRolesWeb();

  // Define validation schema with Yup
  const validationSchema = Yup.object({
    first_name: Yup.string()
      .required("First name is required")
      .test(
        "no-initial-space",
        "Initial space is not allowed",
        (value) => !value || value.trim() === value
      )
      .test(
        "no-multiple-spaces",
        "Multiple consecutive spaces are not allowed",
        (value) => !value || !value.includes("  ")
      ),
    last_name: Yup.string()
      .required("Last name is required")
      .test(
        "no-initial-space",
        "Initial space is not allowed",
        (value) => !value || value.trim() === value
      )
      .test(
        "no-multiple-spaces",
        "Multiple consecutive spaces are not allowed",
        (value) => !value || !value.includes("  ")
      ),
    email: Yup.string()
      .email("Invalid email format")
      .required("Email is required")
      .test(
        "no-spaces",
        "Spaces are not allowed in email",
        (value) => !value || !value.includes(" ")
      ),
    phoneNumber: Yup.string()
      .required("Phone number is required")
      .matches(/^\d{10}$/, "Phone number must be exactly 10 digits"),
    role_Id: Yup.number()
      .required("Role selection is required")
      .min(1, "Please select a role"),
  });

  // Initialize Formik
  const formik = useFormik({
    initialValues: {
      first_name: "",
      last_name: "",
      email: "",
      phoneNumber: "",
      role_Id: 0,
    },
    validationSchema,
    onSubmit: async (values) => {
      try {
        await onSubmit(values);
        onClose();
      } catch (error) {
        toast({
          variant: "destructive",
          title: "Submission Failed",
          description: "An error occurred while submitting the form.",
        });
      }
    },
  });

  // Reset form when modal opens/closes or admin data changes
  useEffect(() => {
    if (isOpen) {
      if (admin) {
        formik.setValues({
          first_name: admin.first_name,
          last_name: admin.last_name,
          email: admin.email,
          phoneNumber: admin.phoneNumber,
          role_Id: admin.role_id,
        });
      } else {
        formik.resetForm();
      }
    }
  }, [admin, isOpen]);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{admin ? "Edit Admin" : "Onboard New Admin"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={formik.handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="first_name">First Name*</Label>
            <Input
              id="first_name"
              name="first_name"
              value={formik.values.first_name}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className={
                formik.touched.first_name && formik.errors.first_name
                  ? "border-red-500"
                  : ""
              }
            />
            {formik.touched.first_name && formik.errors.first_name && (
              <div className="text-red-500 text-sm mt-1">
                {formik.errors.first_name}
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="last_name">Last Name*</Label>
            <Input
              id="last_name"
              name="last_name"
              value={formik.values.last_name}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className={
                formik.touched.last_name && formik.errors.last_name
                  ? "border-red-500"
                  : ""
              }
            />
            {formik.touched.last_name && formik.errors.last_name && (
              <div className="text-red-500 text-sm mt-1">
                {formik.errors.last_name}
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email*</Label>
            <Input
              id="email"
              name="email"
              type="email"
              value={formik.values.email}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              disabled={!!admin}
              className={
                formik.touched.email && formik.errors.email
                  ? "border-red-500"
                  : ""
              }
            />
            {formik.touched.email && formik.errors.email && (
              <div className="text-red-500 text-sm mt-1">
                {formik.errors.email}
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="phoneNumber">Phone Number*</Label>
            <Input
              id="phoneNumber"
              name="phoneNumber"
              value={formik.values.phoneNumber}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className={
                formik.touched.phoneNumber && formik.errors.phoneNumber
                  ? "border-red-500"
                  : ""
              }
            />
            {formik.touched.phoneNumber && formik.errors.phoneNumber && (
              <div className="text-red-500 text-sm mt-1">
                {formik.errors.phoneNumber}
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="role_Id">Role*</Label>
            <Select
              value={formik.values.role_Id.toString()}
              onValueChange={(value) => {
                formik.setFieldValue("role_Id", parseInt(value));
              }}
            >
              <SelectTrigger
                className={
                  formik.touched.role_Id && formik.errors.role_Id
                    ? "border-red-500"
                    : ""
                }
              >
                <SelectValue placeholder="Select a role" />
              </SelectTrigger>
              <SelectContent>
                {rolesData?.map((role: any) => (
                  <SelectItem key={role.role_id} value={role.role_id.toString()}>
                    {role.role_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {formik.touched.role_Id && formik.errors.role_Id && (
              <div className="text-red-500 text-sm mt-1">
                {formik.errors.role_Id}
              </div>
            )}
          </div>

          <div className="flex justify-end space-x-2">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={formik.isSubmitting}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={formik.isSubmitting}>
              {formik.isSubmitting ? "Submitting..." : admin ? "Update" : "Onboard"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default OnboardAdminModal;