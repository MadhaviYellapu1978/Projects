
# Go Denty Dashboard

A comprehensive dental management dashboard built with Vite, React, TypeScript, and Tailwind CSS.

## Features

- **Dashboard Overview**: View key metrics with cards for Total Clinic, Total MDS, Total BDS, and Total Revenue.
- **Doctors Management**: Browse, search, and manage doctors with detailed information.
- **Clinics Management**: Manage dental clinics with comprehensive details.
- **Treatment Plans**: Create and manage treatment plans with file uploads.
- **Go Denty Posts**: Upload and share dental content through blogs, reels, and tweets.
- **Shop Management**: Manage vendors and product categories.
- **Marketplace**: Browse and purchase dental equipment and supplies.
- **Dental Community**: Connect with dental professionals.
- **Events/Webinars**: Create and manage dental events, webinars, workshops, and conferences.
- **User Profile**: View and edit user information.
- **Settings**: Configure application settings.

## Tech Stack

- **Vite**: Fast frontend build tool
- **React**: JavaScript library for building user interfaces
- **TypeScript**: Typed JavaScript for better development experience
- **Tailwind CSS**: Utility-first CSS framework
- **React Router Dom**: Routing library for React
- **Lucide React**: Icon library
- **TanStack Query**: Data fetching and state management
- **shadcn/ui**: UI component library

## Getting Started

### Prerequisites

- Node.js (v14 or higher)
- npm or yarn

### Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/go-denty-dashboard.git
   cd go-denty-dashboard
   ```

2. Install dependencies:
   ```bash
   npm install
   # or
   yarn
   ```

3. Start the development server:
   ```bash
   npm run dev
   # or
   yarn dev
   ```

4. Open your browser and navigate to `http://localhost:8080`

## Project Structure

```
src/
├── components/       # Reusable UI components
│   ├── layout/       # Layout components (Sidebar, Navbar)
│   └── ui/           # UI components (Buttons, Cards, Tables, etc.)
├── data/             # Mock data
├── pages/            # Page components (Dashboard, Doctors, etc.)
└── App.tsx           # Main application component
```

## Features in Detail

### Dashboard
- Overview of key metrics
- Pending approvals for doctors and clinics

### Doctors Management
- List of all doctors with details
- Filtering by doctor type and date range
- Create, edit, and view doctors

### Clinics Management
- List of all clinics with details
- Filtering by date range
- Create, edit, and view clinics

### Treatment Plans
- Comprehensive and implant treatment plans
- View file attachments and amounts
- Create new treatment plans

### Go Denty Posts
- Create and view blogs, reels, and tweets
- Upload files for posts
- Add captions to posts

### Shop Management
- Manage vendors and categories
- View vendor details

### Marketplace
- Browse dental products
- Filter by category
- View product details

### Dental Community
- Connect with dental professionals
- View community posts

### Events/Webinars
- Create and view events, webinars, workshops, and conferences
- Request to join events

### User Profile
- View and edit user information
- Change password

### Settings
- Configure application settings
- Update user preferences

## Responsive Design

The application is fully responsive and works well on:
- Desktop (1024px and above)
- Tablet (768px to 1023px)
- Mobile (below 768px)

## License

This project is licensed under the MIT License.
