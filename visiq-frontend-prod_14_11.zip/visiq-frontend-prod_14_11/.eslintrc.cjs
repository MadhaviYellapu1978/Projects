/* eslint-disable prettier/prettier */
// eslint-disable-next-line no-undef
module.exports = {
  env: {
    browser: true, // Defines global variables for browser environment
    es2021: true, // Enables ES2021 global variables
  },
  extends: [
    'eslint:recommended', // Uses the recommended ESLint rules
    'plugin:react/recommended', // Uses the recommended React rules
    'plugin:jsx-a11y/recommended', // Uses the recommended accessibility rules
    'plugin:import/errors', // Uses the recommended import rules
    'plugin:import/warnings', // Uses additional import warnings
    'plugin:prettier/recommended', // Enables eslint-plugin-prettier and displays prettier errors as ESLint errors
    'prettier', // Disables ESLint rules that might conflict with Prettier
  ],
  parserOptions: {
    ecmaFeatures: {
      jsx: true, // Enables JSX parsing
    },
    ecmaVersion: 'latest', // Allows parsing of modern ECMAScript features
    sourceType: 'module', // Allows the use of imports
  },
  plugins: [
    'react', // Adds React-specific linting rules
    'react-hooks', // Adds React hooks linting rules
    'jsx-a11y', // Adds accessibility-specific linting rules for JSX
    'import', // Adds linting rules for import/export syntax
    'prettier', // Runs Prettier as an ESLint rule
    'jsdoc', // Adds JSDoc linting rules
  ],
  rules: {
    'prettier/prettier': 'error', // Ensures code follows Prettier formatting
    'import/named': 'error', // Ensures named imports correspond to a named export in the remote file
    'import/default': 'error', // Ensures a default import corresponds to a default export in the remote file
    'import/namespace': 'error', // Ensures imported namespaces contain dereferenced properties
    'import/no-restricted-paths': 'error', // Disallows specified modules when loaded by import
    'import/no-absolute-path': 'error', // Disallows the use of absolute paths in imports
    'import/no-dynamic-require': 'error', // Disallows require calls with expressions
    'import/no-webpack-loader-syntax': 'error', // Disallows Webpack loader syntax in imports
    'import/no-self-import': 'error', // Disallows importing from the same file
    'import/no-cycle': 'error', // Prevents circular imports
    'import/no-useless-path-segments': 'error', // Disallows unnecessary path segments in import and require statements
    'import/no-unused-modules': 'error', // Reports modules without any exports or only unused exports
    'import/no-unresolved': 'off', // Turned off
    'react/prop-types': 'off', // Disables prop-types as we might use TypeScript or rely on other ways of type-checking
    'react/react-in-jsx-scope': 'off', // React 17+ does not require React to be in scope
    'jsx-a11y/anchor-is-valid': 'off', // Disables validation of anchor tags for the demo purpose
    'no-unused-vars': [
      'error',
      { args: 'none', vars: 'all', varsIgnorePattern: '^_' },
    ], // Error on unused variables except function arguments
    'no-unused-expressions': 'error', // Disallow unused expressions
    'no-debugger': 'error', // Disallow debugger statements
    'no-warning-comments': [
      'error',
      { terms: ['todo', 'fixme'], location: 'anywhere' },
    ],
    'no-empty': ['error', { allowEmptyCatch: true }], // Disallow empty block statements except for catch blocks
    'no-useless-catch': 'off', // Turned off
    'react/jsx-filename-extension': ['warn', { extensions: ['.jsx', '.js'] }], // Allows JSX syntax in both .js and .jsx files
    'react-hooks/rules-of-hooks': 'error', // Checks rules of Hooks
    'react-hooks/exhaustive-deps': 'warn', // Checks effect dependencies
  },
  settings: {
    react: {
      version: 'detect', // Automatically detects the React version
    },
  },
}
