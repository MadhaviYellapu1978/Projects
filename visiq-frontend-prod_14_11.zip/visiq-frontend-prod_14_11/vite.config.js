import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],

  server: {
    port: 5173,
    host: true,
    strictPort: true,
    cors: true,
    hmr: {
      overlay: true,
    },
    watch: {
      usePolling: true,
      interval: 1000,
    },
    proxy: {
      '/api': {
        target: 'https://api-dev.myvisiq.com',
        changeOrigin: true,
        secure: true,
        rewrite: (path) => path.replace(/^\/api/, '/api'),
      },
    },
  },

  optimizeDeps: {
    include: [
      '@mui/material',
      '@mui/material/styles',
      '@emotion/react',
      '@emotion/styled',
    ],
    exclude: ['@mui/material/styles/createTheme'],
  },

  resolve: {
    alias: {
      '@mui/material/styles/createTheme': '@mui/material/styles',
    },
  },

  build: {
    commonjsOptions: {
      include: [/node_modules/],
    },
  },
})
