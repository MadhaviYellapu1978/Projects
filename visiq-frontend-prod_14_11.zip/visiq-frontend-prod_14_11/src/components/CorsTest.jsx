import React, { useState } from 'react'
import { apiClient } from '../utils/apiClient.js'

const CorsTest = () => {
  const [testResult, setTestResult] = useState('')
  const [loading, setLoading] = useState(false)
  const [credentials, setCredentials] = useState({
    username: '',
    password: '',
  })
  const [fieldType, setFieldType] = useState('username') // username or email

  const testCors = async () => {
    if (!credentials.username || !credentials.password) {
      setTestResult('Please enter both username and password to test')
      return
    }

    setLoading(true)
    setTestResult('Testing login with unencrypted API call...')

    try {
      // Try different field name combinations
      let testData
      if (fieldType === 'email') {
        testData = {
          email: credentials.username,
          password: credentials.password,
          isWeb: true,
        }
      } else {
        testData = {
          username: credentials.username,
          password: credentials.password,
          isWeb: true,
        }
      }

      console.log('Testing login with data:', testData)
      const result = await apiClient.post('/auth/signin', testData)

      setTestResult(
        `Login Test SUCCESS! Response: ${JSON.stringify(result, null, 2)}`,
      )
    } catch (error) {
      console.error('Login Test Error:', error)
      setTestResult(`Login Test FAILED: ${error.message}`)

      if (error.response?.status === 401) {
        setTestResult(
          (prev) =>
            prev +
            '\n\n401 Error: Authentication failed. Check credentials or API endpoint.',
        )
      }
    } finally {
      setLoading(false)
    }
  }

  const testMultipleEndpoints = async () => {
    if (!credentials.username || !credentials.password) {
      setTestResult('Please enter both username and password to test')
      return
    }

    setLoading(true)
    setTestResult('Testing multiple endpoints and field combinations...\n\n')

    const endpoints = ['/auth/signin', '/auth/login', '/auth/authenticate']

    const fieldCombinations = [
      {
        username: credentials.username,
        password: credentials.password,
        isWeb: true,
      },
      {
        email: credentials.username,
        password: credentials.password,
        isWeb: true,
      },
      {
        user: credentials.username,
        password: credentials.password,
        isWeb: true,
      },
      { username: credentials.username, password: credentials.password },
    ]

    let results = []

    for (const endpoint of endpoints) {
      for (const data of fieldCombinations) {
        try {
          setTestResult(
            (prev) =>
              prev + `Testing ${endpoint} with ${JSON.stringify(data)}...\n`,
          )

          const result = await apiClient.post(endpoint, data)
          results.push(`✅ SUCCESS: ${endpoint} with ${JSON.stringify(data)}`)
          setTestResult(
            (prev) =>
              prev + `✅ SUCCESS: ${endpoint} with ${JSON.stringify(data)}\n`,
          )
          break // If one combination works, stop testing this endpoint
        } catch (error) {
          if (error.response?.status === 401) {
            results.push(`❌ 401: ${endpoint} with ${JSON.stringify(data)}`)
            setTestResult(
              (prev) =>
                prev + `❌ 401: ${endpoint} with ${JSON.stringify(data)}\n`,
            )
          } else {
            results.push(
              `❌ ${error.message}: ${endpoint} with ${JSON.stringify(data)}`,
            )
            setTestResult(
              (prev) =>
                prev +
                `❌ ${error.message}: ${endpoint} with ${JSON.stringify(data)}\n`,
            )
          }
        }
      }
    }

    setTestResult(
      (prev) => prev + '\n=== TEST COMPLETE ===\n' + results.join('\n'),
    )
    setLoading(false)
  }

  return (
    <div className="p-4 border rounded-lg bg-gray-50">
      <h3 className="text-lg font-semibold mb-4">
        Login API Test (Unencrypted)
      </h3>

      <div className="mb-4 space-y-2">
        <div className="flex space-x-2 mb-2">
          <label className="flex items-center">
            <input
              type="radio"
              value="username"
              checked={fieldType === 'username'}
              onChange={(e) => setFieldType(e.target.value)}
              className="mr-2"
            />
            Username
          </label>
          <label className="flex items-center">
            <input
              type="radio"
              value="email"
              checked={fieldType === 'email'}
              onChange={(e) => setFieldType(e.target.value)}
              className="mr-2"
            />
            Email
          </label>
        </div>

        <input
          type="text"
          placeholder={fieldType === 'email' ? 'Email' : 'Username'}
          value={credentials.username}
          onChange={(e) =>
            setCredentials((prev) => ({ ...prev, username: e.target.value }))
          }
          className="w-full p-2 border rounded"
        />
        <input
          type="password"
          placeholder="Password"
          value={credentials.password}
          onChange={(e) =>
            setCredentials((prev) => ({ ...prev, password: e.target.value }))
          }
          className="w-full p-2 border rounded"
        />
      </div>

      <div className="flex space-x-2 mb-4">
        <button
          onClick={testCors}
          disabled={loading || !credentials.username || !credentials.password}
          className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 disabled:opacity-50"
        >
          {loading ? 'Testing...' : 'Test Single Login'}
        </button>

        <button
          onClick={testMultipleEndpoints}
          disabled={loading || !credentials.username || !credentials.password}
          className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 disabled:opacity-50"
        >
          {loading ? 'Testing...' : 'Test All Endpoints'}
        </button>
      </div>

      {testResult && (
        <div className="mt-4 p-3 bg-gray-100 rounded">
          <pre className="text-sm whitespace-pre-wrap">{testResult}</pre>
        </div>
      )}

      <div className="mt-4 text-sm text-gray-600">
        <p>
          <strong>Current Configuration:</strong>
        </p>
        <ul className="list-disc list-inside mt-2">
          <li>
            Base URL:{' '}
            {import.meta.env.DEV
              ? '/api (proxy)'
              : 'https://api.myvisiq.com/api'}
          </li>
          <li>Environment: {import.meta.env.MODE}</li>
          <li>API Call Type: Unencrypted (apiClient.post)</li>
          <li>Proxy: {import.meta.env.DEV ? 'Enabled' : 'Disabled'}</li>
          <li>Field Type: {fieldType}</li>
        </ul>

        <div className="mt-3 p-2 bg-yellow-50 border border-yellow-200 rounded">
          <p className="font-semibold text-yellow-800">Note:</p>
          <p className="text-yellow-700 text-xs">
            This test uses the unencrypted API call (apiClient.post) which sends
            plain JSON data to the server. The API expects unencrypted data.
          </p>
        </div>

        <div className="mt-3 p-2 bg-blue-50 border border-blue-200 rounded">
          <p className="font-semibold text-blue-800">Troubleshooting:</p>
          <p className="text-blue-700 text-xs">
            If you're still getting 401 errors, try:
            <br />• Different field names (username vs email)
            <br />• Check if the API endpoint is correct
            <br />• Verify the credentials are correct
            <br />• Check browser console for detailed logs
          </p>
        </div>
      </div>
    </div>
  )
}

export default CorsTest
