import React, { useState } from 'react'
import { useFormik } from 'formik'
import * as Yup from 'yup'
import { bookVisit } from '../services/orgService'
import toast from 'react-hot-toast'

const BookVisitForm = () => {
  const [loading, setLoading] = useState(false)
  const [vmEnabled, setVmEnabled] = useState(false)
  const [mmEnabled, setMmEnabled] = useState(false)
  const [grpEnabled, setGrpEnabled] = useState(false)

  const validationSchema = Yup.object({
    first_name: Yup.string().required('First name is required'),
    last_name: Yup.string().required('Last name is required'),
    email: Yup.string().email('Invalid email').required('Email is required'),
    date_of_visit: Yup.string().required('Visit date is required'),
    branch_id: Yup.string().required('Branch ID is required'),
    org_id: Yup.string().required('Organization ID is required'),
    purpose_of_visit: Yup.string().required('Purpose of visit is required'),
    branch_name: Yup.string().required('Branch name is required'),
    org_name: Yup.string().required('Organization name is required'),
    time_of_visit: Yup.string().required('Visit time is required'),
    visit_duration: Yup.string().required('Visit duration is required'),
    time_to_exit: Yup.string().required('Exit time is required'),
    visitorOrgName: Yup.string().required(
      'Visitor organization name is required',
    ),
    phNo: Yup.string().required('Phone number is required'),
    ph_ext: Yup.string(),
    end_date_of_visit: Yup.string().required('End date is required'),
    meetTo: Yup.string().required('Meeting person is required'),
    role: Yup.string().required('Role is required'),
    reason: Yup.string().required('Reason is required'),
  })

  const formik = useFormik({
    initialValues: {
      first_name: '',
      last_name: '',
      email: '',
      date_of_visit: '',
      branch_id: '',
      org_id: '',
      purpose_of_visit: '',
      branch_name: '',
      org_name: '',
      time_of_visit: '',
      visit_duration: '',
      time_to_exit: '',
      visitorOrgName: '',
      phNo: '',
      ph_ext: '',
      end_date_of_visit: '',
      area_of_permit: [{ area_name: '' }],
      meetTo: '',
      role: '',
      reason: '',
      vm_bool: false,
      mm_bool: false,
      vm_details: [],
      mm_details: [],
      grp_book_bool: false,
      grp_details: [],
    },
    validationSchema,
    onSubmit: async (values) => {
      setLoading(true)
      try {
        const response = await bookVisit(values)
        if (response.statusCode === 200) {
          toast.success(response.message)
          formik.resetForm()
          setVmEnabled(false)
          setMmEnabled(false)
          setGrpEnabled(false)
        } else {
          toast.error(response.message || 'Failed to book visit')
        }
      } catch (error) {
        toast.error(error.message || 'Failed to book visit')
      } finally {
        setLoading(false)
      }
    },
  })

  // Removed unused functions: addAreaOfPermit, removeAreaOfPermit

  const addVehicleDetail = () => {
    formik.setFieldValue('vm_details', [
      ...formik.values.vm_details,
      {
        vehicle_id: '',
        vehicle_name: '',
        vehicle_type: '',
        driver_id: '',
        driver_licence: '',
        insurance_provider: '',
        insurance_no: '',
        rc_no: '',
        vehicle_comments: '',
      },
    ])
  }

  // Removed unused functions: addMaterialDetail, addGroupDetail

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white shadow-lg">
      <h2 className="text-2xl font-bold mb-6 text-gray-800">Book a Visit</h2>

      <form onSubmit={formik.handleSubmit} className="space-y-6">
        {/* Basic Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label
              htmlFor="first_name"
              className="block text-sm font-medium text-gray-700 mb-1"
            >
              First Name *
            </label>
            <input
              id="first_name"
              type="text"
              name="first_name"
              value={formik.values.first_name}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className="w-full px-3 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            {formik.touched.first_name && formik.errors.first_name && (
              <p className="text-red-500 text-sm mt-1">
                {formik.errors.first_name}
              </p>
            )}
          </div>

          <div>
            <label
              htmlFor="last_name"
              className="block text-sm font-medium text-gray-700 mb-1"
            >
              Last Name *
            </label>
            <input
              id="last_name"
              type="text"
              name="last_name"
              value={formik.values.last_name}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className="w-full px-3 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            {formik.touched.last_name && formik.errors.last_name && (
              <p className="text-red-500 text-sm mt-1">
                {formik.errors.last_name}
              </p>
            )}
          </div>
        </div>

        {/* Contact Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label
              htmlFor="email"
              className="block text-sm font-medium text-gray-700 mb-1"
            >
              Email *
            </label>
            <input
              id="email"
              type="email"
              name="email"
              value={formik.values.email}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            {formik.touched.email && formik.errors.email && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.email}</p>
            )}
          </div>

          <div>
            <label
              htmlFor="phNo"
              className="block text-sm font-medium text-gray-700 mb-1"
            >
              Phone Number *
            </label>
            <input
              id="phNo"
              type="tel"
              name="phNo"
              value={formik.values.phNo}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            {formik.touched.phNo && formik.errors.phNo && (
              <p className="text-red-500 text-sm mt-1">{formik.errors.phNo}</p>
            )}
          </div>
        </div>

        {/* Organization Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label
              htmlFor="org_id"
              className="block text-sm font-medium text-gray-700 mb-1"
            >
              Organization ID *
            </label>
            <input
              id="org_id"
              type="text"
              name="org_id"
              value={formik.values.org_id}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            {formik.touched.org_id && formik.errors.org_id && (
              <p className="text-red-500 text-sm mt-1">
                {formik.errors.org_id}
              </p>
            )}
          </div>

          <div>
            <label
              htmlFor="org_name"
              className="block text-sm font-medium text-gray-700 mb-1"
            >
              Organization Name *
            </label>
            <input
              id="org_name"
              type="text"
              name="org_name"
              value={formik.values.org_name}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            {formik.touched.org_name && formik.errors.org_name && (
              <p className="text-red-500 text-sm mt-1">
                {formik.errors.org_name}
              </p>
            )}
          </div>
        </div>

        {/* Visit Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label
              htmlFor="date_of_visit"
              className="block text-sm font-medium text-gray-700 mb-1"
            >
              Visit Date *
            </label>
            <input
              id="date_of_visit"
              type="date"
              name="date_of_visit"
              value={formik.values.date_of_visit}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            {formik.touched.date_of_visit && formik.errors.date_of_visit && (
              <p className="text-red-500 text-sm mt-1">
                {formik.errors.date_of_visit}
              </p>
            )}
          </div>

          <div>
            <label
              htmlFor="time_of_visit"
              className="block text-sm font-medium text-gray-700 mb-1"
            >
              Visit Time *
            </label>
            <input
              id="time_of_visit"
              type="time"
              name="time_of_visit"
              value={formik.values.time_of_visit}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            {formik.touched.time_of_visit && formik.errors.time_of_visit && (
              <p className="text-red-500 text-sm mt-1">
                {formik.errors.time_of_visit}
              </p>
            )}
          </div>
        </div>

        {/* Additional Options */}
        <div className="space-y-4">
          <div className="flex items-center space-x-4">
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={vmEnabled}
                onChange={(e) => {
                  setVmEnabled(e.target.checked)
                  formik.setFieldValue('vm_bool', e.target.checked)
                  if (!e.target.checked) {
                    formik.setFieldValue('vm_details', [])
                  }
                }}
                className="mr-2"
              />
              Vehicle Management
            </label>

            <label className="flex items-center">
              <input
                type="checkbox"
                checked={mmEnabled}
                onChange={(e) => {
                  setMmEnabled(e.target.checked)
                  formik.setFieldValue('mm_bool', e.target.checked)
                  if (!e.target.checked) {
                    formik.setFieldValue('mm_details', [])
                  }
                }}
                className="mr-2"
              />
              Material Management
            </label>

            <label className="flex items-center">
              <input
                type="checkbox"
                checked={grpEnabled}
                onChange={(e) => {
                  setGrpEnabled(e.target.checked)
                  formik.setFieldValue('grp_book_bool', e.target.checked)
                  if (!e.target.checked) {
                    formik.setFieldValue('grp_details', [])
                  }
                }}
                className="mr-2"
              />
              Group Booking
            </label>
          </div>
        </div>

        {/* Vehicle Details */}
        {vmEnabled && (
          <div className="border p-4 rounded-md bg-gray-50">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium">Vehicle Details</h3>
              <button
                type="button"
                onClick={addVehicleDetail}
                className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
              >
                Add Vehicle
              </button>
            </div>
            {formik.values.vm_details.map((vehicle, index) => (
              <div
                key={index}
                className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4 p-4 border rounded-md bg-white"
              >
                <input
                  type="text"
                  placeholder="Vehicle Name"
                  value={vehicle.vehicle_name}
                  onChange={(e) =>
                    formik.setFieldValue(
                      `vm_details.${index}.vehicle_name`,
                      e.target.value,
                    )
                  }
                  className="px-3 py-2 border border-gray-300 rounded-md"
                />
                <input
                  type="text"
                  placeholder="Vehicle Type"
                  value={vehicle.vehicle_type}
                  onChange={(e) =>
                    formik.setFieldValue(
                      `vm_details.${index}.vehicle_type`,
                      e.target.value,
                    )
                  }
                  className="px-3 py-2 border border-gray-300 rounded-md"
                />
                <input
                  type="text"
                  placeholder="Driver License"
                  value={vehicle.driver_licence}
                  onChange={(e) =>
                    formik.setFieldValue(
                      `vm_details.${index}.driver_licence`,
                      e.target.value,
                    )
                  }
                  className="px-3 py-2 border border-gray-300 rounded-md"
                />
              </div>
            ))}
          </div>
        )}

        {/* Submit Button */}
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={loading}
            className="px-6 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Booking Visit...' : 'Book Visit'}
          </button>
        </div>
      </form>
    </div>
  )
}

export default BookVisitForm
