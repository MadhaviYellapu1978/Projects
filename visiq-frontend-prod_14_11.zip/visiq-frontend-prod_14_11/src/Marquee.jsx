// src/Marquee.js
import React from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {
  faCheckCircle,
  faHandSparkles,
  faSmile,
  faHome,
} from '@fortawesome/free-solid-svg-icons'

const Marquee = () => {
  return (
    <div
      style={{
        overflow: 'hidden',
        whiteSpace: 'nowrap',
        boxSizing: 'border-box',
        background: 'linear-gradient(90deg, #00FF00, #00FFFF)', // Neon green to neon cyan gradient background
        color: '#FF00FF', // Neon pink text color
        padding: '0.75rem 1.5rem', // Increased padding for better spacing
        borderRadius: '0.75rem', // Slightly larger border radius
        boxShadow: '0 4px 10px rgba(0, 0, 0, 0.15)', // Slightly larger shadow for more depth
        fontSize: '1rem', // Font size
        fontWeight: '500', // Font weight
        fontFamily: 'Arial, sans-serif', // Font family
        display: 'flex',
        alignItems: 'center',
      }}
    >
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          paddingLeft: '100%',
          animation: 'marquee 27s ease-in-out infinite', // Animation with ease-in-out timing function
        }}
      >
        <FontAwesomeIcon icon={faHandSparkles} className="mr-3" />
        <FontAwesomeIcon icon={faSmile} className="mr-3" />
        <FontAwesomeIcon icon={faHome} className="mr-3" />
        <span role="img" aria-label="party-popper" className="mr-3">
          🎉
        </span>
        <span role="img" aria-label="waving-hand" className="mr-3">
          👋
        </span>
        <FontAwesomeIcon icon={faCheckCircle} className="mr-3" />
        Welcome to GDH! We are dedicated to innovating solutions and empowering
        success through cutting-edge technology and unwavering commitment.
      </div>
    </div>
  )
}

export default Marquee
