import React from 'react'
import Presentation from './Presentation'

function Container(props) {
  console.log('hello propssssssss')
  console.log(props, 'propssssssssssssssss')
  return (
    <div>
      <Presentation brach_id={props?.brach_id} />
    </div>
  )
}

export default Container
