// import { Form, Formik } from 'formik'
// import React, { useContext, useState } from 'react'
// import FormikTextField from '../../../lib/Formik/FormikTextfield'
// import * as yup from 'yup'
// import PrimaryBtn from '../../../shared/Buttons/PrimaryBtn'
// import { AuthContext } from '../../../context/AuthContext'
// import { view, hide } from '../../../assets'

// const Presentation = (props) => {
//   const auth = useContext(AuthContext)
//   const { handleSignIn } = props
//   const initialValues = {
//     username: auth?.username,
//     oldPassword: '',
//     newPassword: '',
//     confirmPassword: '',
//   }

//   const [canSeeOldPassword, setCanSeeOldPassword] = useState(false)
//   const [canSeeNewPassword, setCanSeeNewPassword] = useState(false)
//   const [canSeeConfirmPassword, setCanSeeConfirmPassword] = useState(false)

//   const validpass =
//     /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/
//   const validationSchema = yup.object().shape({
//     username: yup.string().required('Enter User Name'),
//     oldPassword: yup.string().required('Enter Current Password'),
//     newPassword: yup
//       .string()
//       .matches(
//         validpass,
//         'Password must be 8+ characters with upper, lower, number, and special character.',
//       )
//       .required('Enter New Password')
//       .test(
//         'not-same-as-old',
//         'New password must be different from the current password',
//         function (value) {
//           return value !== this.parent.oldPassword
//         },
//       ),
//     confirmPassword: yup
//       .string()
//       .oneOf([yup.ref('newPassword'), null], 'Passwords must match')
//       .required('Enter Confirm Password'),
//   })

//   const handlePasswordToggle = (setView, canSee) => {
//     setView(!canSee)
//   }
//   return (
//     <div className="max-w-80 m-auto flex flex-col justify-center h-[calc(100vh-5rem)] gap-10">
//       <Formik
//         initialValues={initialValues}
//         validationSchema={validationSchema}
//         onSubmit={(values, actions) => {
//           const { confirmPassword: _, ...rest } = values
//           handleSignIn(rest)
//         }}
//       >
//         {() => (
//           <Form className="flex flex-col gap-7">
//             <FormikTextField
//               name="username"
//               label="User Name *"
//               type="text"
//               disabled
//             />
//             <FormikTextField
//               name="oldPassword"
//               label="Current Password *"
//               type={canSeeOldPassword ? 'text' : 'password'}
//               icon={{
//                 src: canSeeOldPassword ? hide : view,
//                 alt: 'toggle visibility',
//                 onClick: () =>
//                   handlePasswordToggle(setCanSeeOldPassword, canSeeOldPassword),
//               }}
//             />
//             <FormikTextField
//               name="newPassword"
//               label="New Password *"
//               type={canSeeNewPassword ? 'text' : 'password'}
//               icon={{
//                 src: canSeeNewPassword ? hide : view,
//                 alt: 'toggle visibility',
//                 onClick: () =>
//                   handlePasswordToggle(setCanSeeNewPassword, canSeeNewPassword),
//               }}
//             />
//             <FormikTextField
//               name="confirmPassword"
//               label="Confirm Password *"
//               type={canSeeConfirmPassword ? 'text' : 'password'}
//               icon={{
//                 src: canSeeConfirmPassword ? hide : view,
//                 alt: 'toggle visibility',
//                 onClick: () =>
//                   handlePasswordToggle(
//                     setCanSeeConfirmPassword,
//                     canSeeConfirmPassword,
//                   ),
//               }}
//             />
//             <PrimaryBtn text="Change Password" type="submit" />
//           </Form>
//         )}
//       </Formik>
//     </div>
//   )
// }

// export default Presentation

// import { Form, Formik } from 'formik'
// import React, { useContext, useState } from 'react'
// import FormikTextField from '../../../lib/Formik/FormikTextfield'
// import * as yup from 'yup'
// import PrimaryBtn from '../../../shared/Buttons/PrimaryBtn'
// import { AuthContext } from '../../../context/AuthContext'
// import { view, hide } from '../../../assets'

// const Presentation = (props) => {
//   const auth = useContext(AuthContext)
//   const { handleSignIn } = props
//   const initialValues = {
//     username: auth?.username || '',
//     oldPassword: '',
//     newPassword: '',
//     confirmPassword: '',
//   }

//   const [canSeeOldPassword, setCanSeeOldPassword] = useState(false)
//   const [canSeeNewPassword, setCanSeeNewPassword] = useState(false)
//   const [canSeeConfirmPassword, setCanSeeConfirmPassword] = useState(false)
//   const [isFocused, setIsFocused] = useState(false)
//   const [passwordValid, setPasswordValid] = useState({
//     length: false,
//     uppercase: false,
//     lowercase: false,
//     number: false,
//     special: false,
//     differentFromOld: false,
//   })

//   const validpass =
//     /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/

//   const validationSchema = yup.object().shape({
//     username: yup.string().required('Enter User Name'),
//     oldPassword: yup.string().required('Enter Current Password'),
//     newPassword: yup
//       .string()
//       .required('Enter New Password')
//       .test('is-valid', 'Password is invalid', (value, context) => {
//         const valid = validpass.test(value)
//         const oldPassword = context.parent.oldPassword
//         setPasswordValid({
//           length: value.length >= 8,
//           uppercase: /[A-Z]/.test(value),
//           lowercase: /[a-z]/.test(value),
//           number: /\d/.test(value),
//           special: /[@$!%*?&]/.test(value),
//           differentFromOld: value !== oldPassword,
//         })
//         return valid && value !== oldPassword
//       }),
//     confirmPassword: yup
//       .string()
//       .oneOf([yup.ref('newPassword'), null], 'Passwords must match')
//       .required('Enter Confirm Password'),
//   })

//   const handlePasswordToggle = (setView, canSee) => {
//     setView(!canSee)
//   }

//   const handleNewPasswordChange = (e, setFieldValue, setFieldTouched) => {
//     const { value } = e.target
//     setFieldValue('newPassword', value)
//     setFieldTouched('newPassword', true)

//     setPasswordValid({
//       length: value.length >= 8,
//       uppercase: /[A-Z]/.test(value),
//       lowercase: /[a-z]/.test(value),
//       number: /\d/.test(value),
//       special: /[@$!%*?&]/.test(value),
//       differentFromOld: value !== initialValues.oldPassword,
//     })
//   }

//   return (
//     <div className="max-w-80 m-auto flex flex-col justify-center h-[calc(100vh-5rem)] gap-10">
//       <Formik
//         initialValues={initialValues}
//         validationSchema={validationSchema}
//         onSubmit={(values, actions) => {
//           const { confirmPassword: _, ...rest } = values
//           handleSignIn(rest)
//         }}
//       >
//         {({ setFieldValue, setFieldTouched, values }) => (
//           <Form className="flex flex-col gap-7">
//             <FormikTextField
//               name="username"
//               label="User Name *"
//               type="text"
//               disabled
//             />
//             <FormikTextField
//               name="oldPassword"
//               label="Current Password *"
//               type={canSeeOldPassword ? 'text' : 'password'}
//               icon={{
//                 src: canSeeOldPassword ? hide : view,
//                 alt: 'toggle visibility',
//                 onClick: () =>
//                   handlePasswordToggle(setCanSeeOldPassword, canSeeOldPassword),
//               }}
//             />
//             <FormikTextField
//               name="newPassword"
//               label="New Password *"
//               type={canSeeNewPassword ? 'text' : 'password'}
//               onFocus={() => setIsFocused(true)}
//               onBlur={() => setIsFocused(false)}
//               onChange={(e) =>
//                 handleNewPasswordChange(e, setFieldValue, setFieldTouched)
//               }
//               icon={{
//                 src: canSeeNewPassword ? hide : view,
//                 alt: 'toggle visibility',
//                 onClick: () =>
//                   handlePasswordToggle(setCanSeeNewPassword, canSeeNewPassword),
//               }}
//             />
//             {isFocused && (
//               <div className="flex flex-col ml-4 text-sm">
//                 <div className="flex items-center">
//                   <input
//                     type="checkbox"
//                     checked={passwordValid.length}
//                     readOnly
//                     className="mr-2"
//                   />
//                   <p
//                     className={`${
//                       passwordValid.length ? 'text-green-500' : 'text-red-500'
//                     }`}
//                   >
//                     {passwordValid.length
//                       ? 'Length is sufficient'
//                       : 'Must be at least 8 characters'}
//                   </p>
//                 </div>
//                 <div className="flex items-center">
//                   <input
//                     type="checkbox"
//                     checked={passwordValid.uppercase}
//                     readOnly
//                     className="mr-2"
//                   />
//                   <p
//                     className={`${
//                       passwordValid.uppercase
//                         ? 'text-green-500'
//                         : 'text-red-500'
//                     }`}
//                   >
//                     {passwordValid.uppercase
//                       ? 'Contains an uppercase letter'
//                       : 'Must contain an uppercase letter'}
//                   </p>
//                 </div>
//                 <div className="flex items-center">
//                   <input
//                     type="checkbox"
//                     checked={passwordValid.lowercase}
//                     readOnly
//                     className="mr-2"
//                   />
//                   <p
//                     className={`${
//                       passwordValid.lowercase
//                         ? 'text-green-500'
//                         : 'text-red-500'
//                     }`}
//                   >
//                     {passwordValid.lowercase
//                       ? 'Contains a lowercase letter'
//                       : 'Must contain a lowercase letter'}
//                   </p>
//                 </div>
//                 <div className="flex items-center">
//                   <input
//                     type="checkbox"
//                     checked={passwordValid.number}
//                     readOnly
//                     className="mr-2"
//                   />
//                   <p
//                     className={`${
//                       passwordValid.number ? 'text-green-500' : 'text-red-500'
//                     }`}
//                   >
//                     {passwordValid.number
//                       ? 'Contains a number'
//                       : 'Must contain a number'}
//                   </p>
//                 </div>
//                 <div className="flex items-center">
//                   <input
//                     type="checkbox"
//                     checked={passwordValid.special}
//                     readOnly
//                     className="mr-2"
//                   />
//                   <p
//                     className={`${
//                       passwordValid.special ? 'text-green-500' : 'text-red-500'
//                     }`}
//                   >
//                     {passwordValid.special
//                       ? 'Contains a special character'
//                       : 'Must contain a special character'}
//                   </p>
//                 </div>
//                 <div className="flex items-center">
//                   <input
//                     type="checkbox"
//                     checked={passwordValid.differentFromOld}
//                     readOnly
//                     className="mr-2"
//                   />
//                   <p
//                     className={`${
//                       passwordValid.differentFromOld
//                         ? 'text-green-500'
//                         : 'text-red-500'
//                     }`}
//                   >
//                     {passwordValid.differentFromOld
//                       ? 'Different from old password'
//                       : 'Must be different from the old password'}
//                   </p>
//                 </div>
//               </div>
//             )}
//             <FormikTextField
//               name="confirmPassword"
//               label="Confirm Password *"
//               type={canSeeConfirmPassword ? 'text' : 'password'}
//               icon={{
//                 src: canSeeConfirmPassword ? hide : view,
//                 alt: 'toggle visibility',
//                 onClick: () =>
//                   handlePasswordToggle(
//                     setCanSeeConfirmPassword,
//                     canSeeConfirmPassword,
//                   ),
//               }}
//             />
//             <PrimaryBtn text="Change Password" type="submit" />
//           </Form>
//         )}
//       </Formik>
//     </div>
//   )
// }

// export default Presentation

import { Form, Formik } from 'formik'
import React, { useContext, useState } from 'react'
import FormikTextField from '../../../lib/Formik/FormikTextfield'
import * as yup from 'yup'
import PrimaryBtn from '../../../shared/Buttons/PrimaryBtn'
import { AuthContext } from '../../../context/AuthContext'
import { view, hide } from '../../../assets'

const Presentation = (props) => {
  const auth = useContext(AuthContext)
  const { handleSignIn } = props

  const initialValues = {
    username: auth?.username || '',
    oldPassword: '',
    newPassword: '',
    confirmPassword: '',
  }

  const [canSeeOldPassword, setCanSeeOldPassword] = useState(false)
  const [canSeeNewPassword, setCanSeeNewPassword] = useState(false)
  const [canSeeConfirmPassword, setCanSeeConfirmPassword] = useState(false)
  const [isFocused, setIsFocused] = useState(false)
  const [passwordValid, setPasswordValid] = useState({
    length: false,
    uppercase: false,
    lowercase: false,
    number: false,
    special: false,
    differentFromOld: false,
  })

  // const validpass =
  //   /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$#!%*?&~^()><{}])[A-Za-z\d#@$!%*?&~^()><{}]{8,}$/
  const validpass =
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_])[A-Za-z\d\W_]{8,}$/

  // const validationSchema = yup.object().shape({
  //   username: yup.string().required('Enter User Name'),
  //   oldPassword: yup.string().required('Enter Current Password'),
  //   newPassword: yup
  //     .string()
  //     .required('Enter New Password')
  //     .test('is-valid', 'Password is invalid', function (value) {
  //       const valid = validpass.test(value)
  //       const { oldPassword } = this.parent
  //       return valid && value !== oldPassword
  //     }),
  //   confirmPassword: yup
  //     .string()
  //     .oneOf([yup.ref('newPassword'), null], 'Passwords must match')
  //     .required('Enter Confirm Password'),
  // })
  const validationSchema = yup.object().shape({
    username: yup.string().required('Enter User Name'),
    oldPassword: yup.string().required('Enter Current Password'),
    newPassword: yup
      .string()
      .required('Enter New Password')
      .test('is-valid', 'Password is invalid', function (value) {
        const valid = validpass.test(value)
        const { oldPassword } = this.parent
        return valid && value !== oldPassword
      })
      .notOneOf(
        [yup.ref('oldPassword')],
        'New password must be different from the old password',
      ),
    confirmPassword: yup
      .string()
      .oneOf([yup.ref('newPassword'), null], 'Passwords must match')
      .required('Enter Confirm Password'),
  })

  const handlePasswordToggle = (setView, canSee) => {
    setView(!canSee)
  }

  const handleNewPasswordChange = (e, setFieldValue, setFieldTouched) => {
    const { value } = e.target
    setFieldValue('newPassword', value)
    setFieldTouched('newPassword', true)

    // Validate password and update state
    // const valid = validpass.test(value)

    setPasswordValid({
      length: value.length >= 8,
      uppercase: /[A-Z]/.test(value),
      lowercase: /[a-z]/.test(value),
      number: /\d/.test(value),
      special: /[!@#$%^&*()\-_=+{}[\]:;'"<>,.?/\\|~`§€£¢©®™]/.test(value),

      differentFromOld: value !== initialValues.oldPassword,
    })
  }

  return (
    <div className="max-w-80 m-auto flex flex-col justify-center h-[calc(100vh-5rem)] gap-10">
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        validateOnChange={true}
        validateOnBlur={false} // Optional: can be true or false depending on UX preference
        onSubmit={(values, actions) => {
          const { confirmPassword: _, ...rest } = values
          handleSignIn(rest)
        }}
      >
        {({ setFieldValue, setFieldTouched, values, errors, touched }) => (
          <Form className="flex flex-col gap-7" autoComplete="off">
            <FormikTextField
              name="username"
              label="User Name *"
              type="text"
              disabled
            />
            <FormikTextField
              name="oldPassword"
              label="Current Password *"
              type={canSeeOldPassword ? 'text' : 'password'}
              autoComplete="new-password"
              InputProps={{
                autoComplete: 'new-password',
                'data-form-type': 'other',
              }}
              inputProps={{
                autoComplete: 'new-password',
                'data-form-type': 'other',
              }}
              icon={{
                src: canSeeOldPassword ? hide : view,
                alt: 'toggle visibility',
                onClick: () =>
                  handlePasswordToggle(setCanSeeOldPassword, canSeeOldPassword),
              }}
            />
            <FormikTextField
              name="newPassword"
              label="New Password *"
              type={canSeeNewPassword ? 'text' : 'password'}
              autoComplete="new-password"
              onFocus={() => setIsFocused(true)}
              onBlur={() => setIsFocused(false)}
              onChange={(e) =>
                handleNewPasswordChange(e, setFieldValue, setFieldTouched)
              }
              icon={{
                src: canSeeNewPassword ? hide : view,
                alt: 'toggle visibility',
                onClick: () =>
                  handlePasswordToggle(setCanSeeNewPassword, canSeeNewPassword),
              }}
              error={touched.newPassword && errors.newPassword}
            />
            {isFocused && (
              <div className="flex flex-col ml-4 text-sm">
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    checked={passwordValid.length}
                    readOnly
                    className="mr-2"
                  />
                  <p
                    className={`${
                      passwordValid.length ? 'text-green-500' : 'text-red-500'
                    }`}
                  >
                    {passwordValid.length
                      ? 'Length is sufficient'
                      : 'Must be at least 8 characters'}
                  </p>
                </div>
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    checked={passwordValid.uppercase}
                    readOnly
                    className="mr-2"
                  />
                  <p
                    className={`${
                      passwordValid.uppercase
                        ? 'text-green-500'
                        : 'text-red-500'
                    }`}
                  >
                    {passwordValid.uppercase
                      ? 'Contains an uppercase letter'
                      : 'Must contain an uppercase letter'}
                  </p>
                </div>
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    checked={passwordValid.lowercase}
                    readOnly
                    className="mr-2"
                  />
                  <p
                    className={`${
                      passwordValid.lowercase
                        ? 'text-green-500'
                        : 'text-red-500'
                    }`}
                  >
                    {passwordValid.lowercase
                      ? 'Contains a lowercase letter'
                      : 'Must contain a lowercase letter'}
                  </p>
                </div>
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    checked={passwordValid.number}
                    readOnly
                    className="mr-2"
                  />
                  <p
                    className={`${
                      passwordValid.number ? 'text-green-500' : 'text-red-500'
                    }`}
                  >
                    {passwordValid.number
                      ? 'Contains a number'
                      : 'Must contain a number'}
                  </p>
                </div>
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    checked={passwordValid.special}
                    readOnly
                    className="mr-2"
                  />
                  <p
                    className={`${
                      passwordValid.special ? 'text-green-500' : 'text-red-500'
                    }`}
                  >
                    {passwordValid.special
                      ? 'Contains a special character'
                      : 'Must contain a special character'}
                  </p>
                </div>
                {/* <div className="flex items-center">
                  <input
                    type="checkbox"
                    checked={passwordValid.differentFromOld}
                    readOnly
                    className="mr-2"
                  />
                  <p
                    className={`${
                      passwordValid.differentFromOld
                        ? 'text-green-500'
                        : 'text-red-500'
                    }`}
                  >
                    {passwordValid.differentFromOld
                      ? 'Different from old password'
                      : 'Must be different from the old password'}
                  </p>
                </div> */}
              </div>
            )}
            <FormikTextField
              name="confirmPassword"
              label="Confirm Password *"
              type={canSeeConfirmPassword ? 'text' : 'password'}
              autoComplete="new-password"
              icon={{
                src: canSeeConfirmPassword ? hide : view,
                alt: 'toggle visibility',
                onClick: () =>
                  handlePasswordToggle(
                    setCanSeeConfirmPassword,
                    canSeeConfirmPassword,
                  ),
              }}
              error={touched.confirmPassword && errors.confirmPassword}
            />
            <PrimaryBtn text="Change Password" type="submit" />
          </Form>
        )}
      </Formik>
    </div>
  )
}

export default Presentation
