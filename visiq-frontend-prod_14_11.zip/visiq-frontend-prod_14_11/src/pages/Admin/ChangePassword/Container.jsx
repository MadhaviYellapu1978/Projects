import React from 'react'
import Presentation from './Presentation'
import { useMutation } from '@tanstack/react-query'
import { changePassword } from '../../../services/authService'
import toast from 'react-hot-toast'
import { useNavigate } from 'react-router-dom'

const Container = () => {
  const navigate = useNavigate()

  const mutation = useMutation({
    mutationFn: (values) => changePassword(values),
    mutationKey: 'ChangePassword',
    onSuccess: (data) => {
      navigate('/auth/login')
      toast.success('Change Password Successful')
    },
    onError: (err) => {
      toast.dismiss()
      toast.error('Invalid Username or Password')
    },
  })
  const handleSignIn = (values) => {
    // eslint-disable-next-line no-unused-vars
    const { confirmPassword, ...rest } = values
    mutation.mutate(values)
  }
  return (
    <div>
      <Presentation handleSignIn={handleSignIn} />
    </div>
  )
}

export default Container
