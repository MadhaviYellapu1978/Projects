import React from 'react'
import VehicleMaterialGroupBookingPresentation from './Presentation'

const VehicleMaterialGroupBookingAdmin = () => {
  return <VehicleMaterialGroupBookingPresentation />
}

export default VehicleMaterialGroupBookingAdmin
