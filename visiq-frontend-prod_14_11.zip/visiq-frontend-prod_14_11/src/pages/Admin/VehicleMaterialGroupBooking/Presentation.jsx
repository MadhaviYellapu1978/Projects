import React, { useState, useEffect, useContext, useCallback } from 'react'
import {
  Box,
  Typography,
  Button,
  Paper,
  IconButton,
  TextField,
  InputAdornment,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Pagination,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Avatar,
  Tooltip,
} from '@mui/material'
import CalendarTodayIcon from '@mui/icons-material/CalendarToday'
import FilterListIcon from '@mui/icons-material/FilterList'
import ExpandMoreIcon from '@mui/icons-material/ExpandMore'
import ExpandLessIcon from '@mui/icons-material/ExpandLess'
import CloseIcon from '@mui/icons-material/Close'
import InfoIcon from '@mui/icons-material/Info'
import {
  getAllVisitors,
  getBranchesByOrgId,
} from '../../../services/adminService'
import { AuthContext } from '../../../context/AuthContext'
import { useQuery } from '@tanstack/react-query'
import { formatDate } from '../../../utils/dateFormat'
import toast from 'react-hot-toast'
import Papa from 'papaparse'
import { saveAs } from 'file-saver'
// eslint-disable-next-line import/no-named-as-default
import jsPDF from 'jspdf'
import 'jspdf-autotable'

const VehicleMaterialGroupBookingPresentation = () => {
  const auth = useContext(AuthContext)
  const [_searchTerm] = useState('')
  const [selectedDate, setSelectedDate] = useState(new Date())
  const [page, setPage] = useState(1)
  const [rowsPerPage] = useState(10)
  const [loading] = useState(false)
  const [_apiLoading, setApiLoading] = useState(false)
  const [_error, setError] = useState(null)

  // Branch selection state
  const [branches, setBranches] = useState([])
  const [selectedBranch, setSelectedBranch] = useState('')
  const [branchId, setBranchId] = useState('')

  // Modal states
  const [vehicleModalOpen, setVehicleModalOpen] = useState(false)
  const [groupModalOpen, setGroupModalOpen] = useState(false)
  const [selectedBooking, setSelectedBooking] = useState(null)
  const [expandedVehicles, setExpandedVehicles] = useState({})
  const [expandedCheckinDropdowns, setExpandedCheckinDropdowns] = useState({})
  const [memberAttendanceData, setMemberAttendanceData] = useState({})
  const [_loadingAttendance, setLoadingAttendance] = useState({})

  // API loading states
  const [vehicleLoading, setVehicleLoading] = useState(false)
  const [groupLoading, setGroupLoading] = useState(false)
  const [apiData, setApiData] = useState({
    vehicleMaterial: null,
    groupBooking: null,
  })

  // Filter states for each column
  const [filters, setFilters] = useState({
    name: '',
    visitStartDate: '',
    visitEndDate: '',
    visitStartTime: '',
    visitEndTime: '',
    category: '',
    phoneNumber: '',
    vehicleMaterial: '',
    groupBooking: '',
  })

  // API data for bookings
  const [bookings, setBookings] = useState([])

  // Filtered bookings based on search criteria
  const [filteredBookings, setFilteredBookings] = useState([])

  // Toggle state for PDF/CSV downloads
  const [isPDF, setIsPDF] = useState(false) // Default to CSV (false)

  // Query to fetch branches with caching
  const { data: branchesData, isError: branchesError } = useQuery({
    queryKey: ['getBranches', auth?.org_id],
    queryFn: () =>
      getBranchesByOrgId({
        org_id: auth.org_id,
        role: auth.role == '1' ? '' : auth.role,
        branch_id: auth?.branch_id || '',
      }),
    enabled: !!auth?.org_id,
    staleTime: 5 * 60 * 1000, // 5 minutes
    cacheTime: 10 * 60 * 1000, // 10 minutes
  })

  // Process branches data when it changes
  useEffect(() => {
    if (branchesData) {
      console.log('🔍 Branches data received:', branchesData)

      // Handle different response structures
      let branchesArray = []
      if (branchesData?.data) {
        branchesArray = branchesData.data
      } else if (branchesData?.organisationDetails?.branches) {
        branchesArray = branchesData.organisationDetails.branches
      } else if (Array.isArray(branchesData)) {
        branchesArray = branchesData
      }

      console.log('🔍 Processed branches array:', branchesArray)

      if (branchesArray && branchesArray.length > 0) {
        setBranches(branchesArray)
        const initialBranchId =
          branchesArray[0].branch_id || branchesArray[0].id
        console.log('🏢 Setting initial branch:', {
          initialBranchId,
          branchName: branchesArray[0].branch_name,
        })
        setSelectedBranch(initialBranchId)
        setBranchId(initialBranchId)
        console.log(
          '✅ Branches set successfully:',
          branchesArray[0].branch_name,
        )
      } else {
        console.warn('No branches found in response')
        setBranches([])
        setSelectedBranch('')
        setBranchId('')
      }
    }
  }, [branchesData])

  // Handle error state
  useEffect(() => {
    if (branchesError) {
      console.error('Error fetching branches:', branchesError)
      toast.error('Failed to load branches')
      setBranches([])
      setSelectedBranch('')
      setBranchId('')
    }
  }, [branchesError])

  // Fetch bookings from API
  const fetchBookings = useCallback(
    async (date = null) => {
      console.log('🚀 fetchBookings CALLED with:', {
        branchId,
        org_id: auth?.org_id,
        date,
      })
      if (!branchId || !auth?.org_id) {
        console.warn('Missing branchId or org_id for fetching bookings', {
          branchId,
          org_id: auth?.org_id,
        })
        return
      }

      setApiLoading(true)
      setError(null)

      try {
        const requestData = {
          org_id: auth.org_id,
          branch_id: branchId,
          role: auth.role == '1' ? '' : auth.role,
          data_of_visit: formatDate(date || new Date()),
        }

        const response = await getAllVisitors(requestData)

        // Handle the getAllVisitors API response structure
        let visitorsData = []

        // Combine both expected visitors (visitors_List) and arrived visitors (arrivedVisitorsList)
        const expectedVisitors =
          response?.visitors_List && Array.isArray(response.visitors_List)
            ? response.visitors_List
            : []
        const arrivedVisitors =
          response?.arrivedVisitorsList &&
          Array.isArray(response.arrivedVisitorsList)
            ? response.arrivedVisitorsList
            : []

        // Combine both lists
        visitorsData = [...expectedVisitors, ...arrivedVisitors]

        console.log('Combined visitors data:', {
          expectedVisitors: expectedVisitors.length,
          arrivedVisitors: arrivedVisitors.length,
          totalVisitors: visitorsData.length,
        })

        // Fallback to other data structures if no visitors found
        if (visitorsData.length === 0) {
          if (response?.data && Array.isArray(response.data)) {
            visitorsData = response.data
            console.log('Using data from response, count:', visitorsData.length)
          } else if (Array.isArray(response)) {
            visitorsData = response
            console.log('Using response as array, count:', visitorsData.length)
          } else {
            console.log('No valid data structure found in response:', response)
            console.log('Response structure:', {
              hasVisitorsList: !!response?.visitors_List,
              visitorsListLength: response?.visitors_List?.length || 0,
              hasArrivedVisitorsList: !!response?.arrivedVisitorsList,
              arrivedVisitorsListLength:
                response?.arrivedVisitorsList?.length || 0,
              hasData: !!response?.data,
              dataLength: response?.data?.length || 0,
            })
          }
        }

        // Debug: Log the first visitor to understand the API response structure
        if (visitorsData.length > 0) {
          console.log(
            'Sample visitor data from getAllVisitors API:',
            visitorsData[0],
          )
          console.log('API Request Data:', requestData)
          console.log('Total visitors found:', visitorsData.length)
        } else {
          console.log('No visitors found for date:', requestData.data_of_visit)
          console.log('API Request Data:', requestData)
        }

        // Transform API data to match our component structure
        const transformedData = visitorsData.map((visitor, index) => ({
          id: visitor.id || visitor.user_id || index + 1,
          name: (() => {
            // Handle name construction with proper fallbacks
            const firstName = visitor.first_name || ''
            const lastName = visitor.last_name || ''

            // If both first_name and last_name exist, combine them
            if (firstName && lastName) {
              return `${firstName} ${lastName}`.trim()
            }

            // If only first_name exists, use it
            if (firstName) {
              return firstName.trim()
            }

            // If only last_name exists, use it
            if (lastName) {
              return lastName.trim()
            }

            // Fallback to other name fields
            return (
              visitor.name || visitor.visitor_name || visitor.full_name || 'N/A'
            )
          })(),
          visitStartDate: formatDate(visitor.date_of_visit) || 'N/A',
          visitEndDate:
            formatDate(visitor.end_date_of_visit || visitor.date_of_visit) ||
            'N/A',
          visitStartTime: visitor.time_of_visit || 'N/A',
          visitEndTime: visitor.time_to_exit || 'N/A',
          category:
            visitor.role_name ||
            visitor.role ||
            visitor.category ||
            visitor.visitor_type ||
            'Visitor',
          phoneNumber:
            visitor.phone ||
            visitor.phNo ||
            visitor.contact ||
            visitor.mobile ||
            'N/A',
          email:
            visitor.email ||
            visitor.email_address ||
            visitor.user_email ||
            visitor.visitor_email ||
            'N/A',
          purpose:
            visitor.purpose_of_visit ||
            visitor.purpose ||
            visitor.visit_purpose ||
            visitor.reason_for_visit ||
            'N/A',
          status:
            visitor.status || (visitor.black_listed ? 'Blacklisted' : 'Active'),
          visitDuration: visitor.visit_duration || 'N/A',
          vehicleMaterial: visitor.vm_bool
            ? 'Vehicle'
            : visitor.mm_bool
              ? 'Material'
              : 'None',
          groupBooking: visitor.grp_book_bool ? 'Group' : 'Individual',
          // API fields for Vehicle/Material
          vm_bool: visitor.vm_bool || false,
          mm_bool: visitor.mm_bool || false,
          vm_details: visitor.vm_details || [],
          mm_details: visitor.mm_details || [],
          // API fields for Group Booking
          grp_book_bool: visitor.grp_book_bool || false,
          grp_details: visitor.grp_details || [],
          // Additional fields for debugging
          user_id: visitor.user_id,
          action: visitor.action,
          black_listed: visitor.black_listed || false,
        }))

        // Debug: Log transformed data to see all fields
        if (transformedData.length > 0) {
          console.log('Sample transformed data:', transformedData[0])
          console.log('Total transformed bookings:', transformedData.length)
        } else {
          console.log('No transformed data available')
        }

        setBookings(transformedData)
      } catch (error) {
        console.error('Error fetching bookings:', error)
        setError('Failed to load bookings')
        toast.error('Failed to load bookings')
        setBookings([])
      } finally {
        setApiLoading(false)
      }
    },
    [branchId, auth?.org_id, selectedDate],
  )

  // Branches are now fetched automatically by useQuery

  // Fetch bookings when branches are loaded and branch is selected
  useEffect(() => {
    console.log('🔍 useEffect for fetchBookings triggered:', {
      branchId,
      org_id: auth?.org_id,
      branchesLength: branches.length,
      willFetch: !!(branchId && auth?.org_id && branches.length > 0),
    })
    if (branchId && auth?.org_id && branches.length > 0) {
      console.log('✅ Conditions met, calling fetchBookings()')
      fetchBookings()
    } else {
      console.log('❌ Conditions not met for fetchBookings')
    }
  }, [branchId, auth.org_id, branches.length, fetchBookings])

  // Filter functionality
  useEffect(() => {
    console.log('Filter useEffect triggered')
    console.log('Original bookings count:', bookings.length)
    console.log('Current filters:', filters)

    let filtered = bookings

    // Apply filters
    if (filters.name) {
      filtered = filtered.filter((booking) =>
        booking.name?.toLowerCase().includes(filters.name.toLowerCase()),
      )
    }

    if (filters.visitStartDate) {
      filtered = filtered.filter((booking) =>
        booking.visitStartDate?.includes(filters.visitStartDate),
      )
    }

    if (filters.visitEndDate) {
      filtered = filtered.filter((booking) =>
        booking.visitEndDate?.includes(filters.visitEndDate),
      )
    }

    if (filters.visitStartTime) {
      filtered = filtered.filter((booking) =>
        booking.visitStartTime
          ?.toLowerCase()
          .includes(filters.visitStartTime.toLowerCase()),
      )
    }

    if (filters.visitEndTime) {
      filtered = filtered.filter((booking) =>
        booking.visitEndTime
          ?.toLowerCase()
          .includes(filters.visitEndTime.toLowerCase()),
      )
    }

    if (filters.category) {
      filtered = filtered.filter((booking) =>
        booking.category
          ?.toLowerCase()
          .includes(filters.category.toLowerCase()),
      )
    }

    if (filters.phoneNumber) {
      filtered = filtered.filter((booking) =>
        booking.phoneNumber?.includes(filters.phoneNumber),
      )
    }

    if (filters.vehicleMaterial) {
      filtered = filtered.filter((booking) =>
        booking.vehicleMaterial
          ?.toLowerCase()
          .includes(filters.vehicleMaterial.toLowerCase()),
      )
    }

    if (filters.groupBooking) {
      filtered = filtered.filter((booking) =>
        booking.groupBooking
          ?.toLowerCase()
          .includes(filters.groupBooking.toLowerCase()),
      )
    }

    console.log('Filtered bookings count:', filtered.length)
    setFilteredBookings(filtered)
    setPage(1) // Reset to first page when filtering
  }, [filters, bookings])

  const handleFilterChange = (field, value) => {
    setFilters((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  // Handle date change
  const handleDateChange = (date) => {
    console.log('Date changed to:', date)
    console.log('Formatted date for API:', formatDate(date))
    setSelectedDate(date)
    fetchBookings(date)
  }

  // Handle branch change
  const handleBranchChange = (event) => {
    const newBranchId = event.target.value
    setSelectedBranch(newBranchId)
    setBranchId(newBranchId)
    // Note: fetchBookings will be called automatically by useEffect when branchId changes
  }

  // Modal handlers
  const handleVehicleMaterialClick = async (booking) => {
    setSelectedBooking(booking)
    setVehicleModalOpen(true)
    setVehicleLoading(true)

    try {
      // Keep the original structure with material details nested in each vehicle
      console.log('🔍 Vehicle Details with Materials:', booking.vm_details)

      // Use data directly from getAllVisitors API response
      setApiData((prev) => ({
        ...prev,
        vehicleMaterial: {
          vm_bool: booking.vm_bool,
          mm_bool: booking.mm_bool,
          vm_details: booking.vm_details || [],
          mm_details: [], // Keep empty as materials are now in vm_details
        },
      }))
    } catch (error) {
      console.error('Error loading vehicle/material details:', error)
      toast.error('Failed to load vehicle/material details')
    } finally {
      setVehicleLoading(false)
    }
  }

  const handleGroupBookingClick = async (booking) => {
    console.log('🎯 GROUP BOOKING BUTTON CLICKED!', booking)
    setSelectedBooking(booking)
    setGroupModalOpen(true)
    setGroupLoading(true)

    try {
      // Use data directly from getAllVisitors API response
      console.log('🎯 Setting apiData with booking:', booking)
      console.log('🎯 Booking grp_details:', booking.grp_details)
      setApiData((prev) => ({
        ...prev,
        groupBooking: {
          grp_book_bool: booking.grp_book_bool,
          grp_details: booking.grp_details || [],
        },
      }))

      // Automatically load attendance data for all group members
      if (booking.grp_details && Array.isArray(booking.grp_details)) {
        console.log(
          '🎯 Auto-loading attendance for all group members...',
          booking.grp_details.length,
        )
        console.log('🎯 Full booking data:', booking)
        for (let index = 0; index < booking.grp_details.length; index++) {
          const member = booking.grp_details[index]
          console.log(`🎯 Auto-loading for member ${index}:`, member)
          console.log(
            `🎯 Member ${index} attendanceData:`,
            member.attendanceData,
          )
          const result = await fetchMemberAttendance(member, index)
          console.log(`🎯 Result for member ${index}:`, result)
        }
      }
    } catch (error) {
      console.error('Error loading group booking details:', error)
      toast.error('Failed to load group booking details')
    } finally {
      setGroupLoading(false)
    }
  }

  const handleCloseModals = () => {
    setVehicleModalOpen(false)
    setGroupModalOpen(false)
    setSelectedBooking(null)
    setApiData({
      vehicleMaterial: null,
      groupBooking: null,
    })
    setMemberAttendanceData({})
    setLoadingAttendance({})
    setExpandedCheckinDropdowns({}) // Reset dropdown states
  }

  // Function to fetch attendance data for a specific member
  const fetchMemberAttendance = async (member, memberIndex) => {
    const memberKey = `${member.grp_user_unique_id}_${memberIndex}`

    // Check if we already have data for this member
    if (memberAttendanceData[memberKey]) {
      return memberAttendanceData[memberKey]
    }

    // Set loading state
    setLoadingAttendance((prev) => ({ ...prev, [memberKey]: true }))

    try {
      console.log('🎯 fetchMemberAttendance called for:', member)
      console.log('🎯 Member attendanceData:', member.attendanceData)
      console.log('🎯 Member key:', memberKey)

      // First, check if the member has attendance data directly
      if (
        member.attendanceData &&
        Array.isArray(member.attendanceData) &&
        member.attendanceData.length > 0
      ) {
        console.log('🔍 Checking member.attendanceData:', {
          hasAttendanceData: !!member.attendanceData,
          isArray: Array.isArray(member.attendanceData),
          length: member.attendanceData?.length,
          data: member.attendanceData,
        })

        // Process all attendance records to show complete tracking
        const allAttendanceRecords = []
        let latestEntry = null
        let latestExit = null

        member.attendanceData.forEach((attendance) => {
          // Process entry times
          if (attendance.entry_time && attendance.entry_time !== '-') {
            allAttendanceRecords.push({
              type: 'entry',
              time: attendance.entry_time,
              timestamp: new Date(attendance.entry_time),
            })
            // Track the latest entry
            if (
              !latestEntry ||
              new Date(attendance.entry_time) > new Date(latestEntry)
            ) {
              latestEntry = attendance.entry_time
            }
          }

          // Process exit times
          if (attendance.exit_time && attendance.exit_time !== '-') {
            allAttendanceRecords.push({
              type: 'exit',
              time: attendance.exit_time,
              timestamp: new Date(attendance.exit_time),
            })
            // Track the latest exit
            if (
              !latestExit ||
              new Date(attendance.exit_time) > new Date(latestExit)
            ) {
              latestExit = attendance.exit_time
            }
          }
        })

        console.log('🔍 PROCESSED allAttendanceRecords:', allAttendanceRecords)

        // Sort by timestamp to show chronological order
        allAttendanceRecords.sort((a, b) => a.timestamp - b.timestamp)

        // Create the attendance data object
        const attendanceData = {
          allRecords: allAttendanceRecords,
          entry_time: latestEntry || '-',
          exit_time: latestExit || '-',
          visitor_code: member.attendanceData[0]?.visitor_code || '',
          user_id: member.grp_user_unique_id,
          name: member.grp_user_name,
          email: member.grp_user_email,
          ph_no: member.grp_user_phno,
        }

        console.log('✅ Processed attendance data:', attendanceData)
        setMemberAttendanceData((prev) => {
          const newData = {
            ...prev,
            [memberKey]: attendanceData,
          }
          console.log('💾 Storing attendance data:', newData)
          return newData
        })

        return attendanceData
      }

      // If no direct attendance data, call getAllVisitors API
      console.log(
        '❌ No attendanceData found in member, trying getAllVisitors API',
      )
      console.log('🔍 Member details:', {
        name: member.grp_user_name,
        email: member.grp_user_email,
        phone: member.grp_user_phno,
        uniqueId: member.grp_user_unique_id,
      })

      const requestData = {
        org_id: auth.org_id,
        branch_id: branchId,
        data_of_visit: formatDate(selectedDate),
        role: auth.role == '1' ? '' : auth.role,
      }

      // Get visitor data from getAllVisitors API
      const response = await getAllVisitors(requestData)
      console.log('getAllVisitors API response:', response)

      // Extract visitor data from the response
      let visitorsData = []
      if (
        response?.arrivedVisitorsList &&
        Array.isArray(response.arrivedVisitorsList)
      ) {
        visitorsData = response.arrivedVisitorsList
      } else if (
        response?.visitors_List &&
        Array.isArray(response.visitors_List)
      ) {
        visitorsData = response.visitors_List
      }

      console.log('Available visitors data:', visitorsData.length)

      // Find the matching visitor for this group member
      console.log('🔍 Searching for member in visitorsData:', {
        memberEmail: member.grp_user_email,
        memberPhone: member.grp_user_phno,
        memberUniqueId: member.grp_user_unique_id,
        totalVisitors: visitorsData.length,
      })

      // Log all visitors for debugging
      visitorsData.forEach((visitor, idx) => {
        console.log(`🔍 Visitor ${idx}:`, {
          email: visitor.email,
          ph_no: visitor.ph_no,
          user_id: visitor.user_id,
          visitor_code: visitor.visitor_code,
          name: visitor.name || visitor.first_name || visitor.visitor_name,
          entry_time: visitor.entry_time,
          exit_time: visitor.exit_time,
          grp_details: visitor.grp_details,
          grp_book_bool: visitor.grp_book_bool,
          isVisited: visitor.isVisited,
        })

        // Log group details if they exist
        if (visitor.grp_details && Array.isArray(visitor.grp_details)) {
          visitor.grp_details.forEach((grpMember, grpIdx) => {
            console.log(`  📋 Group Member ${grpIdx}:`, {
              name: grpMember.grp_user_name,
              email: grpMember.grp_user_email,
              phone: grpMember.grp_user_phno,
              uniqueId: grpMember.grp_user_unique_id,
              attendanceData: grpMember.attendanceData,
            })
          })
        }
      })

      // First, try to find the member directly in the group details of arrived visitors
      let memberAttendance = null
      let foundInGroupDetails = false

      for (const visitor of visitorsData) {
        if (visitor.grp_details && Array.isArray(visitor.grp_details)) {
          const groupMember = visitor.grp_details.find((grpMember) => {
            return (
              grpMember.grp_user_email === member.grp_user_email ||
              grpMember.grp_user_phno === member.grp_user_phno ||
              grpMember.grp_user_unique_id === member.grp_user_unique_id
            )
          })

          if (
            groupMember &&
            groupMember.attendanceData &&
            groupMember.attendanceData.length > 0
          ) {
            console.log(
              '✅ Found member in group details with attendance data:',
              groupMember,
            )
            memberAttendance = groupMember
            foundInGroupDetails = true
            break
          }
        }
      }

      // If not found in group details, try the old matching logic
      if (!foundInGroupDetails) {
        memberAttendance = visitorsData.find((visitor) => {
          // Try multiple matching strategies
          const emailMatch = visitor.email === member.grp_user_email
          const phoneMatch = visitor.ph_no === member.grp_user_phno
          const userIdMatch = visitor.user_id === member.grp_user_unique_id
          const visitorCodeMatch =
            visitor.visitor_code &&
            member.grp_user_phno &&
            visitor.visitor_code.includes(member.grp_user_phno.slice(-4))

          // Also try matching by name (first name + last name)
          const visitorName =
            (visitor.first_name || '') + ' ' + (visitor.last_name || '')
          const memberName = member.grp_user_name || ''
          const nameMatch =
            visitorName.trim().toLowerCase() === memberName.trim().toLowerCase()

          // Try matching with phone number variations (with/without country code)
          const phoneMatchWithExt =
            visitor.phNo === member.grp_user_phno ||
            visitor.phNo === member.grp_user_phext + member.grp_user_phno

          // Try matching visitor_id with grp_user_unique_id
          const visitorIdMatch =
            visitor.visitor_id === member.grp_user_unique_id

          console.log('🔍 Matching attempt:', {
            emailMatch,
            phoneMatch,
            userIdMatch,
            visitorCodeMatch,
            nameMatch,
            phoneMatchWithExt,
            visitorIdMatch,
            visitorEmail: visitor.email,
            visitorPhone: visitor.ph_no,
            visitorPhNo: visitor.phNo,
            visitorUserId: visitor.user_id,
            visitorId: visitor.visitor_id,
            visitorName: visitorName.trim(),
            memberName: memberName.trim(),
            memberPhoneExt: member.grp_user_phext,
            memberPhone: member.grp_user_phno,
          })

          return (
            emailMatch ||
            phoneMatch ||
            userIdMatch ||
            visitorCodeMatch ||
            nameMatch ||
            phoneMatchWithExt ||
            visitorIdMatch
          )
        })
      }

      if (memberAttendance) {
        console.log('✅ Found matching visitor:', memberAttendance)

        let attendanceData = null

        if (
          foundInGroupDetails &&
          memberAttendance.attendanceData &&
          memberAttendance.attendanceData.length > 0
        ) {
          // Use the attendance data from the group member
          console.log(
            '📊 Processing group member attendance data:',
            memberAttendance.attendanceData,
          )

          // Process all attendance records to show complete tracking
          const allAttendanceRecords = []
          let latestEntry = null
          let latestExit = null

          memberAttendance.attendanceData.forEach((attendance) => {
            // Process entry times
            if (attendance.entry_time && attendance.entry_time !== '-') {
              allAttendanceRecords.push({
                type: 'entry',
                time: attendance.entry_time,
                timestamp: new Date(attendance.entry_time),
              })
              // Track the latest entry
              if (
                !latestEntry ||
                new Date(attendance.entry_time) > new Date(latestEntry)
              ) {
                latestEntry = attendance.entry_time
              }
            }

            // Process exit times
            if (attendance.exit_time && attendance.exit_time !== '-') {
              allAttendanceRecords.push({
                type: 'exit',
                time: attendance.exit_time,
                timestamp: new Date(attendance.exit_time),
              })
              // Track the latest exit
              if (
                !latestExit ||
                new Date(attendance.exit_time) > new Date(latestExit)
              ) {
                latestExit = attendance.exit_time
              }
            }
          })

          // Sort by timestamp to show chronological order
          allAttendanceRecords.sort((a, b) => a.timestamp - b.timestamp)

          attendanceData = {
            allRecords: allAttendanceRecords,
            entry_time: latestEntry || '-',
            exit_time: latestExit || '-',
            visitor_code:
              memberAttendance.attendanceData[0]?.visitor_code || '-',
            user_id: memberAttendance.attendanceData[0]?.user_id || '-',
            name: member.grp_user_name,
            email: member.grp_user_email,
            ph_no: member.grp_user_phno,
          }
        } else {
          // Use the main visitor's attendance data
          attendanceData = {
            entry_time: memberAttendance.entry_time || '-',
            exit_time: memberAttendance.exit_time || '-',
            visitor_code: memberAttendance.visitor_code,
            user_id: memberAttendance.user_id,
            name: member.grp_user_name,
            email: member.grp_user_email,
            ph_no: member.grp_user_phno,
          }
        }

        console.log('📅 Final attendance data:', attendanceData)

        // Store the attendance data
        setMemberAttendanceData((prev) => ({
          ...prev,
          [memberKey]: attendanceData,
        }))

        return attendanceData
      } else {
        console.log('❌ No matching visitor found for member:', member)

        // Try one more approach - check if this member is part of a group booking visitor
        console.log('🔍 Trying to find group booking visitor...')
        const groupBookingVisitor = visitorsData.find((visitor) => {
          return (
            visitor.grp_book_bool &&
            visitor.grp_details &&
            visitor.grp_details.some(
              (grpMember) =>
                grpMember.grp_user_email === member.grp_user_email ||
                grpMember.grp_user_phno === member.grp_user_phno ||
                grpMember.grp_user_unique_id === member.grp_user_unique_id,
            )
          )
        })

        if (groupBookingVisitor) {
          console.log('✅ Found group booking visitor:', groupBookingVisitor)

          // Use the main visitor's attendance data
          const attendanceData = {
            entry_time: groupBookingVisitor.entry_time || '-',
            exit_time: groupBookingVisitor.exit_time || '-',
            visitor_code: groupBookingVisitor.visitor_code,
            user_id: groupBookingVisitor.user_id,
            name: member.grp_user_name,
            email: member.grp_user_email,
            ph_no: member.grp_user_phno,
          }

          // Store the attendance data
          setMemberAttendanceData((prev) => ({
            ...prev,
            [memberKey]: attendanceData,
          }))

          return attendanceData
        }

        // Return null if no match found
        setMemberAttendanceData((prev) => ({
          ...prev,
          [memberKey]: null,
        }))

        return null
      }
    } catch (error) {
      console.error('Error fetching member attendance:', error)
      toast.error('Failed to fetch attendance data')
      return null
    } finally {
      // Clear loading state
      setLoadingAttendance((prev) => ({ ...prev, [memberKey]: false }))
    }
  }

  // Toggle handler for PDF/CSV
  const handleToggle = () => {
    setIsPDF(!isPDF)
  }

  // Download functions for CSV
  const downloadGroupBookingCSV = () => {
    const groupBookings = filteredBookings.filter(
      (booking) => booking.grp_book_bool,
    )

    if (groupBookings.length === 0) {
      toast.error('No group booking data available to download')
      return
    }

    const csvData = groupBookings.map((booking) => ({
      Name: booking.name || 'N/A',
      'Visit Start Date': booking.visitStartDate || 'N/A',
      'Visit End Date': booking.visitEndDate || 'N/A',
      'Visit Start Time': booking.visitStartTime || 'N/A',
      'Visit End Time': booking.visitEndTime || 'N/A',
      Category: booking.category || 'N/A',
      'Phone Number': booking.phoneNumber || 'N/A',
      'Group Booking': booking.grp_book_bool ? 'Yes' : 'No',
    }))

    const csv = Papa.unparse(csvData)
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    saveAs(blob, 'group_booking_data.csv')
  }

  const downloadVehicleMaterialCSV = () => {
    const vehicleMaterialBookings = filteredBookings.filter(
      (booking) => booking.vm_bool || booking.mm_bool,
    )

    if (vehicleMaterialBookings.length === 0) {
      toast.error('No vehicle/material data available to download')
      return
    }

    const csvData = vehicleMaterialBookings.map((booking) => ({
      Name: booking.name || 'N/A',
      'Visit Start Date': booking.visitStartDate || 'N/A',
      'Visit End Date': booking.visitEndDate || 'N/A',
      'Visit Start Time': booking.visitStartTime || 'N/A',
      'Visit End Time': booking.visitEndTime || 'N/A',
      Category: booking.category || 'N/A',
      'Phone Number': booking.phoneNumber || 'N/A',
      'Vehicle/Material': booking.vm_bool || booking.mm_bool ? 'Yes' : 'No',
    }))

    const csv = Papa.unparse(csvData)
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    saveAs(blob, 'vehicle_material_data.csv')
  }

  // Download functions for PDF
  const downloadGroupBookingPDF = () => {
    const groupBookings = filteredBookings.filter(
      (booking) => booking.grp_book_bool,
    )

    if (groupBookings.length === 0) {
      toast.error('No group booking data available to download')
      return
    }

    const doc = new jsPDF()

    // Simple, clean header with 12px spacing
    doc.setFontSize(20)
    doc.text('Group Booking Report', 14, 30)
    doc.setFontSize(12)

    // Admin name with 12px spacing
    doc.text(`Admin: ${auth?.username || 'N/A'}`, 14, 50)

    // Branch name with 12px spacing
    doc.text(`Branch: ${selectedBranch?.branch_name || 'N/A'}`, 14, 62)

    // Date information with 12px spacing
    let dateText = ''
    if (selectedDate) {
      const visitDate = formatDate(selectedDate)
      dateText = `Date: ${visitDate}`
    } else {
      dateText = 'Date: All Time'
    }
    doc.text(dateText, 14, 74)

    // Generated on with 12px spacing
    const now = new Date()
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`
    doc.text(`Generated on: ${formatDate(now)} ${timeStr}`, 14, 86)

    // Prepare table data
    const tableColumns = [
      'Name',
      'Visit Start Date',
      'Visit End Date',
      'Visit Start Time',
      'Visit End Time',
      'Category',
      'Phone Number',
    ]
    const tableRows = groupBookings.map((booking) => [
      booking.name || 'N/A',
      booking.visitStartDate || 'N/A',
      booking.visitEndDate || 'N/A',
      booking.visitStartTime || 'N/A',
      booking.visitEndTime || 'N/A',
      booking.category || 'N/A',
      booking.phoneNumber || 'N/A',
    ])

    // Add table with elegant styling
    doc.autoTable({
      startY: 85, // Increased from 75 to 85 to accommodate larger header spacing
      head: [tableColumns],
      body: tableRows,
      tableWidth: 'wrap', // Use full page width
      margin: { left: 0, right: 0, top: 5, bottom: 5 }, // Zero margins for absolute full width
      styles: {
        fontSize: 8, // Font size like in the image
        cellPadding: 4, // Compact padding like in the image
        lineColor: [200, 200, 200], // Light gray grid lines like in the image
        lineWidth: 0.5, // Visible grid lines
        textColor: [0, 0, 0], // Black text like in the image
        valign: 'middle',
        halign: 'center', // Center alignment like in the image
        minCellHeight: 25, // Row height like in the image
      },
      headStyles: {
        fillColor: [39, 174, 96], // Green header
        textColor: [255, 255, 255], // White text
        fontSize: 12, // Larger header font
        fontStyle: 'bold',
        cellPadding: 8, // Increased header padding
        minCellHeight: 14, // Increased header row height
      },
      alternateRowStyles: {
        fillColor: [248, 249, 250], // Light gray alternating rows
      },
      horizontalPageBreak: true,
    })

    doc.save('group_booking_report.pdf')
  }

  const downloadVehicleMaterialPDF = () => {
    const vehicleMaterialBookings = filteredBookings.filter(
      (booking) => booking.vm_bool || booking.mm_bool,
    )

    if (vehicleMaterialBookings.length === 0) {
      toast.error('No vehicle/material data available to download')
      return
    }

    const doc = new jsPDF({
      orientation: 'landscape',
      unit: 'mm',
      format: [842, 595], // A4 landscape size
    })

    // Beautiful header with elegant styling
    doc.setFillColor(39, 174, 96) // Green background
    doc.rect(0, 0, doc.internal.pageSize.width, 40, 'F')

    // Add white text on green background
    doc.setTextColor(255, 255, 255)
    doc.setFontSize(20)
    doc.setFont(undefined, 'bold')
    doc.text('Vehicle/Material Report', 14, 15)

    // Add header details in a beautiful box
    doc.setFillColor(248, 249, 250) // Light gray background
    doc.rect(10, 45, doc.internal.pageSize.width - 20, 30, 'F')
    doc.setDrawColor(39, 174, 96) // Green border
    doc.setLineWidth(1.5)
    doc.rect(10, 45, doc.internal.pageSize.width - 20, 30, 'S')

    // Add content in the box with better spacing
    doc.setTextColor(40, 40, 40)
    doc.setFontSize(18) // Further increased from 14 to 18
    doc.setFont(undefined, 'normal')
    doc.text(`Admin: ${auth?.username || 'N/A'}`, 15, 58)
    doc.text(`Branch: ${selectedBranch?.branch_name || 'N/A'}`, 15, 64)

    // Add date range information
    let dateText = ''
    if (selectedDate) {
      const visitDate = formatDate(selectedDate)
      dateText = `Date: ${visitDate}`
    } else {
      dateText = 'Date: All Time'
    }
    doc.text(dateText, 15, 70)

    // Add generation time in smaller text
    doc.setFontSize(16) // Further increased from 12 to 16
    doc.setTextColor(100, 100, 100)
    const now = new Date()
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`
    doc.text(`Generated on: ${formatDate(now)} ${timeStr}`, 15, 76)

    // Prepare table data
    const tableColumns = [
      'Name',
      'Visit Start Date',
      'Visit End Date',
      'Visit Start Time',
      'Visit End Time',
      'Category',
      'Phone Number',
    ]
    const tableRows = vehicleMaterialBookings.map((booking) => [
      booking.name || 'N/A',
      booking.visitStartDate || 'N/A',
      booking.visitEndDate || 'N/A',
      booking.visitStartTime || 'N/A',
      booking.visitEndTime || 'N/A',
      booking.category || 'N/A',
      booking.phoneNumber || 'N/A',
    ])

    // Add table with elegant styling
    doc.autoTable({
      startY: 85, // Increased from 75 to 85 to accommodate larger header spacing
      head: [tableColumns],
      body: tableRows,
      tableWidth: 'wrap', // Use full page width
      styles: {
        fontSize: 15, // Maximized font size for optimal readability
        cellPadding: 6, // Increased padding for better spacing
        overflow: 'linebreak',
        halign: 'left',
        textColor: [0, 0, 0], // Black text for data rows
        // Grid lines removed for cleaner look
      },
      headStyles: {
        fillColor: [39, 174, 96], // Green header matching Visitor Reports
        fontSize: 15, // Maximized font size for optimal readability
        fontStyle: 'bold',
        textColor: [255, 255, 255], // White text for header
        halign: 'center',
        valign: 'middle',
        // Grid lines removed for cleaner look
      },
      columnStyles: {
        // Column widths maximized to use full page width - no grid lines
        0: { cellWidth: 90, halign: 'left' }, // Name
        1: { cellWidth: 100, halign: 'center' }, // Visit Start Date
        2: { cellWidth: 100, halign: 'center' }, // Visit End Date
        3: { cellWidth: 100, halign: 'center' }, // Visit Start Time
        4: { cellWidth: 100, halign: 'center' }, // Visit End Time
        5: { cellWidth: 90, halign: 'center' }, // Category
        6: { cellWidth: 100, halign: 'center' }, // Phone Number
      },
      horizontalPageBreak: true,
    })

    doc.save('vehicle_material_report.pdf')
  }

  return (
    <Box
      sx={{
        p: 3,
        backgroundColor: '#F8F8F8',
        minHeight: '100vh',
      }}
    >
      {/* Main Content Area */}
      <Box>
        {/* Header */}
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            mb: 3,
          }}
        >
          <Typography
            variant="h4"
            sx={{ fontWeight: 'bold', color: '#333333' }}
          >
            Vehicle/Group Booking
          </Typography>
          <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
            <Typography variant="body2" sx={{ mr: 1 }}>
              Branch:
            </Typography>
            <FormControl size="small" sx={{ minWidth: 150 }}>
              <InputLabel>Select Branch</InputLabel>
              <Select
                value={selectedBranch}
                onChange={handleBranchChange}
                label="Select Branch"
                sx={{
                  backgroundColor: 'white',
                }}
              >
                {branches.map((branch) => (
                  <MenuItem
                    key={branch.branch_id || branch.id}
                    value={branch.branch_id || branch.id}
                  >
                    {branch.branch_name || branch.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <Typography variant="body2" sx={{ mr: 1 }}>
              Filter by Date:
            </Typography>
            <Box sx={{ position: 'relative' }}>
              <TextField
                type="date"
                value={selectedDate.toISOString().split('T')[0]}
                onChange={(e) => handleDateChange(new Date(e.target.value))}
                size="small"
                sx={{
                  '& .MuiOutlinedInput-root': {
                    backgroundColor: 'white',
                  },
                  '& input[type="date"]': {
                    color: 'transparent',
                    '&::-webkit-calendar-picker-indicator': {
                      opacity: 1,
                      cursor: 'pointer',
                      position: 'absolute',
                      right: '8px',
                      top: '50%',
                      transform: 'translateY(-50%)',
                    },
                  },
                }}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <CalendarTodayIcon />
                    </InputAdornment>
                  ),
                }}
              />
              <Typography
                variant="body2"
                sx={{
                  position: 'absolute',
                  left: '40px',
                  top: '50%',
                  transform: 'translateY(-50%)',
                  color: '#333',
                  fontSize: '14px',
                  pointerEvents: 'none',
                  zIndex: 1,
                }}
              >
                {formatDate(selectedDate)}
              </Typography>
            </Box>
          </Box>
        </Box>

        {/* Search Bar - Removed as per image design */}

        {/* Bookings Table */}
        <Paper
          elevation={2}
          sx={{
            backgroundColor: '#FFFFFF',
            borderRadius: 2,
            overflow: 'hidden',
          }}
        >
          <TableContainer sx={{ overflowX: 'auto' }}>
            <Table>
              <TableHead>
                <TableRow sx={{ backgroundColor: '#f5f5f5' }}>
                  <TableCell sx={{ fontWeight: 'bold' }}>Name</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>
                    Visit Start Date
                  </TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>
                    Visit End Date
                  </TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>
                    Visit Start Time
                  </TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>
                    Visit End Time
                  </TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Category</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>
                    Phone Number
                  </TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>
                    Vehicle/Material
                  </TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>
                    Group Booking
                  </TableCell>
                </TableRow>
                {/* Filter Row */}
                <TableRow sx={{ backgroundColor: '#fafafa' }}>
                  <TableCell sx={{ padding: '8px' }}>
                    <TextField
                      size="small"
                      variant="standard"
                      value={filters.name}
                      onChange={(e) =>
                        handleFilterChange('name', e.target.value)
                      }
                      placeholder=""
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <FilterListIcon fontSize="small" />
                          </InputAdornment>
                        ),
                      }}
                      sx={{
                        width: '100%',
                        '& .MuiInput-underline:before': {
                          borderBottom: '1px solid #e0e0e0',
                        },
                        '& .MuiInput-underline:hover:not(.Mui-disabled):before':
                          {
                            borderBottom: '1px solid #e0e0e0',
                          },
                        '& .MuiInput-underline:after': {
                          borderBottom: '1px solid #e0e0e0',
                        },
                      }}
                    />
                  </TableCell>
                  <TableCell sx={{ padding: '8px' }}>
                    <TextField
                      size="small"
                      variant="standard"
                      value={filters.visitStartDate}
                      onChange={(e) =>
                        handleFilterChange('visitStartDate', e.target.value)
                      }
                      placeholder=""
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <FilterListIcon fontSize="small" />
                          </InputAdornment>
                        ),
                      }}
                      sx={{
                        width: '100%',
                        '& .MuiInput-underline:before': {
                          borderBottom: '1px solid #e0e0e0',
                        },
                        '& .MuiInput-underline:hover:not(.Mui-disabled):before':
                          {
                            borderBottom: '1px solid #e0e0e0',
                          },
                        '& .MuiInput-underline:after': {
                          borderBottom: '1px solid #e0e0e0',
                        },
                      }}
                    />
                  </TableCell>
                  <TableCell sx={{ padding: '8px' }}>
                    <TextField
                      size="small"
                      variant="standard"
                      value={filters.visitEndDate}
                      onChange={(e) =>
                        handleFilterChange('visitEndDate', e.target.value)
                      }
                      placeholder=""
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <FilterListIcon fontSize="small" />
                          </InputAdornment>
                        ),
                      }}
                      sx={{
                        width: '100%',
                        '& .MuiInput-underline:before': {
                          borderBottom: '1px solid #e0e0e0',
                        },
                        '& .MuiInput-underline:hover:not(.Mui-disabled):before':
                          {
                            borderBottom: '1px solid #e0e0e0',
                          },
                        '& .MuiInput-underline:after': {
                          borderBottom: '1px solid #e0e0e0',
                        },
                      }}
                    />
                  </TableCell>
                  <TableCell sx={{ padding: '8px' }}>
                    <TextField
                      size="small"
                      variant="standard"
                      value={filters.visitStartTime}
                      onChange={(e) =>
                        handleFilterChange('visitStartTime', e.target.value)
                      }
                      placeholder=""
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <FilterListIcon fontSize="small" />
                          </InputAdornment>
                        ),
                      }}
                      sx={{
                        width: '100%',
                        '& .MuiInput-underline:before': {
                          borderBottom: '1px solid #e0e0e0',
                        },
                        '& .MuiInput-underline:hover:not(.Mui-disabled):before':
                          {
                            borderBottom: '1px solid #e0e0e0',
                          },
                        '& .MuiInput-underline:after': {
                          borderBottom: '1px solid #e0e0e0',
                        },
                      }}
                    />
                  </TableCell>
                  <TableCell sx={{ padding: '8px' }}>
                    <TextField
                      size="small"
                      variant="standard"
                      value={filters.visitEndTime}
                      onChange={(e) =>
                        handleFilterChange('visitEndTime', e.target.value)
                      }
                      placeholder=""
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <FilterListIcon fontSize="small" />
                          </InputAdornment>
                        ),
                      }}
                      sx={{
                        width: '100%',
                        '& .MuiInput-underline:before': {
                          borderBottom: '1px solid #e0e0e0',
                        },
                        '& .MuiInput-underline:hover:not(.Mui-disabled):before':
                          {
                            borderBottom: '1px solid #e0e0e0',
                          },
                        '& .MuiInput-underline:after': {
                          borderBottom: '1px solid #e0e0e0',
                        },
                      }}
                    />
                  </TableCell>
                  <TableCell sx={{ padding: '8px' }}>
                    <TextField
                      size="small"
                      variant="standard"
                      value={filters.category}
                      onChange={(e) =>
                        handleFilterChange('category', e.target.value)
                      }
                      placeholder=""
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <FilterListIcon fontSize="small" />
                          </InputAdornment>
                        ),
                      }}
                      sx={{
                        width: '100%',
                        '& .MuiInput-underline:before': {
                          borderBottom: '1px solid #e0e0e0',
                        },
                        '& .MuiInput-underline:hover:not(.Mui-disabled):before':
                          {
                            borderBottom: '1px solid #e0e0e0',
                          },
                        '& .MuiInput-underline:after': {
                          borderBottom: '1px solid #e0e0e0',
                        },
                      }}
                    />
                  </TableCell>
                  <TableCell sx={{ padding: '8px' }}>
                    <TextField
                      size="small"
                      variant="standard"
                      value={filters.phoneNumber}
                      onChange={(e) =>
                        handleFilterChange('phoneNumber', e.target.value)
                      }
                      placeholder=""
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <FilterListIcon fontSize="small" />
                          </InputAdornment>
                        ),
                      }}
                      sx={{
                        width: '100%',
                        '& .MuiInput-underline:before': {
                          borderBottom: '1px solid #e0e0e0',
                        },
                        '& .MuiInput-underline:hover:not(.Mui-disabled):before':
                          {
                            borderBottom: '1px solid #e0e0e0',
                          },
                        '& .MuiInput-underline:after': {
                          borderBottom: '1px solid #e0e0e0',
                        },
                      }}
                    />
                  </TableCell>
                  <TableCell sx={{ padding: '8px' }}>
                    <TextField
                      size="small"
                      variant="standard"
                      value={filters.vehicleMaterial}
                      onChange={(e) =>
                        handleFilterChange('vehicleMaterial', e.target.value)
                      }
                      placeholder="Filter by vehicle/material..."
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <FilterListIcon fontSize="small" />
                          </InputAdornment>
                        ),
                      }}
                      sx={{
                        width: '100%',
                        '& .MuiInput-underline:before': {
                          borderBottom: '1px solid #e0e0e0',
                        },
                        '& .MuiInput-underline:hover:not(.Mui-disabled):before':
                          {
                            borderBottom: '1px solid #e0e0e0',
                          },
                        '& .MuiInput-underline:after': {
                          borderBottom: '1px solid #e0e0e0',
                        },
                      }}
                    />
                  </TableCell>
                  <TableCell sx={{ padding: '8px' }}>
                    <TextField
                      size="small"
                      variant="standard"
                      value={filters.groupBooking}
                      onChange={(e) =>
                        handleFilterChange('groupBooking', e.target.value)
                      }
                      placeholder="Filter by group booking..."
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <FilterListIcon fontSize="small" />
                          </InputAdornment>
                        ),
                      }}
                      sx={{
                        width: '100%',
                        '& .MuiInput-underline:before': {
                          borderBottom: '1px solid #e0e0e0',
                        },
                        '& .MuiInput-underline:hover:not(.Mui-disabled):before':
                          {
                            borderBottom: '1px solid #e0e0e0',
                          },
                        '& .MuiInput-underline:after': {
                          borderBottom: '1px solid #e0e0e0',
                        },
                      }}
                    />
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={9} align="center">
                      <CircularProgress />
                    </TableCell>
                  </TableRow>
                ) : filteredBookings.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={9} align="center">
                      <Typography variant="body2" color="text.secondary">
                        No bookings found
                      </Typography>
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredBookings
                    .slice((page - 1) * rowsPerPage, page * rowsPerPage)
                    .map((booking) => (
                      <TableRow key={booking.id} hover>
                        <TableCell>{booking.name || 'N/A'}</TableCell>
                        <TableCell>{booking.visitStartDate || 'N/A'}</TableCell>
                        <TableCell>{booking.visitEndDate || 'N/A'}</TableCell>
                        <TableCell>{booking.visitStartTime || 'N/A'}</TableCell>
                        <TableCell>{booking.visitEndTime || 'N/A'}</TableCell>
                        <TableCell>{booking.category || 'N/A'}</TableCell>
                        <TableCell>{booking.phoneNumber || 'N/A'}</TableCell>
                        <TableCell>
                          <Button
                            variant="contained"
                            size="small"
                            onClick={() => handleVehicleMaterialClick(booking)}
                            disabled={!booking.vm_bool && !booking.mm_bool}
                            sx={{
                              backgroundColor:
                                booking.vm_bool || booking.mm_bool
                                  ? '#1976d2'
                                  : '#ccc',
                              '&:hover': {
                                backgroundColor:
                                  booking.vm_bool || booking.mm_bool
                                    ? '#1565c0'
                                    : '#ccc',
                              },
                            }}
                          >
                            Vehicle/Material
                          </Button>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="contained"
                            size="small"
                            onClick={() => handleGroupBookingClick(booking)}
                            disabled={!booking.grp_book_bool}
                            sx={{
                              backgroundColor: booking.grp_book_bool
                                ? '#1976d2'
                                : '#ccc',
                              '&:hover': {
                                backgroundColor: booking.grp_book_bool
                                  ? '#1565c0'
                                  : '#ccc',
                              },
                            }}
                          >
                            Group Booking
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                )}
              </TableBody>
            </Table>
          </TableContainer>

          {/* Pagination */}
          {filteredBookings.length > rowsPerPage && (
            <Box sx={{ display: 'flex', justifyContent: 'center', p: 2 }}>
              <Pagination
                count={Math.ceil(filteredBookings.length / rowsPerPage)}
                page={page}
                onChange={(event, value) => setPage(value)}
                color="primary"
              />
            </Box>
          )}
        </Paper>
      </Box>

      {/* Vehicle/Material Details Modal */}
      <Dialog
        open={vehicleModalOpen}
        onClose={handleCloseModals}
        maxWidth="lg"
        fullWidth
        PaperProps={{
          sx: {
            borderRadius: 2,
            boxShadow: '0 8px 32px rgba(0,0,0,0.12)',
          },
        }}
      >
        <DialogTitle
          sx={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            backgroundColor: '#f5f5f5',
            borderBottom: '1px solid #e0e0e0',
          }}
        >
          <Box>
            <Typography
              variant="h5"
              component="div"
              sx={{ fontWeight: 'bold' }}
            >
              Vehicle & Material Records
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Manage your vehicle and material information
            </Typography>
          </Box>
          <IconButton onClick={handleCloseModals} size="small">
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        <DialogContent dividers sx={{ p: 0 }}>
          {selectedBooking && (
            <Box>
              {vehicleLoading ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
                  <CircularProgress />
                  <Typography variant="body1" sx={{ ml: 2 }}>
                    Loading vehicle/material details...
                  </Typography>
                </Box>
              ) : (
                <Box sx={{ p: 2 }}>
                  {/* Expandable Vehicle Table */}
                  {apiData.vehicleMaterial?.vm_bool &&
                    apiData.vehicleMaterial?.vm_details &&
                    apiData.vehicleMaterial?.vm_details.length > 0 && (
                      <TableContainer component={Paper} sx={{ mb: 2 }}>
                        <Table>
                          <TableHead>
                            <TableRow sx={{ backgroundColor: '#f5f5f5' }}>
                              <TableCell sx={{ width: 50 }}></TableCell>
                              <TableCell sx={{ fontWeight: 'bold' }}>
                                Vehicle Name
                              </TableCell>
                              <TableCell sx={{ fontWeight: 'bold' }}>
                                Vehicle Type
                              </TableCell>
                              <TableCell sx={{ fontWeight: 'bold' }}>
                                Driver Licence Number
                              </TableCell>
                              <TableCell sx={{ fontWeight: 'bold' }}>
                                Insurance Provider
                              </TableCell>
                              <TableCell sx={{ fontWeight: 'bold' }}>
                                Insurance Number
                              </TableCell>
                              <TableCell sx={{ fontWeight: 'bold' }}>
                                RC Numbers
                              </TableCell>
                              <TableCell sx={{ fontWeight: 'bold' }}>
                                Vehicle Comments
                              </TableCell>
                              <TableCell sx={{ fontWeight: 'bold' }}>
                                Status
                              </TableCell>
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            {apiData.vehicleMaterial?.vm_details.map(
                              (vehicle, vehicleIndex) => (
                                <React.Fragment key={vehicleIndex}>
                                  <TableRow>
                                    <TableCell>
                                      <IconButton
                                        size="small"
                                        onClick={() => {
                                          const newExpanded = {
                                            ...expandedVehicles,
                                          }
                                          newExpanded[vehicleIndex] =
                                            !newExpanded[vehicleIndex]
                                          setExpandedVehicles(newExpanded)
                                        }}
                                      >
                                        {expandedVehicles[vehicleIndex] ? (
                                          <ExpandLessIcon />
                                        ) : (
                                          <ExpandMoreIcon />
                                        )}
                                      </IconButton>
                                    </TableCell>
                                    <TableCell>
                                      {vehicle.vehicle_name || 'N/A'}
                                    </TableCell>
                                    <TableCell>
                                      {vehicle.vehicle_type || 'N/A'}
                                    </TableCell>
                                    <TableCell>
                                      {vehicle.driver_licence || 'N/A'}
                                    </TableCell>
                                    <TableCell>
                                      {vehicle.insurance_provider || 'N/A'}
                                    </TableCell>
                                    <TableCell>
                                      {vehicle.insurance_no || 'N/A'}
                                    </TableCell>
                                    <TableCell>
                                      {vehicle.rc_no || 'N/A'}
                                    </TableCell>
                                    <TableCell>
                                      {vehicle.vehicle_comments || 'N/A'}
                                    </TableCell>
                                    <TableCell>
                                      <Box
                                        sx={{
                                          display: 'flex',
                                          flexDirection: 'column',
                                          gap: 0.5,
                                        }}
                                      >
                                        <Typography
                                          variant="body2"
                                          sx={{
                                            color:
                                              vehicle.status === 'rejected'
                                                ? 'error.main'
                                                : vehicle.status === 'approved'
                                                  ? 'success.main'
                                                  : 'warning.main',
                                            fontWeight: 'bold',
                                          }}
                                        >
                                          {vehicle.status || 'pending'}
                                        </Typography>
                                        {vehicle.status === 'rejected' && (
                                          <Tooltip
                                            title={
                                              vehicle.rejected_reason ||
                                              vehicle.vehicle_comments ||
                                              'No rejection reason provided'
                                            }
                                            arrow
                                          >
                                            <InfoIcon
                                              sx={{
                                                fontSize: 14,
                                                color: 'error.main',
                                                cursor: 'pointer',
                                              }}
                                            />
                                          </Tooltip>
                                        )}
                                      </Box>
                                    </TableCell>
                                  </TableRow>
                                  {/* Material Details Row */}
                                  {expandedVehicles[vehicleIndex] && (
                                    <TableRow>
                                      <TableCell
                                        colSpan={8}
                                        sx={{ p: 0, border: 0 }}
                                      >
                                        <Box
                                          sx={{
                                            backgroundColor: '#fafafa',
                                            p: 2,
                                          }}
                                        >
                                          <Typography
                                            variant="h6"
                                            gutterBottom
                                            sx={{ mb: 2 }}
                                          >
                                            Material Details
                                          </Typography>
                                          {vehicle.mm_details &&
                                          vehicle.mm_details.length > 0 ? (
                                            <Table size="small">
                                              <TableHead>
                                                <TableRow>
                                                  <TableCell
                                                    sx={{ fontWeight: 'bold' }}
                                                  >
                                                    Material Name
                                                  </TableCell>
                                                  <TableCell
                                                    sx={{ fontWeight: 'bold' }}
                                                  >
                                                    Device Model
                                                  </TableCell>
                                                  <TableCell
                                                    sx={{ fontWeight: 'bold' }}
                                                  >
                                                    Material Description
                                                  </TableCell>
                                                  <TableCell
                                                    sx={{ fontWeight: 'bold' }}
                                                  >
                                                    Quantity
                                                  </TableCell>
                                                  <TableCell
                                                    sx={{ fontWeight: 'bold' }}
                                                  >
                                                    Number of Units
                                                  </TableCell>
                                                  <TableCell
                                                    sx={{ fontWeight: 'bold' }}
                                                  >
                                                    Serial Number
                                                  </TableCell>
                                                  <TableCell
                                                    sx={{ fontWeight: 'bold' }}
                                                  >
                                                    Status
                                                  </TableCell>
                                                </TableRow>
                                              </TableHead>
                                              <TableBody>
                                                {vehicle.mm_details.map(
                                                  (material, materialIndex) => (
                                                    <TableRow
                                                      key={materialIndex}
                                                    >
                                                      <TableCell>
                                                        {material.material_name ||
                                                          'N/A'}
                                                      </TableCell>
                                                      <TableCell>
                                                        {material.material_device_model ||
                                                          'N/A'}
                                                      </TableCell>
                                                      <TableCell>
                                                        {material.material_description ||
                                                          'N/A'}
                                                      </TableCell>
                                                      <TableCell>
                                                        {material.material_quantity ||
                                                          'N/A'}
                                                      </TableCell>
                                                      <TableCell>
                                                        {material.material_no_of_units ||
                                                          'N/A'}
                                                      </TableCell>
                                                      <TableCell>
                                                        {material.material_s_n ||
                                                          'N/A'}
                                                      </TableCell>
                                                      <TableCell>
                                                        <Box
                                                          sx={{
                                                            display: 'flex',
                                                            flexDirection:
                                                              'column',
                                                            gap: 0.5,
                                                          }}
                                                        >
                                                          <Typography
                                                            variant="body2"
                                                            sx={{
                                                              color:
                                                                material.status ===
                                                                'rejected'
                                                                  ? 'error.main'
                                                                  : material.status ===
                                                                      'approved'
                                                                    ? 'success.main'
                                                                    : 'warning.main',
                                                              fontWeight:
                                                                'bold',
                                                            }}
                                                          >
                                                            {material.status ||
                                                              'pending'}
                                                          </Typography>
                                                          {material.status ===
                                                            'rejected' && (
                                                            <Tooltip
                                                              title={
                                                                material.rejected_reason ||
                                                                material.material_comments ||
                                                                'No rejection reason provided'
                                                              }
                                                              arrow
                                                            >
                                                              <InfoIcon
                                                                sx={{
                                                                  fontSize: 14,
                                                                  color:
                                                                    'error.main',
                                                                  cursor:
                                                                    'pointer',
                                                                }}
                                                              />
                                                            </Tooltip>
                                                          )}
                                                        </Box>
                                                      </TableCell>
                                                    </TableRow>
                                                  ),
                                                )}
                                              </TableBody>
                                            </Table>
                                          ) : (
                                            <Typography
                                              variant="body2"
                                              color="text.secondary"
                                            >
                                              No material details available
                                            </Typography>
                                          )}
                                        </Box>
                                      </TableCell>
                                    </TableRow>
                                  )}
                                </React.Fragment>
                              ),
                            )}
                          </TableBody>
                        </Table>
                      </TableContainer>
                    )}

                  {/* Show message if no vehicle data */}
                  {(!apiData.vehicleMaterial?.vm_bool ||
                    !apiData.vehicleMaterial?.vm_details ||
                    apiData.vehicleMaterial?.vm_details.length === 0) && (
                    <Box sx={{ textAlign: 'center', py: 4 }}>
                      <Typography variant="h6" color="text.secondary">
                        No vehicle details available
                      </Typography>
                    </Box>
                  )}
                </Box>
              )}
            </Box>
          )}
        </DialogContent>
        <DialogActions
          sx={{ backgroundColor: '#f5f5f5', borderTop: '1px solid #e0e0e0' }}
        >
          <Button
            onClick={handleCloseModals}
            color="primary"
            variant="contained"
          >
            Close
          </Button>
        </DialogActions>
      </Dialog>

      {/* Group Booking Details Modal */}
      <Dialog
        open={groupModalOpen}
        onClose={handleCloseModals}
        maxWidth="lg"
        fullWidth
        PaperProps={{
          sx: {
            borderRadius: 2,
            boxShadow: '0 8px 32px rgba(0,0,0,0.12)',
            maxHeight: '85vh',
            height: '80vh',
            overflow: 'auto',
            overflowX: 'auto',
            overflowY: 'auto',
          },
        }}
      >
        <DialogTitle
          sx={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            backgroundColor: '#f5f5f5',
            borderBottom: '1px solid #e0e0e0',
          }}
        >
          <Box>
            <Typography
              variant="h5"
              component="div"
              sx={{ fontWeight: 'bold' }}
            >
              {selectedBooking?.name || 'Group Visit Members'}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Manage your group visit members
            </Typography>
          </Box>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <Box
              sx={{
                backgroundColor: '#E3F2FD',
                color: '#1976D2',
                padding: '8px 16px',
                borderRadius: '20px',
                display: 'flex',
                alignItems: 'center',
                gap: 1,
                fontSize: '0.875rem',
                fontWeight: 500,
              }}
            >
              <Typography variant="body2" sx={{ fontWeight: 'bold' }}>
                {apiData.groupBooking?.grp_details?.length || 0} Total
              </Typography>
            </Box>
            <IconButton onClick={handleCloseModals} size="small">
              <CloseIcon />
            </IconButton>
          </Box>
        </DialogTitle>
        <DialogContent dividers sx={{ p: 0 }}>
          {selectedBooking && (
            <Box>
              {groupLoading ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
                  <CircularProgress />
                  <Typography variant="body1" sx={{ ml: 2 }}>
                    Loading group booking details...
                  </Typography>
                </Box>
              ) : (
                <Box sx={{ p: 2 }}>
                  {/* Group Members Table */}
                  {apiData.groupBooking?.grp_book_bool &&
                    apiData.groupBooking?.grp_details &&
                    apiData.groupBooking?.grp_details.length > 0 && (
                      <TableContainer component={Paper} sx={{ mb: 2 }}>
                        <Table>
                          <TableHead>
                            <TableRow sx={{ backgroundColor: '#f5f5f5' }}>
                              <TableCell sx={{ fontWeight: 'bold' }}>
                                Member Details
                              </TableCell>
                              <TableCell sx={{ fontWeight: 'bold' }}>
                                Contact Information
                              </TableCell>
                              <TableCell sx={{ fontWeight: 'bold' }}>
                                ID Proof
                              </TableCell>
                              <TableCell sx={{ fontWeight: 'bold' }}>
                                Check-in/out
                              </TableCell>
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            {apiData.groupBooking?.grp_details.map(
                              (member, index) => (
                                <TableRow
                                  key={index}
                                  sx={{
                                    '&:not(:last-child)': {
                                      borderBottom: '2px solid #f0f0f0',
                                    },
                                  }}
                                >
                                  <TableCell>
                                    <Box
                                      sx={{
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: 2,
                                      }}
                                    >
                                      <Avatar
                                        sx={{
                                          backgroundColor: '#00BCD4',
                                          width: 40,
                                          height: 40,
                                          fontSize: '1rem',
                                          fontWeight: 'bold',
                                        }}
                                      >
                                        {member.grp_user_name
                                          ?.charAt(0)
                                          ?.toUpperCase() || 'M'}
                                      </Avatar>
                                      <Box>
                                        <Typography
                                          variant="subtitle2"
                                          fontWeight="bold"
                                        >
                                          {member.grp_user_name || 'N/A'}
                                        </Typography>
                                        <Typography
                                          variant="caption"
                                          color="text.secondary"
                                        >
                                          Member #{index + 1}
                                        </Typography>
                                      </Box>
                                    </Box>
                                  </TableCell>
                                  <TableCell>
                                    <Box>
                                      <Typography
                                        variant="body2"
                                        color="text.secondary"
                                      >
                                        {member.grp_user_email || 'N/A'}
                                      </Typography>
                                      <Typography
                                        variant="body2"
                                        color="text.secondary"
                                      >
                                        {member.grp_user_phno || 'N/A'}
                                      </Typography>
                                    </Box>
                                  </TableCell>
                                  <TableCell>
                                    {member.grp_user_id_proof ? (
                                      <Button
                                        variant="text"
                                        color="primary"
                                        size="small"
                                        sx={{
                                          textTransform: 'none',
                                          color: '#1976d2',
                                          textDecoration: 'underline',
                                          '&:hover': {
                                            color: '#1565c0',
                                            backgroundColor:
                                              'rgba(25, 118, 210, 0.04)',
                                          },
                                        }}
                                        onClick={() => {
                                          if (member.grp_user_id_proof) {
                                            window.open(
                                              member.grp_user_id_proof,
                                              '_blank',
                                            )
                                          }
                                        }}
                                      >
                                        View ID proof
                                      </Button>
                                    ) : (
                                      <Typography
                                        variant="body2"
                                        color="text.secondary"
                                      >
                                        No ID proof
                                      </Typography>
                                    )}
                                  </TableCell>
                                  <TableCell>
                                    <Box
                                      sx={{
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: 1,
                                      }}
                                    >
                                      <Typography variant="body2">
                                        {(() => {
                                          // Get latest entry and exit times
                                          const latestEntry =
                                            member.attendanceData
                                              ?.filter((att) => att.isEntry)
                                              ?.sort(
                                                (a, b) =>
                                                  new Date(b.entry_time) -
                                                  new Date(a.entry_time),
                                              )?.[0]
                                          const latestExit =
                                            member.attendanceData
                                              ?.filter((att) => !att.isEntry)
                                              ?.sort(
                                                (a, b) =>
                                                  new Date(b.exit_time) -
                                                  new Date(a.exit_time),
                                              )?.[0]

                                          const entryTime =
                                            latestEntry?.entry_time
                                              ? new Date(
                                                  latestEntry.entry_time,
                                                ).toLocaleTimeString('en-GB', {
                                                  hour12: false,
                                                  hour: '2-digit',
                                                  minute: '2-digit',
                                                  second: '2-digit',
                                                })
                                              : '--'
                                          const exitTime = latestExit?.exit_time
                                            ? new Date(
                                                latestExit.exit_time,
                                              ).toLocaleTimeString('en-GB', {
                                                hour12: false,
                                                hour: '2-digit',
                                                minute: '2-digit',
                                                second: '2-digit',
                                              })
                                            : '--'

                                          return `${entryTime} - ${exitTime}`
                                        })()}
                                      </Typography>
                                      <IconButton
                                        size="small"
                                        onClick={() => {
                                          const newExpanded = {}
                                          newExpanded[index] =
                                            !expandedCheckinDropdowns[index]
                                          setExpandedCheckinDropdowns(
                                            newExpanded,
                                          )
                                        }}
                                      >
                                        {expandedCheckinDropdowns[index] ? (
                                          <ExpandLessIcon fontSize="small" />
                                        ) : (
                                          <ExpandMoreIcon fontSize="small" />
                                        )}
                                      </IconButton>
                                    </Box>
                                    {expandedCheckinDropdowns[index] && (
                                      <Box
                                        sx={{
                                          mt: 1,
                                          p: 2,
                                          backgroundColor: '#fafafa',
                                          borderRadius: 1,
                                        }}
                                      >
                                        {member.attendanceData &&
                                        member.attendanceData.length > 0 ? (
                                          <Box>
                                            {member.attendanceData
                                              .sort(
                                                (a, b) =>
                                                  new Date(
                                                    a.entry_time || a.exit_time,
                                                  ) -
                                                  new Date(
                                                    b.entry_time || b.exit_time,
                                                  ),
                                              )
                                              .map((attendance, attIndex) => (
                                                <Box
                                                  key={attIndex}
                                                  sx={{
                                                    mb: 2,
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    justifyContent:
                                                      'space-between',
                                                    padding: '8px',
                                                    backgroundColor: '#fafafa',
                                                    borderRadius: '4px',
                                                  }}
                                                >
                                                  <Typography
                                                    variant="body2"
                                                    color="primary.main"
                                                    sx={{
                                                      fontSize: '0.75rem',
                                                    }}
                                                  >
                                                    🔵 IN:{' '}
                                                    {attendance.isEntry &&
                                                    attendance.entry_time
                                                      ? new Date(
                                                          attendance.entry_time,
                                                        ).toLocaleTimeString(
                                                          'en-GB',
                                                          {
                                                            hour12: false,
                                                            hour: '2-digit',
                                                            minute: '2-digit',
                                                            second: '2-digit',
                                                          },
                                                        )
                                                      : '--'}
                                                  </Typography>
                                                  <Typography
                                                    variant="body2"
                                                    color="error.main"
                                                    sx={{
                                                      fontSize: '0.75rem',
                                                    }}
                                                  >
                                                    🔴 OUT:{' '}
                                                    {!attendance.isEntry &&
                                                    attendance.exit_time
                                                      ? new Date(
                                                          attendance.exit_time,
                                                        ).toLocaleTimeString(
                                                          'en-GB',
                                                          {
                                                            hour12: false,
                                                            hour: '2-digit',
                                                            minute: '2-digit',
                                                            second: '2-digit',
                                                          },
                                                        )
                                                      : '--'}
                                                  </Typography>
                                                </Box>
                                              ))}
                                          </Box>
                                        ) : (
                                          <Typography
                                            variant="body2"
                                            color="text.secondary"
                                          >
                                            No attendance data available
                                          </Typography>
                                        )}
                                      </Box>
                                    )}
                                  </TableCell>
                                </TableRow>
                              ),
                            )}
                          </TableBody>
                        </Table>
                      </TableContainer>
                    )}

                  {/* Show message if no group data */}
                  {(!apiData.groupBooking?.grp_book_bool ||
                    !apiData.groupBooking?.grp_details ||
                    apiData.groupBooking?.grp_details.length === 0) && (
                    <Box sx={{ textAlign: 'center', py: 4 }}>
                      <Typography variant="h6" color="text.secondary">
                        No group members available
                      </Typography>
                    </Box>
                  )}
                </Box>
              )}
            </Box>
          )}
        </DialogContent>
        <DialogActions
          sx={{ backgroundColor: '#f5f5f5', borderTop: '1px solid #e0e0e0' }}
        >
          <Button
            onClick={handleCloseModals}
            color="primary"
            variant="contained"
          >
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  )
}

export default VehicleMaterialGroupBookingPresentation
