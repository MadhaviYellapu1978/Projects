import React, { useState, useEffect, useContext } from 'react'
import { useForm } from 'react-hook-form'
import { useDropzone } from 'react-dropzone'
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf'
import DescriptionIcon from '@mui/icons-material/Description'
import LinearProgress from '@mui/material/LinearProgress'
import toast from 'react-hot-toast'
import { useMutation } from '@tanstack/react-query'
import { getNDADoc, uploadNda } from '../../../services/adminService'
import { AuthContext } from '../../../context/AuthContext'
import uploadPoliceNDA from '../../../assets/uploadPoliceNDA.png'

const FileUploadWithDragAndDropNDA = (brach_id) => {
  console.log('hello   file Upload')
  console.log(brach_id, 'brach_id')
  const auth = useContext(AuthContext)

  const {
    register,
    handleSubmit,
    setValue,
    reset,
    formState: { errors },
  } = useForm()
  const [fileName, setFileName] = useState(null)
  const [filePreview, setFilePreview] = useState(null)
  const [fileType, setFileType] = useState(null)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [uploading, setUploading] = useState(false)
  const [ndaDoc, setndaDoc] = useState('')
  const onDrop = (acceptedFiles, rejectedFiles) => {
    if (rejectedFiles.length > 0) {
      toast.error('Only PDF files are allowed')
      return
    }

    if (acceptedFiles.length > 0) {
      const file = acceptedFiles[0]
      setValue('file', file, { shouldValidate: true })
      setFileName(file.name)
      setFileType(file.type)

      const fileURL = URL.createObjectURL(file)
      setFilePreview(fileURL)

      setUploading(true)
      let progress = 0
      const interval = setInterval(() => {
        progress += 10
        setUploadProgress(progress)
        if (progress >= 100) {
          clearInterval(interval)
          setUploading(false)
        }
      }, 200)
    }
  }

  const mutationgraphsdata = useMutation({
    mutationFn: (values) => uploadNda(values),
    onSuccess: () => {
      toast.success('Document uploaded successful')
      mutationget.mutate({ org_id: auth.org_id, branch_id: brach_id?.brach_id })
    },
    onError: () => {
      toast.dismiss()
      toast.error('Upload NDA failed')
    },
  })
  const mutationget = useMutation({
    mutationFn: (values) => getNDADoc(values),
    onSuccess: (data) => {
      setndaDoc(data.ndaDoc)
    },
    onError: () => {
      toast.error('Upload NDA failed')
    },
  })
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: 'application/pdf',
    multiple: false,
  })

  useEffect(() => {
    register('file', { required: 'File is required' })
  }, [register])

  useEffect(() => {
    mutationget.mutate({ org_id: auth.org_id, branch_id: brach_id?.brach_id })
  }, [auth.org_id, brach_id?.brach_id])
  const convertFileToBuffer = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onloadend = () => resolve(reader.result)
      reader.onerror = reject
      reader.readAsArrayBuffer(file)
    })
  }

  const onSubmit = async (data) => {
    if (filePreview) {
      URL.revokeObjectURL(filePreview)
    }
    setFileName(null)
    setFilePreview(null)
    setFileType(null)
    setUploadProgress(0)
    reset()

    try {
      const fileBuffer = await convertFileToBuffer(data.file)

      const formData = new FormData()
      formData.append('org_id', auth.org_id)
      formData.append('branch_id', brach_id?.brach_id)
      formData.append(
        'ndaDoc',
        new Blob([fileBuffer], { type: data.file.type }),
        data.file.name,
      )

      mutationgraphsdata.mutate(formData)
    } catch (error) {
      toast.error('Failed to convert file to buffer')
    }
  }

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-6">
      <div className="bg-white p-8 rounded shadow-md w-full max-w-4xl">
        <h2 className="text-2xl font-bold mb-6">Upload NDA File</h2>
        <p className="text-gray-600 mb-4">
          Note: Please upload PDF files only.
        </p>
        <form onSubmit={handleSubmit(onSubmit)}>
          <div
            {...getRootProps()}
            className={`p-10 border-2 border-dashed rounded cursor-pointer transition-colors ${isDragActive ? 'border-blue-400 bg-blue-100' : 'border-gray-400'} h-64 flex flex-col items-center justify-center`}
          >
            <input {...getInputProps()} style={{ display: 'none' }} />
            <div className="text-center">
              {isDragActive ? (
                <p className="text-gray-600">Drop the file here...</p>
              ) : (
                <>
                  <div className="flex justify-center items-center mb-2">
                    <DescriptionIcon color="action" style={{ fontSize: 50 }} />
                  </div>
                  <p className="text-gray-600">
                    {fileName
                      ? `Selected file: ${fileName}`
                      : 'Drag & drop a PDF file here, or click to select one'}
                  </p>
                </>
              )}
            </div>
          </div>
          {errors.file && (
            <span className="text-red-600 text-sm mt-2 block">
              {errors.file.message}
            </span>
          )}

          {uploading && (
            <div className="mt-4">
              <LinearProgress variant="determinate" value={uploadProgress} />
              <p className="text-gray-600 text-center mt-2">
                Uploading: {uploadProgress}%
              </p>
            </div>
          )}

          {filePreview && !uploading && (
            <div className="mt-4">
              {fileType === 'application/pdf' ? (
                <div className="flex flex-col items-center">
                  <PictureAsPdfIcon
                    color="error"
                    style={{ fontSize: 40, marginBottom: 8 }}
                  />
                  <a
                    href={filePreview}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 underline"
                  >
                    View {fileName}
                  </a>
                </div>
              ) : (
                <p className="text-red-600">Upload PDF files only</p>
              )}
            </div>
          )}
          {ndaDoc && (
            <div className="mt-4 flex flex-col items-center">
              <PictureAsPdfIcon
                color="error"
                style={{ fontSize: 40, marginBottom: 8 }}
              />
              <a
                href={ndaDoc}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 underline"
              >
                View previously uploaded NDA
              </a>
            </div>
          )}
          <button
            type="submit"
            disabled={
              uploading ||
              uploadProgress < 100 ||
              fileType !== 'application/pdf'
            }
            className={`mt-6 w-full py-2 px-4 ${uploading || uploadProgress < 100 || fileType !== 'application/pdf' ? 'bg-gray-400 cursor-not-allowed' : 'bg-indigo-600 hover:bg-indigo-700'} text-white rounded focus:outline-none focus:ring-2 focus:ring-indigo-600`}
          >
            {ndaDoc == '' ? 'Submit' : 'Update'}
          </button>
        </form>
      </div>
      {/* Image Section */}
      <div className="hidden lg:block w-1/3 pl-6">
        <img
          src={uploadPoliceNDA} // Replace with your image URL
          alt="Illustration"
          className="rounded shadow-md"
        />
      </div>
    </div>
  )
}

export default FileUploadWithDragAndDropNDA
