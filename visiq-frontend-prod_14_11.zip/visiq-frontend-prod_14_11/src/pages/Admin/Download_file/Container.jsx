import React from 'react'
import Presentation from './Presentation'

function Container(props) {
  console.log(props, 'Propsssss')
  return (
    <div>
      <Presentation brach_id={props?.branch_id} />
    </div>
  )
}

export default Container
