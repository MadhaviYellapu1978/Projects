import React, {
  useState,
  useEffect,
  useContext,
  useRef,
  useCallback,
} from 'react'
import {
  Box,
  Typography,
  TextField,
  InputAdornment,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Switch,
  FormControlLabel,
  Chip,
  Pagination,
  Alert,
  Snackbar,
  CircularProgress,
  Select,
  MenuItem,
  FormControl,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextareaAutosize,
} from '@mui/material'
import SearchIcon from '@mui/icons-material/Search'
import CloseIcon from '@mui/icons-material/Close'
import CalendarTodayIcon from '@mui/icons-material/CalendarToday'
import ListIcon from '@mui/icons-material/List'
import DatePicker from 'react-datepicker'
import 'react-datepicker/dist/react-datepicker.css'
import {
  updateBlackList,
  getAttendance,
  getBranchesByOrgId,
  getUserBlacklistHistory,
} from '../../../services/adminService'
import { AuthContext } from '../../../context/AuthContext'
import { useMutation, useQuery } from '@tanstack/react-query'
import { format } from 'date-fns'

const BlacklistManagement = () => {
  const auth = useContext(AuthContext)
  const [searchTerm, setSearchTerm] = useState('')
  const [visitors, setVisitors] = useState([])
  const [filteredVisitors, setFilteredVisitors] = useState([])
  const [page, setPage] = useState(1)
  const [_rowsPerPage, _setRowsPerPage] = useState(9)
  const [data_of_visit, set_data_of_visit] = useState(new Date())
  const [branches, setBranches] = useState([])
  const [selectedBranch, setSelectedBranch] = useState('')
  const [branch_id, setBranchId] = useState('')
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success',
  })
  const [isInitialized, setIsInitialized] = useState(false)
  const [isLoadingVisitors, setIsLoadingVisitors] = useState(false)

  // Use refs to avoid dependency issues with mutations
  const visitorsMutationRef = useRef()
  const isVisitorsRequestInProgress = useRef(false)
  const lastRequestKey = useRef('')
  const requestTimeoutRef = useRef(null)

  // Mutation to fetch arrived visitors data for blacklist management using getAttendance
  const visitorsMutation = useMutation({
    mutationFn: (values) => getAttendance(values),
    mutationKey: 'getAttendance',
    onSuccess: (data) => {
      // Handle the getAttendance API response structure
      let visitorsData = []

      // Primary: Extract arrived visitors from userdata array (getAttendance structure)
      // This data represents visitors who have actually arrived (have entry/exit times)
      if (data?.userdata && Array.isArray(data.userdata)) {
        data.userdata.forEach((userData) => {
          if (userData.userDetails && Array.isArray(userData.userDetails)) {
            // Only include visitors who have actually arrived (have entry times)
            const arrivedVisitors = userData.userDetails.filter(
              (visitor) => visitor.last_entry && visitor.last_entry !== '--',
            )
            visitorsData = [...visitorsData, ...arrivedVisitors]
          }
        })
      }
      // Fallback: check if data is directly an array
      else if (Array.isArray(data)) {
        visitorsData = data
      }

      // Debug: Log the first visitor to understand the API response structure
      if (visitorsData.length > 0) {
        console.log('Sample visitor data from API:', visitorsData[0])
        console.log('Blacklist status fields:', {
          black_listed: visitorsData[0].black_listed,
          blacklisted: visitorsData[0].blacklisted,
          user_id: visitorsData[0].user_id,
        })
        console.log('Organization fields from API:', {
          visitorOrgName: visitorsData[0].visitorOrgName,
          visitor_company_name: visitorsData[0].visitor_company_name,
          organization: visitorsData[0].organization,
          company: visitorsData[0].company,
          org_name: visitorsData[0].org_name,
        })
      }

      // Transform API data to match our component structure
      const transformedVisitors =
        visitorsData.map((visitor, index) => {
          // Use API response blacklisted field, fallback to localStorage, then default to false
          const userBlacklistKey = `blacklist_${visitor.user_id || visitor.id || visitor.visitor_id}`
          const savedBlacklistState = localStorage.getItem(userBlacklistKey)

          // Priority: API response > localStorage > default false
          // Check both possible field names: blacklisted and black_listed
          const apiBlacklistedValue =
            visitor.blacklisted !== undefined
              ? visitor.blacklisted
              : visitor.black_listed

          const isBlacklisted =
            apiBlacklistedValue !== undefined
              ? apiBlacklistedValue
              : savedBlacklistState === 'true'

          // Debug logging for blacklisted state
          console.log(`Visitor ${visitor.name || visitor.user_id}:`, {
            apiBlacklisted: visitor.blacklisted,
            apiBlackListed: visitor.black_listed, // Check alternative field name
            resolvedApiValue: apiBlacklistedValue,
            localStorageState: savedBlacklistState,
            finalBlacklisted: isBlacklisted,
            allVisitorFields: Object.keys(visitor), // Show all available fields
          })

          return {
            id: index + 1,
            name: (() => {
              // Handle name construction with proper fallbacks
              const firstName = visitor.first_name || ''
              const lastName = visitor.last_name || ''

              // If both first_name and last_name exist, combine them
              if (firstName && lastName) {
                return `${firstName} ${lastName}`.trim()
              }

              // If only first_name exists, use it
              if (firstName) {
                return firstName.trim()
              }

              // If only last_name exists, use it
              if (lastName) {
                return lastName.trim()
              }

              // Fallback to other name fields
              return (
                visitor.name ||
                visitor.visitor_name ||
                visitor.full_name ||
                'Unknown'
              )
            })(),
            category:
              visitor.role_name ||
              visitor.category ||
              visitor.visitor_type ||
              'Business',
            phone:
              visitor.ph_ext && visitor.ph_no
                ? `${visitor.ph_ext}-${visitor.ph_no}`
                : visitor.phone ||
                  visitor.contact ||
                  visitor.mobile ||
                  '+91-XXXXXXXXXX',
            email: visitor.email || 'no-email@example.com',
            purpose:
              visitor.purpose_of_visit ||
              visitor.purpose ||
              visitor.visit_purpose ||
              visitor.reason_for_visit ||
              'General Visit',
            organization: (() => {
              // Try multiple possible organization fields from API
              const orgFields = [
                visitor.visitorOrgName,
                visitor.visitor_company_name,
                visitor.organization,
                visitor.company,
                visitor.org_name,
                visitor.visitor_organization,
                visitor.company_name,
                visitor.organization_name,
              ]

              // Find the first non-empty field
              const orgValue = orgFields.find(
                (field) => field && field.toString().trim() !== '',
              )

              console.log('Organization field mapping for visitor:', {
                visitorOrgName: visitor.visitorOrgName,
                visitor_company_name: visitor.visitor_company_name,
                organization: visitor.organization,
                company: visitor.company,
                org_name: visitor.org_name,
                visitor_organization: visitor.visitor_organization,
                company_name: visitor.company_name,
                organization_name: visitor.organization_name,
                selectedValue: orgValue,
              })

              return orgValue || 'Unknown'
            })(),
            reason: visitor.reason || visitor.blacklist_reason || 'N/A', // Map reason field
            blacklisted: isBlacklisted, // Read from localStorage or default to false
            user_id: visitor.user_id || visitor.id || visitor.visitor_id, // Use user_id, id, or visitor_id
          }
        }) || []

      setVisitors(transformedVisitors)
      setFilteredVisitors(transformedVisitors)
      setIsLoadingVisitors(false) // Reset loading state
      isVisitorsRequestInProgress.current = false // Reset request progress flag

      // Clear timeout and reset request key
      if (requestTimeoutRef.current) {
        clearTimeout(requestTimeoutRef.current)
        requestTimeoutRef.current = null
      }

      console.log('✅ Visitors data loaded successfully', {
        visitorsCount: transformedVisitors.length,
        isLoadingVisitors: false,
        isRequestInProgress: false,
      })

      // Reset search when new data is loaded
      if (searchTerm) {
        // Re-trigger search with new data
        const searchLower = searchTerm.toLowerCase().trim()
        const filtered = transformedVisitors.filter((visitor) => {
          const name = visitor.name || ''
          const email = visitor.email || ''
          const phone = visitor.phone || ''
          const organization = visitor.organization || ''

          return (
            name.toLowerCase().includes(searchLower) ||
            email.toLowerCase().includes(searchLower) ||
            phone.toLowerCase().includes(searchLower) ||
            organization.toLowerCase().includes(searchLower)
          )
        })
        setFilteredVisitors(filtered)
      }
    },
    onError: (error) => {
      console.error('Error fetching visitors:', error)
      setSnackbar({
        open: true,
        message: 'Failed to load visitors. Please try again.',
        severity: 'error',
      })
      // Set empty arrays on error - no fallback data
      setVisitors([])
      setFilteredVisitors([])
      setIsLoadingVisitors(false) // Reset loading state
      isVisitorsRequestInProgress.current = false // Reset request progress flag

      // Clear timeout and reset request key
      if (requestTimeoutRef.current) {
        clearTimeout(requestTimeoutRef.current)
        requestTimeoutRef.current = null
      }

      console.log('❌ Visitors data loading failed', {
        error: error.message,
        isLoadingVisitors: false,
        isRequestInProgress: false,
      })
    },
  })

  // Use React Query for fetching branches with caching to prevent duplicate calls
  const {
    data: branchesData,
    isError: branchesError,
    isLoading: branchesLoading,
  } = useQuery({
    queryKey: ['getBranches', auth?.org_id, auth?.role],
    queryFn: () =>
      getBranchesByOrgId({
        org_id: auth.org_id,
        role: auth.role == '1' ? '' : auth.role,
        branch_id: auth?.branch_id || '',
      }),
    enabled: !!auth?.org_id,
    staleTime: 5 * 60 * 1000, // 5 minutes - prevents refetching
    gcTime: 10 * 60 * 1000, // 10 minutes (formerly cacheTime)
    refetchOnMount: false, // Don't refetch if data exists
    refetchOnWindowFocus: false, // Don't refetch on window focus
  })

  // Mutation to update blacklist status
  const blacklistMutation = useMutation({
    mutationFn: (blacklistData) => updateBlackList(blacklistData),
    mutationKey: 'updateBlackList',
    onSuccess: (data) => {
      console.log('Blacklist update successful:', data)

      setSnackbar({
        open: true,
        message: data.message || 'Blacklist status updated successfully',
        severity: 'success',
      })

      // Update local state to reflect the successful API call
      // This will update the toggle to show the new status
      if (toggledVisitorId) {
        console.log('Updating local state for visitor:', toggledVisitorId)
        console.log('API Response data:', data)
        console.log('API Response type:', typeof data)
        console.log('API Response isArray:', Array.isArray(data))
        if (data && typeof data === 'object') {
          console.log('API Response keys:', Object.keys(data))
        }

        // localStorage will be updated after we determine the new state

        // Update the visitor's blacklisted status based on the API response
        console.log('Current visitors before update:', visitors.length)
        console.log('Looking for visitor with ID:', toggledVisitorId)

        const updatedVisitors = visitors.map((v) => {
          if (v.user_id === toggledVisitorId) {
            console.log(
              'Found visitor to update:',
              v.name,
              'Current blacklisted:',
              v.blacklisted,
            )

            // Use the API response to determine the new blacklisted status
            let newBlacklistedStatus = v.blacklisted // Keep current state as fallback

            // Check if data is an array (request body format)
            if (Array.isArray(data) && data.length > 0) {
              newBlacklistedStatus = data[0].black_listed
              console.log(
                'Using black_listed from array response:',
                data[0].black_listed,
              )
            }
            // Check if data is an object with black_listed field (direct response)
            else if (
              data &&
              typeof data === 'object' &&
              data.black_listed !== undefined
            ) {
              newBlacklistedStatus = data.black_listed
              console.log(
                'Using black_listed from object response:',
                data.black_listed,
              )
            }
            // Check if data has a nested response object
            else if (
              data &&
              data.data &&
              data.data.black_listed !== undefined
            ) {
              newBlacklistedStatus = data.data.black_listed
              console.log(
                'Using black_listed from nested response:',
                data.data.black_listed,
              )
            }
            // Check if the API returns the request body as response (common pattern)
            else if (data && typeof data === 'object') {
              // Look for any field that might contain the black_listed value
              const possibleFields = [
                'black_listed',
                'blacklisted',
                'isBlacklisted',
                'status',
              ]
              for (const field of possibleFields) {
                if (data[field] !== undefined) {
                  newBlacklistedStatus = data[field]
                  console.log(
                    `Using black_listed from field '${field}':`,
                    data[field],
                  )
                  break
                }
              }
            } else {
              console.log(
                'No black_listed found in response, keeping current state:',
                newBlacklistedStatus,
              )
            }

            console.log(
              `Updating visitor ${v.user_id}: ${v.blacklisted} -> ${newBlacklistedStatus}`,
            )
            const updatedVisitor = { ...v, blacklisted: newBlacklistedStatus }
            console.log('Updated visitor object:', updatedVisitor)
            return updatedVisitor
          }
          return v
        })
        setVisitors(updatedVisitors)
        setFilteredVisitors(updatedVisitors)
        setToggledVisitorId(null) // Reset the toggled visitor ID

        // Verify the state update and save to localStorage
        const updatedVisitor = updatedVisitors.find(
          (v) => v.user_id === toggledVisitorId,
        )
        if (updatedVisitor) {
          console.log(
            `Final toggle state for visitor ${toggledVisitorId}:`,
            updatedVisitor.blacklisted,
          )

          // Save the correct state to localStorage
          const userBlacklistKey = `blacklist_${toggledVisitorId}`
          localStorage.setItem(
            userBlacklistKey,
            updatedVisitor.blacklisted.toString(),
          )
          console.log(
            `Saved to localStorage: ${userBlacklistKey} = ${updatedVisitor.blacklisted}`,
          )
        }

        // Additional verification - check if the state was actually updated
        console.log('Total visitors after update:', updatedVisitors.length)
        console.log('Updated visitors array:', updatedVisitors)
      }
    },
    onError: (error) => {
      setSnackbar({
        open: true,
        message: error.message || 'Failed to update blacklist status',
        severity: 'error',
      })

      // Revert the toggle state if API call fails
      if (toggledVisitorId) {
        const updatedVisitors = visitors.map((v) => {
          if (v.user_id === toggledVisitorId) {
            return { ...v, blacklisted: !v.blacklisted }
          }
          return v
        })
        setVisitors(updatedVisitors)
        setFilteredVisitors(updatedVisitors)
        setToggledVisitorId(null)
      }

      // Revert the local state change on error
      // Refresh visitors data to get the correct state from server
      if (selectedBranch && auth?.org_id) {
        visitorsMutation.mutate({
          org_id: auth.org_id || auth.orgId,
          branch_id: branch_id,
          date: format(data_of_visit, 'dd-MM-yyyy'),
        })
      }
    },
  })

  // Mutation to fetch blacklist history
  const blacklistHistoryMutation = useMutation({
    mutationFn: async (params) => {
      console.log('🚀 Calling getUserBlacklistHistory with params:', params)

      // Validate required parameters before making the call
      if (!params.org_id) {
        throw new Error('org_id is required for blacklist history')
      }
      if (!params.branch_id) {
        throw new Error('branch_id is required for blacklist history')
      }
      if (!params.page) {
        throw new Error('page is required for blacklist history')
      }
      if (!params.limit) {
        throw new Error('limit is required for blacklist history')
      }

      try {
        const response = await getUserBlacklistHistory(params)
        console.log('✅ getUserBlacklistHistory API call successful:', response)
        return response
      } catch (error) {
        console.error('❌ getUserBlacklistHistory API call failed:', error)
        throw error
      }
    },
    mutationKey: 'getUserBlacklistHistory',
    onSuccess: (response) => {
      console.log('🎉 Blacklist history mutation success:', response)
      console.log('🔍 Response type:', typeof response)
      console.log('🔍 Response keys:', Object.keys(response || {}))
      console.log('🔍 Current logsData before processing:', logsData)

      // Immediate check of response structure
      console.log('🔍 API RESPONSE CHECK:')
      console.log('  - response.data exists:', !!response.data)
      console.log('  - response.data length:', response.data?.length)
      console.log('  - response.users exists:', !!response.users)
      console.log('  - response.users length:', response.users?.length)
      console.log('  - response.pagination:', response.pagination)
      console.log('  - response.totalLogs:', response.totalLogs)
      console.log('  - First user sample (data):', response.data?.[0])
      console.log('  - First user sample (users):', response.users?.[0])

      // Detailed response structure analysis
      console.log('🔍 FULL API RESPONSE STRUCTURE:')
      console.log('  - response:', response)
      console.log('  - response.users:', response.users)
      console.log('  - response.users type:', typeof response.users)
      console.log('  - response.users isArray:', Array.isArray(response.users))
      console.log('  - response.users length:', response.users?.length)
      console.log('  - response.data:', response.data)
      console.log('  - response.message:', response.message)
      console.log('  - response.totalLogs:', response.totalLogs)
      console.log('  - response.pagination:', response.pagination)

      // Detailed response analysis
      console.log('🔍 DETAILED RESPONSE ANALYSIS:')
      console.log('  - response.users:', response.users)
      console.log('  - response.users type:', typeof response.users)
      console.log('  - response.users isArray:', Array.isArray(response.users))
      console.log('  - response.users length:', response.users?.length)
      console.log('  - response.data:', response.data)
      console.log('  - response.data type:', typeof response.data)
      console.log('  - response.data isArray:', Array.isArray(response.data))
      console.log('  - response.data length:', response.data?.length)
      console.log('  - response.totalLogs:', response.totalLogs)
      console.log('  - response.pagination:', response.pagination)

      try {
        // Simplified data extraction - focus on users array
        let users = []
        let pagination = {}
        let totalLogs = 0

        console.log('🔍 SIMPLIFIED DATA EXTRACTION:')
        console.log('  - response.users exists:', !!response.users)
        console.log('  - response.users type:', typeof response.users)
        console.log(
          '  - response.users isArray:',
          Array.isArray(response.users),
        )
        console.log('  - response.users length:', response.users?.length)
        console.log('  - response is array:', Array.isArray(response))
        console.log('  - response length:', response?.length)
        console.log('  - response.message:', response.message)
        console.log('  - response.totalLogs:', response.totalLogs)
        console.log('  - response.pagination:', response.pagination)
        console.log('  - First user sample:', response.users?.[0])

        // Handle API response structure - use response.data
        if (response.data && Array.isArray(response.data)) {
          console.log('✅ Using response.data array')
          console.log('✅ Users count:', response.data.length)
          users = response.data
          pagination = response.pagination || {}
          totalLogs = response.data.length || 0
        } else if (response.users && Array.isArray(response.users)) {
          console.log('✅ Using response.users array')
          console.log('✅ Users count:', response.users.length)
          users = response.users
          pagination = response.pagination || {}
          totalLogs = response.totalLogs || 0
        } else {
          console.warn('⚠️ No users array found in response')
          console.warn(
            '⚠️ Available response keys:',
            Object.keys(response || {}),
          )
          console.warn('⚠️ Response structure:', response)
          users = []
          pagination = {}
          totalLogs = 0
        }

        // Force debug if we have users but they're not being processed
        if (users.length > 0) {
          console.log(
            '🔍 FORCE DEBUG - Users extracted successfully:',
            users.length,
          )
          console.log('🔍 FORCE DEBUG - First user:', users[0])
          console.log('🔍 FORCE DEBUG - First user logs:', users[0]?.logs)
        } else {
          console.error('❌ FORCE DEBUG - No users extracted from response!')
          console.error('❌ Response structure:', response)
          console.error('❌ Available keys:', Object.keys(response || {}))
        }

        console.log('🔍 EXTRACTED DATA:')
        console.log('  - users.length:', users.length)
        console.log('  - pagination:', pagination)
        console.log('  - totalLogs:', totalLogs)
        console.log('  - first user:', users[0])
        console.log('  - first user logs:', users[0]?.logs)
        console.log('  - first user logs length:', users[0]?.logs?.length)

        console.log('📊 Processing API response:', {
          usersCount: users.length,
          totalLogs: totalLogs,
          pagination: pagination,
          sampleUser: users[0],
          responseKeys: Object.keys(response),
          fullResponse: response,
        })

        // Transform the data for display - create user history entries
        const transformedLogs = []

        console.log('🔄 Starting data transformation:', {
          usersToProcess: users.length,
          firstUser: users[0],
        })

        if (users.length === 0) {
          console.warn('⚠️ No users to process - users array is empty')
        } else {
          console.log(`🔄 Processing ${users.length} users...`)
          users.forEach((user, userIndex) => {
            console.log(`👤 Processing user ${userIndex + 1}:`, {
              user_id: user.user_id,
              first_name: user.first_name,
              last_name: user.last_name,
              email: user.email,
              hasLogs: !!(user.logs && user.logs.length > 0),
              logsCount: user.logs ? user.logs.length : 0,
              userKeys: Object.keys(user),
              userLogs: user.logs,
            })

            const userLogs = user.logs || []
            console.log(`📝 User ${userIndex + 1} has ${userLogs.length} logs`)
            console.log(`📝 User ${userIndex + 1} logs:`, userLogs)

            // Check if user has the expected structure
            if (!user.user_id) {
              console.error(`❌ User ${userIndex + 1} missing user_id:`, user)
            }
            if (!user.first_name && !user.last_name) {
              console.error(`❌ User ${userIndex + 1} missing name:`, user)
            }

            if (userLogs.length === 0) {
              console.warn(
                `⚠️ User ${userIndex + 1} has no logs - creating empty entry`,
              )
              // Create an entry even for users with no logs
              const fullName =
                `${user.first_name || ''} ${user.last_name || ''}`.trim()
              const userHistoryEntry = {
                id: userIndex + 1,
                userId: user.user_id,
                name: fullName || 'N/A',
                email: user.email || 'N/A',
                phone: user.ph_no
                  ? `${user.ph_ext || '+91'} ${user.ph_no}`
                  : 'N/A',
                currentStatus: 'N/A',
                isCurrentlyBlacklisted: false,
                totalActions: user.totalActions || 0,
                lastActionDate: 'N/A',
                lastActionBy: 'N/A',
                blockReasons: [],
                unblockReasons: [],
                allLogs: [],
              }
              console.log(
                `📝 Empty user history entry ${userIndex + 1}:`,
                userHistoryEntry,
              )
              transformedLogs.push(userHistoryEntry)
              console.log(
                `✅ Added empty user ${userIndex + 1} to transformedLogs. Total count:`,
                transformedLogs.length,
              )
            } else {
              console.log(`✅ User ${userIndex + 1} has logs, processing...`)

              // Sort logs by blacklist_time (most recent first)
              const sortedLogs = userLogs.sort(
                (a, b) =>
                  new Date(b.blacklist_time) - new Date(a.blacklist_time),
              )
              console.log(`📝 User ${userIndex + 1} sorted logs:`, sortedLogs)

              // Format the name properly
              const fullName =
                `${user.first_name || ''} ${user.last_name || ''}`.trim()
              console.log(`📝 User ${userIndex + 1} full name:`, fullName)

              // Get current status (most recent action)
              const currentStatus = sortedLogs[0]?.action || 'N/A'
              const currentBlacklisted = sortedLogs[0]?.black_listed || false
              console.log(
                `📝 User ${userIndex + 1} current status:`,
                currentStatus,
                currentBlacklisted,
              )

              // Collect all block and unblock reasons with timestamps
              const blockReasons = []
              const unblockReasons = []

              sortedLogs.forEach((log, logIndex) => {
                const formattedDate = log.blacklist_time
                  ? new Date(log.blacklist_time).toLocaleDateString('en-GB', {
                      day: '2-digit',
                      month: '2-digit',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })
                  : 'N/A'

                const reasonEntry = {
                  reason: log.reason || 'N/A',
                  date: formattedDate,
                  blacklistedBy: log.blacklisted_by || 'N/A',
                  logId: log.log_id || `${user.user_id}_${logIndex}`,
                }

                if (log.action === 'BLACKLISTED') {
                  blockReasons.push(reasonEntry)
                } else if (log.action === 'UNBLOCKED') {
                  unblockReasons.push(reasonEntry)
                }
              })

              // Create a single entry per user showing their history
              const userHistoryEntry = {
                id: userIndex + 1, // Sequential ID for table display
                userId: user.user_id,
                name: fullName || 'N/A',
                email: user.email || 'N/A',
                phone: user.ph_no
                  ? `${user.ph_ext || '+91'} ${user.ph_no}`
                  : 'N/A',
                currentStatus: currentStatus,
                isCurrentlyBlacklisted: currentBlacklisted,
                totalActions: user.totalActions || 0,
                lastActionDate: sortedLogs[0]?.blacklist_time
                  ? new Date(sortedLogs[0].blacklist_time).toLocaleDateString(
                      'en-GB',
                      {
                        day: '2-digit',
                        month: '2-digit',
                        year: 'numeric',
                      },
                    )
                  : 'N/A',
                lastActionBy: sortedLogs[0]?.blacklisted_by || 'N/A',
                blockReasons: blockReasons,
                unblockReasons: unblockReasons,
                allLogs: sortedLogs, // Keep all logs for detailed view
              }

              console.log(
                `📝 User history entry ${userIndex + 1}:`,
                userHistoryEntry,
              )
              transformedLogs.push(userHistoryEntry)
              console.log(
                `✅ Added user ${userIndex + 1} to transformedLogs. Total count:`,
                transformedLogs.length,
              )
            }
          })
        }

        console.log('✅ Data transformation complete:', {
          transformedLogsCount: transformedLogs.length,
          sampleTransformedLog: transformedLogs[0],
        })

        if (transformedLogs.length === 0) {
          console.error('❌ NO TRANSFORMED LOGS CREATED!')
          console.error('❌ Users processed:', users.length)
          console.error(
            '❌ Users with logs:',
            users.filter((u) => u.logs && u.logs.length > 0).length,
          )
        }

        // Display all transformed data for debugging
        console.log('📋 ALL TRANSFORMED LOGS DATA FOR TABLE:', transformedLogs)
        console.log('📊 TABLE DATA SUMMARY:', {
          totalLogs: transformedLogs.length,
          logsByStatus: {
            BLACKLISTED: transformedLogs.filter(
              (log) => log.status === 'BLACKLISTED',
            ).length,
            UNBLOCKED: transformedLogs.filter(
              (log) => log.status === 'UNBLOCKED',
            ).length,
            OTHER: transformedLogs.filter(
              (log) => !['BLACKLISTED', 'UNBLOCKED'].includes(log.status),
            ).length,
          },
          uniqueUsers: [...new Set(transformedLogs.map((log) => log.name))],
        })

        console.log(
          '🔄 Setting logsData state with',
          transformedLogs.length,
          'items',
        )
        console.log('🔄 Transformed logs data:', transformedLogs)
        setLogsData(transformedLogs)
        setLogsPagination({
          ...pagination,
          total: totalLogs,
        })

        // Additional debugging
        console.log(
          '🔄 State update complete - logsData should now have:',
          transformedLogs.length,
          'items',
        )

        console.log('✅ Blacklist history loaded successfully', {
          logsCount: transformedLogs.length,
          totalLogs: totalLogs,
          pagination: pagination,
        })

        // Do not show a toast for logs load success to avoid noise in the logs modal
      } catch (transformError) {
        console.error('❌ Error processing blacklist history:', transformError)
        setSnackbar({
          open: true,
          message: 'Error processing blacklist history data.',
          severity: 'error',
        })
        setLogsData([])
        setLogsPagination({})
      }
    },
    onError: (error) => {
      console.error('❌ Blacklist history mutation error:', error)
      console.error('Error details:', {
        message: error.message,
        response: error.response?.data,
        status: error.response?.status,
        stack: error.stack,
      })

      setSnackbar({
        open: true,
        message:
          error?.response?.data?.message ||
          error?.message ||
          'Failed to load blacklist history. Please try again.',
        severity: 'error',
      })
      setLogsData([])
      setLogsPagination({})
    },
  })

  // Assign mutations to refs to avoid dependency issues
  visitorsMutationRef.current = visitorsMutation

  // Process branches data when it's available from useQuery
  useEffect(() => {
    if (branchesData) {
      console.log('🔍 Branches data received:', branchesData)
      
      // Handle different response structures
      let branchesArray = []
      if (branchesData?.data) {
        branchesArray = branchesData.data
      } else if (branchesData?.organisationDetails?.branches) {
        branchesArray = branchesData.organisationDetails.branches
      } else if (Array.isArray(branchesData)) {
        branchesArray = branchesData
      }

      if (branchesArray && branchesArray.length > 0) {
        setBranches(branchesArray)
        const initialBranchId = branchesArray[0].branch_id || branchesArray[0].id
        setSelectedBranch(initialBranchId)
        setBranchId(initialBranchId)
        setIsInitialized(true)
        console.log('✅ Branches loaded successfully')
      } else {
        console.warn('No branches found in response')
        setBranches([])
        setSelectedBranch('')
        setBranchId('')
      }
    }
  }, [branchesData])

  // Handle branches error
  useEffect(() => {
    if (branchesError) {
      console.error('Error fetching branches:', branchesError)
      setSnackbar({
        open: true,
        message: 'Failed to load branches.',
        severity: 'error',
      })
      setBranches([])
      setSelectedBranch('')
      setBranchId('')
    }
  }, [branchesError])

  // Reset initialization when auth changes significantly
  useEffect(() => {
    if (!auth?.org_id) {
      setIsInitialized(false)
      setIsLoadingVisitors(false)
      isVisitorsRequestInProgress.current = false
      lastRequestKey.current = ''
      if (requestTimeoutRef.current) {
        clearTimeout(requestTimeoutRef.current)
        requestTimeoutRef.current = null
      }
    }
  }, [auth?.org_id])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (requestTimeoutRef.current) {
        clearTimeout(requestTimeoutRef.current)
        requestTimeoutRef.current = null
      }
    }
  }, [])

  // Function to fetch visitors with deduplication
  const fetchVisitors = useCallback(() => {
    if (
      !branch_id ||
      !auth?.org_id ||
      branches.length === 0 ||
      isLoadingVisitors ||
      isVisitorsRequestInProgress.current
    ) {
      console.log('🚫 Skipping visitors fetch - conditions not met', {
        branch_id: !!branch_id,
        org_id: !!auth?.org_id,
        branchesCount: branches.length,
        isLoadingVisitors,
        isRequestInProgress: isVisitorsRequestInProgress.current,
      })
      return
    }

    const requestData = {
      org_id: auth.org_id || auth.orgId,
      branch_id: branch_id,
      date: format(data_of_visit, 'dd-MM-yyyy'),
    }

    // Create a unique request key to prevent duplicate calls
    const requestKey = `${requestData.org_id}-${requestData.branch_id}-${requestData.date}`

    if (lastRequestKey.current === requestKey) {
      console.log('🚫 Skipping duplicate visitors request', { requestKey })
      return
    }

    console.log('🔄 Fetching visitors for blacklist management', {
      requestKey,
      branch_id,
      org_id: auth.org_id,
      branchesCount: branches.length,
      date: requestData.date,
    })

    // Clear any existing timeout
    if (requestTimeoutRef.current) {
      clearTimeout(requestTimeoutRef.current)
    }

    // Set loading states
    setIsLoadingVisitors(true)
    isVisitorsRequestInProgress.current = true
    lastRequestKey.current = requestKey

    // Add a small delay to prevent rapid successive calls
    requestTimeoutRef.current = setTimeout(() => {
      visitorsMutationRef.current?.mutate(requestData)
    }, 100)
  }, [
    branch_id,
    auth?.org_id,
    auth.orgId,
    branches.length,
    data_of_visit,
    isLoadingVisitors,
  ])

  // Reset request progress when branch changes
  useEffect(() => {
    isVisitorsRequestInProgress.current = false
    lastRequestKey.current = ''
    if (requestTimeoutRef.current) {
      clearTimeout(requestTimeoutRef.current)
      requestTimeoutRef.current = null
    }
  }, [branch_id])

  // Fetch visitors when branches are loaded and branch is selected
  useEffect(() => {
    fetchVisitors()
  }, [fetchVisitors])

  // Handle search filtering
  useEffect(() => {
    if (searchTerm && searchTerm.trim() !== '') {
      console.log('Search term:', searchTerm)
      const searchLower = searchTerm.toLowerCase().trim()

      const filtered = visitors.filter((visitor) => {
        // Safely handle null/undefined values
        const name = visitor.name || ''
        const email = visitor.email || ''
        const phone = visitor.phone || ''
        const organization = visitor.organization || ''

        const nameMatch = name.toLowerCase().includes(searchLower)
        const emailMatch = email.toLowerCase().includes(searchLower)
        const phoneMatch = phone.toLowerCase().includes(searchLower)
        const orgMatch = organization.toLowerCase().includes(searchLower)

        console.log('Search matches for visitor:', {
          name: name,
          email: email,
          phone: phone,
          organization: organization,
          nameMatch,
          emailMatch,
          phoneMatch,
          orgMatch,
        })

        return nameMatch || emailMatch || phoneMatch || orgMatch
      })
      console.log('Filtered results:', filtered.length)
      setFilteredVisitors(filtered)
    } else {
      setFilteredVisitors(visitors)
    }
  }, [searchTerm, visitors])

  const [toggledVisitorId, setToggledVisitorId] = useState(null)
  const [blacklistModalOpen, setBlacklistModalOpen] = useState(false)
  const [selectedVisitor, setSelectedVisitor] = useState(null)
  const [blacklistReason, setBlacklistReason] = useState('')
  const [isUnblocking, setIsUnblocking] = useState(false)
  const [logsModalOpen, setLogsModalOpen] = useState(false)
  const [logsData, setLogsData] = useState([])
  const [historyModalOpen, setHistoryModalOpen] = useState(false)
  const [selectedUserHistory, setSelectedUserHistory] = useState(null)

  // Debug effect to monitor logsData changes
  useEffect(() => {
    console.log('🔍 logsData state changed:', {
      length: logsData.length,
      data: logsData,
      type: typeof logsData,
      isArray: Array.isArray(logsData),
    })
  }, [logsData])

  // Logs modal state
  const [logsSearchTerm, setLogsSearchTerm] = useState('')
  const [logsStartDate, setLogsStartDate] = useState('')
  const [logsEndDate, setLogsEndDate] = useState('')
  const [logsCurrentPage, setLogsCurrentPage] = useState(1)
  const [logsPageSize] = useState(10)
  const [logsPagination, setLogsPagination] = useState({})

  const handleBlacklistToggle = async (visitorId) => {
    const visitor = visitors.find((v) => v.user_id === visitorId)
    if (!visitor) return

    // Store the original state for potential reversion
    const originalBlacklistedState = visitor.blacklisted
    const newBlacklistedState = !visitor.blacklisted

    // Immediately update the visual state of the toggle for better UX
    const updatedVisitors = visitors.map((v) => {
      if (v.user_id === visitorId) {
        return { ...v, blacklisted: newBlacklistedState }
      }
      return v
    })
    setVisitors(updatedVisitors)
    setFilteredVisitors(updatedVisitors)

    // Show modal for both blocking and unblocking
    setSelectedVisitor({ ...visitor, blacklisted: newBlacklistedState })
    setBlacklistReason('')
    setIsUnblocking(originalBlacklistedState) // If was blacklisted, this is an unblock action
    setBlacklistModalOpen(true)
  }

  const handleBlacklistConfirm = () => {
    if (!selectedVisitor || !blacklistReason.trim()) {
      return
    }

    // Check if we have a real user_id from the API
    if (!selectedVisitor.user_id) {
      setSnackbar({
        open: true,
        message: `Cannot ${isUnblocking ? 'unblock' : 'block'}: User ID not available from API. Please contact support.`,
        severity: 'error',
      })
      setBlacklistModalOpen(false)
      return
    }

    // Validate the request data before sending
    if (
      !selectedVisitor.user_id ||
      selectedVisitor.user_id === '' ||
      selectedVisitor.user_id === null ||
      selectedVisitor.user_id === undefined
    ) {
      setSnackbar({
        open: true,
        message: 'Invalid user ID. Cannot update blacklist status.',
        severity: 'error',
      })
      setBlacklistModalOpen(false)
      return
    }

    if (!auth?.org_id || !selectedBranch) {
      setSnackbar({
        open: true,
        message: 'Missing organization or branch information.',
        severity: 'error',
      })
      setBlacklistModalOpen(false)
      return
    }

    // Store which visitor is being toggled
    setToggledVisitorId(selectedVisitor.user_id)

    // Prepare the exact API request body as per specification
    const blacklistData = {
      org_id: auth?.org_id || auth.orgId,
      branch_id: selectedBranch,
      user_id: selectedVisitor.user_id, // Direct user_id from visitor data
      black_listed: !isUnblocking, // true for block, false for unblock
      reason: blacklistReason.trim(), // Include the reason from modal
      blacklisted_by: auth?.username || 'system', // Include who blacklisted
    }

    console.log(
      `Sending ${isUnblocking ? 'unblock' : 'block'} request:`,
      blacklistData,
    )
    console.log(
      'API Endpoint: PUT https://api-dev.myvisiq.com/api/faces/updateBlackList',
    )
    console.log('Request Body:', JSON.stringify(blacklistData, null, 2))
    console.log(`Blacklist Status: ${!isUnblocking ? 'BLOCKED' : 'UNBLOCKED'}`)
    console.log(`Reason: ${blacklistReason.trim()}`)
    console.log(`Blacklisted By: ${auth?.username || 'system'}`)

    // Use the mutation to update blacklist - state will be updated on success
    blacklistMutation.mutate(blacklistData)

    // Close modal
    setBlacklistModalOpen(false)
    setSelectedVisitor(null)
    setBlacklistReason('')
    setIsUnblocking(false)
  }

  const handleBlacklistCancel = () => {
    // Revert the toggle state if user cancels
    if (selectedVisitor) {
      const updatedVisitors = visitors.map((v) => {
        if (v.user_id === selectedVisitor.user_id) {
          return { ...v, blacklisted: !selectedVisitor.blacklisted }
        }
        return v
      })
      setVisitors(updatedVisitors)
      setFilteredVisitors(updatedVisitors)
    }

    setBlacklistModalOpen(false)
    setSelectedVisitor(null)
    setBlacklistReason('')
    setIsUnblocking(false)
  }

  const handleLogsClick = () => {
    try {
      console.log('🔍 Logs button clicked')

      // Check if we have required parameters
      if (!auth?.org_id || !selectedBranch) {
        console.log('❌ Missing required parameters:', {
          org_id: auth?.org_id,
          selectedBranch: selectedBranch,
        })
        setSnackbar({
          open: true,
          message: 'Please select a branch to view blacklist logs.',
          severity: 'warning',
        })
        return
      }

      // Reset pagination and open modal
      setLogsCurrentPage(1)
      setLogsModalOpen(true)

      // Call the API to get real blacklist history with all parameters
      const requestParams = {
        org_id: auth.org_id,
        branch_id: selectedBranch,
        page: 1,
        limit: logsPageSize,
        search: logsSearchTerm || '',
        start_date: logsStartDate || '',
        end_date: logsEndDate || '',
      }

      console.log('🚀 Fetching blacklist history with params:', requestParams)
      console.log('📋 Request details:', {
        org_id: requestParams.org_id,
        branch_id: requestParams.branch_id,
        page: requestParams.page,
        limit: requestParams.limit,
        search: requestParams.search || 'not provided',
        start_date: requestParams.start_date || 'not provided',
        end_date: requestParams.end_date || 'not provided',
        hasSearch: !!requestParams.search,
        hasStartDate: !!requestParams.start_date,
        hasEndDate: !!requestParams.end_date,
        totalParams: Object.keys(requestParams).length,
      })

      console.log('📅 Date values being sent:', {
        logsStartDate: logsStartDate,
        logsEndDate: logsEndDate,
        start_date_type: typeof logsStartDate,
        end_date_type: typeof logsEndDate,
        start_date_length: logsStartDate?.length,
        end_date_length: logsEndDate?.length,
      })

      blacklistHistoryMutation.mutate(requestParams)
    } catch (error) {
      console.error('❌ Error in handleLogsClick:', error)
      setSnackbar({
        open: true,
        message: 'An error occurred while opening logs.',
        severity: 'error',
      })
    }
  }

  const handleLogsClose = () => {
    setLogsModalOpen(false)
    setLogsData([])
    setLogsPagination({})
    setLogsSearchTerm('')
    setLogsStartDate('')
    setLogsEndDate('')
    setLogsCurrentPage(1)
  }

  const handleLogsSearch = () => {
    console.log('🔍 SEARCH BUTTON CLICKED!')
    console.log('🔍 Auth check:', {
      org_id: auth?.org_id,
      selectedBranch: selectedBranch,
      hasOrgId: !!auth?.org_id,
      hasBranch: !!selectedBranch,
    })

    if (!auth?.org_id || !selectedBranch) {
      console.log('❌ Search cancelled - missing org_id or selectedBranch')
      return
    }

    const requestParams = {
      org_id: auth.org_id,
      branch_id: selectedBranch,
      page: 1,
      limit: logsPageSize,
      search: logsSearchTerm || '',
      start_date: logsStartDate || '',
      end_date: logsEndDate || '',
    }

    console.log('🔍 Search request params:', requestParams)
    console.log('🔍 Calling blacklistHistoryMutation.mutate...')

    setLogsCurrentPage(1)
    blacklistHistoryMutation.mutate(requestParams)

    console.log(
      '🔍 Mutation called, isPending:',
      blacklistHistoryMutation.isPending,
    )
  }

  const handleViewHistory = (userHistory) => {
    console.log('📋 Opening history modal for user:', userHistory)
    setSelectedUserHistory(userHistory)
    setHistoryModalOpen(true)
  }

  const handleCloseHistoryModal = () => {
    setHistoryModalOpen(false)
    setSelectedUserHistory(null)
  }

  const handleLogsPageChange = (newPage) => {
    if (!auth?.org_id || !selectedBranch) return

    const requestParams = {
      org_id: auth.org_id,
      branch_id: selectedBranch,
      page: newPage,
      limit: logsPageSize,
      search: logsSearchTerm || '',
      start_date: logsStartDate || '',
      end_date: logsEndDate || '',
    }

    setLogsCurrentPage(newPage)
    blacklistHistoryMutation.mutate(requestParams)
  }

  const getCategoryColor = (category) => {
    switch (category) {
      case 'Business':
        return {
          backgroundColor: '#E6F7ED',
          color: '#28A745',
          border: '1px solid #C3E6CB',
        }
      case 'Vendor':
        return {
          backgroundColor: '#FDEBEB',
          color: '#DC3545',
          border: '1px solid #F5C6CB',
        }
      case 'Interview':
        return {
          backgroundColor: '#EBF4FA',
          color: '#007BFF',
          border: '1px solid #BEE5EB',
        }
      case 'Maintenance':
        return {
          backgroundColor: '#FFF3E0',
          color: '#FFC107',
          border: '1px solid #FFEAA7',
        }
      default:
        return {
          backgroundColor: '#F8F9FA',
          color: '#6C757D',
          border: '1px solid #DEE2E6',
        }
    }
  }

  const paginatedVisitors = filteredVisitors.slice(
    (page - 1) * _rowsPerPage,
    page * _rowsPerPage,
  )

  const totalPages = Math.ceil(filteredVisitors.length / _rowsPerPage)

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false })
  }

  const CustomInput = React.forwardRef(({ value, onClick }, ref) => (
    <button
      className="btn bg-secondary"
      onClick={onClick}
      ref={ref}
      readOnly
      style={{
        padding: '14px 16px',
        border: '1px solid #DDDDDD',
        borderRadius: '4px',
        backgroundColor: '#FFFFFF',
        cursor: 'pointer',
        fontSize: '14px',
        color: '#333333',
        display: 'flex',
        alignItems: 'center',
        gap: '8px',
        minWidth: '200px',
        justifyContent: 'space-between',
        height: '56px',
        boxSizing: 'border-box',
      }}
    >
      <span>{value || 'Select a date'}</span>
      <CalendarTodayIcon sx={{ fontSize: 18, color: '#666666' }} />
    </button>
  ))

  CustomInput.displayName = 'CustomInput'

  const handleDateChange = (date) => {
    set_data_of_visit(date)
    // Refresh visitors data when date changes
    if (branch_id && auth?.org_id) {
      const requestData = {
        org_id: auth.org_id || auth.orgId,
        branch_id: branch_id,
        date: format(date, 'dd-MM-yyyy'), // getAttendance expects 'date' parameter
      }
      visitorsMutation.mutate(requestData)
    }
  }

  return (
    <Box
      sx={{
        p: 3,
        minHeight: '100vh',
      }}
    >
      {/* Header */}
      <Typography
        variant="h4"
        sx={{
          mb: 1,
          fontWeight: 'bold',
          color: '#333333',
          display: 'flex',
          alignItems: 'center',
          gap: 2,
        }}
      >
        🛡️ Blacklist Management
      </Typography>
      <Typography
        variant="body1"
        sx={{ color: '#666666', fontSize: '1.1rem', mb: 3 }}
      >
        Manage visitor access and blacklist settings by branch
      </Typography>

      {/* Controls */}
      <Box
        sx={{
          background: 'rgba(255,255,255,0.95)',
          borderRadius: 3,
          p: 3,
          mb: 3,
          boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
          backdropFilter: 'blur(10px)',
          border: '1px solid rgba(255,255,255,0.2)',
          zIndex: 10,
          position: 'relative',
        }}
      >
        <Box
          sx={{
            display: 'flex',
            gap: 2,
            alignItems: 'flex-start',
            flexWrap: 'wrap',
          }}
        >
          {/* Branch Select */}
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              gap: 1,
              minWidth: 200,
            }}
          >
            <Typography
              variant="body2"
              sx={{ color: '#666666', fontWeight: 'medium' }}
            >
              Select Branch
            </Typography>
            <FormControl sx={{ minWidth: 200 }}>
              <Select
                value={selectedBranch}
                onChange={(e) => {
                  setSelectedBranch(e.target.value)
                  setBranchId(e.target.value)
                }}
                disabled={branchesLoading}
                displayEmpty
                sx={{
                  backgroundColor: branchesLoading
                    ? '#F5F5F5'
                    : '#E3F2FD',
                  borderRadius: 2,
                  height: '56px',
                  '& .MuiOutlinedInput-notchedOutline': {
                    borderColor: branchesLoading
                      ? '#BDBDBD'
                      : '#2196F3',
                    borderWidth: 2,
                  },
                  '&:hover .MuiOutlinedInput-notchedOutline': {
                    borderColor: branchesLoading
                      ? '#BDBDBD'
                      : '#1976D2',
                    borderWidth: 2,
                  },
                  '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                    borderColor: branchesLoading
                      ? '#BDBDBD'
                      : '#1976D2',
                    borderWidth: 2,
                  },
                  '& .MuiSelect-select': {
                    padding: '12px 14px',
                    color: branchesLoading ? '#9E9E9E' : '#1976D2',
                    fontWeight: 'medium',
                    height: '56px',
                    display: 'flex',
                    alignItems: 'center',
                  },
                }}
                renderValue={(selected) => {
                  if (branchesLoading) {
                    return (
                      <Box
                        sx={{ display: 'flex', alignItems: 'center', gap: 1 }}
                      >
                        <CircularProgress size={16} sx={{ color: '#2196F3' }} />
                        <Typography variant="body2" sx={{ color: '#666666' }}>
                          Loading branches...
                        </Typography>
                      </Box>
                    )
                  }
                  if (!selected) {
                    return (
                      <Typography variant="body2" sx={{ color: '#9E9E9E' }}>
                        Select a branch
                      </Typography>
                    )
                  }
                  const branch = branches.find((b) => b.branch_id === selected)
                  return branch?.branch_name || 'Select a branch'
                }}
              >
                {branchesLoading ? (
                  <MenuItem disabled>
                    <Box
                      sx={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: 1,
                        width: '100%',
                      }}
                    >
                      <CircularProgress size={20} sx={{ color: '#2196F3' }} />
                      <Typography variant="body2" sx={{ color: '#666666' }}>
                        Loading branches...
                      </Typography>
                    </Box>
                  </MenuItem>
                ) : (
                  branches.map((branch) => (
                    <MenuItem key={branch.branch_id} value={branch.branch_id}>
                      {branch.branch_name}
                    </MenuItem>
                  ))
                )}
              </Select>
            </FormControl>
          </Box>

          {/* Date Picker */}
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              gap: 1,
              minWidth: 200,
            }}
          >
            <Typography
              variant="body2"
              sx={{ color: '#666666', fontWeight: 'medium' }}
            >
              Select Date:
            </Typography>
            <DatePicker
              selected={data_of_visit}
              onChange={handleDateChange}
              dateFormat="dd-MM-yyyy"
              customInput={<CustomInput />}
              onKeyDown={(e) => e.preventDefault()}
              popperPlacement="top"
              popperContainer={({ children }) => (
                <div style={{ zIndex: 9999, position: 'relative' }}>
                  {children}
                </div>
              )}
              popperModifiers={[
                {
                  name: 'preventOverflow',
                  options: {
                    boundary: 'viewport',
                  },
                },
                {
                  name: 'flip',
                  options: {
                    fallbackPlacements: ['top', 'bottom'],
                  },
                },
                {
                  name: 'offset',
                  options: {
                    offset: [0, -5],
                  },
                },
              ]}
            />
          </Box>

          {/* Search */}
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              gap: 1,
              minWidth: 300,
            }}
          >
            <Typography
              variant="body2"
              sx={{ color: '#666666', fontWeight: 'medium' }}
            >
              Search Visitors:
            </Typography>
            <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
              <TextField
                placeholder="Search by name, email, phone, organization"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                disabled={visitorsMutation.isPending}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      {visitorsMutation.isPending ? (
                        <CircularProgress size={20} sx={{ color: '#667eea' }} />
                      ) : (
                        <SearchIcon sx={{ color: '#667eea' }} />
                      )}
                    </InputAdornment>
                  ),
                  endAdornment: searchTerm && (
                    <InputAdornment position="end">
                      <IconButton
                        onClick={() => setSearchTerm('')}
                        size="small"
                        sx={{ color: '#667eea' }}
                      >
                        <CloseIcon fontSize="small" />
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
                sx={{
                  flex: 1,
                  backgroundColor: '#FFFFFF',
                  borderRadius: 2,
                  '& .MuiOutlinedInput-root': {
                    height: '56px',
                  },
                  '& .MuiOutlinedInput-notchedOutline': {
                    borderColor: '#E0E0E0',
                    borderWidth: 2,
                  },
                  '&:hover .MuiOutlinedInput-notchedOutline': {
                    borderColor: '#667eea',
                    borderWidth: 2,
                  },
                  '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                    borderColor: '#667eea',
                    borderWidth: 2,
                  },
                  '& .MuiInputBase-input': {
                    padding: '12px 14px',
                    height: 'auto',
                  },
                }}
              />
              <Button
                variant="outlined"
                startIcon={
                  blacklistHistoryMutation.isPending ? (
                    <CircularProgress size={20} sx={{ color: '#667eea' }} />
                  ) : (
                    <ListIcon />
                  )
                }
                disabled={blacklistHistoryMutation.isPending}
                sx={{
                  height: '56px',
                  minWidth: '100px',
                  borderColor: '#667eea',
                  color: '#667eea',
                  fontWeight: 'medium',
                  borderRadius: 2,
                  textTransform: 'none',
                  '&:hover': {
                    borderColor: '#5a67d8',
                    backgroundColor: '#f7fafc',
                  },
                  '&:disabled': {
                    borderColor: '#BDBDBD',
                    color: '#9E9E9E',
                  },
                }}
                onClick={handleLogsClick}
              >
                {blacklistHistoryMutation.isPending ? 'Loading...' : 'Logs'}
              </Button>
              {/* <Button
                variant="outlined"
                size="small"
                onClick={() => {
                  console.log('🧪 Testing with sample data...')
                  const testData = [
                    {
                      id: 1,
                      name: 'Test User 1',
                      email: 'test1@example.com',
                      phone: '+1234567890',
                      organization: 'Test Org',
                      reason: 'Test reason 1',
                      person: 'Test Person',
                      status: 'BLACKLISTED',
                      date: '28/10/2025',
                      blacklisted: true,
                      logId: 'test-log-1',
                      blockReasons: ['Test reason 1'],
                      unblockReasons: [],
                    },
                    {
                      id: 2,
                      name: 'Test User 2',
                      email: 'test2@example.com',
                      phone: '+1234567891',
                      organization: 'Test Org',
                      reason: 'Test reason 2',
                      person: 'Test Person',
                      status: 'UNBLOCKED',
                      date: '27/10/2025',
                      blacklisted: false,
                      logId: 'test-log-2',
                      blockReasons: [],
                      unblockReasons: ['Test reason 2'],
                    },
                  ]
                  console.log('🧪 Setting test data:', testData)
                  setLogsData(testData)
                  setLogsPagination({
                    currentPage: 1,
                    limit: 10,
                    total: 2,
                    totalPages: 1,
                    hasNextPage: false,
                    hasPreviousPage: false,
                  })
                  console.log('🧪 Test data set successfully!')

                  // Force a re-render by updating state
                  setTimeout(() => {
                    console.log('🧪 After 100ms - logsData state:', logsData)
                    console.log(
                      '🧪 After 100ms - logsPagination state:',
                      logsPagination,
                    )
                  }, 100)
                }}
                sx={{
                  height: '40px',
                  minWidth: '100px',
                  borderColor: '#17a2b8',
                  color: '#17a2b8',
                  fontWeight: 'medium',
                  borderRadius: 2,
                  textTransform: 'none',
                  fontSize: '0.75rem',
                  '&:hover': {
                    borderColor: '#138496',
                    backgroundColor: 'rgba(23, 162, 184, 0.04)',
                  },
                }}
              >
                Test Data
              </Button> */}

              {/* Debug State Button */}

              {/* Test Search Button */}

              {/* Manual Data Test Button */}

              {/* Raw API Test Button */}

              {/* Force Data Button */}

              {/* Debug State Button */}
              {/* <Button
                variant="outlined"
                size="small"
                onClick={() => {
                  console.log('🔍 CURRENT STATE DEBUG:')
                  console.log('  - logsData:', logsData)
                  console.log('  - logsData.length:', logsData.length)
                  console.log('  - logsPagination:', logsPagination)
                  console.log('  - logsModalOpen:', logsModalOpen)
                  console.log(
                    '  - blacklistHistoryMutation.isPending:',
                    blacklistHistoryMutation.isPending,
                  )
                  console.log(
                    '  - blacklistHistoryMutation.isSuccess:',
                    blacklistHistoryMutation.isSuccess,
                  )
                  console.log(
                    '  - blacklistHistoryMutation.isError:',
                    blacklistHistoryMutation.isError,
                  )
                  console.log(
                    '  - blacklistHistoryMutation.error:',
                    blacklistHistoryMutation.error,
                  )

                  const shouldShowData = logsData.length > 0
                  console.log('  - Should show data:', shouldShowData)
                  console.log('  - Table condition check:', {
                    'logsData.length > 0': logsData.length > 0,
                    '!blacklistHistoryMutation.isPending':
                      !blacklistHistoryMutation.isPending,
                    logsModalOpen: logsModalOpen,
                  })
                }}
                sx={{
                  height: '40px',
                  minWidth: '100px',
                  borderColor: '#9c27b0',
                  color: '#9c27b0',
                  fontWeight: 'medium',
                  borderRadius: 2,
                  textTransform: 'none',
                  fontSize: '0.75rem',
                  '&:hover': {
                    borderColor: '#7b1fa2',
                    backgroundColor: 'rgba(156, 39, 176, 0.04)',
                  },
                }}
              >
                Debug State
              </Button> */}

              {/* Exact Test Button */}
            </Box>
          </Box>
        </Box>
      </Box>

      {/* Visitors Table */}
      <Paper
        elevation={0}
        sx={{
          backgroundColor: '#FFFFFF',
          borderRadius: 3,
          overflow: 'hidden',
          border: '1px solid rgba(255,255,255,0.2)',
          boxShadow: '0 8px 32px rgba(0,0,0,0.1)',
          backdropFilter: 'blur(10px)',
          zIndex: 1,
          position: 'relative',
        }}
      >
        {/* Table Header */}
        <Box
          sx={{
            p: 2,
            borderBottom: '1px solid #EEEEEE',
            backgroundColor: '#FAFAFA',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          <Typography
            variant="h6"
            sx={{ fontWeight: 'bold', color: '#333333' }}
          >
            Visitors in{' '}
            {selectedBranch && branches.length > 0
              ? branches.find((b) => b.branch_id === selectedBranch)
                  ?.branch_name || 'Selected Branch'
              : 'Selected Branch'}
          </Typography>
          <Typography variant="body2" sx={{ color: '#666666' }}>
            Total: {filteredVisitors.length} visitors
            {visitorsMutation.isPending && ' (Loading...)'}
          </Typography>
        </Box>

        {/* Table */}
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow sx={{ backgroundColor: '#FAFAFA' }}>
                <TableCell sx={{ fontWeight: 'bold', color: '#333333' }}>
                  Name
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#333333' }}>
                  Category
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#333333' }}>
                  Phone
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#333333' }}>
                  Email
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#333333' }}>
                  Purpose
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#333333' }}>
                  Organization
                </TableCell>
                {auth?.role !== '2' && (
                  <TableCell sx={{ fontWeight: 'bold', color: '#333333' }}>
                    Reason
                  </TableCell>
                )}
                {auth?.role !== '2' && (
                  <TableCell sx={{ fontWeight: 'bold', color: '#333333' }}>
                    Person
                  </TableCell>
                )}
                <TableCell sx={{ fontWeight: 'bold', color: '#333333' }}>
                  Blacklist
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {visitorsMutation.isPending ? (
                <TableRow>
                  <TableCell colSpan={auth?.role === '2' ? 7 : 9} align="center" sx={{ py: 6 }}>
                    <Box
                      sx={{
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        gap: 2,
                      }}
                    >
                      <CircularProgress size={32} sx={{ color: '#667eea' }} />
                      <Typography
                        variant="body1"
                        sx={{ color: '#666666', fontWeight: 'medium' }}
                      >
                        Loading visitors...
                      </Typography>
                      <Typography variant="body2" sx={{ color: '#999999' }}>
                        Please wait while we fetch the latest data
                      </Typography>
                    </Box>
                  </TableCell>
                </TableRow>
              ) : paginatedVisitors.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={auth?.role === '2' ? 7 : 9} align="center" sx={{ py: 4 }}>
                    <Typography variant="body1" sx={{ color: '#666666' }}>
                      {filteredVisitors.length === 0 && visitors.length === 0
                        ? 'No visitors found for this branch. Please select a different branch.'
                        : 'No visitors match your search criteria.'}
                    </Typography>
                  </TableCell>
                </TableRow>
              ) : (
                paginatedVisitors.map((visitor) => (
                  <TableRow
                    key={visitor.id}
                    hover
                    sx={{ '&:hover': { backgroundColor: '#F8F9FA' } }}
                  >
                    <TableCell sx={{ fontWeight: 'medium', color: '#333333' }}>
                      {visitor.name}
                    </TableCell>
                    <TableCell>
                      <Chip
                        label={visitor.category}
                        size="small"
                        sx={{
                          fontWeight: 'medium',
                          ...getCategoryColor(visitor.category),
                          '& .MuiChip-label': {
                            color: getCategoryColor(visitor.category).color,
                          },
                        }}
                      />
                    </TableCell>
                    <TableCell sx={{ color: '#333333' }}>
                      {visitor.phone && 
                       visitor.phone.trim() !== '' && 
                       !visitor.phone.includes('XXXXXXXXXX') 
                        ? visitor.phone 
                        : 'N/A'}
                    </TableCell>
                    <TableCell sx={{ color: '#333333' }}>
                      {visitor.email && 
                       visitor.email.trim() !== '' && 
                       visitor.email.includes('@') &&
                       !visitor.email.includes('XXXXXXXXXX') &&
                       visitor.email !== 'no-email@example.com'
                        ? visitor.email
                        : 'N/A'}
                    </TableCell>
                    <TableCell sx={{ color: '#333333' }}>
                      {visitor.purpose}
                    </TableCell>
                    <TableCell sx={{ color: '#333333' }}>
                      {visitor.organization}
                    </TableCell>
                    {auth?.role !== '2' && (
                      <TableCell sx={{ color: '#333333' }}>
                        {visitor.reason || 'N/A'}
                      </TableCell>
                    )}
                    {auth?.role !== '2' && (
                      <TableCell sx={{ color: '#333333' }}>
                        {auth?.org_name || 'N/A'}
                      </TableCell>
                    )}
                    <TableCell>
                      <FormControlLabel
                        control={
                          <Switch
                            checked={visitor.blacklisted}
                            onChange={() =>
                              handleBlacklistToggle(visitor.user_id)
                            }
                            disabled={blacklistMutation.isPending}
                            sx={{
                              '& .MuiSwitch-switchBase.Mui-checked': {
                                color: '#FF6B6B',
                                '&:hover': {
                                  backgroundColor: 'rgba(255, 107, 107, 0.08)',
                                },
                              },
                              '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track':
                                {
                                  backgroundColor: '#FF6B6B',
                                },
                              '& .MuiSwitch-switchBase:not(.Mui-checked)': {
                                color: '#4A90E2',
                                '&:hover': {
                                  backgroundColor: 'rgba(74, 144, 226, 0.08)',
                                },
                              },
                              '& .MuiSwitch-switchBase:not(.Mui-checked) + .MuiSwitch-track':
                                {
                                  backgroundColor: '#4A90E2',
                                },
                              '& .MuiSwitch-switchBase.Mui-disabled': {
                                color: '#FFB3B3',
                                '&:hover': {
                                  backgroundColor: 'rgba(255, 179, 179, 0.08)',
                                },
                              },
                              '& .MuiSwitch-switchBase.Mui-disabled + .MuiSwitch-track':
                                {
                                  backgroundColor: '#FFB3B3',
                                  opacity: 0.6,
                                },
                            }}
                          />
                        }
                        label={
                          <Box
                            sx={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: 1,
                            }}
                          >
                            {toggledVisitorId === visitor.user_id &&
                            blacklistMutation.isPending ? (
                              <CircularProgress
                                size={16}
                                sx={{ color: '#667eea' }}
                              />
                            ) : null}
                            <Typography
                              variant="body2"
                              sx={{
                                fontWeight: 'medium',
                                color: visitor.blacklisted
                                  ? '#DC3545'
                                  : '#4A90E2',
                              }}
                            >
                              {toggledVisitorId === visitor.user_id &&
                              blacklistMutation.isPending
                                ? 'Processing...'
                                : visitor.blacklisted
                                  ? 'Blacklisted'
                                  : 'Active'}
                            </Typography>
                          </Box>
                        }
                      />
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>

        {/* Pagination */}
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            p: 2,
            borderTop: '1px solid #EEEEEE',
            backgroundColor: '#FFFFFF',
          }}
        >
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <Typography variant="body2" sx={{ color: '#666666' }}>
              {`${(page - 1) * _rowsPerPage + 1}-${Math.min(page * _rowsPerPage, filteredVisitors.length)} of ${filteredVisitors.length}`}
            </Typography>
            <Pagination
              count={totalPages}
              page={page}
              onChange={(e, newPage) => setPage(newPage)}
              color="primary"
              size="small"
            />
          </Box>
        </Box>
      </Paper>

      {/* Snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>

      {/* Blacklist Reason Modal */}
      <Dialog
        open={blacklistModalOpen}
        onClose={handleBlacklistCancel}
        maxWidth="sm"
        fullWidth
        PaperProps={{
          sx: {
            borderRadius: 2,
            boxShadow: '0 8px 32px rgba(0, 0, 0, 0.12)',
          },
        }}
      >
        <DialogTitle
          sx={{
            fontSize: '1.25rem',
            fontWeight: 'bold',
            color: '#6B46C1',
            pb: 1,
          }}
        >
          {isUnblocking ? 'Unblacklisted Reason' : 'Blacklisted Reason'}
        </DialogTitle>

        <DialogContent sx={{ pt: 2 }}>
          {selectedVisitor && (
            <Box sx={{ mb: 3 }}>
              <Typography variant="body1" sx={{ fontWeight: 'medium', mb: 1 }}>
                {selectedVisitor.name} ({selectedVisitor.category})
              </Typography>
              <Typography variant="body2" sx={{ color: '#666', mb: 0.5 }}>
                {auth?.role === '2'
                  ? selectedVisitor.phone &&
                    selectedVisitor.phone.trim() !== '' &&
                    !selectedVisitor.phone.includes('XXXXXXXXXX')
                    ? selectedVisitor.phone
                    : 'N/A'
                  : selectedVisitor.phone}
              </Typography>
              {auth?.role === '2' ? (
                <Typography variant="body2" sx={{ color: '#666' }}>
                  {selectedVisitor.email &&
                  selectedVisitor.email.trim() !== '' &&
                  selectedVisitor.email.includes('@') &&
                  !selectedVisitor.email.includes('XXXXXXXXXX') &&
                  selectedVisitor.email !== 'no-email@example.com'
                    ? selectedVisitor.email
                    : 'N/A'}
                </Typography>
              ) : (
                selectedVisitor.email &&
                String(selectedVisitor.email).includes('@') && (
                  <Typography variant="body2" sx={{ color: '#666' }}>
                    {selectedVisitor.email}
                  </Typography>
                )
              )}
            </Box>
          )}

          <Typography
            variant="body2"
            sx={{ fontWeight: 'medium', mb: 1, color: '#333' }}
          >
            Reason / Comment
          </Typography>
          <TextareaAutosize
            minRows={4}
            maxRows={8}
            value={blacklistReason}
            onChange={(e) => setBlacklistReason(e.target.value)}
            placeholder={
              isUnblocking
                ? 'Enter the reason for unblacklisting this visitor...'
                : 'Enter the reason for blacklisting this visitor...'
            }
            style={{
              width: '100%',
              padding: '12px',
              border: '2px solid #E3F2FD',
              borderRadius: '8px',
              fontSize: '14px',
              fontFamily: 'inherit',
              resize: 'vertical',
              outline: 'none',
              transition: 'border-color 0.2s ease',
            }}
            onFocus={(e) => {
              e.target.style.borderColor = '#2196F3'
            }}
            onBlur={(e) => {
              e.target.style.borderColor = '#E3F2FD'
            }}
          />
        </DialogContent>

        <DialogActions sx={{ p: 3, pt: 1 }}>
          <Button
            onClick={handleBlacklistCancel}
            sx={{
              color: '#2196F3',
              borderColor: '#2196F3',
              border: '1px solid',
              borderRadius: '8px',
              px: 3,
              py: 1,
              textTransform: 'none',
              fontWeight: 'medium',
              '&:hover': {
                backgroundColor: '#F3F9FF',
                borderColor: '#1976D2',
              },
            }}
          >
            Cancel
          </Button>
          <Button
            onClick={handleBlacklistConfirm}
            disabled={!blacklistReason.trim()}
            sx={{
              backgroundColor: blacklistReason.trim()
                ? isUnblocking
                  ? '#4CAF50'
                  : '#F44336'
                : '#E0E0E0',
              color: blacklistReason.trim() ? 'white' : '#9E9E9E',
              borderRadius: '8px',
              px: 3,
              py: 1,
              textTransform: 'none',
              fontWeight: 'medium',
              '&:hover': {
                backgroundColor: blacklistReason.trim()
                  ? isUnblocking
                    ? '#45A049'
                    : '#D32F2F'
                  : '#E0E0E0',
              },
              '&:disabled': {
                backgroundColor: '#E0E0E0',
                color: '#9E9E9E',
              },
            }}
          >
            {isUnblocking ? 'Unblock' : 'Block'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Logs Modal */}
      <Dialog
        open={logsModalOpen}
        onClose={handleLogsClose}
        maxWidth="lg"
        fullWidth
        PaperProps={{
          sx: {
            borderRadius: 2,
            boxShadow: '0 8px 32px rgba(0, 0, 0, 0.12)',
            maxHeight: '90vh',
          },
        }}
      >
        <DialogTitle
          sx={{
            fontSize: '1.25rem',
            fontWeight: 'bold',
            color: '#6B46C1',
            pb: 1,
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          Blacklist Logs
          <Button
            onClick={handleLogsClose}
            sx={{
              minWidth: 'auto',
              p: 1,
              color: '#666',
              '&:hover': {
                backgroundColor: '#f5f5f5',
              },
            }}
          >
            <CloseIcon />
          </Button>
        </DialogTitle>

        {/* Search and Filter Section */}
        <Box sx={{ p: 3, borderBottom: '1px solid #E0E0E0' }}>
          <Box sx={{ display: 'flex', gap: 2, mb: 2, flexWrap: 'wrap' }}>
            <TextField
              placeholder="Search by name, email, phone..."
              value={logsSearchTerm}
              onChange={(e) => setLogsSearchTerm(e.target.value)}
              size="small"
              sx={{ minWidth: '200px', flex: 1 }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon sx={{ color: '#667eea' }} />
                  </InputAdornment>
                ),
              }}
            />
            <TextField
              type="date"
              label="Start Date"
              value={logsStartDate}
              onChange={(e) => {
                console.log('📅 Start date changed:', e.target.value)
                setLogsStartDate(e.target.value)
              }}
              size="small"
              InputLabelProps={{ shrink: true }}
              sx={{ minWidth: '150px' }}
            />
            <TextField
              type="date"
              label="End Date"
              value={logsEndDate}
              onChange={(e) => {
                console.log('📅 End date changed:', e.target.value)
                setLogsEndDate(e.target.value)
              }}
              size="small"
              InputLabelProps={{ shrink: true }}
              sx={{ minWidth: '150px' }}
            />
            <Button
              variant="contained"
              onClick={handleLogsSearch}
              disabled={blacklistHistoryMutation.isPending}
              sx={{
                backgroundColor: '#667eea',
                '&:hover': { backgroundColor: '#5a67d8' },
                minWidth: '100px',
              }}
            >
              {blacklistHistoryMutation.isPending ? 'Searching...' : 'Search'}
            </Button>
          </Box>
        </Box>

        <DialogContent sx={{ p: 0, overflow: 'hidden' }}>
          <TableContainer sx={{ maxHeight: '60vh' }}>
            <Table stickyHeader>
              <TableHead>
                <TableRow sx={{ backgroundColor: '#FAFAFA' }}>
                  <TableCell sx={{ fontWeight: 'bold', color: '#333333' }}>
                    #
                  </TableCell>
                  <TableCell sx={{ fontWeight: 'bold', color: '#333333' }}>
                    User Details
                  </TableCell>
                  <TableCell sx={{ fontWeight: 'bold', color: '#333333' }}>
                    Current Status
                  </TableCell>
                  <TableCell sx={{ fontWeight: 'bold', color: '#333333' }}>
                    Total Actions
                  </TableCell>
                  <TableCell sx={{ fontWeight: 'bold', color: '#333333' }}>
                    Last Action
                  </TableCell>
                  <TableCell sx={{ fontWeight: 'bold', color: '#333333' }}>
                    History
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {(() => {
                  console.log('🔍 TABLE RENDERING DEBUG:', {
                    isPending: blacklistHistoryMutation.isPending,
                    logsDataLength: logsData.length,
                    logsData: logsData,
                    logsDataType: typeof logsData,
                    logsDataIsArray: Array.isArray(logsData),
                    firstLogItem: logsData[0],
                    mutationState: {
                      isPending: blacklistHistoryMutation.isPending,
                      isSuccess: blacklistHistoryMutation.isSuccess,
                      isError: blacklistHistoryMutation.isError,
                      error: blacklistHistoryMutation.error,
                    },
                  })

                  if (blacklistHistoryMutation.isPending) {
                    console.log('🔄 Showing loading state')
                    return (
                      <TableRow>
                        <TableCell colSpan={6} align="center" sx={{ py: 4 }}>
                          <Box
                            sx={{
                              display: 'flex',
                              flexDirection: 'column',
                              alignItems: 'center',
                              gap: 2,
                            }}
                          >
                            <CircularProgress
                              size={32}
                              sx={{ color: '#667eea' }}
                            />
                            <Typography
                              variant="body1"
                              sx={{ color: '#666666', fontWeight: 'medium' }}
                            >
                              Loading blacklist history...
                            </Typography>
                          </Box>
                        </TableCell>
                      </TableRow>
                    )
                  }

                  if (logsData.length === 0) {
                    console.log('📭 Showing empty state - no data')
                    return (
                      <TableRow>
                        <TableCell colSpan={6} align="center" sx={{ py: 4 }}>
                          <Typography variant="body1" sx={{ color: '#666666' }}>
                            No users with blacklist history found for this date
                            range
                          </Typography>
                        </TableCell>
                      </TableRow>
                    )
                  }

                  console.log('📊 Showing data rows:', logsData.length)
                  return logsData.map((user) => (
                    <TableRow
                      key={user.id}
                      hover
                      sx={{ '&:hover': { backgroundColor: '#F8F9FA' } }}
                    >
                      <TableCell sx={{ color: '#333333' }}>{user.id}</TableCell>

                      {/* User Details Column */}
                      <TableCell sx={{ color: '#333333' }}>
                        <Box>
                          <Typography
                            variant="body2"
                            sx={{ fontWeight: 'medium', mb: 0.5 }}
                          >
                            {user.name}
                          </Typography>
                          <Typography
                            variant="caption"
                            sx={{ color: '#666', display: 'block' }}
                          >
                            {user.email &&
                            user.email.trim() !== '' &&
                            user.email.includes('@') &&
                            !user.email.includes('XXXXXXXXXX') &&
                            user.email !== 'no-email@example.com'
                              ? user.email
                              : 'N/A'}
                          </Typography>
                          <Typography
                            variant="caption"
                            sx={{ color: '#666', display: 'block' }}
                          >
                            {user.phone}
                          </Typography>
                        </Box>
                      </TableCell>

                      {/* Current Status Column */}
                      <TableCell>
                        <Chip
                          label={user.currentStatus}
                          size="small"
                          sx={{
                            fontWeight: 'medium',
                            backgroundColor: user.isCurrentlyBlacklisted
                              ? '#f8d7da'
                              : '#d4edda',
                            color: user.isCurrentlyBlacklisted
                              ? '#721c24'
                              : '#155724',
                            border: `1px solid ${user.isCurrentlyBlacklisted ? '#f5c6cb' : '#c3e6cb'}`,
                          }}
                        />
                      </TableCell>

                      {/* Total Actions Column */}
                      <TableCell sx={{ color: '#333333', textAlign: 'center' }}>
                        <Typography
                          variant="body2"
                          sx={{ fontWeight: 'medium' }}
                        >
                          {user.totalActions}
                        </Typography>
                      </TableCell>

                      {/* Last Action Column */}
                      <TableCell sx={{ color: '#333333' }}>
                        <Box>
                          <Typography
                            variant="body2"
                            sx={{ fontWeight: 'medium' }}
                          >
                            {user.lastActionDate}
                          </Typography>
                          <Typography variant="caption" sx={{ color: '#666' }}>
                            by {user.lastActionBy}
                          </Typography>
                        </Box>
                      </TableCell>

                      {/* History Column */}
                      <TableCell sx={{ color: '#333333' }}>
                        <Box
                          sx={{ display: 'flex', alignItems: 'center', gap: 1 }}
                        >
                          <Typography variant="body2" sx={{ flex: 1 }}>
                            {user.blockReasons.length > 0 ||
                            user.unblockReasons.length > 0
                              ? `${user.blockReasons.length} blocks, ${user.unblockReasons.length} unblocks`
                              : 'No history'}
                          </Typography>
                          {(user.blockReasons.length > 0 ||
                            user.unblockReasons.length > 0) && (
                            <Button
                              variant="outlined"
                              size="small"
                              onClick={() => handleViewHistory(user)}
                              sx={{
                                color: '#667eea',
                                borderColor: '#667eea',
                                '&:hover': {
                                  backgroundColor: '#667eea',
                                  color: 'white',
                                },
                              }}
                            >
                              View History
                            </Button>
                          )}
                        </Box>
                      </TableCell>
                    </TableRow>
                  ))
                })()}
              </TableBody>
            </Table>
          </TableContainer>
        </DialogContent>

        <DialogActions sx={{ p: 2, borderTop: '1px solid #E0E0E0' }}>
          <Typography variant="body2" sx={{ color: '#666666', mr: 'auto' }}>
            Showing {logsData.length} of{' '}
            {logsPagination.totalUsers || logsPagination.total || 0} users
            {logsPagination.totalPages &&
              ` (Page ${logsCurrentPage} of ${logsPagination.totalPages})`}
          </Typography>

          {/* Pagination Controls */}
          {logsPagination.totalPages > 1 && (
            <Box sx={{ display: 'flex', gap: 1, alignItems: 'center', mr: 2 }}>
              <Button
                onClick={() => handleLogsPageChange(logsCurrentPage - 1)}
                disabled={
                  logsCurrentPage <= 1 || blacklistHistoryMutation.isPending
                }
                size="small"
                sx={{ minWidth: 'auto', px: 1 }}
              >
                Previous
              </Button>
              <Typography variant="body2" sx={{ px: 1 }}>
                {logsCurrentPage} / {logsPagination.totalPages}
              </Typography>
              <Button
                onClick={() => handleLogsPageChange(logsCurrentPage + 1)}
                disabled={
                  logsCurrentPage >= logsPagination.totalPages ||
                  blacklistHistoryMutation.isPending
                }
                size="small"
                sx={{ minWidth: 'auto', px: 1 }}
              >
                Next
              </Button>
            </Box>
          )}

          <Button
            onClick={handleLogsClose}
            sx={{
              color: '#2196F3',
              borderColor: '#2196F3',
              border: '1px solid',
              borderRadius: '8px',
              px: 3,
              py: 1,
              textTransform: 'none',
              fontWeight: 'medium',
              '&:hover': {
                backgroundColor: '#F3F9FF',
                borderColor: '#1976D2',
              },
            }}
          >
            Close
          </Button>
        </DialogActions>
      </Dialog>

      {/* History Modal */}
      <Dialog
        open={historyModalOpen}
        onClose={handleCloseHistoryModal}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
              Blacklist History
            </Typography>
            {selectedUserHistory && (
              <Typography variant="body2" sx={{ color: '#666' }}>
                - {selectedUserHistory.name}
              </Typography>
            )}
          </Box>
        </DialogTitle>
        <DialogContent>
          {selectedUserHistory && (
            <Box>
              {/* User Info */}
              <Box
                sx={{
                  mb: 3,
                  p: 2,
                  backgroundColor: '#f8f9fa',
                  borderRadius: 1,
                }}
              >
                <Typography
                  variant="subtitle1"
                  sx={{ fontWeight: 'bold', mb: 1 }}
                >
                  User Details
                </Typography>
                <Typography variant="body2">
                  <strong>Name:</strong> {selectedUserHistory.name}
                </Typography>
                <Typography variant="body2">
                  <strong>Email:</strong>{' '}
                  {selectedUserHistory.email &&
                  String(selectedUserHistory.email).includes('@')
                    ? selectedUserHistory.email
                    : 'N/A'}
                </Typography>
                <Typography variant="body2">
                  <strong>Phone:</strong> {selectedUserHistory.phone}
                </Typography>
                <Typography variant="body2">
                  <strong>Current Status:</strong>{' '}
                  {selectedUserHistory.currentStatus}
                </Typography>
                <Typography variant="body2">
                  <strong>Total Actions:</strong>{' '}
                  {selectedUserHistory.totalActions}
                </Typography>
              </Box>

              {/* History Content */}
              <Box sx={{ display: 'flex', gap: 2 }}>
                {/* Blocked Reasons Column */}
                <Box sx={{ flex: 1 }}>
                  <Typography
                    variant="h6"
                    sx={{
                      fontWeight: 'bold',
                      color: '#d32f2f',
                      mb: 2,
                    }}
                  >
                    Blocked History ({selectedUserHistory.blockReasons.length})
                  </Typography>
                  {selectedUserHistory.blockReasons.length > 0 ? (
                    selectedUserHistory.blockReasons.map((reason, index) => (
                      <Box
                        key={`block-${index}`}
                        sx={{
                          mb: 2,
                          p: 2,
                          backgroundColor: '#ffebee',
                          borderRadius: 1,
                          border: '1px solid #ffcdd2',
                        }}
                      >
                        <Typography
                          variant="body2"
                          sx={{
                            fontWeight: 'medium',
                            color: '#c62828',
                            mb: 1,
                          }}
                        >
                          {index + 1}. {reason.reason}
                        </Typography>
                        <Typography
                          variant="caption"
                          sx={{
                            display: 'block',
                            color: '#666',
                          }}
                        >
                          {reason.date} by {reason.blacklistedBy}
                        </Typography>
                      </Box>
                    ))
                  ) : (
                    <Typography
                      variant="body2"
                      sx={{
                        color: '#999',
                        fontStyle: 'italic',
                        textAlign: 'center',
                        py: 2,
                      }}
                    >
                      No blocked history
                    </Typography>
                  )}
                </Box>

                {/* Unblocked Reasons Column */}
                <Box sx={{ flex: 1 }}>
                  <Typography
                    variant="h6"
                    sx={{
                      fontWeight: 'bold',
                      color: '#2e7d32',
                      mb: 2,
                    }}
                  >
                    Unblocked History (
                    {selectedUserHistory.unblockReasons.length})
                  </Typography>
                  {selectedUserHistory.unblockReasons.length > 0 ? (
                    selectedUserHistory.unblockReasons.map((reason, index) => (
                      <Box
                        key={`unblock-${index}`}
                        sx={{
                          mb: 2,
                          p: 2,
                          backgroundColor: '#e8f5e8',
                          borderRadius: 1,
                          border: '1px solid #c8e6c9',
                        }}
                      >
                        <Typography
                          variant="body2"
                          sx={{
                            fontWeight: 'medium',
                            color: '#2e7d32',
                            mb: 1,
                          }}
                        >
                          {index + 1}. {reason.reason}
                        </Typography>
                        <Typography
                          variant="caption"
                          sx={{
                            display: 'block',
                            color: '#666',
                          }}
                        >
                          {reason.date} by {reason.blacklistedBy}
                        </Typography>
                      </Box>
                    ))
                  ) : (
                    <Typography
                      variant="body2"
                      sx={{
                        color: '#999',
                        fontStyle: 'italic',
                        textAlign: 'center',
                        py: 2,
                      }}
                    >
                      No unblocked history
                    </Typography>
                  )}
                </Box>
              </Box>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button
            onClick={handleCloseHistoryModal}
            variant="outlined"
            sx={{
              borderColor: '#1976D2',
              color: '#1976D2',
              px: 3,
              py: 1,
              textTransform: 'none',
              fontWeight: 'medium',
              '&:hover': {
                backgroundColor: '#F3F9FF',
                borderColor: '#1976D2',
              },
            }}
          >
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  )
}

export default BlacklistManagement
