import React, { useContext, useState, useEffect } from 'react'
import FileUploadWithDragAndDropPolices from './Upload_polices/index' // Your NDA component
import FileUploadWithDragAndDropNDA from './Download_file/index' // Your Policies component
import { AuthContext } from '../../context/AuthContext'
import { useParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { getBranchesByOrgId } from '../../services/adminService'
import { dropdown } from '../../assets/index'

const TabbedUpload = () => {
  const [activeTab, setActiveTab] = useState('nda')
  const [selectedBranch, setSelectedBranch] = useState(null)
  const [showDropdown, setShowDropdown] = useState(false)

  const handleTabChange = (tab) => {
    setActiveTab(tab)
  }

  const handleBranchSelect = (branch) => {
    setSelectedBranch(branch)
    setShowDropdown(false)
  }

  const auth = useContext(AuthContext)
  const { orgId } = useParams()
  const values = {
    org_id: auth.org_id || orgId,
    role: auth.role == '1' ? '' : auth.role,
    branch_id: auth?.branch_id || '',
  }

  const { data: branches, isLoading } = useQuery({
    queryKey: ['getBranches', values.org_id],
    queryFn: () => getBranchesByOrgId(values),
  })

  // Set initial selectedBranch when branches data is loaded
  useEffect(() => {
    if (branches && branches.length > 0 && !selectedBranch) {
      setSelectedBranch(branches[0])
    }
  }, [branches, selectedBranch])

  const handleDropdownToggle = () => {
    setShowDropdown((prev) => !prev)
  }
  const truncateBranchName = (name) => {
    return name?.length > 5 ? name?.slice(0, 5) + '...' : name
  }

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-6">
      <div className="bg-white rounded shadow-md w-full mx-auto">
        {/* Tab Buttons */}
        <div
          className="flex space-x-4 border-b border-gray-300 p-4"
          style={{ width: '43rem' }}
        >
          <button
            onClick={() => handleTabChange('nda')}
            className={`py-2 px-4 w-full text-center ${activeTab === 'nda' ? 'bg-dark-500 text-white' : 'bg-gray-200'}`}
            style={
              activeTab === 'nda'
                ? {
                    backgroundColor: 'rgb(5 23 55 / var(--tw-bg-opacity))',
                    color: 'white',
                  }
                : { color: 'black' }
            }
          >
            Upload NDA
          </button>
          <button
            onClick={() => handleTabChange('policies')}
            className={`py-2 px-4 w-full text-center ${activeTab === 'policies' ? 'bg-dark-500 text-white' : 'bg-gray-200'}`}
            style={
              activeTab === 'policies'
                ? {
                    backgroundColor: 'rgb(5 23 55 / var(--tw-bg-opacity))',
                    color: 'white',
                  }
                : { color: 'black' }
            }
          >
            Upload Guideliness
          </button>
        </div>
        <div className="flex gap-5 items-end justify-center">
          <div className="flex flex-col justify-between">
            <p className="text-sm font-bold mb-2 ml-2">Select Branch :</p>
            <div className="dropdown dropdown-hover relative">
              <div
                tabIndex={0}
                role="button"
                className="btn bg-secondary flex-row flex justify-between min-w-48 w-full text-center items-center"
                onClick={handleDropdownToggle}
                title={selectedBranch?.branch_name}
              >
                <span className="flex-1 text-center">
                  {truncateBranchName(selectedBranch?.branch_name)}
                </span>
                <img src={dropdown} alt="dropdown" className="h-9" />
              </div>
              {showDropdown && (
                <ul
                  tabIndex={0}
                  className="dropdown-content p-2 shadow bg-base-100 rounded-box max-h-[200px] w-full overflow-y-auto"
                  style={{ zIndex: 9999 }}
                >
                  {branches?.length === 0 ? (
                    <p>No Branches Found</p>
                  ) : (
                    branches.map((branch, i) => (
                      <li
                        key={i}
                        onClick={() => handleBranchSelect(branch)}
                        className="p-1 hover:bg-slate-100 rounded cursor-pointer"
                      >
                        <a>{branch.branch_name}</a>
                      </li>
                    ))
                  )}
                </ul>
              )}
            </div>
          </div>
        </div>

        {/* Tab Content */}
        {activeTab === 'nda' ? (
          <FileUploadWithDragAndDropNDA />
        ) : (
          <FileUploadWithDragAndDropPolices />
        )}
      </div>
    </div>
  )
}

export default TabbedUpload
