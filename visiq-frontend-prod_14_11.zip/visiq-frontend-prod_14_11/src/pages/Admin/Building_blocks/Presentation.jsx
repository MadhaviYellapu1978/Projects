/* eslint-disable prettier/prettier */
import React, { useEffect, useState, useContext } from 'react'
import AreaTable from '../../../shared/AreaTable'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  AreasByBranchId,
  postBranchAreas,
  updateVehicleMovement,
} from '../../../services/adminService'
import TotalLoding from '../../../shared/TotalLoding'
import loading from '../../../assets/loading.json'
import { dropdown } from '../../../assets/index'
import toast from 'react-hot-toast'
import { AuthContext } from '../../../context/AuthContext'

function Presentation(props) {
  const { branches } = props
  const auth = useContext(AuthContext)
  const [selectedBranch, setSelectedBranch] = useState(branches[0])
  const [showDropdown, setShowDropdown] = useState(false)
  const [branchId, setBranchId] = useState(branches[0].branch_id)
  const [showAddAreaModal, setShowAddAreaModal] = useState(false)
  const [newArea, setNewArea] = useState('')
  const [areas, setAreas] = useState([])
  const [_vehicleMovementEnabled, setVehicleMovementEnabled] = useState(false)
  const [isEditing, setIsEditing] = useState(false)
  const [editingArea, setEditingArea] = useState(null)

  const queryClient = useQueryClient()

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (showDropdown && !event.target.closest('.branch-dropdown')) {
        setShowDropdown(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [showDropdown])

  const { data: visitors, isLoading } = useQuery({
    queryKey: ['AreasByBranchId', branchId],

    queryFn: () =>
      AreasByBranchId({
        branch_id: branchId,
      }),
    keepPreviousData: true,
  })
  // console.log('selectedBranch', selectedBranch)
  // Sync local state with API data - removed automatic API call to prevent multiple calls

  // Sync local state with API data
  useEffect(() => {
    if (visitors && typeof visitors?.vm_boolean === 'boolean') {
      setVehicleMovementEnabled(visitors.vm_boolean)
    }
  }, [visitors])

  const mutate = useMutation({
    mutationFn: (values) => postBranchAreas(values),
    mutationKey: 'postBranchAreas',
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ['AreasByBranchId'],
      })
      toast.success('Area Added  Successful')
      setAreas([])
      setNewArea([])
    },
    onError: (err) => {
      toast.dismiss()
      toast.error(`${err}`)
      setAreas([])
      setNewArea([])
    },
  })
  const handleBranchSelect = (branch) => {
    setSelectedBranch(branch)
    setBranchId(branch.branch_id)

    console.log('branches', branch)
    setVehicleMovementEnabled(branch.vm_boolean)

    queryClient.invalidateQueries({
      queryKey: ['AreasByBranchId', branch.branch_id],
    })
    setShowDropdown(false)
  }

  const truncateBranchName = (name) => {
    return name.length > 5 ? name.slice(0, 5) + '...' : name
  }

  const handleDropdownToggle = () => {
    setShowDropdown((prev) => !prev)
  }

  const handleAddArea = () => {
    setIsEditing(false)
    setEditingArea(null)
    setShowAddAreaModal(true)
  }

  const handleAddChip = () => {
    if (newArea.trim()) {
      setAreas((prev) => [...prev, { area_name: newArea, decat: false }]) // Add object instead of string
      setNewArea('')
    }
  }

  const vehicleMovementMutation = useMutation({
    mutationFn: ({ branch_id, vm_boolean }) =>
      updateVehicleMovement({ branch_id, vm_boolean }),
    onSuccess: (data, variables) => {
      const status = variables.vm_boolean ? 'enabled' : 'disabled'
      toast.success(`Vehicle movement ${status} successfully`)
      console.log(`Vehicle movement ${status} successfully`)

      // Invalidate branches cache to reflect changes immediately in BookAVisit modal
      queryClient.invalidateQueries({
        queryKey: ['getBranches'],
      })
    },
    onError: (err) => {
      toast.error(`${err}`)
      setVehicleMovementEnabled((prev) => !prev)
    },
  })

  const handleVehicleMovementToggle = () => {
    const newValue = !selectedBranch?.vm_boolean
    console.log('=== VEHICLE MOVEMENT TOGGLE ===')
    console.log('Current value:', selectedBranch?.vm_boolean)
    console.log('New value:', newValue)
    console.log('Branch ID:', branchId)
    console.log('===============================')

    // Update selectedBranch immediately for visual feedback
    setSelectedBranch((prev) => ({
      ...prev,
      vm_boolean: newValue,
    }))

    setVehicleMovementEnabled(newValue)
    vehicleMovementMutation.mutate({
      branch_id: branchId,
      vm_boolean: newValue,
    })
  }

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault()
      if (isEditing) {
        handleSubmit()
      } else {
        handleAddChip()
      }
    }
  }

  const handleRemoveChip = (index) => {
    setAreas((prev) => prev.filter((_, i) => i !== index))
  }

  const handleSubmit = () => {
    if (isEditing) {
      // Handle edit - you'll need to implement an update API
      console.log('Editing area:', editingArea.area_id, 'New name:', newArea)
      // TODO: Add update area API call here
      toast.success('Area updated successfully')
    } else {
      // Handle add
      const payload = {
        branch_id: branchId,
        areas: areas,
      }
      mutate.mutate(payload)
    }
    setShowAddAreaModal(false)
  }

  const HandleClose = () => {
    setShowAddAreaModal(false)
    setAreas([])
    setNewArea('')
    setIsEditing(false)
    setEditingArea(null)
  }
  return (
    <div>
      {isLoading ? (
        <div className="text-xl text-center">
          <TotalLoding data={loading} height="20vh" />
        </div>
      ) : (
        <div className="flex flex-col justify-between ml-5 mt-5 max-w-5xl">
          <div className="mb-6">
            <h1 className="text-3xl font-bold mb-2 text-gray-800 flex items-center gap-3">
              🏢 Areas-Vehicle Movement
            </h1>
            <p className="text-gray-600 text-base">
              Manage areas and vehicle movement settings by branch
            </p>
          </div>
          <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6 flex items-center justify-between gap-6 hover:shadow-xl transition-shadow duration-300">
            <div className="flex flex-col gap-2">
              <div className="text-sm font-medium text-gray-700 flex items-center gap-2">
                🏢 Select Branch
              </div>
              {auth.role === '4' ? (
                // Simple box for SecurityAdmin - no dropdown functionality
                <div className="btn bg-blue-50 border-2 border-blue-200 text-blue-700 font-medium min-w-40 rounded-lg flex items-center px-4 py-2">
                  <span>{selectedBranch?.branch_name}</span>
                </div>
              ) : (
                // Dropdown for Admin and BranchAdmin roles
                <div className="relative branch-dropdown">
                  <button
                    onClick={() => setShowDropdown(!showDropdown)}
                    className="btn bg-blue-50 border-2 border-blue-200 text-blue-700 font-medium min-w-40 rounded-lg flex items-center justify-between px-4 py-2 hover:bg-blue-100 transition-colors"
                  >
                    <span>{selectedBranch?.branch_name}</span>
                    <img
                      src={dropdown}
                      alt="dropdown"
                      className={`w-4 h-4 transition-transform ${
                        showDropdown ? 'rotate-180' : ''
                      }`}
                    />
                  </button>
                  {showDropdown && (
                    <div className="absolute top-full left-0 mt-1 w-full bg-white border border-gray-200 rounded-lg shadow-lg z-10 max-h-60 overflow-y-auto">
                      {branches?.map((branch) => (
                        <button
                          key={branch.branch_id}
                          onClick={() => {
                            setSelectedBranch(branch)
                            setBranchId(branch.branch_id)
                            setShowDropdown(false)
                          }}
                          className={`w-full text-left px-4 py-3 hover:bg-blue-50 transition-colors ${
                            selectedBranch?.branch_id === branch.branch_id
                              ? 'bg-blue-100 text-blue-700 font-medium'
                              : 'text-gray-700'
                          }`}
                        >
                          {branch.branch_name}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
            {/* Hide vehicle movement toggle for SecurityAdmin role */}
            {auth.role !== '4' && (
              <div className="text-right">
                <div className="text-sm font-medium text-gray-700 flex items-center gap-2 justify-end mb-2">
                  Vehicle & Material Movement
                </div>
                <div className="flex items-center gap-3 justify-end">
                  <input
                    type="checkbox"
                    className="toggle toggle-primary scale-110"
                    checked={selectedBranch?.vm_boolean}
                    onChange={handleVehicleMovementToggle}
                    disabled={true}
                    value={true}
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      )}
      <AreaTable
        data={visitors?.areasOfBranch || []}
        onAddArea={handleAddArea}
      />

      {/* Modal */}
      {showAddAreaModal && (
        <div
          className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50"
          onClick={() => HandleClose()}
        >
          <div
            className="bg-white p-8 rounded-lg shadow-lg w-full max-w-md"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              className="text-gray-600 hover:text-gray-800 float-right"
              onClick={() => HandleClose()}
              type="button"
            >
              ✕
            </button>
            <h3 className="text-xl font-semibold text-gray-800 mb-6 text-center mt-4">
              {isEditing ? 'Edit Area' : 'Add Area'}
            </h3>

            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Area Name
              </label>
              <input
                type="text"
                value={newArea}
                onChange={(e) => setNewArea(e.target.value)}
                onKeyDown={handleKeyDown}
                className="input input-bordered w-full border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                placeholder="Enter area name"
              />
            </div>

            {!isEditing && (
              <div className="mb-6">
                <h4 className="text-sm font-medium text-gray-700 mb-3">
                  Added Areas:
                </h4>
                <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto">
                  {areas.map((area, index) => (
                    <div
                      key={index}
                      className="flex items-center bg-gray-100 border border-gray-300 px-3 py-1 rounded-full"
                    >
                      <span className="text-gray-700 text-sm">
                        {area.area_name}
                      </span>
                      <button
                        onClick={() => handleRemoveChip(index)}
                        className="ml-2 text-red-500 hover:text-red-700 transition"
                      >
                        &times;
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex justify-end mt-6">
              <button
                className="px-6 py-2 bg-primary text-white font-semibold rounded-lg hover:bg-primary-dark transition-all disabled:bg-gray-300 disabled:cursor-not-allowed"
                onClick={handleSubmit}
                disabled={isEditing ? !newArea.trim() : areas.length === 0}
              >
                {isEditing ? 'Update' : 'Submit'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Presentation
