/* eslint-disable jsx-a11y/no-noninteractive-tabindex */
/* eslint-disable jsx-a11y/no-noninteractive-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import React, { useState, useEffect } from 'react'
import { dropdown } from '../../../assets/index'
import AdminTable from '../../../shared/AdminTable'
import { getAdmins } from '../../../services/adminService'
import TotalLoding from '../../../shared/TotalLoding'
import loading from '../../../assets/loading.json'

function Presentation(props) {
  const { branches } = props
  const [selectedBranch, setSelectedBranch] = useState(branches[0])
  const [showBranchDropdown, setShowBranchDropdown] = useState(false)
  const [branchId, setBranchId] = useState(branches[0].branch_id)
  const [selectedRole, setSelectedRole] = useState('3') // Default to Branch Admin
  const [showRoleDropdown, setShowRoleDropdown] = useState(false)
  const [adminData, setAdminData] = useState([])
  const [Loading, setLoading] = useState(false)

  const handleBranchDropdownToggle = () => {
    setShowBranchDropdown((prev) => !prev)
  }

  const handleRoleDropdownToggle = () => {
    setShowRoleDropdown((prev) => !prev)
  }

  const truncateBranchName = (name) => {
    return name.length > 5 ? name.slice(0, 5) + '...' : name
  }

  const handleBranchSelect = (branch) => {
    setSelectedBranch(branch)
    setBranchId(branch.branch_id)
    setShowBranchDropdown(false) // Close the dropdown when a branch is selected
  }

  const handleRoleSelect = (role) => {
    const roleId = role === 'Branch Admin' ? '3' : '4'
    setSelectedRole(roleId)
    setShowRoleDropdown(false) // Close the dropdown when a role is selected
  }

  const fetchAdmins = async () => {
    setLoading(true)
    try {
      const data = await getAdmins({
        branch_id: branchId,
        role: selectedRole,
      })
      setAdminData(data.adminDetails || [])
    } catch (error) {
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchAdmins()
  }, [branchId, selectedRole])

  return (
    <div>
      <div className="flex justify-between gap-6 items-end">
        <div className="flex gap-5 items-end justify-center p-4">
          {/* <div className="flex flex-col font-bold ml-3 mt-2 justify-between">
            Select Branch : */}
          <div className="flex flex-col justify-between">
            <p className="font-bold mb-2 ml-2">Select Branch :</p>
            <div className="dropdown dropdown-hover relative">
              <div
                tabIndex={0}
                role="button"
                className="btn bg-secondary flex-row flex justify-between min-w-48 w-full"
                onClick={handleBranchDropdownToggle}
                title={selectedBranch?.branch_name}
              >
                {truncateBranchName(selectedBranch?.branch_name)}
                <img src={dropdown} alt="dropdown" className="h-9" />
              </div>
              {showBranchDropdown && (
                <ul
                  tabIndex={0}
                  className="dropdown-content p-2 shadow bg-base-100 rounded-box max-h-[200px] w-full overflow-y-auto"
                  style={{ zIndex: 9999 }}
                >
                  {branches.length === 0 ? (
                    <p>No Branches Found</p>
                  ) : (
                    branches.map((branch, i) => (
                      <li
                        key={i}
                        onClick={() => handleBranchSelect(branch)}
                        className="p-1 hover:bg-slate-100 rounded cursor-pointer"
                      >
                        <a>{branch.branch_name}</a>
                      </li>
                    ))
                  )}
                </ul>
              )}
            </div>
          </div>

          <div className="flex flex-col justify-between">
            <p className="font-bold mb-2 ml-2">Select Admin :</p>
            <div className="dropdown dropdown-hover relative">
              <div
                tabIndex={0}
                role="button"
                className="btn bg-secondary flex-row flex justify-between min-w-48 w-full"
                onClick={handleRoleDropdownToggle}
                title={selectedRole === '3' ? 'Branch Admin' : 'Security Admin'}
              >
                {selectedRole === '3' ? 'Branch Admin' : 'Security Admin'}
                <img src={dropdown} alt="dropdown" className="h-9" />
              </div>
              {showRoleDropdown && (
                <ul
                  tabIndex={0}
                  className="dropdown-content p-2 shadow bg-base-100 rounded-box max-h-[200px] w-full overflow-y-auto"
                  style={{ zIndex: 9999 }}
                >
                  {['Branch Admin', 'Security Admin'].map((role, i) => (
                    <li
                      key={i}
                      onClick={() => handleRoleSelect(role)}
                      className="p-1 hover:bg-slate-100 rounded cursor-pointer"
                    >
                      <a>{role}</a>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
      </div>
      <div>
        <AdminTable data={adminData} isLoading={Loading} />
      </div>
    </div>
  )
}

export default Presentation
