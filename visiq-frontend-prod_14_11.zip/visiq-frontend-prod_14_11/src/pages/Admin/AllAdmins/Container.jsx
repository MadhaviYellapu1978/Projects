/* eslint-disable jsx-a11y/img-redundant-alt */
import React, { useContext } from 'react'
import Presentation from './Presentation'
import { useQuery } from '@tanstack/react-query'
import { getBranchesByOrgId } from '../../../services/adminService'
import { AuthContext } from '../../../context/AuthContext'
import { useParams } from 'react-router-dom'

import loading from '../../../assets/loading.json'
import LottieLoader from '../../../shared/LottieLoader'
import NoDataImage from '../../../assets/NoDataPic.png' // Example path to your image

const Container = () => {
  const auth = useContext(AuthContext)
  const { orgId } = useParams()
  const values = {
    org_id: auth.org_id || orgId,
    role: auth.role == '1' ? '' : auth.role,
    branch_id: auth?.branch_id || '',
  }

  const {
    data: branches,
    isLoading,
    isError,
  } = useQuery({
    queryKey: ['getBranches', values.org_id],
    queryFn: () => getBranchesByOrgId(values),
  })

  // Show loading state while data is being fetched
  if (isLoading) return <LottieLoader data={loading} />

  // Show error state if query failed
  if (isError) {
    return (
      <div className="flex flex-col items-center justify-center h-64">
        <p className="text-red-500 text-lg mb-4">
          Error loading data. Please try again.
        </p>
      </div>
    )
  }

  // Only show No Data image when data is loaded but empty
  if (branches && branches.organisationDetails?.branches?.length === 0) {
    return (
      <div>
        <div className="flex flex-col items-center">
          <img
            src={NoDataImage}
            alt="No data available"
            className="mb-8 w-82 h-70 object-contain"
            style={{
              maxWidth: '45%',
              maxHeight: '45%',
              objectFit: 'fit',
            }}
          />
        </div>
      </div>
    )
  }

  // Show main content when data is available
  if (branches && branches.organisationDetails?.branches?.length > 0) {
    return (
      <Presentation
        branches={branches.organisationDetails.branches}
        orgId={orgId}
      />
    )
  }

  return null
}

export default Container
