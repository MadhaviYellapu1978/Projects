/* eslint-disable jsx-a11y/no-distracting-elements */
/* eslint-disable jsx-a11y/no-noninteractive-tabindex */
/* eslint-disable jsx-a11y/no-noninteractive-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable react/display-name */
import React, { useContext, useEffect, useState } from 'react'
import VisitorsTable from '../../../shared/Visitors_no_show_reports'
import { dropdown } from '../../../assets/index'
import { useMutation } from '@tanstack/react-query'
import { AuthContext } from '../../../context/AuthContext'
import DatePicker from 'react-datepicker'
import 'react-datepicker/dist/react-datepicker.css'
import { format } from 'date-fns'
import TotalLoding from '../../../shared/TotalLoding'
import loading from '../../../assets/loading.json'
import { CalendarIcon } from '@mui/x-date-pickers'
import { visitorReports, getAllVisitors } from '../../../services/adminService'
import AllVisitorsAttendance from '../Dashboard/Components/AllVisitorsAttendance'

const Presentation = (props) => {
  const {
    branches,
    VisitorData,
    setSelectedBranch,
    selectedBranch,
    isLoadingVisitorData,
  } = props
  const auth = useContext(AuthContext)
  const [isLoading, setIsLoading] = useState(false)
  const [start_date, set_start_date] = useState(new Date())
  const [to_date, set_to_date] = useState(new Date())
  const [selectVisitorOrg, setselectVisitorOrg] = useState(null)
  const [branch_id, setBranchId] = useState(branches?.[0]?.branch_id || '')
  const [, setShowVisitorsGrid] = useState(false)
  const [showDropdown, setShowDropdown] = useState(false)
  const [ShowDropdowns, setShowDropdowns] = useState(false)
  const [VisitorOrgData, setVisitorOrgData] = useState([])
  const visitorTypes = [
    { label: 'Visitors', value: 'all' },
    { label: 'No Show Visitors', value: 'no_show' },
  ]
  const [visitorType, setVisitorType] = useState(visitorTypes[0].value)

  useEffect(() => {
    if (VisitorData && VisitorData.length > 0) {
      setselectVisitorOrg(VisitorData[0])
    } else if (VisitorData && VisitorData.length === 0) {
      // Handle case where no visitor organizations are available
      setselectVisitorOrg(null)
    }
  }, [VisitorData])

  const CustomInput = React.forwardRef(({ value, onClick }, ref) => (
    <button className="btn bg-secondary" onClick={onClick} ref={ref} readOnly>
      {value || 'Select a date'}
      <CalendarIcon />
    </button>
  ))

  const handleDateChange = (date) => {
    set_start_date(date)
  }

  const handleDateChanges = (date) => {
    set_to_date(date)
  }

  const handleDropdownToggle = () => {
    setShowDropdown((prev) => !prev)
  }

  const handleDropdownToggles = () => {
    setShowDropdowns((prev) => !prev)
  }

  const truncateBranchName = (name) => {
    return name?.length > 5 ? name?.slice(0, 5) + '...' : name
  }

  const handleBranchSelect = (branch) => {
    setShowVisitorsGrid(false)
    setSelectedBranch(branch)
    setBranchId(branch.branch_id)
    setShowDropdown(false)
  }

  const handleVisitorSelect = (visitor) => {
    setselectVisitorOrg(visitor)
    setShowDropdowns(false)
  }
  const mutaion = useMutation({
    mutationFn: (values) => visitorReports(values),
    onSuccess: (data) => {
      console.log('🔍 Visitor Reports API Success - Raw data:', data)

      // Debug visitor_type data from raw API response
      if (data?.usersDataList && data.usersDataList.length > 0) {
        console.log('🔍 Raw API visitor_type data sample:', {
          first_visitor: data.usersDataList[0],
          visitor_type_fields: {
            visitor_type: data.usersDataList[0]?.visitor_type,
            grp_book_bool: data.usersDataList[0]?.grp_book_bool,
            is_group_booking: data.usersDataList[0]?.is_group_booking,
            main_visitor_email: data.usersDataList[0]?.main_visitor_email,
            main_visitor_name: data.usersDataList[0]?.main_visitor_name,
          },
        })
        console.log(
          '🔍 All visitor types in API response:',
          data.usersDataList.map((v) => ({
            name: v.first_name,
            visitor_type: v.visitor_type,
            grp_book_bool: v.grp_book_bool,
            is_group_booking: v.is_group_booking,
          })),
        )
      }

      try {
        // Transform the API response to ensure compatibility
        const transformedData = transformApiResponse(data)
        console.log('🔍 Transformed data:', transformedData)
        console.log(
          '🔍 Final visitor types after transformation:',
          transformedData.usersDataList?.map((v) => ({
            name: v.first_name,
            visitor_type: v.visitor_type,
            original_visitor_type: v.visitor_type,
          })),
        )
        setVisitorOrgData(transformedData)
        setIsLoading(false)
      } catch (transformError) {
        console.error('🔍 Data transformation error:', transformError)
        setIsLoading(false)
        alert('Error processing visitor data. Please try again.')
      }
    },
    onError: (error) => {
      console.error('🔍 visitorReports API failed:', error)
      setIsLoading(false)

      // Show user-friendly error message
      alert(`Failed to fetch visitor reports: ${error.message}`)

      // Try fallback API if visitorReports fails
      fallbackMutation.mutate({
        org_id: auth?.org_id || '',
        branch_id: branch_id,
        role: '',
        data_of_visit: format(start_date, 'dd-MM-yyyy'),
      })
    },
  })

  // Fallback mutation using getAllVisitors API
  const fallbackMutation = useMutation({
    mutationFn: (values) => getAllVisitors(values),
    onSuccess: (data) => {
      try {
        console.log('🔍 Fallback API Success - Raw data:', data)
        // Transform getAllVisitors response to match expected structure
        const transformedData = {
          usersDataList: data?.visitors_List || [],
          noShowVisitors: [],
        }

        console.log('🔍 Fallback transformed data:', transformedData)
        setVisitorOrgData(transformedData)
        setIsLoading(false)
      } catch (transformError) {
        console.error('🔍 Fallback data transformation error:', transformError)
        setIsLoading(false)
        setVisitorOrgData({
          usersDataList: [],
          noShowVisitors: [],
        })
        alert('Error processing fallback data. Please try again.')
      }
    },
    onError: (error) => {
      console.error('🔍 Fallback API also failed:', error)
      setIsLoading(false)

      // Set empty data to show "No Data Found" instead of crashing
      setVisitorOrgData({
        usersDataList: [],
        noShowVisitors: [],
      })

      // Show user-friendly error message
      alert(
        `Unable to fetch visitor data. Please check your connection and try again. Error: ${error.message}`,
      )
    },
  })

  const HandelClick = () => {
    try {
      // Validate required fields before making API call
      if (!auth?.org_id) {
        alert(
          'Organization ID is missing. Please refresh the page and try again.',
        )
        return
      }

      if (!branch_id) {
        alert('Please select a branch before submitting.')
        return
      }

      if (!selectVisitorOrg) {
        alert('Please select a visitor organization before submitting.')
        return
      }

      if (!start_date || !to_date) {
        alert('Please select both from and to dates before submitting.')
        return
      }

      if (start_date > to_date) {
        alert(
          'From date cannot be greater than To date. Please select valid dates.',
        )
        return
      }

      setIsLoading(true)

      const values = {
        branch_id: branch_id,
        org_id: auth?.org_id || '',
        visitor_org_name:
          selectVisitorOrg.visitor_org_name == 'All'
            ? ''
            : selectVisitorOrg.visitor_org_name,
        from: format(start_date, 'dd-MM-yyyy'),
        to: format(to_date, 'dd-MM-yyyy'),
      }

      console.log('🔍 Submitting visitor reports with values:', values)
      mutaion.mutate(values)
    } catch (error) {
      console.error('🔍 Error in HandelClick:', error)
      setIsLoading(false)
      alert('An unexpected error occurred. Please try again.')
    }
  }

  const handleVisitorTypeSelect = (type) => {
    setVisitorType(type)
    setShowDropdowns(false)
  }

  // Transform API response to ensure compatibility with expected data structure
  const transformApiResponse = (data) => {
    try {
      if (!data) {
        console.warn('No data received from API')
        return {
          usersDataList: [],
          noShowVisitors: [],
        }
      }

      // Check if data already has the expected structure
      if (data.usersDataList && data.noShowVisitors) {
        return data
      }

      // Handle different possible API response structures
      let transformedData = { usersDataList: [], noShowVisitors: [] }

      // Case 1: Data is directly an array
      if (Array.isArray(data)) {
        transformedData.usersDataList = data
      }
      // Case 2: Data has a different key structure
      else if (data.visitors) {
        transformedData.usersDataList = data.visitors
      } else if (data.visitorList) {
        transformedData.usersDataList = data.visitorList
      } else if (data.data) {
        if (Array.isArray(data.data)) {
          transformedData.usersDataList = data.data
        } else if (data.data.usersDataList) {
          transformedData.usersDataList = data.data.usersDataList
        }
      }
      // Case 3: Check for any array properties
      else {
        const arrayKeys = Object.keys(data).filter((key) =>
          Array.isArray(data[key]),
        )

        if (arrayKeys.length > 0) {
          // Use the first array as usersDataList
          transformedData.usersDataList = data[arrayKeys[0]]
        }
      }

      // For "Visitors" (all) - filter to show only checked-in visitors
      let processedUsersDataList = []

      // Only apply checked-in filtering when visitorType is 'all' (Visitors)
      console.log('🔍 Current visitorType:', visitorType)
      if (visitorType === 'all') {
        console.log('🔍 Applying checked-in filtering for Visitors (all)')
        console.log(
          '🔍 Total visitors before filtering:',
          transformedData.usersDataList.length,
        )
        transformedData.usersDataList.forEach((visitor, index) => {
          console.log(`🔍 Processing visitor ${index}:`, visitor)
          console.log(
            `🔍 Group details for visitor ${index}:`,
            visitor.grp_details,
          )

          // Enhanced check for checked-in status
          const hasValidLastEntry =
            visitor.last_entry &&
            visitor.last_entry !== '--' &&
            visitor.last_entry !== '' &&
            visitor.last_entry !== null &&
            visitor.last_entry !== undefined

          const hasValidLastExit =
            visitor.last_exit &&
            visitor.last_exit !== '--' &&
            visitor.last_exit !== '' &&
            visitor.last_exit !== null &&
            visitor.last_exit !== undefined

          const isCurrentlyPresent =
            hasValidLastEntry &&
            (!hasValidLastExit || visitor.last_exit === '--')

          const hasCheckedInAtLeastOnce = hasValidLastEntry

          // Check attendance data for additional validation
          const hasAttendanceData =
            visitor.attendanceData &&
            Array.isArray(visitor.attendanceData) &&
            visitor.attendanceData.length > 0

          const hasValidAttendance =
            hasAttendanceData &&
            visitor.attendanceData.some(
              (att) =>
                att.entry_time &&
                att.entry_time !== '--' &&
                att.entry_time !== '' &&
                att.isEntry === true,
            )

          // Check if any group members have checked in
          const hasGroupMembersCheckedIn =
            visitor.grp_details &&
            Array.isArray(visitor.grp_details) &&
            visitor.grp_details.length > 0 &&
            visitor.grp_details.some(
              (member) =>
                member.attendanceData &&
                Array.isArray(member.attendanceData) &&
                member.attendanceData.length > 0 &&
                member.attendanceData.some(
                  (att) =>
                    att.entry_time &&
                    att.entry_time !== '--' &&
                    att.entry_time !== '' &&
                    att.isEntry === true,
                ),
            )

          console.log(
            `🔍 Visitor ${index} - hasValidLastEntry:`,
            hasValidLastEntry,
          )
          console.log(
            `🔍 Visitor ${index} - isCurrentlyPresent:`,
            isCurrentlyPresent,
          )
          console.log(
            `🔍 Visitor ${index} - hasCheckedInAtLeastOnce:`,
            hasCheckedInAtLeastOnce,
          )
          console.log(
            `🔍 Visitor ${index} - hasValidAttendance:`,
            hasValidAttendance,
          )
          console.log(
            `🔍 Visitor ${index} - hasGroupMembersCheckedIn:`,
            hasGroupMembersCheckedIn,
          )
          console.log(`🔍 Visitor ${index} - last_entry:`, visitor.last_entry)
          console.log(`🔍 Visitor ${index} - last_exit:`, visitor.last_exit)

          // Only include visitors who have checked in (main visitor OR group members)
          const isCheckedInVisitor =
            hasCheckedInAtLeastOnce ||
            isCurrentlyPresent ||
            hasValidAttendance ||
            hasGroupMembersCheckedIn

          if (isCheckedInVisitor) {
            // Process the main visitor and keep group details intact
            const processedVisitor = {
              ...visitor,
              fullName:
                `${visitor.first_name || ''} ${visitor.last_name || ''}`.trim(),
              isMainVisitor: true,
              isGroupMember: false,
              // Ensure group details are preserved for user cards
              grp_details: visitor.grp_details || [],
              grp_book_bool: visitor.grp_book_bool || false,
              visitor_type: visitor.visitor_type || 'individual_visitor',
              // Keep original photo handling for main visitors
              photo: visitor.photo || '',
            }

            console.log(
              `🔍 Processed visitor ${index} (checked in):`,
              processedVisitor,
            )
            console.log(`🔍 Processed visitor ${index} group data:`, {
              visitor_type: processedVisitor.visitor_type,
              original_visitor_type: visitor.visitor_type,
              grp_book_bool: processedVisitor.grp_book_bool,
              grp_details: processedVisitor.grp_details,
              grp_details_length: processedVisitor.grp_details?.length,
            })
            console.log(`🔍 Raw API visitor data for ${index}:`, {
              first_name: visitor.first_name,
              visitor_type: visitor.visitor_type,
              grp_book_bool: visitor.grp_book_bool,
              is_group_booking: visitor.is_group_booking,
              main_visitor_email: visitor.main_visitor_email,
              main_visitor_name: visitor.main_visitor_name,
            })
            console.log(`🔍 Processed visitor ${index} photo data:`, {
              original_photo: visitor.photo,
              final_photo: processedVisitor.photo,
              has_photo: !!processedVisitor.photo,
            })
            processedUsersDataList.push(processedVisitor)
          } else {
            console.log(
              `🔍 Visitor ${index} excluded - not checked in (last_entry: ${visitor.last_entry}, last_exit: ${visitor.last_exit})`,
            )
          }
        })

        console.log(
          '🔍 Total visitors after filtering:',
          processedUsersDataList.length,
        )
        console.log(
          '🔍 Filtered visitors:',
          processedUsersDataList.map((v) => ({
            name: v.first_name,
            last_entry: v.last_entry,
            last_exit: v.last_exit,
          })),
        )
        transformedData.usersDataList = processedUsersDataList
      } else {
        // For other visitor types, use the data as-is without filtering
        processedUsersDataList = transformedData.usersDataList
        transformedData.usersDataList = processedUsersDataList
      }

      // Keep original photo handling and visitor_type for all visitors
      transformedData.usersDataList = transformedData.usersDataList.map(
        (visitor) => ({
          ...visitor,
          photo: visitor.photo || '',
          visitor_type: visitor.visitor_type || 'individual_visitor', // Ensure visitor_type is preserved
        }),
      )

      // For no show visitors, use the actual noShowVisitors data from API response
      if (data.noShowVisitors && Array.isArray(data.noShowVisitors)) {
        console.log(
          '🔍 Using actual noShowVisitors data from API:',
          data.noShowVisitors,
        )
        console.log(
          '🔍 Sample noShowVisitor with vm_details:',
          data.noShowVisitors[0]?.vm_details,
        )
        console.log(
          '🔍 Sample noShowVisitor with mm_details:',
          data.noShowVisitors[0]?.mm_details,
        )
        transformedData.noShowVisitors = data.noShowVisitors
      } else {
        console.log(
          '🔍 No noShowVisitors data found, using usersDataList as fallback',
        )
        // Fallback: use the same data as usersDataList if noShowVisitors is not available
        transformedData.noShowVisitors = transformedData.usersDataList
      }

      return transformedData
    } catch (error) {
      console.error('🔍 Error in transformApiResponse:', error)
      // Return safe default data structure
      return {
        usersDataList: [],
        noShowVisitors: [],
      }
    }
  }

  return (
    <div className="px-5 py-4">
      <div className="overflow-hidden whitespace-nowrap">
        <div className="animate-marquee inline-block">
          Welcome to VisiQ! Keep your workforce safe and manage your visitors at
          any scale with a simple yet effective AI-based visitor management
          system.
        </div>
      </div>
      <br />
      <div className="flex justify-between gap-6 items-end ">
        <div className="flex gap-5 items-end justify-center">
          {/* <div className="flex flex-col justify-between">
            <p className="text-sm font-bold mb-2 ml-2">Select Branch :</p>
            <div className="dropdown dropdown-hover relative">
              <div
                tabIndex={0}
                role="button"
                className="btn bg-secondary flex-row flex justify-between min-w-48 w-full "
                onClick={handleDropdownToggle}
                title={selectedBranch?.branch_name}
              >
                {truncateBranchName(selectedBranch?.branch_name)}
                <img src={dropdown} alt="dropdown" className="h-9 " />
              </div>
              {showDropdown && (
                <ul
                  tabIndex={0}
                  className="dropdown-content p-2 shadow bg-base-100 rounded-box max-h-[200px] w-full overflow-y-auto "
                  style={{ zIndex: 9999 }}
                >
                  {branches?.length === 0 ? (
                    <p>No Branches Found</p>
                  ) : (
                    branches.map((branch, i) => (
                      <li
                        key={i}
                        onClick={() => handleBranchSelect(branch)}
                        className="p-1 hover:bg-slate-100 rounded cursor-pointer"
                      >
                        <a>{branch.branch_name}</a>
                      </li>
                    ))
                  )}
                </ul>
              )}
            </div>
          </div> */}
          {auth?.role === '3' || auth?.role === '4' ? (
            <div className="flex gap-5 justify-center">
              <div className="flex flex-col">
                <p className="text-sm font-bold mb-2">Branch Name :</p>
                <div className="btn bg-secondary py-2 px-4 w-48 text-center">
                  {selectedBranch?.branch_name}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col justify-between">
              <p className="text-sm font-bold mb-2 ml-2">Select Branch :</p>
              <div className="dropdown dropdown-hover relative">
                <div
                  tabIndex={0}
                  role="button"
                  className="btn bg-secondary flex-row flex justify-between min-w-48 w-full py-2 px-4 text-center"
                  onClick={handleDropdownToggle}
                  title={selectedBranch?.branch_name}
                >
                  {truncateBranchName(selectedBranch?.branch_name)}
                  <img src={dropdown} alt="dropdown" className="h-9" />
                </div>
                {showDropdown && (
                  <ul
                    tabIndex={0}
                    className="dropdown-content p-2 shadow bg-base-100 rounded-box max-h-[200px] w-full overflow-y-auto"
                    style={{ zIndex: 9999 }}
                  >
                    {branches?.length === 0 ? (
                      <p>No Branches Found</p>
                    ) : (
                      branches.map((branch, i) => (
                        <li
                          key={i}
                          onClick={() => handleBranchSelect(branch)}
                          className="p-1 hover:bg-slate-100 rounded cursor-pointer"
                        >
                          <a>{branch.branch_name}</a>
                        </li>
                      ))
                    )}
                  </ul>
                )}
              </div>
            </div>
          )}
          <div className="flex flex-col justify-between">
            <p className="text-sm font-bold mb-2 ml-2">From Date :</p>
            <DatePicker
              selected={start_date}
              onChange={(date) => handleDateChange(date)}
              dateFormat="dd-MM-yyyy"
              className="btn bg-secondary"
              customInput={<CustomInput />}
              onKeyDown={(e) => e.preventDefault()}
            />
          </div>
          <div className="flex flex-col justify-between">
            <p className="text-sm font-bold mb-2 ml-2">To Date :</p>
            <DatePicker
              selected={to_date}
              onChange={(date) => handleDateChanges(date)}
              dateFormat="dd-MM-yyyy"
              className="btn bg-secondary"
              customInput={<CustomInput />}
              onKeyDown={(e) => e.preventDefault()}
              minDate={start_date}
            />
          </div>
          <div>
            <p className="text-sm font-bold mb-2 ml-2">
              Select Visitor Organization:
            </p>
            <div className="dropdown dropdown-hover relative">
              <div
                tabIndex={0}
                role="button"
                className="btn bg-secondary flex-row flex justify-between min-w-48 w-full "
                onClick={handleDropdownToggles}
                title={selectVisitorOrg?.visitor_org_name}
              >
                {isLoadingVisitorData ? (
                  <p>Loading...</p>
                ) : !VisitorData || VisitorData?.length === 0 ? (
                  <p>No Visitors Org Found</p>
                ) : selectVisitorOrg ? (
                  truncateBranchName(selectVisitorOrg?.visitor_org_name)
                ) : (
                  <p>Loading...</p>
                )}

                <img src={dropdown} alt="dropdown" className="h-9 " />
              </div>
              {ShowDropdowns && (
                <ul
                  tabIndex={0}
                  className="dropdown-content p-2 shadow bg-base-100 rounded-box max-h-[200px] w-full overflow-y-auto "
                  style={{ zIndex: 9999 }}
                >
                  {isLoadingVisitorData ? (
                    <p>Loading...</p>
                  ) : !VisitorData || VisitorData?.length === 0 ? (
                    <p>No Visitors Org Found</p>
                  ) : (
                    VisitorData.map((visit, i) => (
                      <li
                        key={i}
                        onClick={() => handleVisitorSelect(visit)}
                        className="p-1 hover:bg-slate-100 rounded cursor-pointer"
                      >
                        <a>{visit.visitor_org_name}</a>
                      </li>
                    ))
                  )}
                </ul>
              )}
            </div>
          </div>
          <div>
            <p className="text-sm font-bold mb-2 ml-2">Select Visitor Type:</p>
            <div className="dropdown dropdown-hover relative">
              <div
                tabIndex={0}
                role="button"
                className="btn bg-secondary flex-row flex justify-between min-w-48 w-full"
                onClick={handleDropdownToggles}
                title={visitorType}
              >
                {visitorTypes.find((type) => type.value === visitorType)?.label}
                <img src={dropdown} alt="dropdown" className="h-9" />
              </div>
              {ShowDropdowns && (
                <ul
                  tabIndex={0}
                  className="dropdown-content p-2 shadow bg-base-100 rounded-box max-h-[200px] w-full overflow-y-auto"
                  style={{ zIndex: 9999 }}
                >
                  {visitorTypes.map((type, i) => (
                    <li
                      key={i}
                      onClick={() => handleVisitorTypeSelect(type.value)}
                      className="p-1 hover:bg-slate-100 rounded cursor-pointer"
                    >
                      <a>{type.label}</a>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>

          <div>
            {/* <PrimaryBtn text="Submit" type="submit" onClick={HandelClick} /> */}
            <button
              type="submit"
              className="rounded px-5 py-2.5 bg-primary text-white"
              onClick={HandelClick}
            >
              Submit
            </button>
          </div>
        </div>
      </div>
      <div className="py-20">
        {isLoading ? (
          <div className="text-xl text-center">
            <TotalLoding data={loading} height="20vh" />
          </div>
        ) : visitorType === 'all' &&
          VisitorOrgData?.usersDataList?.length > 0 ? (
          <>
            {console.log(
              '🔍 Rendering AllVisitorsAttendance with data:',
              VisitorOrgData?.usersDataList,
            )}
            <AllVisitorsAttendance
              userData={VisitorOrgData?.usersDataList || []}
              noShowVisitorsData={VisitorOrgData?.noShowVisitors || []}
              branch={selectedBranch}
              data_of_visit={{
                from_date: start_date,
                to_date: to_date,
                visit_date: start_date,
              }}
              name={auth?.username || ''}
              report_name="Visitor Reports"
            />
            {console.log('🔍 Passing data to AllVisitorsAttendance:', {
              userDataLength: VisitorOrgData?.usersDataList?.length,
              sampleUserData: VisitorOrgData?.usersDataList
                ?.slice(0, 2)
                .map((u) => ({
                  name: u.first_name,
                  visitor_type: u.visitor_type,
                  raw_visitor_type: u.visitor_type,
                })),
            })}
          </>
        ) : visitorType === 'no_show' &&
          VisitorOrgData?.noShowVisitors?.length > 0 ? (
          <VisitorsTable
            data={VisitorOrgData?.noShowVisitors || []}
            selectedBranch={selectedBranch}
            data_of_visit={start_date}
            name={auth?.username || ''}
            start_date={start_date}
            to_date={to_date}
            visitorType={visitorType}
            report_name="No Show Visitors Reports"
          />
        ) : visitorType === 'all' &&
          VisitorOrgData?.noShowVisitors?.length > 0 &&
          (!VisitorOrgData?.usersDataList ||
            VisitorOrgData?.usersDataList?.length === 0) ? (
          <div className="text-center py-12">
            <div className="max-w-md mx-auto">
              <div className="mb-6">
                <svg
                  className="mx-auto h-16 w-16 text-gray-400"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                  />
                </svg>
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No Data Found
              </h3>
            </div>
          </div>
        ) : visitorType === 'no_show' &&
          VisitorOrgData?.usersDataList?.length > 0 &&
          (!VisitorOrgData?.noShowVisitors ||
            VisitorOrgData?.noShowVisitors?.length === 0) ? (
          <div className="text-center py-12">
            <div className="max-w-md mx-auto">
              <div className="mb-6">
                <svg
                  className="mx-auto h-16 w-16 text-gray-400"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                  />
                </svg>
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No Data Found
              </h3>
            </div>
          </div>
        ) : VisitorOrgData && Object.keys(VisitorOrgData).length > 0 ? (
          <div className="text-center py-12">
            <div className="max-w-md mx-auto">
              <div className="mb-6">
                <svg
                  className="mx-auto h-16 w-16 text-gray-400"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                  />
                </svg>
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No Data Found
              </h3>
            </div>
          </div>
        ) : (
          <div className="text-center py-12">
            <div className="max-w-md mx-auto">
              <div className="mb-6">
                <svg
                  className="mx-auto h-16 w-16 text-gray-400"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                  />
                </svg>
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No Data Available
              </h3>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default Presentation
