// import React, { useEffect, useState } from 'react'
// import Chart from 'react-apexcharts'
// import { useMutation } from '@tanstack/react-query'
// import { graphsData } from '../../../services/adminService'
// import LottieLoader from '../../../shared/LottieLoader'
// import loading from '../../../assets/loading.json'

// const Graphs = (props) => {
//   const [data, setData] = useState({})
//   const [isLoading, setIsLoading] = useState(false)
//   const [timeline, setTimeline] = useState('this_year')
//   const [dateFrom, setDateFrom] = useState('')
//   const [dateTo, setDateTo] = useState('')
//   const { branches, orgId } = props
//   const [selectedBranch, setSelectedBranch] = useState(branches[0].branch_id)

//   useEffect(() => {
//     fetchData()
//   }, [timeline, dateFrom, dateTo, selectedBranch])

//   const fetchData = () => {
//     setIsLoading(true)
//     mutationgraphsdata.mutate({
//       timeline,
//       org_id: orgId,
//       branch_id: selectedBranch,
//       dateFrom: timeline === 'custom_range' ? dateFrom : '',
//       dateTo: timeline === 'custom_range' ? dateTo : '',
//     })
//   }

//   const mutationgraphsdata = useMutation({
//     mutationFn: (values) => graphsData(values),
//     onSuccess: (data) => {
//       setData(data)
//       setIsLoading(false)
//     },
//     onError: () => {
//       setIsLoading(false)
//     },
//   })

//   const handleTimelineChange = (e) => {
//     const newTimeline = e.target.value
//     setTimeline(newTimeline)

//     // Reset dates if the new timeline is not 'custom_range'
//     if (newTimeline !== 'custom_range') {
//       setDateFrom('')
//       setDateTo('')
//     }
//   }

//   const handleDateChange = (e) => {
//     const { name, value } = e.target
//     if (name === 'dateFrom') setDateFrom(value)
//     if (name === 'dateTo') setDateTo(value)
//   }

//   const handleBranchChange = (e) => {
//     setSelectedBranch(e.target.value)
//   }

//   const getBarWidth = () => {
//     const numLabels = data?.visitorStats?.labels?.length || 0
//     if (numLabels === 1) return '10%'
//     if (numLabels <= 5) return '50%'
//     return '100%'
//   }

//   const getColumnWidth = () => {
//     const numLabels = data?.Top5Visitors?.labels?.length || 0
//     if (numLabels === 1) return '20%'
//     if (numLabels <= 5) return '50%'
//     return '8%'
//   }

//   const donutOptions = {
//     chart: {
//       type: 'donut',
//       toolbar: {
//         show: false, // Disable toolbar, including download option
//       },
//     },
//     labels: data?.visitorsPieChart?.labels || [],
//     series: data?.visitorsPieChart?.series || [],
//     dataLabels: {
//       enabled: true,
//       formatter: function (val, opts) {
//         return `${opts.w.config.series[opts.seriesIndex]}`
//       },
//     },
//     plotOptions: {
//       pie: {
//         donut: {
//           labels: {
//             show: true,
//             name: {
//               show: true,
//             },
//             value: {
//               show: true,
//               formatter: function (val) {
//                 return `${val}`
//               },
//             },
//           },
//         },
//       },
//     },
//   }

//   // const barOptions = {
//   //   chart: {
//   //     type: 'bar',
//   //     toolbar: {
//   //       show: false, // Disable toolbar, including download option
//   //     },
//   //   },
//   //   plotOptions: {
//   //     bar: {
//   //       horizontal: false,
//   //       columnWidth: getBarWidth(), // Ensure this function returns the desired width
//   //     },
//   //   },
//   //   xaxis: {
//   //     categories: data?.visitorStats?.labels || [], // Ensure labels are defined
//   //   },
//   //   yaxis: {
//   //     labels: {
//   //       formatter: (value) => {
//   //         return Math.floor(value) // Display integer values
//   //       },
//   //     },
//   //   },
//   //   series: [
//   //     {
//   //       name: 'Visitors',
//   //       data: data?.visitorStats?.series || [], // Ensure series data is defined
//   //     },
//   //   ],
//   // }

//   // Calculate the maximum value in the visitorStats series data
//   const visitorStatsSeries = data?.visitorStats?.series || []
//   const maxVisitorStatsValue = Math.max(...visitorStatsSeries, 0)

//   // Set the maximum value for the y-axis
//   const yAxisMaxValue = maxVisitorStatsValue + 6

//   // Configure chart options for the vertical bar chart
//   const barOptions = {
//     chart: {
//       type: 'bar',
//       toolbar: {
//         show: false, // Disable toolbar, including download option
//       },
//     },
//     plotOptions: {
//       bar: {
//         horizontal: false,
//         columnWidth: getBarWidth(), // Ensure this function returns the desired width
//       },
//     },
//     xaxis: {
//       categories: data?.visitorStats?.labels || [], // Ensure labels are defined
//     },
//     yaxis: {
//       max: yAxisMaxValue, // Set max value for y-axis
//       labels: {
//         formatter: (value) => {
//           return Math.floor(value) // Display integer values
//         },
//       },
//     },
//     series: [
//       {
//         name: 'Visitors',
//         data: visitorStatsSeries, // Ensure series data is defined
//       },
//     ],
//   }

//   // Define default and max values
//   // Calculate the maximum value in the series data and set defaultMaxValue to be 10 more
//   const dataSeries = data?.Top5Visitors?.series || []

//   // Find the max value in the series data
//   const maxValue = Math.max(...dataSeries.flatMap((series) => series.data), 0)

//   // Set defaultMaxValue to be 10 more than the maximum value found
//   const defaultMaxValue = maxValue + 6

//   // Generate unique ticks
//   const uniqueTicks = Array.from(
//     new Set([
//       0,
//       ...dataSeries.flatMap((series) => series.data),
//       Math.max(defaultMaxValue, maxValue),
//     ]),
//   )

//   // Configure chart options
//   const barOptionsHorizontal = {
//     chart: {
//       type: 'bar',
//       toolbar: {
//         show: false,
//       },
//     },
//     plotOptions: {
//       bar: {
//         horizontal: true,
//         distributed: false,
//         barHeight: getColumnWidth(), // Ensure this function is defined and returns a value
//       },
//     },
//     xaxis: {
//       categories: data?.Top5Visitors?.labels || [],
//       min: 0,
//       max: Math.max(defaultMaxValue, maxValue),
//       tickAmount: uniqueTicks.length, // Set tickAmount to the number of unique ticks
//       labels: {
//         formatter: (value) => {
//           return Math.floor(value) // Display integer values
//         },
//         style: {
//           colors: '#000', // Adjust label color if needed
//         },
//       },
//       tickPlacement: 'between',
//       ticks: uniqueTicks.map((tick) => ({ value: tick })), // Custom ticks
//     },
//     series: dataSeries,
//     colors: ['#FF5733'],
//   }

//   // const areaOptions = {
//   //   chart: {
//   //     type: 'area',
//   //     height: 350,
//   //     width: '100%',
//   //     toolbar: {
//   //       show: false, // Disable toolbar, including download option
//   //     },
//   //   },
//   //   series: [
//   //     {
//   //       name: 'Visitors',
//   //       data: data?.visitorStatsCheckIns?.series,
//   //     },
//   //   ],
//   //   xaxis: {
//   //     categories: data?.visitorStatsCheckIns?.labels,
//   //   },
//   // }
//   // Calculate the maximum value in the visitorStatsCheckIns series data
//   const checkInsSeries = data?.visitorStatsCheckIns?.series || []
//   const maxCheckInsValue = Math.max(...checkInsSeries, 0)

//   // Set the maximum value for the y-axis
//   const yAxisMaxCheckInsValue = maxCheckInsValue + 6

//   // Configure chart options for the area chart
//   const areaOptions = {
//     chart: {
//       type: 'area',
//       height: 350,
//       width: '100%',
//       toolbar: {
//         show: false, // Disable toolbar, including download option
//       },
//     },
//     series: [
//       {
//         name: 'Visitors',
//         data: checkInsSeries, // Ensure series data is defined
//       },
//     ],
//     xaxis: {
//       categories: data?.visitorStatsCheckIns?.labels || [], // Ensure labels are defined
//     },
//     yaxis: {
//       max: yAxisMaxCheckInsValue, // Set max value for y-axis
//       labels: {
//         formatter: (value) => Math.floor(value), // Display integer values
//       },
//     },
//   }

//   return (
//     <div>
//       <div className="p-4 bg-white shadow rounded-lg mb-4 flex items-center justify-between">
//         <div className="flex items-center">
//           {/* <select value={timeline} onChange={handleTimelineChange}>
//             <option value="this_year">This Year</option>
//             <option value="this_month">This Month</option>
//             <option value="this_week">This Week</option>
//             <option value="custom_range">Custom Range</option>
//           </select> */}
//           <select
//             value={timeline}
//             onChange={handleTimelineChange}
//             className="bg-white border border-gray-300 text-gray-700 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 p-2"
//           >
//             <option value="all_time"> Today</option>
//             <option value="today">Yesterday</option>
//             <option value="this_week">This Week</option>
//             <option value="this_month">This Month</option>
//             <option value="this_year">This Year</option>

//             <option value="custom_range">Custom Range</option>
//           </select>

//           {/* {timeline === 'custom_range' && (
//             <div className="ml-4">
//               <label className="mr-2">From: </label>
//               <input
//                 type="date"
//                 name="dateFrom"
//                 value={dateFrom}
//                 onChange={handleDateChange}
//               />
//               <label className="ml-2 mr-2">To: </label>
//               <input
//                 type="date"
//                 name="dateTo"
//                 value={dateTo}
//                 onChange={handleDateChange}
//               />
//             </div>
//           )} */}
//           {timeline === 'custom_range' && (
//             <div className="ml-4 flex items-center space-x-4">
//               <div className="flex items-center space-x-2">
//                 <label htmlFor="dateFrom" className="text-gray-700 font-medium">
//                   <strong className="text-green-600 bg-green-100 px-2 py-1 rounded-md font-semibold">
//                     From:
//                   </strong>
//                 </label>
//                 <input
//                   id="dateFrom"
//                   type="date"
//                   name="dateFrom"
//                   value={dateFrom}
//                   onChange={handleDateChange}
//                   className="border border-gray-300 rounded-lg p-2 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
//                 />
//               </div>
//               <div className="flex items-center space-x-2">
//                 <label htmlFor="dateTo" className="text-gray-700 font-medium">
//                   <strong className="text-blue-600 bg-blue-100 px-2 py-1 rounded-md font-semibold">
//                     To:
//                   </strong>
//                 </label>
//                 <input
//                   id="dateTo"
//                   type="date"
//                   name="dateTo"
//                   value={dateTo}
//                   onChange={handleDateChange}
//                   className="border border-gray-300 rounded-lg p-2 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
//                 />
//               </div>
//             </div>
//           )}
//         </div>
//         <div className="flex items-center">
//           {/* <select value={selectedBranch} onChange={handleBranchChange}>
//             {branches.map((branch) => (
//               <option key={branch.branch_id} value={branch.branch_id}>
//                 {branch.branch_name}
//               </option>
//             ))}
//           </select> */}
//           {/* <select
//             value={selectedBranch}
//             onChange={handleBranchChange}
//             className="bg-white border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 p-2.5 text-gray-700 appearance-none"
//           >
//             {branches.map((branch) => (
//               <option key={branch.branch_id} value={branch.branch_id}>
//                 {branch.branch_name}
//               </option>
//             ))}
//           </select> */}
//           <select
//             value={selectedBranch}
//             onChange={handleBranchChange}
//             className="bg-white border border-gray-300 text-gray-700 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 p-2"
//           >
//             {branches.map((branch) => (
//               <option key={branch.branch_id} value={branch.branch_id}>
//                 {branch.branch_name}
//               </option>
//             ))}
//           </select>
//         </div>
//       </div>
//       {isLoading ? (
//         <LottieLoader data={loading} />
//       ) : (
//         <div className="grid grid-cols-2 gap-10 p-10">
//           <div className="w-full p-4 bg-white shadow rounded-lg relative">
//             {/* <div className="absolute top-2 left-2 font-bold">
//               Complete Visitor Metrics Analysis
//             </div> */}

//             <Chart
//               options={donutOptions}
//               series={donutOptions.series}
//               type="donut"
//               width="500"
//               height="500"
//             />
//             <div className=" text-lg font-semibold   mt-14  mr-12 text-transparent bg-clip-text bg-gradient-to-br  from-[#051737] to-[#76E5F0] rounded-md  text-center">
//               Complete Visitor Analysis
//             </div>
//           </div>
//           <div className="w-full p-4 bg-white shadow rounded-lg relative">
//             <Chart
//               options={barOptionsHorizontal}
//               series={barOptionsHorizontal.series}
//               type="bar"
//               height={350}
//               width="100%"
//             />
//             <div className=" text-lg font-semibold  mb-4 mt-4   mr-12 text-transparent bg-clip-text bg-gradient-to-br  from-[#051737] to-[#76E5F0] rounded-md  text-center">
//               Most Frequent Visitors
//             </div>
//           </div>

//           <div className="w-full p-4 bg-white shadow rounded-lg relative">
//             {/* <div className="absolute top-2 left-2 font-bold">
//               Visitor Checkout Metrics
//             </div> */}

//             <Chart
//               options={barOptions}
//               series={barOptions.series}
//               type="bar"
//               height={350}
//               width="100%"
//             />
//             <div className=" text-lg font-semibold    mt-12 mr-12 text-transparent bg-clip-text bg-gradient-to-br  from-[#051737] to-[#76E5F0] rounded-md  text-center">
//               Visitor Checkout
//             </div>
//           </div>
//           <div className="w-full p-4 bg-white shadow rounded-lg relative">
//             <Chart
//               options={areaOptions}
//               series={areaOptions.series}
//               type="area"
//               height={350}
//               width="100%"
//             />
//             <div className=" text-lg font-semibold    mt-12 mr-12 text-transparent bg-clip-text bg-gradient-to-br  from-[#051737] to-[#76E5F0] rounded-md  text-center">
//               Visitor Check-In
//             </div>
//           </div>
//         </div>
//       )}
//     </div>
//   )
// }

// export default Graphs

import React, { useEffect, useState } from 'react'
import Chart from 'react-apexcharts'
import { useMutation } from '@tanstack/react-query'
import { graphsData } from '../../../services/adminService'
import LottieLoader from '../../../shared/LottieLoader'
import loading from '../../../assets/loading.json'

const Graphs = (props) => {
  const [data, setData] = useState({})
  const [isLoading, setIsLoading] = useState(false)
  const [timeline, setTimeline] = useState('this_year')
  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')
  const { branches, orgId } = props
  const [selectedBranch, setSelectedBranch] = useState(branches[0].branch_id)

  useEffect(() => {
    fetchData()
  }, [timeline, dateFrom, dateTo, selectedBranch])

  const fetchData = () => {
    setIsLoading(true)

    // Determine date range based on timeline
    let dateFromParam = ''
    let dateToParam = ''

    if (timeline === 'custom_range') {
      dateFromParam = dateFrom
      dateToParam = dateTo
    } else if (timeline === 'today') {
      const today = new Date().toISOString().split('T')[0] // Format as YYYY-MM-DD
      dateFromParam = today
      dateToParam = today
    } else if (timeline === 'yesterday') {
      const yesterday = new Date()
      yesterday.setDate(yesterday.getDate() - 1)
      const formattedYesterday = yesterday.toISOString().split('T')[0] // Format as YYYY-MM-DD
      dateFromParam = formattedYesterday
      dateToParam = formattedYesterday
    }

    mutationgraphsdata.mutate({
      timeline,
      org_id: orgId,
      branch_id: selectedBranch,
      dateFrom: dateFromParam,
      dateTo: dateToParam,
    })
  }

  const mutationgraphsdata = useMutation({
    mutationFn: (values) => graphsData(values),
    onSuccess: (data) => {
      setData(data)
      setIsLoading(false)
    },
    onError: () => {
      setIsLoading(false)
    },
  })

  const handleTimelineChange = (e) => {
    const newTimeline = e.target.value
    setTimeline(newTimeline)

    // Reset dates if the new timeline is not 'custom_range'
    if (newTimeline !== 'custom_range') {
      setDateFrom('')
      setDateTo('')
    }
  }

  const handleDateChange = (e) => {
    const { name, value } = e.target
    if (name === 'dateFrom') setDateFrom(value)
    if (name === 'dateTo') setDateTo(value)
  }

  const handleBranchChange = (e) => {
    setSelectedBranch(e.target.value)
  }

  const getBarWidth = () => {
    const numLabels = data?.visitorStats?.labels?.length || 0
    if (numLabels === 1) return '10%'
    if (numLabels <= 5) return '50%'
    return '100%'
  }

  const getColumnWidth = () => {
    const numLabels = data?.Top5Visitors?.labels?.length || 0
    if (numLabels === 1) return '20%'
    if (numLabels <= 5) return '50%'
    return '8%'
  }

  const donutOptions = {
    chart: {
      type: 'donut',
      toolbar: {
        show: false, // Disable toolbar, including download option
      },
    },
    labels: data?.visitorsPieChart?.labels || [],
    series: data?.visitorsPieChart?.series || [],
    dataLabels: {
      enabled: true,
      formatter: function (val, opts) {
        return `${opts.w.config.series[opts.seriesIndex]}`
      },
    },
    plotOptions: {
      pie: {
        donut: {
          labels: {
            show: true,
            name: {
              show: true,
            },
            value: {
              show: true,
              formatter: function (val) {
                return `${val}`
              },
            },
          },
        },
      },
    },
  }

  // Calculate the maximum value in the visitorStats series data
  const visitorStatsSeries = data?.visitorStats?.series || []
  const maxVisitorStatsValue = Math.max(...visitorStatsSeries, 0)

  // Set the maximum value for the y-axis
  const yAxisMaxValue = maxVisitorStatsValue + 6

  // Configure chart options for the vertical bar chart
  const barOptions = {
    chart: {
      type: 'bar',
      toolbar: {
        show: false, // Disable toolbar, including download option
      },
    },
    plotOptions: {
      bar: {
        horizontal: false,
        columnWidth: getBarWidth(), // Ensure this function returns the desired width
      },
    },
    xaxis: {
      categories: data?.visitorStats?.labels || [], // Ensure labels are defined
    },
    yaxis: {
      max: yAxisMaxValue, // Set max value for y-axis
      labels: {
        formatter: (value) => {
          return Math.floor(value) // Display integer values
        },
      },
    },
    series: [
      {
        name: 'Visitors',
        data: visitorStatsSeries, // Ensure series data is defined
      },
    ],
  }

  const dataSeries = data?.Top5Visitors?.series || []
  const maxValue = Math.max(...dataSeries.flatMap((series) => series.data), 0)
  const defaultMaxValue = maxValue + 6

  const uniqueTicks = Array.from(
    new Set([
      0,
      ...dataSeries.flatMap((series) => series.data),
      Math.max(defaultMaxValue, maxValue),
    ]),
  )

  const barOptionsHorizontal = {
    chart: {
      type: 'bar',
      toolbar: {
        show: false,
      },
    },
    plotOptions: {
      bar: {
        horizontal: true,
        distributed: false,
        barHeight: getColumnWidth(), // Ensure this function is defined and returns a value
      },
    },
    xaxis: {
      categories: data?.Top5Visitors?.labels || [],
      min: 0,
      max: Math.max(defaultMaxValue, maxValue),
      tickAmount: uniqueTicks.length, // Set tickAmount to the number of unique ticks
      labels: {
        formatter: (value) => Math.floor(value), // Display integer values
        style: {
          colors: '#000', // Adjust label color if needed
        },
      },
      tickPlacement: 'between',
      ticks: uniqueTicks.map((tick) => ({ value: tick })), // Custom ticks
    },
    series: dataSeries,
    colors: ['#FF5733'],
  }

  const checkInsSeries = data?.visitorStatsCheckIns?.series || []
  const maxCheckInsValue = Math.max(...checkInsSeries, 0)
  const yAxisMaxCheckInsValue = maxCheckInsValue + 6

  const areaOptions = {
    chart: {
      type: 'area',
      height: 350,
      width: '100%',
      toolbar: {
        show: false, // Disable toolbar, including download option
      },
    },
    series: [
      {
        name: 'Visitors',
        data: checkInsSeries, // Ensure series data is defined
      },
    ],
    xaxis: {
      categories: data?.visitorStatsCheckIns?.labels || [], // Ensure labels are defined
    },
    yaxis: {
      max: yAxisMaxCheckInsValue, // Set max value for y-axis
      labels: {
        formatter: (value) => Math.floor(value), // Display integer values
      },
    },
  }

  return (
    <div>
      <div className="p-4 bg-white shadow rounded-lg mb-4 flex items-center justify-between">
        <div className="flex items-center">
          <select
            value={timeline}
            onChange={handleTimelineChange}
            className="bg-white border border-gray-300 text-gray-700 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 p-2"
          >
            <option value="today">Today</option>
            <option value="yesterday">Yesterday</option>
            <option value="this_week">This Week</option>
            <option value="this_month">This Month</option>
            <option value="this_year">This Year</option>
            <option value="custom_range">Custom Range</option>
          </select>

          {timeline === 'custom_range' && (
            <div className="ml-4 flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <label htmlFor="dateFrom" className="text-gray-700 font-medium">
                  <strong className="text-green-600 bg-green-100 px-2 py-1 rounded-md font-semibold">
                    From:
                  </strong>
                </label>
                <input
                  id="dateFrom"
                  type="date"
                  name="dateFrom"
                  value={dateFrom}
                  onChange={handleDateChange}
                  className="border border-gray-300 rounded-lg p-2 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              <div className="flex items-center space-x-2">
                <label htmlFor="dateTo" className="text-gray-700 font-medium">
                  <strong className="text-blue-600 bg-blue-100 px-2 py-1 rounded-md font-semibold">
                    To:
                  </strong>
                </label>
                <input
                  id="dateTo"
                  type="date"
                  name="dateTo"
                  value={dateTo}
                  onChange={handleDateChange}
                  className="border border-gray-300 rounded-lg p-2 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>
          )}
        </div>
        <div className="flex items-center">
          <select
            value={selectedBranch}
            onChange={handleBranchChange}
            className="bg-white border border-gray-300 text-gray-700 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 p-2"
          >
            {branches.map((branch) => (
              <option key={branch.branch_id} value={branch.branch_id}>
                {branch.branch_name}
              </option>
            ))}
          </select>
        </div>
      </div>
      {isLoading ? (
        <LottieLoader data={loading} />
      ) : (
        <div className="grid grid-cols-2 gap-10 p-10">
          <div className="w-full p-4 bg-white shadow rounded-lg relative">
            <Chart
              options={donutOptions}
              series={donutOptions.series}
              type="donut"
              width="500"
              height="500"
            />
            <div className="text-lg font-bold mt-14 mr-12 text-transparent bg-clip-text bg-gradient-to-br from-[#051737] to-[#76E5F0] rounded-md text-center text-shadow">
              Complete Visitor Analysis
            </div>
          </div>
          <div className="w-full p-4 bg-white shadow rounded-lg relative">
            <Chart
              options={barOptionsHorizontal}
              series={barOptionsHorizontal.series}
              type="bar"
              height={350}
              width="100%"
            />
            <div className=" text-lg font-semibold mb-4 mt-4 mr-12 text-transparent bg-clip-text bg-gradient-to-br from-[#051737] to-[#76E5F0] rounded-md text-center">
              Most Frequent Visitors
            </div>
          </div>

          <div className="w-full p-4 bg-white shadow rounded-lg relative">
            <Chart
              options={barOptions}
              series={barOptions.series}
              type="bar"
              height={350}
              width="100%"
            />
            <div className=" text-lg font-semibold mt-14 mb-4  mr-12 text-transparent bg-clip-text bg-gradient-to-br from-[#051737] to-[#76E5F0] rounded-md text-center">
              Visitor Checkout
            </div>
          </div>
          <div className="w-full p-4 bg-white shadow rounded-lg relative">
            <Chart
              options={areaOptions}
              series={areaOptions.series}
              type="area"
              height={350}
              width="100%"
            />
            <div className=" text-lg font-semibold mt-14 mb-4 mr-12 text-transparent bg-clip-text bg-gradient-to-br from-[#051737] to-[#76E5F0] rounded-md text-center">
              Visitor Check-In
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Graphs
