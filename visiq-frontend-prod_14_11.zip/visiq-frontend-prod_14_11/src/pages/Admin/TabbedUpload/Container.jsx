/* eslint-disable jsx-a11y/img-redundant-alt */
import React, { useContext } from 'react'
import Presentation from './Presentation'
import { useQuery } from '@tanstack/react-query'
import { getBranchesByOrgId } from '../../../services/adminService'
import { AuthContext } from '../../../context/AuthContext'
import { useParams } from 'react-router-dom'
import loading from '../../../assets/loading.json'
import LottieLoader from '../../../shared/LottieLoader'

const Container = () => {
  const auth = useContext(AuthContext)
  const { orgId } = useParams()
  const values = {
    org_id: auth.org_id || orgId,
    role: auth.role == '1' ? '' : auth.role,
    branch_id: auth?.branch_id || '',
  }

  const { data: branches, isLoading } = useQuery({
    queryKey: ['getBranches', values.org_id],
    queryFn: () => getBranchesByOrgId(values),
  })

  if (isLoading) return <LottieLoader data={loading} />

  if (branches) {
    if (branches.organisationDetails?.branches?.length > 0) {
      return (
        <Presentation
          branches={branches.organisationDetails.branches}
          orgId={orgId}
        />
      )
    } else {
      return <div></div>
    }
  }

  return null
}

export default Container
