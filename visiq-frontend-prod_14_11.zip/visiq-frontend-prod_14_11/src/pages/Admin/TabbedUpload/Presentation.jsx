// import React, { useContext, useState } from 'react'
// import FileUploadWithDragAndDropPolices from '../Upload_polices/index' // Your NDA component
// import FileUploadWithDragAndDropNDA from '../Download_file/index' // Your Policies component
// import { dropdown } from '../../../assets/index'
// import { AuthContext } from '../../../context/AuthContext'

// const Presentation = (props) => {
//   const auth = useContext(AuthContext)

//   const { branches, orgId } = props
//   const [activeTab, setActiveTab] = useState('nda')
//   const [selectedBranch, setSelectedBranch] = useState(branches[0])
//   const [branch_id, setBranchId] = useState(branches[0].branch_id)
//   const [showDropdown, setShowDropdown] = useState(false)

//   const handleTabChange = (tab) => {
//     setActiveTab(tab)
//   }
//   const handleBranchSelect = (branch) => {
//     setSelectedBranch(branch)
//     setBranchId(branch.branch_id)
//     setShowDropdown(false)
//   }

//   const handleDropdownToggle = () => {
//     setShowDropdown((prev) => !prev)
//   }
//   const truncateBranchName = (name) => {
//     return name?.length > 5 ? name?.slice(0, 5) + '...' : name
//   }

//   console.log(selectedBranch?.branch_id, 'selectedBranch?.branch_id')
//   return (
//     <div className="min-h-screen bg-gray-100 flex justify-between  p-6">
//       <div className="bg-white rounded shadow-md w-full mx-auto">
//         {/* Tab Buttons and Branch Selector */}
//         <div
//           className="flex space-x-4 border-b border-gray-300 p-4 items-center"
//           style={{ width: '43rem' }}
//         >
//           <button
//             onClick={() => handleTabChange('nda')}
//             className={`py-2 px-4 w-full text-center ${activeTab === 'nda' ? 'bg-dark-500 text-white' : 'bg-gray-200'}`}
//             style={
//               activeTab === 'nda'
//                 ? {
//                     backgroundColor: 'rgb(5 23 55 / var(--tw-bg-opacity))',
//                     color: 'white',
//                   }
//                 : { color: 'black' }
//             }
//           >
//             Upload NDA
//           </button>
//           <button
//             onClick={() => handleTabChange('policies')}
//             className={`py-2 px-4 w-full text-center ${activeTab === 'policies' ? 'bg-dark-500 text-white' : 'bg-gray-200'}`}
//             style={
//               activeTab === 'policies'
//                 ? {
//                     backgroundColor: 'rgb(5 23 55 / var(--tw-bg-opacity))',
//                     color: 'white',
//                   }
//                 : { color: 'black' }
//             }
//           >
//             Upload Guidelines
//           </button>

//           {/* Select Branch beside buttons */}
//           {auth?.role === '3' || auth?.role === '4' ? (
//             <div className="flex gap-5  justify-center">
//               <div className="flex flex-col">
//                 <p className="text-sm font-bold mb-2">Branch Name :</p>
//                 <div className="btn  bg-secondary">
//                   {selectedBranch?.branch_name}
//                 </div>
//               </div>
//             </div>
//           ) : (
//             <div className="flex flex-col justify-between">
//               <p className="text-sm font-bold mb-2 ml-2">Select Branch :</p>
//               <div className="dropdown dropdown-hover relative">
//                 <div
//                   tabIndex={0}
//                   role="button"
//                   className="btn bg-secondary flex-row flex justify-between min-w-48 w-full "
//                   onClick={handleDropdownToggle}
//                   title={selectedBranch?.branch_name}
//                 >
//                   {truncateBranchName(selectedBranch?.branch_name)}
//                   <img src={dropdown} alt="dropdown" className="h-9 " />
//                 </div>
//                 {showDropdown && (
//                   <ul
//                     tabIndex={0}
//                     className="dropdown-content p-2 shadow bg-base-100 rounded-box max-h-[200px] w-full overflow-y-auto "
//                     style={{ zIndex: 9999 }}
//                   >
//                     {branches?.length === 0 ? (
//                       <p>No Branches Found</p>
//                     ) : (
//                       branches.map((branch, i) => (
//                         <li
//                           key={i}
//                           onClick={() => handleBranchSelect(branch)}
//                           className="p-1 hover:bg-slate-100 rounded cursor-pointer"
//                         >
//                           <a>{branch.branch_name}</a>
//                         </li>
//                       ))
//                     )}
//                   </ul>
//                 )}
//               </div>
//             </div>
//           )}
//         </div>

//         {/* Tab Content */}
//         {activeTab === 'nda' ? (
//           <FileUploadWithDragAndDropNDA branch_id={selectedBranch?.branch_id} />
//         ) : (
//           <FileUploadWithDragAndDropPolices
//             brach_id={selectedBranch?.branch_id}
//           />
//         )}
//       </div>
//     </div>
//   )
// }

// export default Presentation
import React, { useContext, useState } from 'react'
import FileUploadWithDragAndDropPolices from '../Upload_polices/index' // Your NDA component
import FileUploadWithDragAndDropNDA from '../Download_file/index' // Your Policies component
import { dropdown } from '../../../assets/index'
import { AuthContext } from '../../../context/AuthContext'

const Presentation = (props) => {
  const auth = useContext(AuthContext)

  const { branches, orgId } = props
  const [activeTab, setActiveTab] = useState('nda')
  const [selectedBranch, setSelectedBranch] = useState(branches[0])
  const [branch_id, setBranchId] = useState(branches[0].branch_id)
  const [showDropdown, setShowDropdown] = useState(false)

  const handleTabChange = (tab) => {
    setActiveTab(tab)
  }
  const handleBranchSelect = (branch) => {
    setSelectedBranch(branch)
    setBranchId(branch.branch_id)
    setShowDropdown(false)
  }

  const handleDropdownToggle = () => {
    setShowDropdown((prev) => !prev)
  }
  const truncateBranchName = (name) => {
    return name?.length > 5 ? name?.slice(0, 5) + '...' : name
  }

  console.log(selectedBranch?.branch_id, 'selectedBranch?.branch_id')
  return (
    <div className="min-h-screen bg-gray-100 flex justify-between p-6">
      <div className="bg-white rounded shadow-md w-full mx-auto">
        {/* Tab Buttons and Branch Selector */}
        <div
          className="flex space-x-4 border-b border-gray-300 p-4 items-center"
          style={{ width: '43rem' }}
        >
          {/* Tab Buttons */}
          <div className="flex flex-grow space-x-4 items-end">
            {/* Placeholder label for alignment */}
            <div className="flex flex-col">
              <p className="text-sm font-bold mb-2 invisible">Placeholder</p>
              <button
                onClick={() => handleTabChange('nda')}
                className={`py-2 px-4 w-48 text-center ${
                  activeTab === 'nda' ? 'bg-dark-500 text-white' : 'bg-gray-200'
                }`}
                style={
                  activeTab === 'nda'
                    ? {
                        backgroundColor: 'rgb(5 23 55 / var(--tw-bg-opacity))',
                        color: 'white',
                      }
                    : { color: 'black' }
                }
              >
                Upload NDA
              </button>
            </div>
            <div className="flex flex-col">
              <p className="text-sm font-bold mb-2 invisible">Placeholder</p>
              <button
                onClick={() => handleTabChange('policies')}
                className={`py-2 px-4 w-48 text-center ${
                  activeTab === 'policies'
                    ? 'bg-dark-500 text-white'
                    : 'bg-gray-200'
                }`}
                style={
                  activeTab === 'policies'
                    ? {
                        backgroundColor: 'rgb(5 23 55 / var(--tw-bg-opacity))',
                        color: 'white',
                      }
                    : { color: 'black' }
                }
              >
                Upload Guidelines
              </button>
            </div>
          </div>

          {/* Select Branch at the end of the left side */}
          {auth?.role === '3' || auth?.role === '4' ? (
            <div className="flex gap-5 justify-center">
              <div className="flex flex-col">
                <p className="text-sm font-bold mb-2">Branch Name :</p>
                <div className="btn bg-secondary py-2 px-4 w-48 text-center">
                  {selectedBranch?.branch_name}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col justify-between">
              <p className="text-sm font-bold mb-2 ml-2">Select Branch :</p>
              <div className="dropdown dropdown-hover relative">
                <div
                  tabIndex={0}
                  role="button"
                  className="btn bg-secondary flex-row flex justify-between min-w-48 w-full py-2 px-4 text-center"
                  onClick={handleDropdownToggle}
                  title={selectedBranch?.branch_name}
                >
                  {truncateBranchName(selectedBranch?.branch_name)}
                  <img src={dropdown} alt="dropdown" className="h-9" />
                </div>
                {showDropdown && (
                  <ul
                    tabIndex={0}
                    className="dropdown-content p-2 shadow bg-base-100 rounded-box max-h-[200px] w-full overflow-y-auto"
                    style={{ zIndex: 9999 }}
                  >
                    {branches?.length === 0 ? (
                      <p>No Branches Found</p>
                    ) : (
                      branches.map((branch, i) => (
                        <li
                          key={i}
                          onClick={() => handleBranchSelect(branch)}
                          className="p-1 hover:bg-slate-100 rounded cursor-pointer"
                        >
                          <a>{branch.branch_name}</a>
                        </li>
                      ))
                    )}
                  </ul>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Tab Content */}
        {activeTab === 'nda' ? (
          <FileUploadWithDragAndDropNDA branch_id={selectedBranch?.branch_id} />
        ) : (
          <FileUploadWithDragAndDropPolices
            brach_id={selectedBranch?.branch_id}
          />
        )}
      </div>
    </div>
  )
}

export default Presentation
