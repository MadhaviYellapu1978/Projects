import React, { useState, useContext } from 'react'
import {
  Modal,
  Box,
  Typography,
  TextField,
  Button,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  IconButton,
  Avatar,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
} from '@mui/material'
import {
  Group as GroupIcon,
  Add as AddIcon,
  Close as CloseIcon,
  Upload as UploadIcon,
  Business as BusinessIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Visibility as ViewIcon,
} from '@mui/icons-material'
import { styled } from '@mui/material/styles'
import { useMutation, useQuery } from '@tanstack/react-query'
import {
  uploadImage,
  listOfCountriesExt,
} from '../../../../services/adminService'
import { toast } from 'react-hot-toast'
import { AuthContext } from '../../../../context/AuthContext'
import { baseUrl } from '../../../../constants/baseUrl'
import ProgressLine from '../../../../shared/ProgressLine'

const StyledModal = styled(Modal)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  padding: theme.spacing(2),
}))

const ModalContent = styled(Box)(({ theme }) => ({
  backgroundColor: 'white',
  borderRadius: 0,
  padding: theme.spacing(4),
  width: '85%',
  maxWidth: 800,
  maxHeight: '95vh',
  overflow: 'auto',
  position: 'relative',
  boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)',
  '&::-webkit-scrollbar': {
    width: '8px',
  },
  '&::-webkit-scrollbar-track': {
    background: '#f1f1f1',
    borderRadius: '4px',
  },
  '&::-webkit-scrollbar-thumb': {
    background: '#c1c1c1',
    borderRadius: '4px',
    '&:hover': {
      background: '#a8a8a8',
    },
  },
}))

const HeaderSection = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  marginBottom: theme.spacing(3),
}))

const HeaderLeft = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  gap: theme.spacing(2),
}))

const HeaderIcon = styled(Box)(({ theme }) => ({
  width: 48,
  height: 48,
  borderRadius: '50%',
  backgroundColor: '#00BCD4',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  color: 'white',
}))

const MemberCounter = styled(Box)(({ theme }) => ({
  backgroundColor: '#E3F2FD',
  color: '#1976D2',
  padding: theme.spacing(1, 2),
  borderRadius: 20,
  display: 'flex',
  alignItems: 'center',
  gap: theme.spacing(1),
  fontSize: '0.875rem',
  fontWeight: 500,
}))

const FormSection = styled(Box)(({ theme }) => ({
  backgroundColor: '#FAFAFA',
  padding: theme.spacing(3),
  borderRadius: 0,
  marginBottom: theme.spacing(3),
}))

const FormGrid = styled(Box)(({ theme }) => ({
  display: 'grid',
  gridTemplateColumns: '1fr 1fr',
  gap: theme.spacing(3),
  marginBottom: theme.spacing(3),
}))

const UploadButton = styled(Button)(({ theme }) => ({
  backgroundColor: '#F5F5F5',
  color: '#666',
  border: '1px solid #E0E0E0',
  textTransform: 'none',
  padding: theme.spacing(1.5, 2),
  '&:hover': {
    backgroundColor: '#EEEEEE',
  },
}))

const AddMemberButton = styled(Button)(({ theme }) => ({
  background: 'linear-gradient(135deg, #00BCD4 0%, #26C6DA 100%)',
  color: 'white',
  textTransform: 'none',
  padding: theme.spacing(1.5, 3),
  borderRadius: 8,
  fontWeight: 500,
  boxShadow: '0 2px 8px rgba(0, 188, 212, 0.3)',
  '&:hover': {
    background: 'linear-gradient(135deg, #00ACC1 0%, #00BCD4 100%)',
    boxShadow: '0 4px 12px rgba(0, 188, 212, 0.4)',
  },
}))

const EmptyState = styled(Box)(({ theme }) => ({
  textAlign: 'center',
  padding: theme.spacing(6),
  color: '#666',
}))

const EmptyIcon = styled(Box)(({ theme }) => ({
  width: 80,
  height: 80,
  borderRadius: '50%',
  backgroundColor: '#F5F5F5',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  margin: '0 auto',
  marginBottom: theme.spacing(2),
  color: '#999',
}))

const GroupSection = styled(Box)(({ theme }) => ({
  marginBottom: theme.spacing(3),
  padding: theme.spacing(0, 4),
}))

const GroupHeader = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  marginBottom: theme.spacing(2),
}))

const GroupTitle = styled(Typography)(({ theme }) => ({
  fontSize: '1.25rem',
  fontWeight: 600,
  color: '#333',
}))

const GroupSubtitle = styled(Typography)(({ theme }) => ({
  fontSize: '0.875rem',
  color: '#666',
  marginTop: theme.spacing(0.5),
}))

const GroupCounter = styled(Box)(({ theme }) => ({
  backgroundColor: '#E3F2FD',
  color: '#1976D2',
  padding: theme.spacing(1, 2),
  borderRadius: 20,
  display: 'flex',
  alignItems: 'center',
  gap: theme.spacing(1),
  fontSize: '0.875rem',
  fontWeight: 500,
}))

const StyledTable = styled(Table)(({ theme }) => ({
  '& .MuiTableCell-head': {
    backgroundColor: '#F5F5F5',
    fontWeight: 600,
    color: '#333',
    borderBottom: '2px solid #E0E0E0',
    position: 'sticky',
    top: 0,
    zIndex: 1,
  },
  '& .MuiTableCell-body': {
    borderBottom: '1px solid #E0E0E0',
    padding: theme.spacing(2),
  },
}))

const MemberAvatar = styled(Avatar)(({ theme }) => ({
  backgroundColor: '#00BCD4',
  width: 32,
  height: 32,
  fontSize: '0.875rem',
}))

const ActionButton = styled(Button)(({ theme, variant }) => ({
  textTransform: 'none',
  padding: theme.spacing(0.5, 1.5),
  borderRadius: 4,
  fontSize: '0.75rem',
  minWidth: 'auto',
  ...(variant === 'edit' && {
    backgroundColor: '#E3F2FD',
    color: '#1976D2',
    '&:hover': {
      backgroundColor: '#BBDEFB',
    },
  }),
  ...(variant === 'delete' && {
    backgroundColor: '#FFEBEE',
    color: '#D32F2F',
    '&:hover': {
      backgroundColor: '#FFCDD2',
    },
  }),
}))

const Footer = styled(Box)(({ theme }) => ({
  borderTop: '1px solid #E0E0E0',
  margin: theme.spacing(0, -4, -4, -4),
  padding: theme.spacing(3, 4),
  display: 'flex',
  justifyContent: 'flex-start',
  gap: theme.spacing(2),
}))

const FooterButton = styled(Button)(({ theme, variant }) => ({
  textTransform: 'none',
  padding: theme.spacing(1.5, 3),
  borderRadius: 8,
  fontWeight: 500,
  minWidth: 100,
  ...(variant === 'primary' && {
    backgroundColor: '#051737',
    color: 'white',
    '&:hover': {
      backgroundColor: '#0a2a5a',
    },
  }),
  ...(variant === 'secondary' && {
    backgroundColor: 'white',
    color: '#1976D2',
    border: '1px solid #1976D2',
    '&:hover': {
      backgroundColor: '#F5F5F5',
    },
  }),
}))

const GroupVisitModal = ({
  isOpen,
  onClose,
  onGroupDataSubmit,
  groupName = 'Gopi Krishna',
  selectedBranch = null,
  bookVisitData = null,
}) => {
  const auth = useContext(AuthContext)

  // Create dynamic group name from bookVisitData
  const dynamicGroupName = bookVisitData
    ? `${bookVisitData.first_name || ''} ${bookVisitData.last_name || ''}`.trim() ||
      'Group Visit'
    : groupName

  // Debug auth context values
  console.log('=== GroupVisitModal Auth Debug ===')
  console.log('auth.org_id:', auth.org_id)
  console.log('auth.branch_id:', auth.branch_id)
  console.log('selectedBranch:', selectedBranch)
  console.log('bookVisitData:', bookVisitData)
  console.log('dynamicGroupName:', dynamicGroupName)
  console.log('=== End Auth Debug ===')
  const [members, setMembers] = useState([])
  const [editingMember, setEditingMember] = useState(null)
  const [uploadedImagePath, setUploadedImagePath] = useState('')
  const [isUploadComplete, setIsUploadComplete] = useState(true)
  const [isUploading, setIsUploading] = useState(false)

  // Get country codes from API
  const { data: countrycodesData } = useQuery({
    queryFn: () => listOfCountriesExt(),
  })

  // Ensure countrycodes is always an array
  const countrycodes = Array.isArray(countrycodesData)
    ? countrycodesData
    : Array.isArray(countrycodesData?.data)
      ? countrycodesData.data
      : []

  // Upload Image Mutation
  const uploadImageMutation = useMutation({
    mutationFn: (formData) => uploadImage(formData),
    onSuccess: (data) => {
      console.log('Image uploaded successfully:', data)
      setUploadedImagePath(data.uploadedImagePath)
      toast.success('Image uploaded successfully!')
      // Enable the Add Group Member button after successful upload and toast
      setTimeout(() => {
        setIsUploadComplete(true)
      }, 3000) // Wait for toast to disappear (typically 3 seconds)
    },
    onError: (error) => {
      console.error('Image upload failed:', error)
      toast.error('Image upload failed: ' + error.message)
      // Enable the button even on error
      setIsUploadComplete(true)
    },
  })
  const getFileNameFromPath = (path) => {
    if (!path || typeof path !== 'string') return ''
    const parts = path.split('/')
    return parts[parts.length - 1]
  }
  const [formData, setFormData] = useState({
    memberName: '',
    email: '',
    roleName: '',
    phoneNumber: '',
    countryCode: '', // No default country code
    idProof: null,
  })

  const [fieldErrors, setFieldErrors] = useState({
    memberName: '',
    email: '',
    roleName: '',
    phoneNumber: '',
  })

  const onlyDigits = /^\d+$/

  const isLikelyEmail = (val) =>
    val && typeof val === 'string' && val.includes('@') && !onlyDigits.test(val)

  const handleInputChange = (field) => (event) => {
    let value = event.target.value

    // For phone number field, only allow numeric characters
    if (field === 'phoneNumber') {
      value = value.replace(/[^0-9]/g, '')
    }

    setFormData({
      ...formData,
      [field]: value,
    })

    // Real-time validation for email only
    if (field === 'email') {
      // Real-time validation for email
      let error = ''
      if (value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        error = 'Please enter a valid email address'
      }
      setFieldErrors({
        ...fieldErrors,
        email: error,
      })
    } else {
      // Clear errors when other fields change
      setFieldErrors({
        ...fieldErrors,
        email: '',
      })
    }
  }

  const handleFileUpload = async (event) => {
    const file = event.target.files[0]
    if (file) {
      setIsUploading(true) // Start loading indicator
      setIsUploadComplete(false) // Disable Add Group Member button during upload
      setFormData({
        ...formData,
        idProof: file,
      })

      // Validate required fields
      const branchId = selectedBranch || auth.branch_id
      if (!auth.org_id || !branchId) {
        toast.error('Missing organization or branch information')
        console.error('Auth context missing:', {
          org_id: auth.org_id,
          branch_id: branchId,
        })
        return
      }

      // Check if file is an image
      const allowedImageTypes = ['image/jpeg', 'image/jpg', 'image/png']
      const isImage = allowedImageTypes.includes(file.type)

      if (isImage) {
        // Upload image using uploadImage endpoint
        console.log('🔄 Uploading image using uploadImage endpoint...')

        const formDataToUpload = new FormData()
        formDataToUpload.append('org_id', auth.org_id)
        formDataToUpload.append('branch_id', branchId)
        formDataToUpload.append('images', file)

        console.log('FormData entries for image upload:')
        for (let [key, value] of formDataToUpload.entries()) {
          console.log(key, ':', value)
        }

        try {
          const data = await uploadImage(formDataToUpload)
          console.log('✅ SUCCESS uploading image via uploadImage:', data)
          toast.success('Image uploaded successfully!')

          // Backend returns uploadedImagePaths array, take the first one
          const imagePath =
            data.uploadedImagePaths && data.uploadedImagePaths[0]
              ? data.uploadedImagePaths[0]
              : 'Image uploaded successfully'
          setUploadedImagePath(imagePath)
          setIsUploading(false) // Stop loading indicator
          // Enable the Add Group Member button after successful upload and toast
          setTimeout(() => {
            setIsUploadComplete(true)
          }, 3000) // Wait for toast to disappear (typically 3 seconds)
          return
        } catch (err) {
          console.error('❌ Network error uploading image:', err)
          toast.error('Image upload failed: ' + err.message)
          setIsUploading(false) // Stop loading indicator
          // Enable the button even on error
          setIsUploadComplete(true)
        }
      } else {
        toast.error('Please select an image file (JPEG, JPG, PNG)')
      }
    }
  }

  const handleAddMember = () => {
    console.log('🔍 Adding member with data:', formData)

    // Validate required fields
    if (!formData.memberName) {
      toast.error('Member name is required')
      return
    }
    if (!formData.roleName) {
      toast.error('Role name is required')
      return
    }
    // Check if either email or phone is provided (allows both)
    if (!formData.email && !formData.phoneNumber) {
      toast.error('Either email or phone number is required')
      return
    }

    console.log(
      '✅ Validation passed - email:',
      formData.email,
      'phone:',
      formData.phoneNumber,
    )

    // Validate email format if provided
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      toast.error('Please enter a valid email address')
      return
    }

    // Validate phone number format only if phone is provided
    if (formData.phoneNumber) {
      const phoneRegex = /^[0-9]{7,16}$/
      if (!phoneRegex.test(formData.phoneNumber)) {
        toast.error('Phone number must be between 7 and 16 digits')
        return
      }

      // Check if phone number starts with 0
      // if (formData.phoneNumber.startsWith('0')) {
      //   toast.error('Phone number cannot start with 0')
      //   return
      // }

      // Validate country code is required when phone is provided
      if (!formData.countryCode) {
        toast.error('Country code is required when phone number is provided')
        return
      }
    }

    // Validate ID proof is required
    if (!formData.idProof) {
      toast.error('ID proof upload is required')
      return
    }

    if (
      formData.memberName &&
      formData.roleName &&
      (formData.email || formData.phoneNumber)
    ) {
      const newMember = {
        id: Date.now(),
        name: formData.memberName,
        email: formData.email,
        role: formData.roleName,
        phone: formData.phoneNumber,
        countryCode: formData.countryCode, // Include country code
        idProof:
          uploadedImagePath ||
          (formData.idProof ? formData.idProof.name : null),
        addedDate: new Date().toLocaleString(),
        memberNumber: members.length + 1,
      }
      setMembers([...members, newMember])
      setFormData({
        memberName: '',
        email: '',
        roleName: '',
        phoneNumber: '',
        countryCode: '', // Reset country code
        idProof: null,
      })
      setUploadedImagePath('') // Reset uploaded image path
    }
  }

  const handleEditMember = (member) => {
    setEditingMember(member)
    setFormData({
      memberName: member.name,
      email: member.email,
      roleName: member.role,
      phoneNumber: member.phone,
      countryCode: member.countryCode || '', // Keep existing country code or empty
      // Pre-fill with existing file name so user can see current attachment
      idProof: member.idProof
        ? { name: getFileNameFromPath(member.idProof) }
        : null,
    })
    // Preserve existing uploaded path so it remains unless changed
    setUploadedImagePath(member.idProof || '')

    // Remove the member from the display temporarily
    setMembers((prevMembers) => prevMembers.filter((m) => m.id !== member.id))
  }

  const handleUpdateMember = () => {
    // Validate required fields
    if (!formData.memberName) {
      toast.error('Member name is required')
      return
    }
    if (!formData.roleName) {
      toast.error('Role name is required')
      return
    }
    // Check if either email or phone is provided
    if (!formData.email && !formData.phoneNumber) {
      toast.error('Either email or phone number is required')
      return
    }

    // Validate email format if provided
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      toast.error('Please enter a valid email address')
      return
    }

    // Validate phone number format only if phone is provided
    if (formData.phoneNumber) {
      const phoneRegex = /^[0-9]{7,16}$/
      if (!phoneRegex.test(formData.phoneNumber)) {
        toast.error('Phone number must be between 7 and 16 digits')
        return
      }

      // Check if phone number starts with 0
      // if (formData.phoneNumber.startsWith('0')) {
      //   toast.error('Phone number cannot start with 0')
      //   return
      // }

      // Validate country code is required when phone is provided
      if (!formData.countryCode) {
        toast.error('Country code is required when phone number is provided')
        return
      }
    }

    // Validate ID proof is required
    if (!formData.idProof) {
      toast.error('ID proof upload is required')
      return
    }

    if (
      formData.memberName &&
      formData.roleName &&
      (formData.email || formData.phoneNumber)
    ) {
      // Create updated member with same ID and add it back to the list
      const updatedMember = {
        id: editingMember.id, // Keep the same ID
        name: formData.memberName,
        email: formData.email,
        role: formData.roleName,
        phone: formData.phoneNumber,
        // If phone is empty on update, ignore country code
        countryCode: formData.phoneNumber ? formData.countryCode : '',
        idProof: uploadedImagePath || editingMember.idProof, // Keep existing ID proof if no new one uploaded
        addedDate: new Date().toLocaleString(),
        memberNumber: editingMember.memberNumber, // Keep the same member number
      }

      // Add the updated member back to the list at the first position
      setMembers((prevMembers) => [updatedMember, ...prevMembers])

      setEditingMember(null)
      setFormData({
        memberName: '',
        email: '',
        roleName: '',
        phoneNumber: '',
        countryCode: '', // Reset country code
        idProof: null,
      })
      setUploadedImagePath('')
      toast.success('Member updated successfully!')
    }
  }

  const handleCancelEdit = () => {
    // Add the member back to the list if canceling edit
    if (editingMember) {
      setMembers((prevMembers) => [...prevMembers, editingMember])
    }

    setEditingMember(null)
    setFormData({
      memberName: '',
      email: '',
      roleName: '',
      phoneNumber: '',
      countryCode: '+91', // Reset country code
      idProof: null,
    })
    setUploadedImagePath('')
  }

  const handleRemoveMember = (memberId) => {
    setMembers(members.filter((member) => member.id !== memberId))
    // Reorder member numbers
    setMembers((prev) =>
      prev.map((member, index) => ({
        ...member,
        memberNumber: index + 1,
      })),
    )
  }

  const handleSubmit = () => {
    // Transform members data to match API structure
    const grp_details = members.map((member) => ({
      grp_id: String(member.id), // Convert to string
      grp_name: member.name,
      grp_user_email: isLikelyEmail(member.email) ? member.email : '',
      grp_user_id_proof: member.idProof || '',
      grp_user_name: member.name,
      grp_user_phno: member.phone, // Use the phone number directly
      grp_user_role: member.role,
      grp_user_role_name: member.role,
      grp_user_unique_id: String(member.id), // Convert to string
      grp_user_phext: member.countryCode || '', // Use country code from member data
    }))

    // Pass group data back to parent component
    if (onGroupDataSubmit) {
      const groupData = {
        grp_details: grp_details,
      }
      console.log('Group data submitted:', groupData)
      onGroupDataSubmit(groupData)
    } else {
      console.error('onGroupDataSubmit callback not provided')
      onClose()
    }
  }

  const handleCancel = () => {
    // Clear all members from the table
    setMembers([])
    setEditingMember(null)
    setFormData({
      memberName: '',
      email: '',
      roleName: '',
      phoneNumber: '',
      countryCode: '',
      idProof: null,
    })
    setFieldErrors({
      memberName: '',
      email: '',
      roleName: '',
      phoneNumber: '',
    })
    setUploadedImagePath('')
    setIsUploadComplete(true) // Reset upload state
    // Close the modal
    onClose()
  }

  return (
    <StyledModal
      open={isOpen}
      onClose={(event, reason) => {
        // Prevent closing when clicking outside the modal
        if (reason !== 'backdropClick') {
          onClose()
        }
      }}
    >
      <ModalContent>
        {/* Header Section */}
        <HeaderSection>
          <HeaderLeft>
            <HeaderIcon>
              <GroupIcon />
            </HeaderIcon>
            <Box>
              <Typography variant="h5" fontWeight="bold" color="#333">
                Group Visit Management
              </Typography>
              <Typography variant="body2" color="#666">
                Manage multiple visitors for group entries.
              </Typography>
            </Box>
          </HeaderLeft>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <MemberCounter>
              <BusinessIcon fontSize="small" />
              {members.length} Members
            </MemberCounter>
            <IconButton
              onClick={onClose}
              sx={{
                color: '#666',
                '&:hover': {
                  backgroundColor: '#f5f5f5',
                },
              }}
            >
              <CloseIcon />
            </IconButton>
          </Box>
        </HeaderSection>

        {/* Form Section */}
        <FormSection>
          {editingMember && (
            <Box
              sx={{
                mb: 2,
                p: 2,
                bgcolor: '#E3F2FD',
                borderRadius: 1,
                border: '1px solid #BBDEFB',
              }}
            >
              <Typography
                variant="subtitle2"
                color="#1976D2"
                sx={{ display: 'flex', alignItems: 'center', gap: 1 }}
              >
                <EditIcon fontSize="small" />
                Editing: {editingMember.name} (Member #
                {editingMember.memberNumber})
              </Typography>
            </Box>
          )}
          <FormGrid>
            <TextField
              label="Member Name*"
              value={formData.memberName}
              onChange={handleInputChange('memberName')}
              fullWidth
              size="small"
            />
            <TextField
              label="Email"
              value={formData.email}
              onChange={handleInputChange('email')}
              fullWidth
              size="small"
              placeholder="Enter email address"
              error={!!fieldErrors.email}
              helperText={fieldErrors.email}
            />
            <FormControl fullWidth size="small">
              <InputLabel>Role Name*</InputLabel>
              <Select
                value={formData.roleName}
                onChange={handleInputChange('roleName')}
                label="Role Name*"
              >
                <MenuItem value="visitor">Visitor</MenuItem>
                <MenuItem value="contractor">Contractor</MenuItem>
                <MenuItem value="subcontractor">Sub Contractor</MenuItem>
                <MenuItem value="customer">Customer</MenuItem>
                <MenuItem value="permanentstaff">Permanent Staff</MenuItem>
              </Select>
            </FormControl>
            <FormControl fullWidth size="small">
              <InputLabel>Country Code</InputLabel>
              <Select
                value={formData.countryCode}
                onChange={handleInputChange('countryCode')}
                label="Country Code"
              >
                {countrycodes?.map((country) => (
                  <MenuItem key={country.code} value={country.code}>
                    {country.country} ({country.code})
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <TextField
              label="Phone Number"
              value={formData.phoneNumber}
              onChange={handleInputChange('phoneNumber')}
              fullWidth
              size="small"
              placeholder="Enter phone number"
              type="tel"
              inputProps={{
                pattern: '[0-9]*',
                inputMode: 'numeric',
              }}
            />
          </FormGrid>

          <Box sx={{ mb: 3 }}>
            <input
              accept="image/jpeg,image/jpg,image/png"
              style={{ display: 'none' }}
              id="id-proof-upload"
              type="file"
              onChange={handleFileUpload}
            />
            <label htmlFor="id-proof-upload">
              <UploadButton
                component="span"
                startIcon={<UploadIcon />}
                fullWidth
                disabled={uploadImageMutation.isPending}
              >
                {uploadImageMutation.isPending
                  ? 'Uploading...'
                  : 'Upload ID Proof (Images Only) *'}
              </UploadButton>
            </label>
            {formData.idProof ? (
              <Typography variant="caption" color="success.main" sx={{ ml: 1 }}>
                {formData.idProof.name}
              </Typography>
            ) : uploadedImagePath ? (
              <Typography variant="caption" color="success.main" sx={{ ml: 1 }}>
                {getFileNameFromPath(uploadedImagePath)}
              </Typography>
            ) : null}
            <Typography
              variant="caption"
              color="text.secondary"
              sx={{ mt: 1, display: 'block' }}
            >
              Accepted formats: JPEG, JPG, PNG
            </Typography>
            <ProgressLine isActive={isUploading} color="primary" height={4} />
          </Box>

          <Box sx={{ display: 'flex', gap: 2 }}>
            <AddMemberButton
              onClick={editingMember ? handleUpdateMember : handleAddMember}
              startIcon={editingMember ? <EditIcon /> : <AddIcon />}
              fullWidth
              disabled={!isUploadComplete || uploadImageMutation.isPending}
            >
              {editingMember ? 'Update Member' : 'Add Group Member'}
            </AddMemberButton>
            {editingMember && (
              <Button
                variant="outlined"
                onClick={handleCancelEdit}
                sx={{
                  borderColor: '#666',
                  color: '#666',
                  textTransform: 'none',
                  '&:hover': {
                    borderColor: '#333',
                    color: '#333',
                  },
                }}
              >
                Cancel
              </Button>
            )}
          </Box>
        </FormSection>

        {/* Members Display Section */}
        {members.length === 0 ? (
          <EmptyState>
            <EmptyIcon>
              <GroupIcon sx={{ fontSize: 40 }} />
            </EmptyIcon>
            <Typography variant="h6" gutterBottom>
              No group members added yet.
            </Typography>
            <Typography variant="body2" color="#666">
              Start building your group by adding the first member.
            </Typography>
            {/* <Box sx={{ mt: 2 }}>
              <AddMemberButton
                onClick={handleAddMember}
                startIcon={<AddIcon />}
              >
                Add First Member
              </AddMemberButton>
            </Box> */}
          </EmptyState>
        ) : (
          <GroupSection>
            <GroupHeader>
              <Box>
                <GroupTitle>{dynamicGroupName}</GroupTitle>
                <GroupSubtitle>Manage your group visit members.</GroupSubtitle>
              </Box>
              <GroupCounter>
                <GroupIcon fontSize="small" />
                {members.length} Total
              </GroupCounter>
            </GroupHeader>

            {/* Members Table */}
            <Box
              sx={{
                border: '1px solid #E0E0E0',
                borderRadius: '4px',
                backgroundColor: 'white',
                maxHeight: '300px',
                overflow: 'auto',
              }}
            >
              <StyledTable>
                <TableHead>
                  <TableRow>
                    <TableCell>Member Details</TableCell>
                    <TableCell>Contact Information</TableCell>
                    <TableCell>ID Proof</TableCell>
                    <TableCell>Added</TableCell>
                    <TableCell>Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {members.map((member) => (
                    <TableRow key={member.id}>
                      <TableCell>
                        <Box
                          sx={{ display: 'flex', alignItems: 'center', gap: 2 }}
                        >
                          <MemberAvatar>
                            {member.name.charAt(0).toUpperCase()}
                          </MemberAvatar>
                          <Box>
                            <Typography variant="subtitle2" fontWeight="500">
                              {member.name}
                            </Typography>
                            <Typography variant="caption" color="#666">
                              Member #{member.memberNumber}
                            </Typography>
                          </Box>
                        </Box>
                      </TableCell>
                      <TableCell>
                        <Box>
                          <Typography variant="body2" color="#666">
                            {member.email}
                          </Typography>
                          <Typography variant="body2" color="#666">
                            {member.phone}
                          </Typography>
                        </Box>
                      </TableCell>
                      <TableCell>
                        {member.idProof ? (
                          <Button
                            startIcon={<ViewIcon />}
                            size="small"
                            sx={{ color: '#1976D2', textTransform: 'none' }}
                            onClick={() => {
                              // Check if we have a valid file path
                              if (
                                !member.idProof ||
                                member.idProof ===
                                  'PDF uploaded successfully' ||
                                member.idProof === 'Image uploaded successfully'
                              ) {
                                toast.error(
                                  'File path not available. Please re-upload the file.',
                                )
                                return
                              }

                              // Handle both image and PDF URLs properly
                              let fileUrl = member.idProof

                              console.log(
                                '🔍 Original idProof:',
                                member.idProof,
                              )

                              // Fix S3 URLs for images - handle various S3 URL formats
                              if (member.idProof.includes('visiqbucket.s3.')) {
                                // Handle different S3 URL formats
                                if (
                                  member.idProof.includes(
                                    'https://visiqbucket.s3.',
                                  )
                                ) {
                                  // Already has https, just fix the region if needed
                                  fileUrl = member.idProof.replace(
                                    'visiqbucket.s3.',
                                    'visiqbucket.s3.us-east-1.',
                                  )
                                } else {
                                  // Add https and fix region
                                  fileUrl = `https://visiqbucket.s3.us-east-1.${member.idProof.split('visiqbucket.s3.')[1]}`
                                }
                              }
                              // Handle AWS S3 URLs with different regions
                              else if (
                                member.idProof.includes('amazonaws.com')
                              ) {
                                // Ensure proper S3 URL format
                                if (!member.idProof.startsWith('https://')) {
                                  fileUrl = `https://${member.idProof}`
                                } else {
                                  fileUrl = member.idProof
                                }
                              }
                              // Handle PDFs uploaded through ndaUpload API
                              else if (
                                member.idProof.toLowerCase().includes('.pdf') &&
                                !member.idProof.startsWith('http')
                              ) {
                                // PDFs might be stored in a different location
                                fileUrl = `${baseUrl}/nda/${member.idProof}`
                              }
                              // Handle images uploaded through uploadImage API
                              else if (
                                (member.idProof
                                  .toLowerCase()
                                  .includes('.jpg') ||
                                  member.idProof
                                    .toLowerCase()
                                    .includes('.jpeg') ||
                                  member.idProof
                                    .toLowerCase()
                                    .includes('.png') ||
                                  member.idProof
                                    .toLowerCase()
                                    .includes('.gif')) &&
                                !member.idProof.startsWith('http')
                              ) {
                                // Images uploaded through uploadImage API
                                fileUrl = `${baseUrl}/uploads/${member.idProof}`
                              }
                              // Handle other files that might not have full URLs
                              else if (!member.idProof.startsWith('http')) {
                                // Try different possible paths for new accounts
                                const possiblePaths = [
                                  `${baseUrl}/uploads/${member.idProof}`,
                                  `${baseUrl}/images/${member.idProof}`,
                                  `${baseUrl}/files/${member.idProof}`,
                                  `${baseUrl}/nda/${member.idProof}`,
                                ]

                                // For now, use the first path, but we could implement a fallback mechanism
                                fileUrl = possiblePaths[0]
                              }

                              console.log('🔍 Final fileUrl:', fileUrl)

                              // Add error handling for the window.open
                              try {
                                const newWindow = window.open(
                                  fileUrl,
                                  '_blank',
                                  'width=800,height=600,scrollbars=yes,resizable=yes',
                                )

                                if (!newWindow) {
                                  toast.error(
                                    'Popup blocked. Please allow popups for this site.',
                                  )
                                }
                              } catch (error) {
                                console.error('Error opening file:', error)
                                toast.error(
                                  'Failed to open file. Please check the file path.',
                                )
                              }
                            }}
                          >
                            View ID proof
                          </Button>
                        ) : (
                          <Typography variant="body2" color="#666">
                            No ID proof
                          </Typography>
                        )}
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2" color="#666">
                          {member.addedDate}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', gap: 1 }}>
                          <ActionButton
                            variant="edit"
                            startIcon={<EditIcon />}
                            size="small"
                            onClick={() => handleEditMember(member)}
                            disabled={editingMember !== null && editingMember.id !== member.id}
                          >
                            Edit
                          </ActionButton>
                          <ActionButton
                            variant="delete"
                            startIcon={<DeleteIcon />}
                            size="small"
                            onClick={() => handleRemoveMember(member.id)}
                            disabled={editingMember !== null}
                          >
                            Delete
                          </ActionButton>
                        </Box>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </StyledTable>
            </Box>
          </GroupSection>
        )}

        {/* Footer */}
        <Footer>
          <FooterButton variant="primary" onClick={handleSubmit}>
            Submit
          </FooterButton>
          <FooterButton variant="secondary" onClick={handleCancel}>
            Cancel
          </FooterButton>
        </Footer>
      </ModalContent>
    </StyledModal>
  )
}

export default GroupVisitModal
