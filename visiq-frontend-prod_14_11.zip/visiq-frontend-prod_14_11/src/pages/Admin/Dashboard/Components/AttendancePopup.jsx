import React, { useState, useEffect } from 'react'
import {
  Modal,
  Box,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Typography,
  Avatar,
  Tooltip,
} from '@mui/material'
import ExpandMoreIcon from '@mui/icons-material/ExpandMore'
import PrimaryBtn from '../../../../shared/Buttons/PrimaryBtn'
import { entry, exit, id } from '../../../../assets'
import EmailIcon from '@mui/icons-material/Email'
import PhoneIcon from '@mui/icons-material/Phone'
import moment from 'moment/moment'
import BusinessIcon from '@mui/icons-material/Business'
import PersonIcon from '@mui/icons-material/Person'

const AttendancePopup = ({ user }) => {
  const [attendanceData, setAttendanceData] = useState({})
  const [openAttendanceModal, setOpenAttendanceModal] = useState(false)
  const [openVisitorModal, setOpenVisitorModal] = useState(false)
  const [status] = useState(user.userDetails[0].isEntry ? 'In' : 'Out')
  const isLikelyEmail = (val) =>
    !!val && typeof val === 'string' && val.includes('@')
  useEffect(() => {
    // Try to get attendance data from multiple sources
    let attendanceData =
      user?.attendanceData || user?.userDetails?.[0]?.attendanceData || []

    console.log('🔍 AttendancePopup - user object:', user)
    console.log('🔍 AttendancePopup - attendanceData:', attendanceData)

    if (user && attendanceData && attendanceData.length > 0) {
      const formattedData = attendanceData.reduce((acc, record) => {
        // Get the date from entry_time or exit_time, with proper validation
        let dateString = null
        if (record?.entry_time && record.entry_time !== '-') {
          dateString = record.entry_time.split(' ')[0]
        } else if (record?.exit_time && record.exit_time !== '-') {
          dateString = record.exit_time.split(' ')[0]
        }

        // Try different date formats and validate before formatting
        let date = 'Today'
        if (dateString) {
          // Try parsing with different formats (including more variations)
          const momentDate = moment(
            dateString,
            [
              'YYYY-MM-DD',
              'DD-MM-YYYY',
              'MM/DD/YYYY',
              'YYYY/MM/DD',
              'DD/MM/YYYY',
              'MM-DD-YYYY',
              'YYYY-MM-DD HH:mm:ss',
              'DD-MM-YYYY HH:mm:ss',
            ],
            true,
          )
          if (momentDate.isValid()) {
            date = momentDate.format('DD/MM/YY')
          } else {
            // Try parsing without strict format matching as fallback
            const looseMomentDate = moment(dateString)
            if (looseMomentDate.isValid()) {
              date = looseMomentDate.format('DD/MM/YY')
            } else {
              // If all parsing fails, try to extract date manually from the string
              const dateMatch = dateString.match(/(\d{1,2})[-/](\d{1,2})[-/](\d{4})/)
              if (dateMatch) {
                const [, day, month, year] = dateMatch
                const parsedDate = moment(`${year}-${month}-${day}`, 'YYYY-MM-DD')
                if (parsedDate.isValid()) {
                  date = parsedDate.format('DD/MM/YY')
                }
              }
            }
          }
        }

        if (!acc[date]) {
          acc[date] = []
        }
        acc[date].push({
          entry_time:
            record.entry_time !== '-' ? record.entry_time.split(' ')[1] : '--',
          exit_time:
            record.exit_time !== '-' ? record.exit_time.split(' ')[1] : '--',
        })
        return acc
      }, {})
      setAttendanceData(formattedData)
    }
  }, [user])

  const handleOpenAttendance = () => setOpenAttendanceModal(true)
  const handleCloseAttendance = () => setOpenAttendanceModal(false)

  const handleOpenVisitor = () => setOpenVisitorModal(true)
  const handleCloseVisitor = () => setOpenVisitorModal(false)

  return (
    <div className="w-full">
      <div className="mb-4">
        <PrimaryBtn
          text={'View Attendance'}
          handleClick={handleOpenAttendance}
          fullWidth
        />
      </div>
      <div className="mb-4 text-center">
        <button
          className="text-blue-500 hover:underline"
          onClick={handleOpenVisitor}
        >
          View Visitor Details
        </button>
      </div>

      {/* Attendance Modal */}
      <Modal
        open={openAttendanceModal}
        onClose={handleCloseAttendance}
        aria-labelledby="attendance-modal-title"
        aria-describedby="attendance-modal-description"
      >
        <Box
          sx={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: 600, // Increased width
            bgcolor: 'background.paper',
            border: '0px solid #000',
            boxShadow: 24,
            p: 4,
            outline: 'none',
            borderRadius: 0,
            paddingY: 10,
            maxHeight: 500,
            overflowY: 'auto',
          }}
        >
          <Typography
            variant="h5"
            component="h2"
            id="attendance-modal-title"
            className="absolute top-6 left-1/2 transform -translate-x-1/2 text-center "
            sx={{ fontWeight: 'bold' }}
          >
            Attendance Data
          </Typography>
          {Object.entries(attendanceData).map(([date, records], index) => (
            <Accordion key={date}>
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls={`panel${index}-content`}
                id={`panel${index}-header`}
              >
                <Typography
                  variant="body1"
                  component="span"
                  sx={{ fontWeight: 'bold' }}
                >
                  {date}
                </Typography>
              </AccordionSummary>

              <AccordionDetails>
                {records.map((record, idx) => (
                  <div key={idx} className="flex justify-between my-2">
                    <p className="flex gap-3 items-center">
                      <img src={entry} alt="entry" />
                      {record.entry_time}
                    </p>
                    <p className="flex gap-3 items-center">
                      {record.exit_time === '23:59:59' ? (
                        <span className="text-xs text-gray-500">
                          Auto Checkout
                        </span>
                      ) : (
                        <></>
                      )}
                      <img src={exit} alt="exit" />
                      {record.exit_time !== 'Missing'
                        ? record.exit_time
                        : 'Missing'}
                    </p>
                  </div>
                ))}
              </AccordionDetails>
            </Accordion>
          ))}
          <button
            className="btn btn-sm btn-circle btn-ghost absolute right-2 top-2"
            onClick={handleCloseAttendance}
          >
            ✕
          </button>
        </Box>
      </Modal>

      {/* Visitor Details Modal */}
      <Modal
        open={openVisitorModal}
        onClose={handleCloseVisitor}
        aria-labelledby="visitor-modal-title"
        aria-describedby="visitor-modal-description"
      >
        <Box
          sx={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: 350,
            bgcolor: 'background.paper',
            border: '0px solid #000',
            boxShadow: 24,
            outline: 'none',
            borderRadius: 0,
            paddingY: 10,
            overflowY: 'auto',
            backgroundImage: `url(${id})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        >
          {user && user.userDetails && user.userDetails.length > 0 && (
            <div className="flex flex-col items-center">
              <Avatar
                alt={user.userDetails[0].first_name}
                src={user.userDetails[0].recent_captured_pic}
                sx={{ width: 120, height: 120, marginBottom: 2 }} // Increased size
              />
              <Typography
                variant="p"
                component="h3"
                sx={{
                  textAlign: 'center',
                  mb: 2,
                  color:
                    user === 'In'
                      ? 'green'
                      : status === 'Out'
                        ? 'red'
                        : '#ff6a00',
                }}
                border={
                  status === 'In'
                    ? '1px solid green'
                    : status === 'Out'
                      ? '1px solid red'
                      : '1px solid orange'
                }
                bgcolor={
                  status === 'In'
                    ? '#beedad'
                    : status === 'Out'
                      ? '#ffd6d6'
                      : '#ffe4d6'
                }
                px={2}
                borderRadius={100}
              >
                {status}
              </Typography>
              <Tooltip
                title={`${user.userDetails[0].first_name} ${user.userDetails[0].last_name}`}
              >
                <Typography variant="h6">
                  {`${user.userDetails[0].first_name} ${user.userDetails[0].last_name}`
                    .length > 20
                    ? `${user.userDetails[0].first_name} ${user.userDetails[0].last_name}`.substring(
                        0,
                        20,
                      ) + '...'
                    : `${user.userDetails[0].first_name} ${user.userDetails[0].last_name}`}
                </Typography>
              </Tooltip>
              <div className="mt-2 text-center">
                <div className="flex items-center justify-start mb-2">
                  <BusinessIcon sx={{ marginRight: 1 }} fontSize="12px" />
                  <p className="text-md">
                    {user.userDetails[0].visitor_company_name}
                  </p>
                </div>
                  <div className="flex items-center justify-start mb-2">
                    <EmailIcon sx={{ marginRight: 1 }} fontSize="12px" />
                  <p className="text-md">
                    {(() => {
                      const email = user.userDetails[0].email || ''
                      const isValidEmail =
                        email &&
                        email.trim() !== '' &&
                        email.includes('@') &&
                        !email.includes('XXXXXXXXXX') &&
                        email !== 'no-email@example.com'
                      return isValidEmail ? email : 'N/A'
                    })()}
                  </p>
                  </div>
                <div className="flex items-center justify-start">
                  <PhoneIcon sx={{ marginRight: 1 }} fontSize="12px" />
                  <p className="text-md">
                    {(() => {
                      const phoneNumber =
                        user.userDetails[0].ph_no || user.userDetails[0].phone || ''
                      const countryCode = user.userDetails[0].ph_ext || ''
                      const isPhoneValid =
                        phoneNumber &&
                        phoneNumber.trim() !== '' &&
                        !phoneNumber.includes('XXXXXXXXXX')
                      if (!isPhoneValid) {
                        return 'N/A'
                      }
                      const formattedCountryCode = countryCode
                        ? countryCode.startsWith('+')
                          ? countryCode
                          : `+${countryCode}`
                        : ''
                      return formattedCountryCode && phoneNumber
                        ? `${formattedCountryCode}-${phoneNumber}`
                        : phoneNumber
                    })()}
                  </p>
                </div>
                <div className="flex items-center justify-start">
                  <PersonIcon sx={{ marginRight: 1 }} fontSize="12px" />
                  <p className="text-md">{user.userDetails[0].role_name}</p>
                </div>

                {/* Group Visitor Indicator - Enhanced Debug */}
                {(() => {
                  const userData = user.userDetails[0]
                  const isGroupVisitor =
                    userData.is_group_visitor ||
                    userData.group_visitor ||
                    userData.visitor_type === 'group' ||
                    userData.visitor_type === 'group_visitor' ||
                    userData.grp_book_bool ||
                    userData.isGroupMember ||
                    userData.grp_id ||
                    userData.grp_user_unique_id

                  console.log('🔍 Group Visitor Check:', {
                    isGroupVisitor,
                    is_group_visitor: userData.is_group_visitor,
                    group_visitor: userData.group_visitor,
                    visitor_type: userData.visitor_type,
                    grp_book_bool: userData.grp_book_bool,
                    isGroupMember: userData.isGroupMember,
                    grp_id: userData.grp_id,
                    grp_user_unique_id: userData.grp_user_unique_id,
                    allKeys: Object.keys(userData),
                  })

                  return isGroupVisitor
                })() && (
                  <div className="mt-2 text-center">
                    <div
                      style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '4px',
                        padding: '3px 8px',
                        borderRadius: '8px',
                        backgroundColor: '#E3F2FD',
                        border: '1px solid #2196F3',
                        fontSize: '0.6rem',
                        fontWeight: 'bold',
                        color: '#1976D2',
                        boxShadow: '0 1px 3px rgba(33, 150, 243, 0.3)',
                      }}
                    >
                      👥 Group Visitor
                    </div>
                  </div>
                )}

                {/* Debug: Log all available fields to console */}
                {console.log('🔍 Full user data:', user.userDetails[0])}
                {console.log(
                  '🔍 visitor_type:',
                  user.userDetails[0].visitor_type,
                )}
                {console.log('🔍 All keys:', Object.keys(user.userDetails[0]))}
                {console.log('🔍 Group Visitor Debug:', {
                  // Check userDetails[0]
                  userDetails_visitor_type: user.userDetails[0].visitor_type,
                  userDetails_grp_user_unique_id:
                    user.userDetails[0].grp_user_unique_id,
                  userDetails_grp_id: user.userDetails[0].grp_id,
                  userDetails_isGroupMember: user.userDetails[0].isGroupMember,
                  userDetails_grp_book_bool: user.userDetails[0].grp_book_bool,
                  userDetails_group_visitor: user.userDetails[0].group_visitor,
                  userDetails_is_group_visitor:
                    user.userDetails[0].is_group_visitor,
                  // Check main user object
                  user_visitor_type: user.visitor_type,
                  user_grp_user_unique_id: user.grp_user_unique_id,
                  user_grp_id: user.grp_id,
                  user_isGroupMember: user.isGroupMember,
                  user_grp_book_bool: user.grp_book_bool,
                  user_group_visitor: user.group_visitor,
                  user_is_group_visitor: user.is_group_visitor,
                })}
              </div>
            </div>
          )}
          <button
            className="btn btn-sm btn-circle btn-ghost absolute right-2 top-2"
            onClick={handleCloseVisitor}
          >
            ✕
          </button>
        </Box>
      </Modal>
    </div>
  )
}

export default AttendancePopup
