// components/VisitorsPDF.jsx
import React from 'react'
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Image,
  Font,
} from '@react-pdf/renderer'
import { formatDate, formatTime } from '../../../../utils/dateFormat'

// Optional font registration
Font.register({
  family: 'Helvetica',
  fonts: [
    { src: 'https://fonts.gstatic.com/s/helvetica/Helvetica-Regular.ttf' },
  ],
})

// Removed pagination - rows will flow continuously across pages

const styles = StyleSheet.create({
  page: {
    padding: 40,
    fontSize: 10,
    fontFamily: 'Helvetica',
  },
  header: {
    marginBottom: 10,
    textAlign: 'center',
  },
  head: {
    marginBottom: 10,
    textAlign: 'left',
  },
  title: {
    fontSize: 18,
    marginBottom: 4,
    color: '#27ae60',
  },
  info: {
    marginBottom: 2,
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#27ae60',
    color: '#ffffff',
    padding: 4,
    alignItems: 'center',
    marginTop: 10,
  },
  tableRow: {
    flexDirection: 'row',
    borderBottomWidth: 0.5,
    borderBottomColor: '#eee',
    paddingVertical: 5,
    alignItems: 'center',
  },
  tableCell: {
    padding: 2,
    wordBreak: 'break-word',
    fontSize: 9,
  },
  column: {
    width: '5%', // Reduced for better fit
  },
  wideColumn: {
    width: '8%',
  },
  emailColumn: {
    width: '8%',
  },
  areaColumn: {
    width: '8%',
  },
  areaparmetedColumn: {
    width: '4%',
  },
  imageColumn: {
    width: '5%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  blacklistColumn: {
    width: '4%',
  },
  image: {
    width: 40,
    height: 40,
    borderRadius: 4,
  },
  footer: {
    textAlign: 'center',
    marginTop: 10,
    fontSize: 8,
    color: '#aaa',
  },
})

const VisitorsPDFDetailed = ({
  userData,
  data_of_visit,
  branch,
  name,
  report_name,
}) => {
  console.log('userData', userData)

  // Map raw visitor_type to display-friendly text
  const getVisitorTypeDisplay = (visitorType) => {
    if (!visitorType) {
      return 'Individual Visitor'
    }
    
    // Normalize to lowercase for case-insensitive comparison
    const normalized = String(visitorType).toLowerCase().trim()
    
    switch (normalized) {
      case 'group_visitor':
      case 'group':
        return 'Group Visitor'
      case 'main_visitor':
      case 'main':
        return 'Main Visitor'
      case 'individual_visitor':
      case 'individual':
        return 'Individual Visitor'
      case 'group_member':
      case 'member':
        return 'Group Member'
      default:
        // If it's a known format but doesn't match, try to format it
        if (normalized.includes('group')) {
          return 'Group Visitor'
        }
        if (normalized.includes('main')) {
          return 'Main Visitor'
        }
        if (normalized.includes('individual')) {
          return 'Individual Visitor'
        }
        return 'Individual Visitor'
    }
  }

  return (
    <Document>
      <Page style={styles.page} size="A2" wrap>
        {/* Fixed Header - appears on every page */}
        <View fixed>
          <View style={styles.header}>
            <Text style={styles.title}>{report_name || 'Visitor Report'}</Text>
          </View>
          <View style={styles.head}>
            <Text style={styles.info}>Admin: {String(name || 'N/A')}</Text>
            <Text style={styles.info}>
              Branch: {String(branch?.branch_name || 'N/A')}
            </Text>
            <Text style={styles.info}>
              Date:{' '}
              {data_of_visit && data_of_visit.from_date && data_of_visit.to_date
                ? `${formatDate(data_of_visit.from_date)} to ${formatDate(data_of_visit.to_date)}`
                : data_of_visit && data_of_visit.visit_date
                  ? formatDate(data_of_visit.visit_date)
                  : data_of_visit
                    ? formatDate(data_of_visit)
                    : 'All Time'}
            </Text>
          </View>

          {/* Table Header - fixed on every page */}
          <View style={styles.tableHeader}>
            {[
              { label: 'Name' },
              { label: 'Visitor Type' },
              { label: 'Category' },
              {
                label: 'Purpose of Visit',
                customStyle: styles.areaparmetedColumn,
              },
              { label: 'Area of Permit', customStyle: styles.areaColumn },
              { label: 'Asset' },
              { label: 'Phone Number', customStyle: styles.emailColumn },
              { label: 'Email', customStyle: styles.emailColumn },
              { label: 'Last Entry' },
              { label: 'Last Exit' },
              { label: 'Visitor Company Name' },
              { label: 'Access Reference Code' },
              { label: 'KYC Type' },
              { label: 'KYC ID' },
              { label: 'Entry Time' },
              { label: 'Exit Time' },
              { label: 'Blacklist', customStyle: styles.blacklistColumn },
              { label: 'Photo', customStyle: styles.imageColumn },
            ].map((col, i) => (
              <Text
                key={i}
                style={[styles.tableCell, col.customStyle || styles.column]}
              >
                {col.label}
              </Text>
            ))}
          </View>
        </View>

        {/* Data Rows - Continuous flow across pages */}
        {userData.map((user, index) => {
          // Debug: Log the visitor_type for each user
          console.log(
            `🔍 PDF User ${index} visitor_type:`,
            user.visitor_type,
            'Raw user data:',
            user,
          )

          return (
            <View key={index} style={styles.tableRow} wrap={false}>
              <Text style={[styles.tableCell, styles.column]}>
                {user.first_name || 'N/A'}
              </Text>
              <Text style={[styles.tableCell, styles.column]}>
                {getVisitorTypeDisplay(user.visitor_type)}
              </Text>
              <Text style={[styles.tableCell, styles.column]}>
                {user.role_name || 'N/A'}
              </Text>
              <Text style={[styles.tableCell, styles.column]}>
                {user.purpose_of_visit || 'N/A'}
              </Text>
              <Text style={[styles.tableCell, styles.areaColumn]}>
                {user.area_of_permit || 'N/A'}
              </Text>
              <Text style={[styles.tableCell, styles.column]}>
                {user.asset || 'N/A'}
              </Text>
              <Text style={[styles.tableCell, styles.emailColumn]}>
                {user.ph_no || 'N/A'}
              </Text>
              <Text style={[styles.tableCell, styles.emailColumn]}>
                {user.email || 'N/A'}
              </Text>
              <Text style={[styles.tableCell, styles.column]}>
                {formatDate(user.last_entry) || 'N/A'}
              </Text>
              <Text style={[styles.tableCell, styles.column]}>
                {formatDate(user.last_exit) || 'N/A'}
              </Text>
              <Text style={[styles.tableCell, styles.column]}>
                {user.visitor_company_name || 'N/A'}
              </Text>
              <Text style={[styles.tableCell, styles.column]}>
                {user.visitor_code || user.last_visited_code || 'N/A'}
              </Text>
              <Text style={[styles.tableCell, styles.column]}>
                {user.kyc_type || 'N/A'}
              </Text>
              <Text style={[styles.tableCell, styles.column]}>
                {user.kyc_id || 'N/A'}
              </Text>
              <Text style={[styles.tableCell, styles.column]}>
                {formatTime(user.entry_time) || 'N/A'}
              </Text>
              <Text style={[styles.tableCell, styles.column]}>
                {formatTime(user.exit_time) || 'N/A'}
              </Text>
              <Text style={[styles.tableCell, styles.blacklistColumn]}>
                {user.black_listed === true ||
                user.blacklisted === true ||
                user.blacklist_status === 'blacklisted' ||
                user.is_blacklisted === true ||
                user.status === 'Blacklisted'
                  ? 'Yes'
                  : 'No'}
              </Text>
              <View style={[styles.tableCell, styles.imageColumn]}>
                {user.photo ? (
                  <Image style={styles.image} src={user.photo} />
                ) : (
                  <Text>No Photo</Text>
                )}
              </View>
            </View>
          )
        })}
      </Page>
    </Document>
  )
}

export default VisitorsPDFDetailed
