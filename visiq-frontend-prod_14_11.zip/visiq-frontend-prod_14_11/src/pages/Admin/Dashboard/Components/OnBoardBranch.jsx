import React, { useCallback, useContext, useState } from 'react'
import PrimaryBtn from '../../../../shared/Buttons/PrimaryBtn'
import * as yup from 'yup'
import { Form, Formik } from 'formik'
import FormikTextField from '../../../../lib/Formik/FormikTextfield'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { onBoardBranches } from '../../../../services/adminService'
import { AuthContext } from '../../../../context/AuthContext'
import FormikSelect from '../../../../lib/Formik/FormikSelect'
import { Box, Modal } from '@mui/material'
import { styles } from '../../../../constants/styes'
import toast from 'react-hot-toast'

const OnBoardBranch = (props) => {
  const { branches } = props
  const [isOpen, setIsOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false) // Add a state to track submission
  const queryClient = useQueryClient()
  const auth = useContext(AuthContext)

  const mutate = useMutation({
    mutationFn: (values) => onBoardBranches(values),
    mutationKey: 'onBoardBranch',
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ['getBranches'],
      })
      toast.dismiss()
      toast.success('Register Branch Successful')
      setIsSubmitting(false) // Reset submission state on success
      setIsOpen(false) // Close modal on success
    },
    onError: () => {
      toast.dismiss()
      toast.error('Register Branch Failed')
      setIsSubmitting(false) // Reset submission state on error
    },
  })

  const validateBranchName = (branchName) => {
    return !branches.some(
      (branch) => branch.branch_name.toLowerCase() === branchName.toLowerCase(),
    )
  }

  const handleClick = useCallback(() => {
    setIsOpen(true)
  }, [])

  const phoneRegexIndia = /^[0-9]{10}$/
  const phoneRegexDubai = /^[0-9]+$/
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

  const validationSchema = yup.object().shape({
    branch_name: yup
      .string()
      .required('Branch name is required')
      .matches(/[a-zA-Z]/, 'Branch name must contain at least one letter')
      .test('is-unique', 'Branch name already exists', function (value) {
        if (branches) return validateBranchName(value)
        else return true
      }),
    timezone: yup.string().required('Timezone is required'),
    phone: yup
      .string()
      .required('Phone number is required')
      .test('is-valid-phone', 'Enter a valid phone number', function (value) {
        const { phone_ext } = this.parent
        if (phone_ext === '+91') {
          return phoneRegexIndia.test(value) && value.length === 10
        }
        if (phone_ext === '+971') {
          return (
            phoneRegexDubai.test(value) &&
            value.length <= 10 &&
            value.length >= 5
          )
        }
        return false
      }),
    phone_ext: yup.string().required('Country code is required'),
    address: yup
      .string()
      .required('Address is required')
      .matches(/[a-zA-Z]/, 'Address must contain at least one letter'),
    supportemail: yup
      .string()
      .email('Enter a valid email')
      .required('Email is required')
      .matches(emailRegex, 'Enter a valid email'),
    ref_start_code: yup
      .string()
      .matches(/^\d{5}$/, 'Access code must be exactly 5 digits')
      .required('Access code is required'),
  })

  const initialValues = {
    branch_name: '',
    timezone: '',
    phone: '',
    phone_ext: '',
    address: '',
    supportemail: '',
    ref_start_code: '',
  }

  const timezoneOptions = [
    { value: 'IST', label: 'Asia/India' },
    { value: 'GST', label: 'Asia/Dubai' },
  ]

  return (
    <div>
      <PrimaryBtn
        text="Register Branch"
        type={'button'}
        handleClick={handleClick}
      />
      <Modal open={isOpen} onClose={() => setIsOpen(false)}>
        <Box sx={styles.modal}>
          <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={(values, { resetForm }) => {
              setIsSubmitting(true) // Disable button on submission
              const body = {
                org_id: auth.role === '2' ? auth.org_id : props.orgId,
                branches: [values],
              }
              mutate.mutate(body, {
                onSuccess: () => {
                  resetForm() // Reset form here if needed
                },
              })
            }}
          >
            {({ setFieldValue, values }) => (
              <Form style={{ flex: 1 }}>
                <div className="mb-4">
                  <FormikTextField name="branch_name" label="Branch Name *" />
                </div>

                <div className="mb-4">
                  <FormikSelect
                    name={'timezone'}
                    label={'Time Zone*'}
                    options={timezoneOptions}
                    onChange={(e) => {
                      const selectedValue = e.target.value
                      setFieldValue('timezone', selectedValue)
                      setFieldValue(
                        'phone_ext',
                        selectedValue === 'IST' ? '+91' : '+971',
                      )
                      setFieldValue('phone', '') // Clear phone number to trigger validation
                    }}
                  />
                  <br />
                  <FormikTextField
                    name="supportemail"
                    label="Support Email *"
                  />
                  <br />
                  <FormikTextField
                    name="ref_start_code"
                    label="Access Code *"
                  />
                </div>

                <div className="grid grid-cols-2 gap-5 mb-4">
                  <div>
                    <FormikTextField
                      name="phone_ext"
                      label="Country Code *"
                      disabled={true}
                    />
                  </div>
                  <div>
                    <FormikTextField name="phone" label="Phone *" />
                  </div>

                  <div className="col-span-2">
                    <FormikTextField name="address" label="Address *" />
                  </div>
                </div>

                <br />
                {/* Disable the button when submitting */}
                <PrimaryBtn text="Register Branch" disabled={isSubmitting} />
                <form method="dialog">
                  <button
                    className="btn btn-sm btn-circle btn-ghost absolute right-2 top-2"
                    id="my_modal_2_btn"
                    onClick={() => setIsOpen(false)} // Close modal on button click
                  >
                    ✕
                  </button>
                </form>
              </Form>
            )}
          </Formik>
        </Box>
      </Modal>
    </div>
  )
}

export default OnBoardBranch
