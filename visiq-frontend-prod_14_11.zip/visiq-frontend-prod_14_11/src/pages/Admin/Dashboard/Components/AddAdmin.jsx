import React, {
  useCallback,
  useContext,
  useState,
  useEffect,
  useRef,
  useMemo,
} from 'react'
import PrimaryBtn from '../../../../shared/Buttons/PrimaryBtn'
import * as yup from 'yup'
import { Form, Formik } from 'formik'
import FormikTextField from '../../../../lib/Formik/FormikTextfield'
import { AuthContext } from '../../../../context/AuthContext'
import FormikSelect from '../../../../lib/Formik/FormikSelect'
import { Box, Modal } from '@mui/material'
import { styles } from '../../../../constants/styes'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  createAdmin,
  listOfCountriesExt,
} from '../../../../services/adminService'
import toast from 'react-hot-toast'
import { apiCall } from '../../../../utils/apiCall.js'

const AddAdmin = ({ branches }) => {
  const [selectedBranch, setSelectedBranch] = useState('')
  const [phoneExt, setPhoneExt] = useState('')
  const queryClient = useQueryClient()
  const [isOpen, setIsOpen] = useState(false)
  const auth = useContext(AuthContext)
  const isAdmin = auth?.role === '1' || '2'
  const [username, setUsername] = useState('')
  const [usernameValidation, setUsernameValidation] = useState({
    isValid: true,
    isChecking: false,
  })
  const debounceTimerRef = useRef(null)
  const validationCacheRef = useRef({})
  const mutate = useMutation({
    mutationFn: (values) => createAdmin(values),
    mutationKey: 'createAdmin',
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ['createAdmin'],
      })
      toast.success('Admin Create Successful')
      setIsOpen(false) // Close modal on success
    },
    onError: () => {
      toast.dismiss()
      toast.error('Admin Create Failed')
    },
  })

  const { data: countrycodes, isCountryCodesLoading } = useQuery({
    queryFn: () => listOfCountriesExt(),
  })

  // Debounced username validation
  useEffect(() => {
    // Clear previous timer
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current)
    }

    // If username is too short, reset validation
    if (!username || username.length < 6) {
      setUsernameValidation({ isValid: true, isChecking: false })
      return
    }

    // Check cache first
    if (validationCacheRef.current[username] !== undefined) {
      setUsernameValidation({
        isValid: validationCacheRef.current[username],
        isChecking: false,
      })
      return
    }

    // Set checking state
    setUsernameValidation({ isValid: true, isChecking: true })

    // Debounce the API call
    debounceTimerRef.current = setTimeout(async () => {
      try {
        const response = await apiCall('/auth/availUser', 'POST', {
          username: username,
        })
        const isValid = !response.isAvail
        validationCacheRef.current[username] = isValid
        setUsernameValidation({ isValid, isChecking: false })
      } catch (error) {
        console.error('Error checking username availability:', error)
        setUsernameValidation({ isValid: true, isChecking: false })
      }
    }, 500) // 500ms debounce delay

    // Cleanup function
    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current)
      }
    }
  }, [username])

  const validationSchema = useMemo(
    () =>
      yup.object().shape({
        first_name: yup
          .string()
          .required('First name is required')
          .matches(/[a-zA-Z]/, 'First name must contain at least one letter'),
        last_name: yup
          .string()
          .required('Last name is required')
          .matches(/[a-zA-Z]/, 'Last name must contain at least one letter'),
        branch_id: yup.string().required('Branch is required'),
        email: yup
          .string()
          .email('Enter a valid email')
          .required('Branch admin email is required'),
        role: yup.string().required('Role is required'),
        phone: yup
          .string()
          .required('Phone number is required')
          .min(5, 'Phone number must be at least 5 digits')
          .max(10, 'Phone number must not exceed 10 digits')
          .matches(/^[0-9]+$/, 'Phone number must contain only numbers'),

        phone_ext: yup.string().required('Country code is required'),
        username: yup
          .string()
          .required('Username is a required field')
          .min(6, 'Username must be at least 6 characters')
          .matches(/^\S*$/, 'Username should not contain spaces')
          .test(
            'checkUsernameAvailability',
            'Username is not available',
            (value) => {
              if (!value || value.length < 6) {
                return true
              }
              // If still checking, return true to avoid blocking user input
              if (usernameValidation.isChecking) {
                return true
              }
              // Return the cached validation result
              return usernameValidation.isValid
            },
          ),
      }),
    [usernameValidation],
  )
  const handleClick = useCallback(() => {
    setSelectedBranch('')
    setPhoneExt('') // Ensure phoneExt is reset
    setUsername('') // Reset username
    setUsernameValidation({ isValid: true, isChecking: false }) // Reset validation
    validationCacheRef.current = {} // Clear cache
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current)
    }
    setIsOpen(true)
  }, [])

  const initialValues = {
    first_name: '',
    last_name: '',
    org_id: branches[0]?.org_id || '',
    role: '',
    email: '',
    branch_id: '',
    branch_name: '',
    phone: '',
    phone_ext: phoneExt, // This will be an empty string by default
    username: '',
  }

  return (
    <div>
      <PrimaryBtn text="Add Admin" type={'button'} handleClick={handleClick} />
      <Modal open={isOpen} onClose={() => setIsOpen(false)}>
        <Box sx={styles.modal}>
          <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={(values, { resetForm }) => {
              mutate.mutate(values)
              resetForm()
              setIsOpen(false) // Close modal after successful submit
            }}
          >
            {({ setFieldValue, values, props }) => (
              <Form style={{ flex: 1 }}>
                <div className="grid grid-cols-2 gap-5">
                  <div>
                    <FormikTextField name="first_name" label="First Name *" />
                  </div>
                  <div>
                    <FormikTextField name="last_name" label="Last Name *" />
                  </div>
                  <div>
                    {/* <FormikSelect
                      name="phone_ext"
                      label="Country Code *"
                      options={[
                        { value: '', label: 'Select Country Code' }, // Default option
                        { value: '+91', label: '+91' },
                        { value: '+971', label: '+971' },
                      ]}
                      onChange={(e) => {
                        const newExt = e.target.value
                        setFieldValue('phone_ext', newExt)
                        setPhoneExt(newExt) // Update phoneExt state
                        setFieldValue('phone', '') // Clear phone number to trigger validation
                      }}
                      value={values.phone_ext}
                    /> */}
                    <FormikSelect
                      name="phone_ext"
                      label="Country Code *"
                      options={
                        isCountryCodesLoading
                          ? [{ value: '', label: 'Loading...' }]
                          : (() => {
                              const countriesArray = Array.isArray(countrycodes)
                                ? countrycodes
                                : Array.isArray(countrycodes?.data)
                                  ? countrycodes.data
                                  : []
                              return countriesArray.length > 0
                                ? countriesArray.map((country) => ({
                                    value: country.code,
                                    label: `${country.country} (${country.code})`,
                                  }))
                                : [
                                    {
                                      value: '',
                                      label: 'No countries available',
                                    },
                                  ]
                            })()
                      }
                      onChange={(e) => {
                        setFieldValue('phone_ext', e.target.value) // Properly use setFieldValue from context
                        setFieldValue('phone', '') // Clear phone number to trigger validation
                      }}
                      value={values.phone_ext} // Use values directly
                      disabled={isCountryCodesLoading}
                      MenuProps={{
                        PaperProps: {
                          style: {
                            maxHeight: 200, // Limit dropdown height
                            maxWidth: 200, // Set a smaller dropdown width
                          },
                        },
                      }}
                      InputProps={{
                        style: { width: '200px' }, // Set the input field width
                      }}
                    />
                  </div>
                  <div>
                    <FormikTextField name="phone" label="Phone *" />
                  </div>
                  <div>
                    <FormikTextField name="email" label="Email *" />
                  </div>
                  <div>
                    <FormikTextField
                      name="username"
                      label="Username *"
                      onChange={(e) => {
                        const value = e.target.value
                        setFieldValue('username', value)
                        setUsername(value)
                      }}
                    />
                  </div>
                  {isAdmin && (
                    <div>
                      <FormikSelect
                        name="branch_id"
                        label="Branches *"
                        onChange={(e) => {
                          setFieldValue('branch_id', e.target.value)
                          setSelectedBranch(e.target.value)
                        }}
                        value={selectedBranch}
                        options={branches.map((branch) => ({
                          value: branch.branch_id,
                          label: branch.branch_name,
                        }))}
                      />
                    </div>
                  )}
                  <div>
                    <FormikSelect
                      name="role"
                      label="Role *"
                      options={[
                        { value: '3', label: 'Branch Level Admin' },
                        { value: '4', label: 'Security Level Admin' },
                      ]}
                      onChange={(e) => {
                        setFieldValue('role', e.target.value)
                      }}
                      value={values.role}
                    />
                  </div>
                </div>
                <br />
                <PrimaryBtn text="Add Admin" />
                <button
                  className="btn btn-sm btn-circle btn-ghost absolute right-2 top-2"
                  onClick={() => {
                    setIsOpen(false)
                    setSelectedBranch('')
                    setPhoneExt('') // Reset phoneExt state
                    setUsername('') // Reset username
                    setUsernameValidation({ isValid: true, isChecking: false }) // Reset validation
                    validationCacheRef.current = {} // Clear cache
                    if (debounceTimerRef.current) {
                      clearTimeout(debounceTimerRef.current)
                    }
                  }}
                >
                  ✕
                </button>
              </Form>
            )}
          </Formik>
        </Box>
      </Modal>
    </div>
  )
}

export default AddAdmin
