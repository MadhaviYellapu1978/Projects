import React from 'react'
import AttendancePopup from './AttendancePopup'
import { Tooltip } from '@mui/material'

const UserCard = (props) => {
  const { user } = props

  // Debug logging for attendance data
  console.log('🔍 UserCard - user object:', user)
  console.log('🔍 UserCard - attendanceData:', user?.attendanceData)
  console.log('🔍 UserCard - userDetails:', user?.userDetails)
  console.log('🔍 UserCard - photo data:', {
    userPhoto: user?.userDetails?.[0]?.photo,
    isMainVisitor: user?.userDetails?.[0]?.isMainVisitor,
    isGroupMember: user?.userDetails?.[0]?.isGroupMember,
    photoSource: user?.userDetails?.[0]?.photo ? 'has_photo' : 'no_photo',
  })

  // Add comprehensive error handling
  try {
    // Validate user data
    if (
      !user ||
      !user.userDetails ||
      !Array.isArray(user.userDetails) ||
      user.userDetails.length === 0
    ) {
      return (
        <div className="p-4 border border-red-300 rounded-lg bg-red-50">
          <p className="text-red-600 text-sm">Invalid user data</p>
        </div>
      )
    }

    return (
      <div
        className="card  bg-base-100 shadow-lg shadow-secondary100 hover:scale-[1.1] cursor-pointer"
        key={user.userDetails[0]?.user_id}
      >
        <figure className="max-h-40 flex justify-end items-end">
          {(() => {
            const photoUrl = user.userDetails[0]?.photo
            const hasValidPhoto =
              photoUrl &&
              photoUrl !== '' &&
              photoUrl !== null &&
              photoUrl !== undefined &&
              photoUrl !== 'null' &&
              photoUrl !== 'undefined'

            console.log('🔍 UserCard - Photo validation:', {
              photoUrl,
              hasValidPhoto,
              fallbackUsed: !hasValidPhoto,
            })

            // Get visitor name and initials for fallback
            const visitorName = user.userDetails[0]?.first_name || 'User'
            const initials = visitorName
              .split(' ')
              .map((name) => name.charAt(0))
              .join('')
              .toUpperCase()
              .slice(0, 2)

            return (
              <>
                {hasValidPhoto && (
                  <img
                    src={photoUrl}
                    alt={visitorName}
                    className="mt-12 pt-12"
                    onError={(e) => {
                      console.log(
                        '🔍 UserCard - Photo load error, using fallback',
                      )
                      e.target.style.display = 'none'
                      e.target.nextElementSibling.style.display = 'flex'
                    }}
                  />
                )}
                <div
                  className="mt-12 pt-12 w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-xl shadow-lg"
                  style={{ display: hasValidPhoto ? 'none' : 'flex' }}
                >
                  <div className="text-center">
                    <div className="text-2xl mb-1">👤</div>
                    <div className="text-xs font-semibold">{initials}</div>
                  </div>
                </div>
              </>
            )
          })()}
        </figure>
        <div className="card-body">
          <h2 className="card-title">
            <Tooltip
              title={`${user.userDetails[0]?.first_name || ''} ${user.userDetails[0]?.last_name || ''}`}
              arrow
            >
              {(() => {
                const fullName = `${user.userDetails[0]?.first_name || ''} ${user.userDetails[0]?.last_name || ''}`
                return fullName.length > 20
                  ? `${fullName.slice(0, 8)}...`
                  : fullName
              })()}
            </Tooltip>
            {/* Blacklisted indicator - moved to title area */}
            {(() => {
              const _userId =
                user.userDetails[0]?.user_id ||
                user.userDetails[0]?.id ||
                user.userDetails[0]?.visitor_id

              const userBlacklistKey = `blacklist_${_userId}`
              const savedBlacklistState = localStorage.getItem(userBlacklistKey)

              // Comprehensive blacklist detection
              const isBlacklisted =
                savedBlacklistState === 'true' ||
                user.userDetails[0]?.black_listed === true ||
                user.userDetails[0]?.blacklisted === true ||
                user.userDetails[0]?.blacklist_status === 'blacklisted' ||
                user.userDetails[0]?.is_blacklisted === true ||
                user.userDetails[0]?.status === 'Blacklisted' ||
                user.black_listed === true ||
                user.blacklisted === true ||
                user.blacklist_status === 'blacklisted' ||
                user.is_blacklisted === true ||
                user.status === 'Blacklisted'

              console.log('AllVisitorUserCard - Blacklist check for user:', {
                _userId,
                savedBlacklistState,
                userDetails: user.userDetails[0],
                user,
                isBlacklisted,
              })

              if (isBlacklisted) {
                return (
                  <span
                    style={{
                      fontSize: '0.45rem',
                      color: '#dc3545',
                      backgroundColor: '#f8d7da',
                      padding: '2px 6px',
                      borderRadius: '4px',
                      fontWeight: 'bold',
                      display: 'inline-block',
                      boxShadow: 'none',
                      cursor: 'default',
                    }}
                  >
                    ⚠️ Blacklisted
                  </span>
                )
              }
              return null
            })()}
          </h2>
          <div className="flex text-sm">
            <p>
              Last Entry: <br />{' '}
              {user.userDetails[0]?.last_entry?.split(' ')[1] || '--'}
            </p>
            <p>
              Last Exit: <br />{' '}
              {user.userDetails[0]?.last_exit?.split(' ')[1] || '--'}
            </p>
          </div>
          <AttendancePopup user={user} />

          {/* Group Visitor indicator and details - positioned below View Visitor Details button */}
          {(() => {
            // Debug logging
            console.log('🔍 UserCard Debug - Full user:', user)
            console.log(
              '🔍 UserCard Debug - userDetails[0]:',
              user.userDetails?.[0],
            )
            console.log(
              '🔍 UserCard Debug - visitor_type:',
              user.userDetails?.[0]?.visitor_type,
            )
            console.log(
              '🔍 UserCard Debug - grp_book_bool:',
              user.userDetails?.[0]?.grp_book_bool,
            )
            console.log(
              '🔍 UserCard Debug - grp_details:',
              user.userDetails?.[0]?.grp_details,
            )
            console.log(
              '🔍 UserCard Debug - grp_details length:',
              user.userDetails?.[0]?.grp_details?.length,
            )

            // Check if this is actually a group visitor (not just any visitor with group details)
            const visitorType = user.userDetails?.[0]?.visitor_type
            const grpBookBool = user.userDetails?.[0]?.grp_book_bool
            const grpDetails = user.userDetails?.[0]?.grp_details
            const grpDetailsLength = grpDetails?.length || 0

            // Only show group visitor indicator for actual group visitors
            // Use only the primary indicators: visitor_type and grp_book_bool
            const isGroupVisitor =
              visitorType === 'group_visitor' || grpBookBool === true

            console.log('🔍 UserCard Debug - Group visitor check details:', {
              visitorType,
              grpBookBool,
              grpDetailsLength,
              isGroupVisitor,
              reason: isGroupVisitor
                ? visitorType === 'group_visitor'
                  ? 'visitor_type'
                  : 'grp_book_bool'
                : 'not_group_visitor',
            })

            console.log('🔍 UserCard Debug - isGroupVisitor:', isGroupVisitor)
            console.log(
              '🔍 UserCard Debug - visitor_type check:',
              user.userDetails?.[0]?.visitor_type === 'group_visitor',
            )
            console.log(
              '🔍 UserCard Debug - grp_book_bool check:',
              user.userDetails?.[0]?.grp_book_bool === true,
            )
            console.log(
              '🔍 UserCard Debug - grp_details check:',
              user.userDetails?.[0]?.grp_details &&
                Array.isArray(user.userDetails[0].grp_details) &&
                user.userDetails[0].grp_details.length > 0,
            )

            if (isGroupVisitor) {
              const groupDetails = user.userDetails[0]?.grp_details || []
              const _hasGroupMembers = groupDetails.length > 0

              return (
                <div
                  style={{
                    marginTop: '4px',
                    textAlign: 'center',
                    width: '100%',
                  }}
                >
                  <span
                    style={{
                      fontSize: '0.45rem',
                      color: '#ffffff',
                      backgroundColor: '#87ceeb',
                      padding: '2px 6px',
                      borderRadius: '8px',
                      fontWeight: 'normal',
                      display: 'inline-block',
                      boxShadow: 'none',
                      cursor: 'default',
                    }}
                  >
                    👥 Group Visitor
                  </span>
                </div>
              )
            }
            return null
          })()}
        </div>
      </div>
    )
  } catch (error) {
    console.error('🔍 Error in UserCard component:', error)
    return (
      <div className="p-4 border border-red-300 rounded-lg bg-red-50">
        <p className="text-red-600 text-sm">Error loading visitor card</p>
        <p className="text-gray-500 text-xs">Error: {error.message}</p>
      </div>
    )
  }
}

export default UserCard
