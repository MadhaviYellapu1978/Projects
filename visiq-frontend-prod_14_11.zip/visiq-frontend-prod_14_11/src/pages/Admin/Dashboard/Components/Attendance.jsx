﻿import React, { useState } from 'react'
import UserCard from './AllVisitorUserCard'
import Papa from 'papaparse'
import { saveAs } from 'file-saver'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {
  faDownload,
  faToggleOn,
  faToggleOff,
} from '@fortawesome/free-solid-svg-icons'
import { pdf } from '@react-pdf/renderer'
import VisitorsPDF from './PdfDownload'
import VisitorsPDFDetailed from './pdfDownloadDetailed'
import { formatDate, formatTime } from '../../../../utils/dateFormat'

const Attendance = (props) => {
  const { userData, branch, data_of_visit, name, report_name } = props
  const [isPDF, setIsPDF] = useState(true) // Toggle state for PDF/CSV
  const [filter, setFilter] = useState('')

  const handleToggle = () => {
    setIsPDF(!isPDF)
  }

  // Function to map visitor_type to display names
  const getVisitorTypeDisplay = (visitorType) => {
    if (!visitorType) {
      return 'Individual Visitor'
    }

    // Normalize to lowercase for case-insensitive comparison
    const normalized = String(visitorType).toLowerCase().trim()

    switch (normalized) {
      case 'group_visitor':
      case 'group':
        return 'Group Visitor'
      case 'main_visitor':
      case 'main':
        return 'Main Visitor'
      case 'individual_visitor':
      case 'individual':
        return 'Individual Visitor'
      case 'group_member':
      case 'member':
        return 'Group Member'
      default:
        // If it's a known format but doesn't match, try to format it
        if (normalized.includes('group')) {
          return 'Group Visitor'
        }
        if (normalized.includes('main')) {
          return 'Main Visitor'
        }
        if (normalized.includes('individual')) {
          return 'Individual Visitor'
        }
        return 'Individual Visitor'
    }
  }

  const convertImageToBase64s = async (url) => {
    try {
      const response = await fetch(url)
      const blob = await response.blob()

      return await new Promise((resolve, reject) => {
        const reader = new FileReader()
        reader.onloadend = () => resolve(reader.result)
        reader.onerror = reject
        reader.readAsDataURL(blob)
      })
    } catch (error) {
      console.error('Error converting image:', error)
      return null
    }
  }

  const downloadPDF = async () => {
    try {
      // Fetch images and prepare table data
      const tableRows = await Promise.all(
        userData.flatMap((item) =>
          item.userDetails.map(async (user) => {
            let base64Photo = ''
            try {
              if (user.photo) {
                const addingRegionPhoto = user.photo.includes('ap-south-1')
                  ? user.photo
                  : `https://visiqbucket.s3.us-east-1.${user.photo.split('https://visiqbucket.s3.')[1]}`
                base64Photo = await convertImageToBase64s(addingRegionPhoto)
              }
            } catch (error) {
              console.error('Image processing error:', error)
              base64Photo = ''
            }

            return {
              first_name: user.first_name || '',
              visitor_type: user.visitor_type || 'individual_visitor', // Include visitor_type
              purpose_of_visit: user.purpose_of_visit || '',
              area_of_permit: user.area_of_permit || '',
              asset: user.asset || '',
              ph_no: user.ph_no && user.ph_ext ? `${user.ph_ext}-${user.ph_no}` : 'N/A',
              email: user.email || 'N/A',
              last_entry: formatDate(user.last_entry) || '',
              last_exit: formatDate(user.last_exit) || '',
              visitor_company_name: user.visitor_company_name || '',
              visitor_code: user.visitor_code || user.last_visited_code || '', // Map visitor_code
              last_visited_code:
                user.visitor_code || user.last_visited_code || '', // Keep for backward compatibility
              photo: base64Photo, // Ensure proper mapping
              kyc_type: user.kyc_type || '',
              kyc_id: user.kyc_id || '',
              role_name: user.role_name || '',
              // Add blacklist fields for basic PDF
              black_listed: user.black_listed || false,
              blacklisted: user.blacklisted || false,
              blacklist_status: user.blacklist_status || '',
              is_blacklisted: user.is_blacklisted || false,
              status: user.status || '',
            }
          }),
        ),
      )

      console.log(tableRows, 'Processed Table Rows')

      const blob = await pdf(
        <VisitorsPDF
          userData={tableRows}
          branch={branch}
          name={name}
          data_of_visit={data_of_visit}
          report_name={report_name}
        />,
      ).toBlob()

      // Download
      const url = URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = 'visitors_download_report.pdf'
      link.click()
      URL.revokeObjectURL(url)
    } catch (error) {
      console.error('Error generating PDF:', error)
    }
  }

  const _downloadDetailedPDF = async () => {
    try {
      const updatedUserData = await Promise.all(
        userData.map(async (user) => {
          let base64Photo = ''
          if (user.userDetails[0]?.photo) {
            try {
              const originalPhoto = user.userDetails[0].photo
              const regionAddedPhoto = `https://visiqbucket.s3.us-east-1.${originalPhoto.split('https://visiqbucket.s3.')[1]}`
              base64Photo = await convertImageToBase64s(regionAddedPhoto)
            } catch (err) {
              console.error('Failed to fetch/convert image', err)
            }
          }

          // Merge attendanceData with userDetails
          const details = user.userDetails[0]
          return user.attendanceData.map((att) => ({
            first_name: details.first_name || '',
            visitor_type: details.visitor_type || 'individual_visitor', // Include visitor_type
            role_name: details.role_name || '',
            purpose_of_visit: details.purpose_of_visit || '',
            area_of_permit: details.area_of_permit || '',
            asset: details.asset || '',
            ph_no: `${details.ph_ext}-${details.ph_no}` || '',
            email: details.email || '',
            last_entry: formatDate(details.last_entry) || '',
            last_exit: formatDate(details.last_exit) || '',
            visitor_company_name: details.visitor_company_name || '',
            visitor_code:
              details.visitor_code || details.last_visited_code || '', // Map visitor_code
            last_visited_code:
              details.visitor_code || details.last_visited_code || '', // Keep for backward compatibility
            photo: base64Photo,
            kyc_type: details.kyc_type || '',
            kyc_id: details.kyc_id || '',
            entry_time: att.entry_time || '',
            exit_time: att.exit_time || '',
            // Add blacklist fields for detailed PDF
            black_listed: details.black_listed || false,
            blacklisted: details.blacklisted || false,
            blacklist_status: details.blacklist_status || '',
            is_blacklisted: details.is_blacklisted || false,
            status: details.status || '',
          }))
        }),
      )

      // Flatten the final array
      const flattenedUserData = updatedUserData.flat()
      console.log('Flattened User Data:', flattenedUserData)

      // Generate the PDF using a React component
      const blob = await pdf(
        <VisitorsPDFDetailed
          userData={flattenedUserData}
          branch={branch}
          name={name}
          data_of_visit={data_of_visit}
          report_name={report_name}
        />,
      ).toBlob()

      // Download
      const url = URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = 'visitors_detailed_report.pdf'
      link.click()
      URL.revokeObjectURL(url)
    } catch (error) {
      console.error('Error generating detailed PDF:', error)
    }
  }
  const downloadCSV = () => {
    const csvData = userData.flatMap((item) =>
      item.userDetails.map((user) => {
        const phoneExt = user.ph_ext.startsWith('+')
          ? user.ph_ext
          : `+${user.ph_ext}`
        
        // Get photo URL - handle different photo URL formats
        let photoUrl = ''
        if (user.photo) {
          if (user.photo.includes('ap-south-1')) {
            photoUrl = user.photo
          } else if (user.photo.includes('https://visiqbucket.s3.')) {
            photoUrl = `https://visiqbucket.s3.us-east-1.${user.photo.split('https://visiqbucket.s3.')[1]}`
          } else {
            photoUrl = user.photo
          }
        }
        
        return {
          Name: user.first_name,
          'Visitor Type': getVisitorTypeDisplay(user.visitor_type),
          Category: user?.role_name,
          'Purpose of Visit': user.purpose_of_visit,
          'Area of Permit': user.area_of_permit,
          Asset: user.asset,
          'Phone Number': user.ph_no && user.ph_ext ? `\t${phoneExt}-${user.ph_no}` : 'N/A',
          Email: user.email || 'N/A',
          'Last Entry': formatDate(user.last_entry) || '-',
          'Last Exit': formatDate(user.last_exit) || '-',
          'Visitor Company Name': user.visitor_company_name,
          'Access Reference Code': `\t${user.visitor_code || user.last_visited_code || ''}`,
          'KYC Type': user.kyc_type,
          'KYC ID': `\t${user.kyc_id}`,
          Blacklist:
            user.black_listed === true ||
            user.blacklisted === true ||
            user.blacklist_status === 'blacklisted' ||
            user.is_blacklisted === true ||
            user.status === 'Blacklisted'
              ? 'Yes'
              : 'No',
          Photo: photoUrl || 'N/A',
        }
      }),
    )

    const csv = Papa.unparse(csvData)
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    saveAs(blob, 'Check In Check Out Report.csv')
  }

  const handleFilterChange = (e) => {
    setFilter(e.target.value)
  }

  const filteredData = userData.filter((user) =>
    `${user.userDetails[0].first_name} ${user.userDetails[0].last_name}`
      .toLowerCase()
      .includes(filter.toLowerCase()),
  )
  const _downloadAllCSV = () => {
    const csvData = userData.flatMap((item) =>
      item.userDetails.flatMap((user) =>
        item.attendanceData.map((att) => {
          const phoneExt = user.ph_ext?.startsWith('+')
            ? user.ph_ext
            : `+${user.ph_ext}`
          return {
            Name: user.first_name,
            'Visitor Type': getVisitorTypeDisplay(user.visitor_type),
            Category: user?.role_name,
            'Purpose of Visit': user.purpose_of_visit,
            'Area of Permit': user.area_of_permit,
            Asset: user.asset,
            'Phone Number': `\t${phoneExt}-${user.ph_no}` || '',
            Email: user.email,
            'Last Entry': formatDate(user.last_entry) || '',
            'Last Exit': formatDate(user.last_exit) || '',
            'Visitor Company Name': user.visitor_company_name,
            'Access Reference Code': `\t${user.visitor_code || user.last_visited_code || ''}`,
            'KYC Type': user.kyc_type,
            'KYC ID': `\t${user.kyc_id}`,
            'Entry Time': formatTime(att.entry_time) || '',
            'Exit Time': formatTime(att.exit_time) || '',
          }
        }),
      ),
    )

    const csv = Papa.unparse(csvData)
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    saveAs(blob, 'All Details Report.csv')
  }

  return (
    <div>
      {filteredData.length > 0 ? (
        <div>
          <div className="flex items-center space-x-4 mb-4">
            {/* Toggle Button */}
            <button
              onClick={handleToggle}
              className="bg-gray-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-gray-600 transition-colors"
            >
              {isPDF ? (
                <>
                  <FontAwesomeIcon
                    icon={faToggleOn}
                    className="mr-1.5 text-xs"
                  />
                  Switch to CSV
                </>
              ) : (
                <>
                  <FontAwesomeIcon
                    icon={faToggleOff}
                    className="mr-1.5 text-xs"
                  />
                  Switch to PDF
                </>
              )}
            </button>

            {/* Conditional Buttons */}
            {isPDF ? (
              <>
                <button
                  onClick={downloadPDF}
                  className="bg-green-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-green-600 transition-colors"
                >
                  Download PDF
                  <FontAwesomeIcon
                    icon={faDownload}
                    className="ml-1.5 text-xs"
                  />
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={downloadCSV}
                  className="bg-blue-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-blue-600 transition-colors"
                >
                  Download CSV
                  <FontAwesomeIcon
                    icon={faDownload}
                    className="ml-1.5 text-xs"
                  />
                </button>
              </>
            )}

            {/* Search Input */}
            <div className="relative">
              <input
                id="attendance-search"
                type="text"
                className="w-64 px-4 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                placeholder="Search visitors..."
                value={filter}
                onChange={handleFilterChange}
              />
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 16 16"
                fill="currentColor"
                className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400"
              >
                <path
                  fillRule="evenodd"
                  d="M9.965 11.026a5 5 0 1 1 1.06-1.06l2.755 2.754a.75.75 0 1 1-1.06 1.06l-2.755-2.754ZM10.5 7a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Z"
                  clipRule="evenodd"
                />
              </svg>
            </div>
          </div>

          {/* User Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-5">
            {filteredData.map((user) => (
              <UserCard key={user.user_id} user={user} />
            ))}
          </div>
        </div>
      ) : (
        <div>
          <div className="flex items-center space-x-4 mb-4">
            {/* Toggle Button */}
            <button
              onClick={handleToggle}
              className="bg-gray-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-gray-600 transition-colors"
            >
              {isPDF ? (
                <>
                  <FontAwesomeIcon
                    icon={faToggleOn}
                    className="mr-1.5 text-xs"
                  />
                  Switch to CSV
                </>
              ) : (
                <>
                  <FontAwesomeIcon
                    icon={faToggleOff}
                    className="mr-1.5 text-xs"
                  />
                  Switch to PDF
                </>
              )}
            </button>

            {/* Conditional Buttons */}
            {isPDF ? (
              <>
                <button
                  onClick={downloadPDF}
                  className="bg-green-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-green-600 transition-colors"
                >
                  Download PDF
                  <FontAwesomeIcon
                    icon={faDownload}
                    className="ml-1.5 text-xs"
                  />
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={downloadCSV}
                  className="bg-blue-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-blue-600 transition-colors"
                >
                  Download CSV
                  <FontAwesomeIcon
                    icon={faDownload}
                    className="ml-1.5 text-xs"
                  />
                </button>
              </>
            )}

            {/* Search Input */}
            <div className="relative">
              <input
                id="attendance-search"
                type="text"
                className="w-64 px-4 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                placeholder="Search visitors..."
                value={filter}
                onChange={handleFilterChange}
              />
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 16 16"
                fill="currentColor"
                className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400"
              >
                <path
                  fillRule="evenodd"
                  d="M9.965 11.026a5 5 0 1 1 1.06-1.06l2.755 2.754a.75.75 0 1 1-1.06 1.06l-2.755-2.754ZM10.5 7a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Z"
                  clipRule="evenodd"
                />
              </svg>
            </div>
          </div>

          {/* No Data Message */}
          <div className="col-span-full text-center text-gray-500">
            No data available
          </div>
        </div>
      )}
    </div>
  )
}

export default Attendance
