import React from 'react'
import { Link } from 'react-router-dom'

const Branches = (props) => {
  const { branches } = props
  return (
    <div>
      <div className="overflow-x-auto">
        <table className="table">
          {/* head */}
          <thead>
            <tr>
              <th>Branch Name</th>
              <th>Phone</th>
              <th>Timezone</th>
              <th>Address</th>
            </tr>
          </thead>
          <tbody>
            <tr key={'head'} className="border-b" />
            {branches.map((branch) => (
              <>
                <tr key={branch.branch_id}>
                  <td>
                    <Link
                      to={`/admin/branch/${branch.branch_id}`}
                      className="text-primary underline underline-offset-2"
                    >
                      {branch.branch_name}
                    </Link>
                  </td>
                  <td>{branch.phone}</td>
                  <td>{branch.timezone}</td>
                  <td>{branch.address}</td>
                </tr>
              </>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default Branches
