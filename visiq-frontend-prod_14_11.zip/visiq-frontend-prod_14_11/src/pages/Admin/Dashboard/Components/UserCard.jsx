import React from 'react'
import AttendancePopup from './AttendancePopup'
import { Tooltip } from '@mui/material'

const UserCard = (props) => {
  const { user } = props
  return (
    <div
      className="card  bg-base-100 shadow-lg shadow-secondary100 hover:scale-[1.1] cursor-pointer"
      key={user.userDetails[0].user_id}
    >
      <figure className="max-h-40 flex justify-end items-end">
        <img
          src={user.userDetails[0].photo}
          alt="Movie"
          className="mt-12 pt-12"
        />
      </figure>
      <div className="card-body">
        <h2 className="card-title">
          <Tooltip
            title={`${user.userDetails[0].first_name} ${user.userDetails[0].last_name}`}
            arrow
          >
            {(() => {
              const fullName = `${user.userDetails[0].first_name} ${user.userDetails[0].last_name}`
              return fullName.length > 20
                ? `${fullName.slice(0, 8)}...`
                : fullName
            })()}
          </Tooltip>
          {/* Blacklisted indicator - moved to title area */}
          {(() => {
            const userId =
              user.userDetails[0].user_id ||
              user.userDetails[0].id ||
              user.userDetails[0].visitor_id
            const userBlacklistKey = `blacklist_${userId}`
            const savedBlacklistState = localStorage.getItem(userBlacklistKey)

            // Priority: API response > localStorage > default false
            // Check both possible field names: blacklisted and black_listed
            const apiBlacklistedValue =
              user.userDetails[0].blacklisted !== undefined
                ? user.userDetails[0].blacklisted
                : user.userDetails[0].black_listed

            const isBlacklisted =
              apiBlacklistedValue !== undefined
                ? apiBlacklistedValue
                : savedBlacklistState === 'true'

            console.log('Blacklist check for user:', {
              userId,
              apiBlacklisted: user.userDetails[0].blacklisted,
              apiBlackListed: user.userDetails[0].black_listed,
              resolvedApiValue: apiBlacklistedValue,
              savedBlacklistState,
              finalBlacklisted: isBlacklisted,
            })

            if (isBlacklisted) {
              return (
                <span
                  style={{
                    backgroundColor: '#f8d7da',
                    color: '#721c24',
                    border: '1px solid #f5c6cb',
                    fontSize: '0.5rem',
                    padding: '0px 3px',
                    borderRadius: '8px',
                    fontWeight: 'normal',
                    marginLeft: '3px',
                    boxShadow: 'none',
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '1px',
                    cursor: 'default',
                  }}
                >
                  <span style={{ fontSize: '0.8em' }}>⚠️</span>
                  <span>BLACKLISTED</span>
                </span>
              )
            }
            return null
          })()}
        </h2>
        {/* <p>Click the button to watch on Jetflix app.</p> */}
        <div className="flex text-sm">
          <p>
            Last Entry: <br />{' '}
            {user.userDetails[0].last_entry.split(' ')[1] || '--'}
          </p>
          <p>
            Last Exit: <br />{' '}
            {user.userDetails[0].last_exit.split(' ')[1] || '--'}
          </p>
        </div>
        <AttendancePopup user={user} />

        {/* Group Visitor indicator and details - positioned below View Visitor Details button */}
        {(() => {
          // Check multiple possible indicators for group visitor
          const isGroupVisitor =
            user.userDetails?.[0]?.visitor_type === 'group_visitor' ||
            user.userDetails?.[0]?.grp_book_bool === true ||
            (user.userDetails?.[0]?.grp_details &&
              user.userDetails?.[0]?.grp_details.length > 0) ||
            user.visitor_type === 'group_visitor' ||
            user.grp_book_bool === true ||
            (user.grp_details && user.grp_details.length > 0)

          // Get group details from different possible locations
          const grpDetails =
            user.userDetails?.[0]?.grp_details || user.grp_details || []

          if (isGroupVisitor && grpDetails.length > 0) {
            return (
              <div className="text-center" style={{ marginTop: '-8px' }}>
                <span
                  style={{
                    backgroundColor: '#e3f2fd',
                    color: '#1976d2',
                    border: '1px solid #90caf9',
                    fontSize: '0.5rem',
                    padding: '2px 6px',
                    borderRadius: '8px',
                    fontWeight: 'normal',
                    display: 'inline-block',
                    boxShadow: 'none',
                    cursor: 'default',
                    marginBottom: '8px',
                  }}
                >
                  👥 Group Visitor ({grpDetails.length} members)
                </span>

                {/* Group Member Details */}
                <div
                  style={{
                    backgroundColor: '#f8f9fa',
                    border: '1px solid #e9ecef',
                    borderRadius: '6px',
                    padding: '8px',
                    marginTop: '4px',
                    maxHeight: '120px',
                    overflowY: 'auto',
                  }}
                >
                  <div
                    style={{
                      fontSize: '0.6rem',
                      fontWeight: 'bold',
                      color: '#495057',
                      marginBottom: '4px',
                      textAlign: 'left',
                    }}
                  >
                    Group Members:
                  </div>
                  {grpDetails.map((member, index) => (
                    <div
                      key={index}
                      style={{
                        fontSize: '0.5rem',
                        color: '#6c757d',
                        marginBottom: '2px',
                        textAlign: 'left',
                        padding: '2px 4px',
                        backgroundColor: '#ffffff',
                        borderRadius: '3px',
                        border: '1px solid #dee2e6',
                      }}
                    >
                      <div style={{ fontWeight: 'bold' }}>
                        {member.grp_user_name ||
                          member.name ||
                          'Unknown Member'}
                      </div>
                      {member.grp_user_role_name && (
                        <div style={{ fontSize: '0.45rem', color: '#868e96' }}>
                          Role: {member.grp_user_role_name}
                        </div>
                      )}
                      {member.grp_user_phone && (
                        <div style={{ fontSize: '0.45rem', color: '#868e96' }}>
                          Phone: {member.grp_user_phone}
                        </div>
                      )}
                      {member.last_entry && member.last_entry !== '--' && (
                        <div style={{ fontSize: '0.45rem', color: '#28a745' }}>
                          ✓ Checked In: {member.last_entry}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )
          } else if (isGroupVisitor) {
            return (
              <div className="text-center" style={{ marginTop: '-8px' }}>
                <span
                  style={{
                    backgroundColor: '#e3f2fd',
                    color: '#1976d2',
                    border: '1px solid #90caf9',
                    fontSize: '0.5rem',
                    padding: '2px 6px',
                    borderRadius: '8px',
                    fontWeight: 'normal',
                    display: 'inline-block',
                    boxShadow: 'none',
                    cursor: 'default',
                  }}
                >
                  👥 Group Visitor
                </span>
              </div>
            )
          }
          return null
        })()}
      </div>
    </div>
  )
}

export default UserCard
