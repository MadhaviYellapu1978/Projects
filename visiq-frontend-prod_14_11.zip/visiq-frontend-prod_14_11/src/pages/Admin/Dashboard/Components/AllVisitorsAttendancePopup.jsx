import React, { useState, useEffect } from 'react'
import {
  Modal,
  Box,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Typography,
  Avatar,
  Tooltip,
} from '@mui/material'
import ExpandMoreIcon from '@mui/icons-material/ExpandMore'
import PrimaryBtn from '../../../../shared/Buttons/PrimaryBtn'
import { entry, exit, id } from '../../../../assets'
import EmailIcon from '@mui/icons-material/Email'
import PhoneIcon from '@mui/icons-material/Phone'
import moment from 'moment/moment'
import BusinessIcon from '@mui/icons-material/Business'
import PersonIcon from '@mui/icons-material/Person'

const AllVisitorsAttendancePopup = ({ user }) => {
  console.log(user, 'user user useruser user useruser user useruser user user')
  const [attendanceData, setAttendanceData] = useState({})
  const [openAttendanceModal, setOpenAttendanceModal] = useState(false)
  const [openVisitorModal, setOpenVisitorModal] = useState(false)
  const [status] = useState(user.isEntry ? 'In' : 'Out')
  useEffect(() => {
    if (user && user.attendanceData) {
      const formattedData = user.attendanceData.reduce((acc, record) => {
        let date = 'Today'
        const dateString =
          record?.entry_time === '-'
            ? record?.exit_time?.split(' ')[0]
            : record?.entry_time?.split(' ')[0]

        if (dateString) {
          // Try parsing with different formats
          const momentDate = moment(
            dateString,
            [
              'YYYY-MM-DD',
              'DD-MM-YYYY',
              'MM/DD/YYYY',
              'YYYY/MM/DD',
              'DD/MM/YYYY',
              'MM-DD-YYYY',
              'YYYY-MM-DD HH:mm:ss',
              'DD-MM-YYYY HH:mm:ss',
            ],
            true,
          )
          if (momentDate.isValid()) {
            date = momentDate.format('DD/MM/YY')
          } else {
            // Try parsing without strict format matching as fallback
            const looseMomentDate = moment(dateString)
            if (looseMomentDate.isValid()) {
              date = looseMomentDate.format('DD/MM/YY')
            } else {
              // If all parsing fails, try to extract date manually from the string
              const dateMatch = dateString.match(
                /(\d{1,2})[-/](\d{1,2})[-/](\d{4})/,
              )
              if (dateMatch) {
                const [, day, month, year] = dateMatch
                const parsedDate = moment(
                  `${year}-${month}-${day}`,
                  'YYYY-MM-DD',
                )
                if (parsedDate.isValid()) {
                  date = parsedDate.format('DD/MM/YY')
                }
              }
            }
          }
        }

        if (!acc[date]) {
          acc[date] = []
        }
        acc[date].push({
          entry_time:
            record.entry_time !== '-' ? record.entry_time.split(' ')[1] : '--',
          exit_time:
            record.exit_time !== '-' ? record.exit_time.split(' ')[1] : '--',
        })
        return acc
      }, {})
      setAttendanceData(formattedData)
    }
  }, [user])

  const handleOpenAttendance = () => setOpenAttendanceModal(true)
  const handleCloseAttendance = () => setOpenAttendanceModal(false)

  const handleOpenVisitor = () => setOpenVisitorModal(true)
  const handleCloseVisitor = () => setOpenVisitorModal(false)

  return (
    <div className="w-full">
      <div className="mb-4">
        <PrimaryBtn
          text={'View Attendance'}
          handleClick={handleOpenAttendance}
          fullWidth
        />
      </div>
      <div className="mb-4 text-center">
        <button
          className="text-blue-500 hover:underline"
          onClick={handleOpenVisitor}
        >
          View Visitor Details
        </button>
      </div>

      {/* Attendance Modal */}
      <Modal
        open={openAttendanceModal}
        onClose={handleCloseAttendance}
        aria-labelledby="attendance-modal-title"
        aria-describedby="attendance-modal-description"
      >
        <Box
          sx={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: 600, // Increased width
            bgcolor: 'background.paper',
            border: '0px solid #000',
            boxShadow: 24,
            p: 4,
            outline: 'none',
            borderRadius: 3,
            paddingY: 10,
            maxHeight: 500,
            overflowY: 'auto',
          }}
        >
          <Typography
            variant="h5"
            component="h2"
            id="attendance-modal-title"
            className="absolute top-6 left-1/2 transform -translate-x-1/2 text-center "
            sx={{ fontWeight: 'bold' }}
          >
            Attendance Data
          </Typography>
          {Object.entries(attendanceData).map(([date, records], index) => (
            <Accordion key={date}>
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls={`panel${index}-content`}
                id={`panel${index}-header`}
              >
                <Typography
                  variant="body1"
                  component="span"
                  sx={{ fontWeight: 'bold' }}
                >
                  {date}
                </Typography>
              </AccordionSummary>

              <AccordionDetails>
                {records.map((record, idx) => (
                  <div key={idx} className="flex justify-between my-2">
                    <p className="flex gap-3 items-center">
                      <img src={entry} alt="entry" />
                      {record.entry_time}
                    </p>
                    <p className="flex gap-3 items-center">
                      {record.exit_time === '23:59:59' ? (
                        <span className="text-xs text-gray-500">
                          Auto Checkout
                        </span>
                      ) : (
                        <></>
                      )}
                      <img src={exit} alt="exit" />
                      {record.exit_time !== 'Missing'
                        ? record.exit_time
                        : 'Missing'}
                    </p>
                  </div>
                ))}
              </AccordionDetails>
            </Accordion>
          ))}
          <button
            className="btn btn-sm btn-circle btn-ghost absolute right-2 top-2"
            onClick={handleCloseAttendance}
          >
            ✕
          </button>
        </Box>
      </Modal>

      {/* Visitor Details Modal */}
      <Modal
        open={openVisitorModal}
        onClose={handleCloseVisitor}
        aria-labelledby="visitor-modal-title"
        aria-describedby="visitor-modal-description"
      >
        <Box
          sx={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: 350,
            bgcolor: 'background.paper',
            border: '0px solid #000',
            boxShadow: 24,
            outline: 'none',
            borderRadius: 3,
            paddingY: 10,
            overflowY: 'auto',
            backgroundImage: `url(${id})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        >
          {user && (
            <div className="flex flex-col items-center">
              <Avatar
                alt={user.first_name}
                src={user.recent_captured_pic}
                sx={{ width: 120, height: 120, marginBottom: 2 }} // Increased size
              />
              <Typography
                variant="p"
                component="h3"
                sx={{
                  textAlign: 'center',
                  mb: 2,
                  color:
                    user === 'In'
                      ? 'green'
                      : status === 'Out'
                        ? 'red'
                        : '#ff6a00',
                }}
                border={
                  status === 'In'
                    ? '1px solid green'
                    : status === 'Out'
                      ? '1px solid red'
                      : '1px solid orange'
                }
                bgcolor={
                  status === 'In'
                    ? '#beedad'
                    : status === 'Out'
                      ? '#ffd6d6'
                      : '#ffe4d6'
                }
                px={2}
                borderRadius={100}
              >
                {status}
              </Typography>
              <Tooltip title={`${user.first_name} ${user.last_name}`}>
                <Typography variant="h6">
                  {`${user.first_name} ${user.last_name}`.length > 20
                    ? `${user.first_name} ${user.last_name}`.substring(0, 20) +
                      '...'
                    : `${user.first_name} ${user.last_name}`}
                </Typography>
              </Tooltip>
              <div className="mt-2 text-center">
                <div className="flex items-center justify-start mb-2">
                  <BusinessIcon sx={{ marginRight: 1 }} fontSize="12px" />
                  <p className="text-md">{user.visitor_company_name}</p>
                </div>
                <div className="flex items-center justify-start mb-2">
                  <EmailIcon sx={{ marginRight: 1 }} fontSize="12px" />
                  <p className="text-md">
                    {(() => {
                      const email = user.email || ''
                      const isValidEmail =
                        email &&
                        email.trim() !== '' &&
                        email.includes('@') &&
                        !email.includes('XXXXXXXXXX') &&
                        email !== 'no-email@example.com'
                      return isValidEmail ? email : 'N/A'
                    })()}
                  </p>
                </div>
                <div className="flex items-center justify-start">
                  <PhoneIcon sx={{ marginRight: 1 }} fontSize="12px" />
                  <p className="text-md">
                    {(() => {
                      const phoneNumber = user.ph_no || user.phone || ''
                      const countryCode = user.ph_ext || ''
                      const isPhoneValid =
                        phoneNumber &&
                        phoneNumber.trim() !== '' &&
                        !phoneNumber.includes('XXXXXXXXXX')
                      if (!isPhoneValid) {
                        return 'N/A'
                      }
                      const formattedCountryCode = countryCode
                        ? countryCode.startsWith('+')
                          ? countryCode
                          : `+${countryCode}`
                        : ''
                      return formattedCountryCode && phoneNumber
                        ? `${formattedCountryCode}-${phoneNumber}`
                        : phoneNumber
                    })()}
                  </p>
                </div>
                <div className="flex items-center justify-start">
                  <PersonIcon sx={{ marginRight: 1 }} fontSize="12px" />
                  <p className="text-md">{user.role_name}</p>
                </div>

                {/* Group Visitor indicator */}
                {user.visitor_type === 'group_visitor' && (
                  <div className="flex items-center justify-center mt-3">
                    <span
                      style={{
                        backgroundColor: '#e3f2fd',
                        color: '#1976d2',
                        border: '1px solid #90caf9',
                        fontSize: '0.8rem',
                        padding: '4px 8px',
                        borderRadius: '6px',
                        fontWeight: 'bold',
                        textAlign: 'center',
                      }}
                    >
                      Group Visitor
                    </span>
                  </div>
                )}

                {/* Debug: Log all available fields to console */}
                {console.log('🔍 Full user data:', user)}
                {console.log('🔍 visitor_type:', user.visitor_type)}
                {console.log('🔍 All keys:', Object.keys(user))}
              </div>
            </div>
          )}
          <button
            className="btn btn-sm btn-circle btn-ghost absolute right-2 top-2"
            onClick={handleCloseVisitor}
          >
            ✕
          </button>
        </Box>
      </Modal>
    </div>
  )
}

export default AllVisitorsAttendancePopup
