/* eslint-disable jsx-a11y/label-has-associated-control */
import React, { useState } from 'react'
import UserCard from './AllVisitorUserCard'
import Papa from 'papaparse'
import { saveAs } from 'file-saver'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {
  faDownload,
  faToggleOn,
  faToggleOff,
} from '@fortawesome/free-solid-svg-icons'
import jsPDF from 'jspdf'
import 'jspdf-autotable'
import { format } from 'date-fns'
import { pdf } from '@react-pdf/renderer'
import VisitorsPDF from './PdfDownload'
import VisitorsPDFDetailed from './pdfDownloadDetailed'
import { formatDate, formatTime } from '../../../../utils/dateFormat'

const AllVisitorsAttendance = (props) => {
  const {
    userData,
    noShowVisitorsData,
    branch,
    data_of_visit,
    name,
    report_name,
  } = props
  const [filter, setFilter] = useState('')
  const [isPDF, setIsPDF] = useState(true) // Toggle state for PDF/CSV

  const handleToggle = () => {
    setIsPDF(!isPDF)
  }

  console.log(
    userData,
    'userDatauserData userData userDatauserDatauserData userData userData',
  )
  console.log('🔍 AllVisitorsAttendance - userData length:', userData?.length)
  console.log(
    '🔍 AllVisitorsAttendance - userData structure:',
    userData?.map((u) => ({
      name: u.first_name,
      visitor_type: u.visitor_type,
      last_entry: formatDate(u.last_entry) || u.last_entry,
      last_exit: formatDate(u.last_exit) || u.last_exit,
      hasGroupDetails: !!u.grp_details?.length,
    })),
  )
  console.log(
    '🔍 AllVisitorsAttendance - visitor_type values:',
    userData?.map((u) => ({
      name: u.first_name,
      visitor_type: u.visitor_type,
      raw_visitor_type: u.visitor_type,
    })),
  )
  console.log('Branch prop:', branch)
  console.log('Data of visit prop:', data_of_visit)
  console.log('Name prop:', name)
  const _convertImageToBase64 = async (url) => {
    try {
      const addingRegionPhoto = `https://visiqbucket.s3.us-east-1.${url.split('https://visiqbucket.s3.')[1]}`
      const response = await fetch(addingRegionPhoto)
      if (!response.ok) throw new Error('Image fetch failed')

      const blob = await response.blob()
      const reader = new FileReader()

      return await new Promise((resolve, reject) => {
        reader.onloadend = () => resolve(reader.result)
        reader.onerror = () => reject(new Error('Failed to read image'))
        reader.readAsDataURL(blob)
      })
    } catch (error) {
      console.error('Failed to convert image:', error)
      return null
    }
  }
  const _convertImageToBase64s = async (url) => {
    try {
      if (!url || url === '' || !url.startsWith('http')) {
        return null
      }
      
      // Handle different S3 URL formats
      let imageUrl = url
      if (url.includes('ap-south-1')) {
        imageUrl = url
      } else if (url.includes('https://visiqbucket.s3.')) {
        imageUrl = `https://visiqbucket.s3.us-east-1.${url.split('https://visiqbucket.s3.')[1]}`
      }
      
      const response = await fetch(imageUrl)
      if (!response.ok) {
        return null
      }
      const blob = await response.blob()

      return await new Promise((resolve, reject) => {
        const reader = new FileReader()
        reader.onloadend = () => resolve(reader.result)
        reader.onerror = reject
        reader.readAsDataURL(blob)
      })
    } catch (error) {
      console.error('Error converting image:', error)
      return null
    }
  }

  const downloadPDF = async () => {
    try {
      console.log('Download PDF button clicked!')
      console.log('UserData length:', userData?.length)
      console.log(data_of_visit, 'date_of_visit')

      if (!userData || userData.length === 0) {
        console.error('No user data available for PDF generation')
        return
      }

      // Convert photo URLs to base64
      const updatedUserData = await Promise.all(
        userData.map(async (user) => {
          let photoBase64 = null
          if (user.photo && user.photo !== '' && user.photo !== 'N/A') {
            photoBase64 = await _convertImageToBase64s(user.photo)
          }
          
          return {
        ...user,
            photo: photoBase64 || user.photo || '', // Use base64 if available, otherwise keep original or empty
            ph_no: user.ph_no && user.ph_ext ? `${user.ph_ext}-${user.ph_no}` : 'N/A',
        visitor_code: user.visitor_code || user.last_visited_code || '', // Ensure visitor_code is mapped
        visitor_type: user.visitor_type || 'individual_visitor', // Ensure visitor_type is mapped
          }
        }),
      )
      console.log(updatedUserData, 'updatedUserDataupdatedUserData')

      console.log('Generating PDF blob...')

      // Fix date formatting to prevent "Invalid time value" error
      let safeDataOfVisit = data_of_visit
      if (data_of_visit) {
        try {
          safeDataOfVisit = {
            from_date: data_of_visit.from_date
              ? formatDate(data_of_visit.from_date)
              : null,
            to_date: data_of_visit.to_date
              ? formatDate(data_of_visit.to_date)
              : null,
            visit_date: data_of_visit.visit_date
              ? formatDate(data_of_visit.visit_date)
              : null,
          }
        } catch (dateError) {
          console.error('Date formatting error:', dateError)
          safeDataOfVisit = {
            from_date: null,
            to_date: null,
            visit_date: null,
          }
        }
      }

      const blob = await pdf(
        <VisitorsPDF
          userData={updatedUserData}
          branch={branch}
          name={name}
          data_of_visit={safeDataOfVisit}
          report_name={report_name}
        />,
      ).toBlob()

      console.log('PDF blob generated, creating download link...')
      const url = URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = 'visitors_report.pdf'
      link.click()
      URL.revokeObjectURL(url)
      console.log('PDF download initiated successfully!')
    } catch (error) {
      console.error('Error generating PDF:', error)
      alert('Error generating PDF: ' + error.message)
    }
  }

  const downloadDetailedPDF = async () => {
    try {
      console.log('Download Detailed PDF button clicked!')
      console.log('UserData length:', userData?.length)
      console.log('ALL RECORDDDDDDDDDD ', userData)

      if (!userData || userData.length === 0) {
        console.error('No user data available for detailed PDF generation')
        return
      }

      // Convert photo URLs to base64 for detailed PDF
      const updatedUserData = await Promise.all(
        userData.map(async (user) => {
          let photoBase64 = null
          if (user.photo && user.photo !== '' && user.photo !== 'N/A') {
            photoBase64 = await _convertImageToBase64s(user.photo)
          }
          
        const rows = user.attendanceData.map((att) => ({
          first_name: user.first_name || '',
          visitor_type: user.visitor_type || 'individual_visitor', // Include visitor_type
          role_name: user.role_name || '',
          purpose_of_visit: user.purpose_of_visit || '',
          area_of_permit: user.area_of_permit || '',
          asset: user.asset || '',
          ph_ext: user.ph_ext || '',
            ph_no: user.ph_no && user.ph_ext ? `${user.ph_ext}-${user.ph_no}` : 'N/A',
            email: user.email || 'N/A',
          last_entry: formatDate(user.last_entry) || '',
          last_exit: formatDate(user.last_exit) || '',
          visitor_company_name: user.visitor_company_name || '',
          visitor_code: user.visitor_code || user.last_visited_code || '', // Map visitor_code for detailed PDF
          last_visited_code: user.visitor_code || user.last_visited_code || '', // Keep for backward compatibility
            photo: photoBase64 || user.photo || '', // Use base64 if available, otherwise keep original or empty
          kyc_type: user.kyc_type || '',
          kyc_id: user.kyc_id || '',
          entry_time: att.entry_time || '',
          exit_time: att.exit_time || '',
          // Add blacklist fields for detailed PDF
          black_listed: user.black_listed || false,
          blacklisted: user.blacklisted || false,
          blacklist_status: user.blacklist_status || '',
          is_blacklisted: user.is_blacklisted || false,
          status: user.status || '',
        }))

        return rows
        }),
      )

      const flattenedUserData = updatedUserData.flat()
      console.log(
        flattenedUserData,
        'flattenedUserData flattenedUserData flattenedUserData',
      )

      // Generate the PDF using a React component
      console.log('Generating detailed PDF blob...')

      // Fix date formatting to prevent "Invalid time value" error
      let safeDataOfVisit = data_of_visit
      if (data_of_visit) {
        try {
          safeDataOfVisit = {
            from_date: data_of_visit.from_date
              ? formatDate(data_of_visit.from_date)
              : null,
            to_date: data_of_visit.to_date
              ? formatDate(data_of_visit.to_date)
              : null,
            visit_date: data_of_visit.visit_date
              ? formatDate(data_of_visit.visit_date)
              : null,
          }
        } catch (dateError) {
          console.error('Date formatting error:', dateError)
          safeDataOfVisit = {
            from_date: null,
            to_date: null,
            visit_date: null,
          }
        }
      }

      const blob = await pdf(
        <VisitorsPDFDetailed
          userData={flattenedUserData}
          branch={branch}
          name={name}
          data_of_visit={safeDataOfVisit}
          report_name={report_name}
        />,
      ).toBlob()

      // Download
      console.log('Detailed PDF blob generated, creating download link...')
      const url = URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = 'visitors_detailed_report.pdf'
      link.click()
      URL.revokeObjectURL(url)
      console.log('Detailed PDF download initiated successfully!')
    } catch (error) {
      console.error('Error generating detailed PDF:', error)
      alert('Error generating detailed PDF: ' + error.message)
    }
  }
  // Function to map visitor_type to display names
  const getVisitorTypeDisplay = (visitorType) => {
    if (!visitorType) {
      return 'Individual Visitor'
    }
    
    // Normalize to lowercase for case-insensitive comparison
    const normalized = String(visitorType).toLowerCase().trim()
    
    switch (normalized) {
      case 'group_visitor':
      case 'group':
        return 'Group Visitor'
      case 'main_visitor':
      case 'main':
        return 'Main Visitor'
      case 'individual_visitor':
      case 'individual':
        return 'Individual Visitor'
      case 'group_member':
      case 'member':
        return 'Group Member'
      default:
        // If it's a known format but doesn't match, try to format it
        if (normalized.includes('group')) {
          return 'Group Visitor'
        }
        if (normalized.includes('main')) {
          return 'Main Visitor'
        }
        if (normalized.includes('individual')) {
          return 'Individual Visitor'
        }
        return 'Individual Visitor'
    }
  }

  const downloadCSV = () => {
    // Debug: Log the userData to see what visitor_type values we're getting
    console.log(
      '🔍 CSV Export - userData sample:',
      userData.slice(0, 3).map((u) => ({
        name: u.first_name,
        visitor_type: u.visitor_type,
        raw_visitor_type: u.visitor_type,
      })),
    )

    // Ensure `userData` is mapped correctly
    const csvData = userData.map((user) => {
      console.log(
        `🔍 CSV Processing user:`,
        user.first_name,
        'visitor_type:',
        user.visitor_type,
      )
      return {
        Name: user.first_name || '',
        'Visitor Type': getVisitorTypeDisplay(user.visitor_type),
        Category: user.role_name || '',
        'Purpose of Visit': user.purpose_of_visit || '',
        'Area of Permit': user.area_of_permit || 'N/A',
        Asset: user.asset || 'N/A',
        'Phone Number': user.ph_no && user.ph_ext ? `\t${user.ph_ext}-${user.ph_no}` : 'N/A',
        Email: user.email || 'N/A',
        'Last Entry': formatDate(user.last_entry) || '-',
        'Last Exit': formatDate(user.last_exit) || '-',
        'Visitor Company Name': user.visitor_company_name || '',
        'Access Reference Code': `\t${user.visitor_code || user.last_visited_code || ''}`,
        'KYC Type': user.kyc_type || '',
        'KYC ID': `\t${user.kyc_id}` || '',
        Blacklist:
          user.black_listed === true ||
          user.blacklisted === true ||
          user.blacklist_status === 'blacklisted' ||
          user.is_blacklisted === true ||
          user.status === 'Blacklisted'
            ? 'Yes'
            : 'No',
        // Keep Photo column at the end
        Photo: (() => {
          const url = user.photo || ''
          if (!url) return 'N/A'
          if (url.startsWith('http')) return url
          try {
            if (url.includes('visiqbucket.s3.')) {
              return `https://visiqbucket.s3.us-east-1.${url.split('https://visiqbucket.s3.')[1]}`
            }
          } catch (e) {
            // fallback to original url string
          }
          return url
        })(),
      }
    })

    // Add metadata header with date range in DD-MM-YYYY format
    let csvRows = []
    csvRows.push(`"Report: ${report_name || 'Visitor Reports'}"`)
    csvRows.push(`"Admin: ${name || ''}"`)
    csvRows.push(`"Branch: ${branch?.branch_name || 'N/A'}"`)
    
    // Format date range
    if (data_of_visit && data_of_visit.from_date && data_of_visit.to_date) {
      const fromDate = formatDate(data_of_visit.from_date)
      const toDate = formatDate(data_of_visit.to_date)
      csvRows.push(`"Date Range: ${fromDate} to ${toDate}"`)
    } else if (data_of_visit && data_of_visit.visit_date) {
      const visitDate = formatDate(data_of_visit.visit_date)
      csvRows.push(`"Date: ${visitDate}"`)
    } else {
      csvRows.push('"Date: All Time"')
    }
    csvRows.push('') // Empty row for spacing

    // Convert data to CSV format
    const csvDataString = Papa.unparse(csvData)
    
    // Combine header and data
    const csv = csvRows.join('\n') + '\n' + csvDataString
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    saveAs(blob, 'All Visitors Attendance Report.csv')
  }

  // Download functions for Group Booking and Vehicle/Material PDF
  const downloadGroupBookingPDF = async () => {
    const doc = new jsPDF({
      orientation: 'landscape',
      unit: 'pt',
      format: [842, 595], // A4 landscape size
    })

    // Enhanced debug logging
    console.log('🔍 Group Booking PDF - Starting download...')
    console.log('🔍 Group Booking PDF - Branch:', branch)
    console.log('🔍 Group Booking PDF - Data of visit:', data_of_visit)
    console.log('🔍 Group Booking PDF - Name:', name)
    console.log('🔍 Group Booking PDF - userData length:', userData?.length)
    console.log(
      '🔍 Group Booking PDF - noShowVisitorsData length:',
      noShowVisitorsData?.length,
    )
    console.log('🔍 Group Booking PDF - userData sample:', userData?.[0])
    console.log('🔍 Group Booking PDF - Timestamp:', new Date().toISOString())

    // Simple, clean header with 12px spacing
    doc.setFontSize(20)
    doc.text('Group Booking Report', 14, 30)
    doc.setFontSize(12)

    // Admin name with 12px spacing
    doc.text(`Admin: ${String(name || 'N/A')}`, 14, 50)

    // Branch name with 12px spacing
    doc.text(`Branch: ${String(branch?.branch_name || 'N/A')}`, 14, 62)

    // Date information with 12px spacing
    let dateText = ''
    console.log('Date processing - data_of_visit:', data_of_visit)
    if (data_of_visit && data_of_visit.from_date && data_of_visit.to_date) {
      const fromDate = formatDate(data_of_visit.from_date)
      const toDate = formatDate(data_of_visit.to_date)
      dateText = `Date: ${fromDate} to ${toDate}`
      console.log('Using from_date and to_date:', dateText)
    } else if (data_of_visit && data_of_visit.visit_date) {
      const visitDate = formatDate(data_of_visit.visit_date)
      dateText = `Date: ${visitDate}`
      console.log('Using visit_date:', dateText)
    } else if (data_of_visit) {
      dateText = `Date: ${formatDate(data_of_visit)}`
      console.log('Using data_of_visit as date:', dateText)
    } else {
      dateText = 'Date: All Time'
      console.log('Using All Time:', dateText)
    }

    console.log('Final dateText:', dateText)
    doc.text(dateText, 14, 74)
    // Format "Generated on" date as DD-MM-YYYY HH:mm:ss
    const now = new Date()
    const generatedDate = formatDate(now.toISOString().split('T')[0])
    const generatedTime = format(now, 'HH:mm:ss')
    doc.text(
      `Generated on: ${generatedDate} ${generatedTime}`,
      14,
      86,
    )

    // Table columns
    const tableColumns = [
      { header: 'Group Member Name', dataKey: 'name' },
      { header: 'Main Visitor Name', dataKey: 'mainVisitorName' },
      { header: 'Visitor Type', dataKey: 'visitorType' },
      { header: 'Role', dataKey: 'role' },
      { header: 'Phone Number', dataKey: 'phone' },
      { header: 'Email', dataKey: 'email' },
      { header: 'ID Proof', dataKey: 'idProof' },
    ]

    // Process data and convert images to base64
    const tableRows = []
    let hasGroupData = false

    // Filter for only group visitors (visitor_type: "group_visitor")
    // Use ONLY usersDataList for group visitors (not noShowVisitorsData)
    const dataSource = userData

    // Filter for group visitors only
    const groupVisitors = dataSource.filter((visitor) => {
      const isGroupVisitor =
        visitor.visitor_type === 'group_visitor' ||
        visitor.grp_book_bool === true
      console.log('🔍 Group Booking PDF - Visitor filter:', {
        name: visitor.first_name,
        visitor_type: visitor.visitor_type,
        grp_book_bool: visitor.grp_book_bool,
        isGroupVisitor: isGroupVisitor,
        hasGroupDetails: !!visitor.grp_details?.length,
      })
      return isGroupVisitor
    })

    console.log('🔍 Group Booking PDF - Total visitors:', dataSource.length)
    console.log(
      '🔍 Group Booking PDF - Group visitors found:',
      groupVisitors.length,
    )

    // Debug: Show all visitor types in the data
    console.log(
      '🔍 Group Booking PDF - All visitor types in data:',
      dataSource.map((v) => ({
        name: v.first_name,
        visitor_type: v.visitor_type,
        grp_book_bool: v.grp_book_bool,
        hasGroupDetails: !!v.grp_details?.length,
      })),
    )

    // Debug: Show what we're looking for
    console.log('🔍 Group Booking PDF - Looking for visitors with:')
    console.log('  - visitor_type === "group_visitor"')
    console.log('  - OR grp_book_bool === true')

    for (const visitor of groupVisitors) {
      console.log('🔍 Group Booking PDF - Processing group visitor:', {
        name: visitor.first_name,
        visitor_type: visitor.visitor_type,
        grp_book_bool: visitor.grp_book_bool,
        hasGroupDetails: !!visitor.grp_details?.length,
        groupDetailsLength: visitor.grp_details?.length || 0,
        groupDetails: visitor.grp_details,
      })

      // Show the group visitor themselves (not looking for grp_details)
      console.log(
        '🔍 Group Booking PDF - Adding group visitor to report:',
        visitor.first_name,
      )
      hasGroupData = true

      let idProofImage = 'N/A'

      // Convert image to base64 if available
      if (
        visitor.id_proof &&
        visitor.id_proof !== 'N/A' &&
        visitor.id_proof !== '' &&
        visitor.id_proof.startsWith('http')
      ) {
        try {
          console.log(
            'Processing visitor ID proof image URL:',
            visitor.id_proof,
          )

          const response = await fetch(visitor.id_proof)
          if (!response.ok) {
            throw new Error(`Failed to fetch image: ${response.status}`)
          }

          const blob = await response.blob()
          console.log(
            'Visitor ID proof image blob size:',
            blob.size,
            'type:',
            blob.type,
          )

          if (blob.size === 0) {
            throw new Error('Empty image blob')
          }

          const base64 = await new Promise((resolve, reject) => {
            const reader = new FileReader()
            reader.onloadend = () => resolve(reader.result)
            reader.onerror = reject
            reader.readAsDataURL(blob)
          })

          console.log(
            'Visitor ID proof base64 conversion successful, length:',
            base64.length,
          )
          idProofImage = base64
        } catch (error) {
          console.error(
            'Error converting visitor ID proof image to base64:',
            error,
          )
          idProofImage = 'No ID Proof'
        }
      } else {
        idProofImage = 'No ID Proof'
      }

      tableRows.push({
        name: visitor.first_name || visitor.name || 'N/A',
        role: visitor.role_name || visitor.role || 'N/A',
        phone:
          `${visitor.ph_ext || ''}-${visitor.ph_no || visitor.phone || ''}` ||
          'N/A',
        email: visitor.email || 'N/A',
        mainVisitorName: visitor.main_visitor_name || 'N/A',
        visitorType: getVisitorTypeDisplay(visitor.visitor_type),
        idProof: idProofImage,
      })

      // Skip the old grp_details logic
      if (false && visitor.grp_details && visitor.grp_details.length > 0) {
        console.log(
          '🔍 Group Booking PDF - Found group details for visitor:',
          visitor.first_name,
        )
        hasGroupData = true
        for (const member of visitor.grp_details) {
          let idProofImage = 'N/A'

          // Convert image to base64 if available
          if (
            member.grp_user_id_proof &&
            member.grp_user_id_proof !== 'Image uploaded successfully!' &&
            typeof member.grp_user_id_proof === 'string' &&
            member.grp_user_id_proof.startsWith('http')
          ) {
            try {
              console.log('Processing image URL:', member.grp_user_id_proof)

              // Fix S3 URLs for images
              let imageUrl = member.grp_user_id_proof
              if (imageUrl.includes('visiqbucket.s3.')) {
                imageUrl = `https://visiqbucket.s3.us-east-1.${imageUrl.split('https://visiqbucket.s3.')[1]}`
              }

              console.log('Fixed image URL:', imageUrl)

              const response = await fetch(imageUrl)
              if (!response.ok) {
                throw new Error(`Failed to fetch image: ${response.status}`)
              }

              const blob = await response.blob()
              console.log('Image blob size:', blob.size, 'type:', blob.type)

              if (blob.size === 0) {
                throw new Error('Empty image blob')
              }

              const base64 = await new Promise((resolve, reject) => {
                const reader = new FileReader()
                reader.onloadend = () => {
                  const result = reader.result
                  console.log(
                    'Base64 result length:',
                    result ? result.length : 'null',
                  )
                  resolve(result)
                }
                reader.onerror = () => reject(new Error('Failed to read image'))
                reader.readAsDataURL(blob)
              })

              // Validate base64 string
              if (base64 && base64.startsWith('data:image/')) {
                idProofImage = base64
                console.log('Successfully converted image to base64')
              } else {
                throw new Error('Invalid base64 result')
              }
            } catch (error) {
              console.log('Error loading image:', error)
              idProofImage = 'Image not available'
            }
          } else {
            console.log(
              'Skipping image processing for:',
              member.grp_user_id_proof,
              'Type:',
              typeof member.grp_user_id_proof,
            )
            // Handle cases where grp_user_id_proof might be an object or other data type
            if (typeof member.grp_user_id_proof === 'object') {
              idProofImage = 'Invalid ID Proof Data'
            } else if (
              member.grp_user_id_proof === 'Image uploaded successfully!'
            ) {
              idProofImage = 'Image uploaded but path not available'
            } else {
              idProofImage = 'No ID Proof'
            }
          }

          tableRows.push({
            name: member.grp_user_name || 'N/A',
            role: member.grp_user_role_name || 'N/A',
            phone:
              `${member.grp_user_phext || ''}-${member.grp_user_phno || ''}` ||
              'N/A',
            email: member.grp_user_email || 'N/A',
            visitorType: getVisitorTypeDisplay('group_member'),
            idProof: idProofImage,
          })
        }
      } else {
        console.log(
          '🔍 Group Booking PDF - No group details found for visitor:',
          visitor.first_name,
        )
      }
    }

    // If no group data found, show message only without table
    if (!hasGroupData || tableRows.length === 0) {
      // Show message instead of empty table
      doc.setFontSize(14)
      doc.setTextColor(0, 0, 0)
      doc.text('No Group Booking Data Available', 14, 120)
      doc.save('group_booking_report.pdf')
      return
    }

    // Add table with optimized column widths for landscape
    const headers = tableColumns.map((col) => col.header)
    console.log('Table headers:', headers)
    console.log('Number of columns:', headers.length)
    console.log('Table columns array:', tableColumns)

    doc.autoTable({
      startY: 100,
      head: [headers],
      columns: tableColumns,
      tableWidth: 'wrap',
      margin: { left: 20, right: 20, top: 30, bottom: 30 },
      showHead: 'everyPage',
      body: tableRows
        .filter((row) => {
          // Filter out empty or invalid rows
          return (
            row &&
            row.name &&
            row.name.trim() !== '' &&
            row.role &&
            row.role.trim() !== '' &&
            row.phone &&
            row.phone.trim() !== '' &&
            row.email &&
            row.email.trim() !== '' &&
            // Ensure all required fields are present
            typeof row.name === 'string' &&
            typeof row.role === 'string' &&
            typeof row.phone === 'string' &&
            typeof row.email === 'string'
          )
        })
        .map((row) => {
          console.log('Processing row for PDF:', {
            name: row.name,
            idProof: row.idProof,
            idProofType: typeof row.idProof,
            isBase64: row.idProof && row.idProof.startsWith('data:image/'),
          })
          console.log('Full row data:', row)

          let idProofCell
          if (
            row.idProof === 'N/A' ||
            row.idProof === 'Image not available' ||
            row.idProof === 'No ID Proof' ||
            row.idProof === 'Invalid ID Proof Data' ||
            row.idProof === 'Image uploaded but path not available' ||
            !row.idProof ||
            typeof row.idProof !== 'string' ||
            !row.idProof.startsWith('data:image/') ||
            row.idProof.length < 100 // Ensure it's a valid base64 image
          ) {
            idProofCell = 'No ID Proof'
          } else {
            // For valid images, return a special marker that will be handled by didDrawCell
            idProofCell = 'IMAGE_PLACEHOLDER'
            console.log(
              'Valid image data found for',
              row.name,
              ':',
              row.idProof.substring(0, 50) + '...',
            )
          }

          const rowData = [
            row.name,
            row.mainVisitorName || 'N/A',
            row.visitorType || 'N/A',
            row.role,
            row.phone,
            row.email,
            idProofCell,
          ]
          console.log('Row data for PDF:', rowData)
          console.log('Number of columns in row:', rowData.length)
          return rowData
        }),
      styles: {
        fontSize: 7, // Smaller font for single page
        cellPadding: 3, // Reduced padding
        lineColor: [200, 200, 200], // Light gray grid lines like in the image
        lineWidth: 0.5, // Visible grid lines
        minCellHeight: 35, // Increased row height for better ID proof visibility
        valign: 'middle',
        textColor: [0, 0, 0], // Black text
        fontStyle: 'normal',
        halign: 'center',
      },
      columnStyles: {
        0: { cellWidth: 120 }, // Group Member Name
        1: { cellWidth: 120 }, // Main Visitor Name
        2: { cellWidth: 90 }, // Visitor Type
        3: { cellWidth: 80 }, // Role
        4: { cellWidth: 110 }, // Phone Number
        5: { cellWidth: 150 }, // Email
        6: {
          cellWidth: 80,
          cellHeight: 35, // Increased height for better ID proof image visibility
          halign: 'center',
          lineColor: [200, 200, 200], // Light gray grid lines
          lineWidth: 0.5, // Visible lines
        }, // ID Proof
      },
      headStyles: {
        fillColor: [39, 174, 96],
        textColor: [255, 255, 255],
        fontSize: 9,
        fontStyle: 'bold',
        lineColor: [200, 200, 200], // Light gray grid lines
        lineWidth: 0.5, // Visible lines
        cellPadding: 4,
        halign: 'center',
        valign: 'middle',
      },
      didDrawCell: (data) => {
        // Handle image rendering in ID Proof column (column index 6)
        if (data.column.index === 6) {
          // Prevent any text from being rendered in image cells
          if (data.cell.raw === 'IMAGE_PLACEHOLDER') {
            // Clear the cell completely before rendering image
            data.doc.setFillColor(255, 255, 255)
            data.doc.rect(
              data.cell.x,
              data.cell.y,
              data.cell.width,
              data.cell.height,
              'F',
            )
          }
          // Find the corresponding row data to get the original image
          const rowIndex = data.row.index
          const rowData = tableRows[rowIndex]

          console.log(`Processing cell for row ${rowIndex}:`, {
            hasRowData: !!rowData,
            idProof: rowData?.idProof?.substring(0, 50) + '...',
            isImage: rowData?.idProof?.startsWith('data:image/'),
            cellContent: data.cell.raw,
            cellPosition: {
              x: data.cell.x,
              y: data.cell.y,
              width: data.cell.width,
              height: data.cell.height,
            },
          })

          if (
            rowData &&
            rowData.idProof &&
            rowData.idProof.startsWith('data:image/') &&
            rowData.idProof.length > 100 && // Ensure it's a valid base64 image
            data.cell.raw === 'IMAGE_PLACEHOLDER'
          ) {
            try {
              console.log(
                'Rendering image for cell:',
                rowData.idProof.substring(0, 50) + '...',
              )

              // Extract base64 data
              const base64Data = rowData.idProof.split(',')[1]

              // Determine image format
              let imageFormat = 'JPEG'
              if (rowData.idProof.includes('data:image/png')) {
                imageFormat = 'PNG'
              } else if (rowData.idProof.includes('data:image/jpeg')) {
                imageFormat = 'JPEG'
              }

              // Adjustable sizing to fill most of the cell while keeping margins
              const cellWidth = data.cell.width
              const cellHeight = data.cell.height
              const padding = 6
              const imgWidth = Math.max(10, cellWidth - padding * 2)
              const imgHeight = Math.max(10, cellHeight - padding * 2)
              const x = data.cell.x + padding
              const y = data.cell.y + padding

              console.log(
                `Adding image: ${imageFormat}, size: ${imgWidth}x${imgHeight}, pos: ${x},${y}`,
                `Cell bounds: x=${data.cell.x}, y=${data.cell.y}, w=${cellWidth}, h=${cellHeight}`,
              )

              // Clear the cell content completely - no text should appear
              data.doc.setFillColor(255, 255, 255)
              data.doc.rect(
                data.cell.x,
                data.cell.y,
                data.cell.width,
                data.cell.height,
                'F',
              )

              // Add only the image - no text overlay
              data.doc.addImage(
                base64Data,
                imageFormat,
                x,
                y,
                imgWidth,
                imgHeight,
              )

              console.log('Image added successfully')
            } catch (error) {
              console.log('Error adding image to cell:', error)
              // If image fails, show "No ID Proof" instead of error text
              data.doc.setFontSize(8)
              data.doc.setFillColor(255, 255, 255)
              data.doc.rect(
                data.cell.x,
                data.cell.y,
                data.cell.width,
                data.cell.height,
                'F',
              )
              data.doc.text('No ID Proof', data.cell.x + 5, data.cell.y + 20)
            }
          } else if (
            rowData &&
            rowData.idProof &&
            rowData.idProof !== 'No ID Proof' &&
            !rowData.idProof.startsWith('data:image/') &&
            data.cell.raw !== 'IMAGE_PLACEHOLDER'
          ) {
            // Show text only for non-image ID proofs
            data.doc.setFontSize(8)
            data.doc.text(rowData.idProof, data.cell.x + 5, data.cell.y + 20)
          }
        }
      },
      horizontalPageBreak: true,
    })

    // Images are now embedded directly in the table cells

    doc.save('group_booking_report.pdf')
  }

  const downloadVehicleMaterialPDF = () => {
    const doc = new jsPDF({
      orientation: 'landscape',
      unit: 'mm',
      format: [842, 595], // A4 landscape size
    })

    // Header - matching format from other PDFs
    doc.setTextColor(0, 0, 0)
    doc.setFontSize(22) // Further increased from 18 to 22
    doc.text('Vehicle/Material Report', 14, 20)
    doc.setFontSize(16) // Further increased from 12 to 16

    // Admin name
    doc.text(`Admin: ${String(name || 'N/A')}`, 14, 35)

    // Branch name
    doc.text(`Branch: ${String(branch?.branch_name || 'N/A')}`, 14, 42)

    // Date information - matching format from other PDFs
    let dateText = ''
    if (data_of_visit && data_of_visit.from_date && data_of_visit.to_date) {
      const fromDate = formatDate(data_of_visit.from_date)
      const toDate = formatDate(data_of_visit.to_date)
      dateText = `Date: ${fromDate} to ${toDate}`
    } else if (data_of_visit && data_of_visit.visit_date) {
      const visitDate = formatDate(data_of_visit.visit_date)
      dateText = `Date: ${visitDate}`
    } else if (data_of_visit) {
      dateText = `Date: ${formatDate(data_of_visit)}`
    } else {
      dateText = 'Date: All Time'
    }

    doc.text(dateText, 14, 49)
    // Format "Generated on" date as DD-MM-YYYY HH:mm:ss
    const now = new Date()
    const generatedDate = formatDate(now.toISOString().split('T')[0])
    const generatedTime = format(now, 'HH:mm:ss')
    doc.text(
      `Generated on: ${generatedDate} ${generatedTime}`,
      14,
      56,
    )

    // Table columns
    const tableColumns = [
      'Visitor Name',
      'Visitor Type',
      'Vehicle Name',
      'Vehicle Type',
      'RC Number',
      'Driver License',
      'Insurance Provider',
      'Insurance Number',
      'Material Name',
      'Material Quantity',
      'Number of Units',
      'Device Model',
    ]

    // Process data from noShowVisitorsData which contains vehicle/material information
    const tableRows = []
    let hasVehicleMaterialData = false

    // Use noShowVisitorsData for vehicle/material data
    // Use ONLY usersDataList for group visitors (not noShowVisitorsData)
    const dataSource = userData

    dataSource.forEach((visitor) => {
      const displayName =
        `${visitor.first_name || ''} ${visitor.last_name || ''}`.trim() || 'N/A'

      // Check for vehicle/material data
      const vehicleDetails = visitor.vm_details || []
      const materialDetails = visitor.mm_details || []

      if (vehicleDetails && vehicleDetails.length > 0) {
        hasVehicleMaterialData = true
        vehicleDetails.forEach((vehicle) => {
          if (materialDetails && materialDetails.length > 0) {
            materialDetails.forEach((material) => {
              tableRows.push([
                displayName,
                getVisitorTypeDisplay(visitor.visitor_type),
                vehicle.vehicle_name || 'N/A',
                vehicle.vehicle_type || 'N/A',
                vehicle.rc_no || 'N/A',
                vehicle.driver_licence || 'N/A',
                vehicle.insurance_provider || 'N/A',
                vehicle.insurance_no || 'N/A',
                material.material_name || 'N/A',
                material.material_quantity || 'N/A',
                material.material_no_of_units || 'N/A',
                material.material_device_model || 'N/A',
              ])
            })
          } else {
            tableRows.push([
              displayName,
              visitor.visitor_type || 'Individual Visitor',
              vehicle.vehicle_name || 'N/A',
              vehicle.vehicle_type || 'N/A',
              vehicle.rc_no || 'N/A',
              vehicle.driver_licence || 'N/A',
              vehicle.insurance_provider || 'N/A',
              vehicle.insurance_no || 'N/A',
              'N/A',
              'N/A',
              'N/A',
              'N/A',
            ])
          }
        })
      } else if (materialDetails && materialDetails.length > 0) {
        hasVehicleMaterialData = true
        materialDetails.forEach((material) => {
          tableRows.push([
            displayName,
            visitor.visitor_type || 'Individual Visitor',
            'N/A',
            'N/A',
            'N/A',
            'N/A',
            'N/A',
            'N/A',
            material.material_name || 'N/A',
            material.material_quantity || 'N/A',
            material.material_no_of_units || 'N/A',
            material.material_device_model || 'N/A',
          ])
        })
      }
    })

    // If no vehicle/material data found, show message
    if (!hasVehicleMaterialData) {
      tableRows.push([
        'No Vehicle/Material Data Available',
        'N/A',
        'N/A',
        'N/A',
        'N/A',
        'N/A',
        'N/A',
        'N/A',
        'N/A',
        'N/A',
        'N/A',
        'N/A',
      ])
    }

    // Add table with styling matching Visitor Reports layout
    doc.autoTable({
      startY: 65, // Increased from 55 to 65 to accommodate larger header spacing
      head: [tableColumns],
      body: tableRows,
      styles: {
        fontSize: 15, // Maximized font size for optimal readability
        cellPadding: 6, // Increased padding for better spacing
        overflow: 'linebreak',
        halign: 'left',
        textColor: [0, 0, 0], // Black text for data rows
        // Grid lines removed for cleaner look
      },
      headStyles: {
        fillColor: [39, 174, 96], // Green header matching Visitor Reports
        fontSize: 15, // Maximized font size for optimal readability
        fontStyle: 'bold',
        textColor: [255, 255, 255], // White text for header
        halign: 'center',
        valign: 'middle',
        // Grid lines removed for cleaner look
      },
      columnStyles: {
        // Column widths maximized to use full page width - no grid lines
        0: { cellWidth: 60, halign: 'left' }, // Visitor Name
        1: { cellWidth: 60, halign: 'left' }, // Vehicle Name
        2: { cellWidth: 55, halign: 'center' }, // Vehicle Type
        3: { cellWidth: 65, halign: 'center' }, // RC Number
        4: { cellWidth: 65, halign: 'center' }, // Driver License
        5: { cellWidth: 65, halign: 'left' }, // Insurance Provider
        6: { cellWidth: 65, halign: 'center' }, // Insurance Number
        7: { cellWidth: 65, halign: 'left' }, // Material Name
        8: { cellWidth: 55, halign: 'center' }, // Material Quantity
        9: { cellWidth: 55, halign: 'center' }, // Number of Units
        10: { cellWidth: 65, halign: 'left' }, // Device Model
      },
      horizontalPageBreak: true,
    })

    doc.save('vehicle_material_report.pdf')
  }

  // Download functions for Group Booking and Vehicle/Material CSV
  const downloadGroupBookingCSV = () => {
    const csvData = []
    let hasGroupData = false

    // Filter for only group visitors (visitor_type: "group_visitor")
    // Use ONLY usersDataList for group visitors (not noShowVisitorsData)
    const dataSource = userData

    // Filter for group visitors only
    const groupVisitors = dataSource.filter((visitor) => {
      const isGroupVisitor =
        visitor.visitor_type === 'group_visitor' ||
        visitor.grp_book_bool === true
      console.log('🔍 Group Booking CSV - Visitor filter:', {
        name: visitor.first_name,
        visitor_type: visitor.visitor_type,
        grp_book_bool: visitor.grp_book_bool,
        isGroupVisitor: isGroupVisitor,
        hasGroupDetails: !!visitor.grp_details?.length,
      })
      return isGroupVisitor
    })

    console.log('🔍 Group Booking CSV - Total visitors:', dataSource.length)
    console.log(
      '🔍 Group Booking CSV - Group visitors found:',
      groupVisitors.length,
    )

    // Debug: Show all visitor types in the data
    console.log(
      '🔍 Group Booking CSV - All visitor types in data:',
      dataSource.map((v) => ({
        name: v.first_name,
        visitor_type: v.visitor_type,
        grp_book_bool: v.grp_book_bool,
        hasGroupDetails: !!v.grp_details?.length,
      })),
    )

    // Debug: Show what we're looking for
    console.log('🔍 Group Booking CSV - Looking for visitors with:')
    console.log('  - visitor_type === "group_visitor"')
    console.log('  - OR grp_book_bool === true')

    groupVisitors.forEach((visitor) => {
      console.log('🔍 Group Booking CSV - Processing group visitor:', {
        name: visitor.first_name,
        visitor_type: visitor.visitor_type,
        grp_book_bool: visitor.grp_book_bool,
        hasGroupDetails: !!visitor.grp_details?.length,
        groupDetailsLength: visitor.grp_details?.length || 0,
        groupDetails: visitor.grp_details,
      })

      // Show the group visitor themselves (not looking for grp_details)
      console.log(
        '🔍 Group Booking CSV - Adding group visitor to report:',
        visitor.first_name,
      )
      hasGroupData = true

      csvData.push({
        'Group Member Name': visitor.first_name || visitor.name || 'N/A',
        'Main Visitor Name': visitor.main_visitor_name || 'N/A',
        Role: visitor.role_name || visitor.role || 'N/A',
        'Phone Number':
          `${visitor.ph_ext || ''}-${visitor.ph_no || visitor.phone || ''}` ||
          'N/A',
        Email: visitor.email || 'N/A',
        'ID Proof': visitor.id_proof || 'N/A',
      })

      // Skip the old grp_details logic
      if (false && visitor.grp_details && visitor.grp_details.length > 0) {
        console.log(
          '🔍 Group Booking CSV - Found group details for visitor:',
          visitor.first_name,
        )
        hasGroupData = true
        visitor.grp_details.forEach((member) => {
          csvData.push({
            'Group Member Name': member.grp_user_name || 'N/A',
            Role: member.grp_user_role_name || 'N/A',
            'Phone Number':
              `${member.grp_user_phext || ''}-${member.grp_user_phno || ''}` ||
              'N/A',
            Email: member.grp_user_email || 'N/A',
            'ID Proof': member.grp_user_id_proof || 'N/A',
          })
        })
      } else {
        console.log(
          '🔍 Group Booking CSV - No group details found for visitor:',
          visitor.first_name,
        )
      }
    })

    // If no group data found, show error message and return without creating CSV
    if (!hasGroupData || csvData.length === 0) {
      toast.error('No group booking data available to download')
      return
    }

    // Add debug rows to CSV (commented out - only for debugging)
    if (false) {
      csvData.push({
        'Group Member Name': `Debug: Total visitors: ${dataSource.length}`,
        Role: 'N/A',
        'Phone Number': 'N/A',
        Email: 'N/A',
        'Main Visitor Name': 'N/A',
        'ID Proof': 'N/A',
      })
      csvData.push({
        'Group Member Name': `Debug: Group visitors found: ${groupVisitors.length}`,
        Role: 'N/A',
        'Phone Number': 'N/A',
        Email: 'N/A',
        'Main Visitor Name': 'N/A',
        'ID Proof': 'N/A',
      })
    }

    // Add metadata header with "Generated on" in DD-MM-YYYY format
    const now = new Date()
    const generatedDate = formatDate(now.toISOString().split('T')[0])
    const generatedTime = format(now, 'HH:mm:ss')
    let csvRows = []
    csvRows.push(`"Generated on: ${generatedDate} ${generatedTime}"`)
    csvRows.push('') // Empty row for spacing

    // Convert data to CSV format
    const csvDataString = Papa.unparse(csvData)
    
    // Combine header and data
    const csv = csvRows.join('\n') + '\n' + csvDataString
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    saveAs(blob, 'Group Booking Report.csv')
  }

  const downloadVehicleMaterialCSV = () => {
    const csvData = []
    let hasVehicleMaterialData = false

    // Use noShowVisitorsData for vehicle/material data
    // Use ONLY usersDataList for group visitors (not noShowVisitorsData)
    const dataSource = userData

    dataSource.forEach((visitor) => {
      const displayName =
        `${visitor.first_name || ''} ${visitor.last_name || ''}`.trim() || 'N/A'

      // Check for vehicle/material data
      const vehicleDetails = visitor.vm_details || []
      const materialDetails = visitor.mm_details || []

      if (vehicleDetails && vehicleDetails.length > 0) {
        hasVehicleMaterialData = true
        vehicleDetails.forEach((vehicle) => {
          if (materialDetails && materialDetails.length > 0) {
            materialDetails.forEach((material) => {
              csvData.push({
                'Visitor Name': displayName,
                'Vehicle Name': vehicle.vehicle_name || 'N/A',
                'Vehicle Type': vehicle.vehicle_type || 'N/A',
                'RC Number': vehicle.rc_no || 'N/A',
                'Driver License': vehicle.driver_licence || 'N/A',
                'Insurance Provider': vehicle.insurance_provider || 'N/A',
                'Insurance Number': vehicle.insurance_no || 'N/A',
                'Material Name': material.material_name || 'N/A',
                'Material Quantity': material.material_quantity || 'N/A',
                'Number of Units': material.material_no_of_units || 'N/A',
                'Device Model': material.material_device_model || 'N/A',
              })
            })
          } else {
            csvData.push({
              'Visitor Name': displayName,
              'Vehicle Name': vehicle.vehicle_name || 'N/A',
              'Vehicle Type': vehicle.vehicle_type || 'N/A',
              'RC Number': vehicle.rc_no || 'N/A',
              'Driver License': vehicle.driver_licence || 'N/A',
              'Insurance Provider': vehicle.insurance_provider || 'N/A',
              'Insurance Number': vehicle.insurance_no || 'N/A',
              'Material Name': 'N/A',
              'Material Quantity': 'N/A',
              'Number of Units': 'N/A',
              'Device Model': 'N/A',
            })
          }
        })
      } else if (materialDetails && materialDetails.length > 0) {
        hasVehicleMaterialData = true
        materialDetails.forEach((material) => {
          csvData.push({
            'Visitor Name': displayName,
            'Vehicle Name': 'N/A',
            'Vehicle Type': 'N/A',
            'RC Number': 'N/A',
            'Driver License': 'N/A',
            'Insurance Provider': 'N/A',
            'Insurance Number': 'N/A',
            'Material Name': material.material_name || 'N/A',
            'Material Quantity': material.material_quantity || 'N/A',
            'Number of Units': material.material_no_of_units || 'N/A',
            'Device Model': material.material_device_model || 'N/A',
          })
        })
      }
    })

    // If no vehicle/material data found, add a message row
    if (!hasVehicleMaterialData) {
      csvData.push({
        'Visitor Name': 'No Vehicle/Material Data Available',
        'Vehicle Name': 'N/A',
        'Vehicle Type': 'N/A',
        'RC Number': 'N/A',
        'Driver License': 'N/A',
        'Insurance Provider': 'N/A',
        'Insurance Number': 'N/A',
        'Material Name': 'N/A',
        'Material Quantity': 'N/A',
        'Number of Units': 'N/A',
        'Device Model': 'N/A',
      })
    }

    // Add metadata header with "Generated on" in DD-MM-YYYY format
    const now = new Date()
    const generatedDate = formatDate(now.toISOString().split('T')[0])
    const generatedTime = format(now, 'HH:mm:ss')
    let csvRows = []
    csvRows.push(`"Generated on: ${generatedDate} ${generatedTime}"`)
    csvRows.push('') // Empty row for spacing

    // Convert data to CSV format
    const csvDataString = Papa.unparse(csvData)
    
    // Combine header and data
    const csv = csvRows.join('\n') + '\n' + csvDataString
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    saveAs(blob, 'Vehicle Material Report.csv')
  }

  const handleFilterChange = (e) => {
    setFilter(e.target.value)
  }

  const downloadAllCSV = () => {
    console.log(userData, 'userData userData userData')
    const csvData = userData.flatMap((user) =>
      (user.attendanceData || []).map((att) => ({
        Name: user.first_name || '',
        'Visitor Type': getVisitorTypeDisplay(user.visitor_type),
        Category: user.role_name || '',
        'Purpose of Visit': user.purpose_of_visit || '',
        'Area of Permit': user.area_of_permit || '',
        Asset: user.asset || '',
        'Phone Number': `\t${user.ph_ext}-${user.ph_no}` || '' || '',
        Email: user.email || '',
        'Last Entry': formatDate(user.last_entry) || '',
        'Last Exit': formatDate(user.last_exit) || '',
        'Visitor Company Name': user.visitor_company_name || '',
        'Access Reference Code': `\t${user.visitor_code || user.last_visited_code || ''}`,
        'KYC Type': user.kyc_type || '',
        'KYC ID': `\t${user.kyc_id}` || '',
        'Entry Time': formatTime(att.entry_time) || '',
        'Exit Time': formatTime(att.exit_time) || '',
        Blacklist:
          user.black_listed === true ||
          user.blacklisted === true ||
          user.blacklist_status === 'blacklisted' ||
          user.is_blacklisted === true ||
          user.status === 'Blacklisted'
            ? 'Yes'
            : 'No',
        Photo: (() => {
          const url = user.photo || ''
          if (!url) return 'N/A'
          if (url.startsWith('http')) return url
          try {
            if (url.includes('visiqbucket.s3.')) {
              return `https://visiqbucket.s3.us-east-1.${url.split('https://visiqbucket.s3.')[1]}`
            }
          } catch (e) {
            // fall back to original string
          }
          return url
        })(),
      })),
    )
    const csv = Papa.unparse(csvData)
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    saveAs(blob, 'All Details Report.csv')
  }

  // Function to expand group members into separate cards
  const getExpandedUserData = () => {
    const expandedData = []

    // Add safety check for userData
    if (!userData || !Array.isArray(userData)) {
      console.warn('userData is not an array or is undefined:', userData)
      return []
    }

    userData.forEach((visitor) => {
      // Add safety check for visitor object
      if (!visitor || typeof visitor !== 'object') {
        console.warn('Invalid visitor object:', visitor)
        return
      }

      // Check if visitor has attendance data (main visitor or any group member)
      const hasMainVisitorAttendance =
        visitor.attendanceData &&
        Array.isArray(visitor.attendanceData) &&
        visitor.attendanceData.length > 0

      const hasGroupMemberAttendance =
        visitor.grp_details &&
        Array.isArray(visitor.grp_details) &&
        visitor.grp_details.length > 0 &&
        visitor.grp_details.some(
          (member) =>
            member.attendanceData &&
            Array.isArray(member.attendanceData) &&
            member.attendanceData.length > 0,
        )

      const hasAnyAttendance =
        hasMainVisitorAttendance || hasGroupMemberAttendance

      console.log(
        '🔍 AllVisitorsAttendance - visitor:',
        visitor.first_name,
        'hasMainVisitorAttendance:',
        hasMainVisitorAttendance,
        'hasGroupMemberAttendance:',
        hasGroupMemberAttendance,
        'hasAnyAttendance:',
        hasAnyAttendance,
      )

      // Only include visitors who have attendance data
      if (!hasAnyAttendance) {
        console.log(
          '🔍 AllVisitorsAttendance - Excluding visitor (no attendance data):',
          visitor.first_name,
        )
        return
      }

      // Add main visitor card with safety checks
      const expandedVisitor = {
        ...visitor,
        isMainVisitor: true,
        isGroupMember: false,
        // Ensure required fields exist
        user_id:
          visitor.user_id || visitor.visitor_id || `visitor_${Math.random()}`,
        first_name: visitor.first_name || visitor.name || 'Unknown',
        last_name: visitor.last_name || '',
        photo: visitor.photo || '',
      }

      console.log(
        '🔍 AllVisitorsAttendance - visitor attendanceData:',
        visitor.attendanceData,
      )
      console.log(
        '🔍 AllVisitorsAttendance - expandedVisitor attendanceData:',
        expandedVisitor.attendanceData,
      )
      console.log('🔍 AllVisitorsAttendance - visitor group data:', {
        visitor_type: visitor.visitor_type,
        grp_book_bool: visitor.grp_book_bool,
        grp_details: visitor.grp_details,
        grp_details_length: visitor.grp_details?.length,
      })
      console.log('🔍 AllVisitorsAttendance - expandedVisitor group data:', {
        visitor_type: expandedVisitor.visitor_type,
        grp_book_bool: expandedVisitor.grp_book_bool,
        grp_details: expandedVisitor.grp_details,
        grp_details_length: expandedVisitor.grp_details?.length,
      })

      expandedData.push(expandedVisitor)

      // Add group members as separate cards
      if (
        visitor.grp_details &&
        Array.isArray(visitor.grp_details) &&
        visitor.grp_details.length > 0
      ) {
        visitor.grp_details.forEach((member, index) => {
          // Add safety check for member object
          if (!member || typeof member !== 'object') {
            console.warn('Invalid group member object:', member)
            return
          }

          // Check if group member has attendance data
          const hasMemberAttendance =
            member.attendanceData &&
            Array.isArray(member.attendanceData) &&
            member.attendanceData.length > 0

          console.log(
            '🔍 AllVisitorsAttendance - group member:',
            member.grp_user_name,
            'hasAttendance:',
            hasMemberAttendance,
          )

          // Only include group members who have attendance data
          if (!hasMemberAttendance) {
            console.log(
              '🔍 AllVisitorsAttendance - Excluding group member (no attendance data):',
              member.grp_user_name,
            )
            return
          }

          // Parse group member name into first and last name
          const fullName =
            member.grp_user_name || member.name || member.fullName || ''
          const nameParts = fullName.split(' ')
          const firstName = nameParts[0] || 'Unknown'
          const lastName = nameParts.slice(1).join(' ') || ''

          // Debug photo data for group members
          console.log('🔍 AllVisitorsAttendance - Group member photo data:', {
            memberName: fullName,
            grp_user_photo: member.grp_user_photo,
            grp_user_id_proof: member.grp_user_id_proof,
            member_photo: member.photo,
            visitor_photo: visitor.photo,
            final_photo:
              member.grp_user_photo ||
              member.grp_user_id_proof ||
              member.photo ||
              visitor.photo ||
              '',
          })

          expandedData.push({
            ...member,
            fullName: fullName,
            // Map group member fields to form field names
            first_name: firstName,
            last_name: lastName,
            phNo: member.grp_user_phno || member.phone || member.phNo || '',
            ph_ext: member.grp_user_phext || member.ph_ext || '+91',
            email: member.grp_user_email || member.email || '',
            role: member.grp_user_role_name || member.role || 'Group Member',
            purpose_of_visit: visitor.purpose_of_visit,
            visitorOrgName: visitor.visitorOrgName,
            date_of_visit: visitor.date_of_visit,
            // Inherit vehicle/material data from parent visitor
            vm_bool: visitor.vm_bool,
            mm_bool: visitor.mm_bool,
            vm_details: visitor.vm_details,
            mm_details: visitor.mm_details,
            grp_book_bool: visitor.grp_book_bool,
            grp_details: visitor.grp_details,
            // Use group member's unique ID
            user_id:
              member.grp_user_unique_id ||
              member.grp_user_id ||
              `group_${visitor.user_id || visitor.visitor_id}_${index}`,
            visitor_id:
              member.grp_user_unique_id ||
              member.grp_user_id ||
              `group_${visitor.visitor_id || visitor.user_id}_${index}`,
            branch_id: visitor.branch_id,
            org_id: visitor.org_id,
            isMainVisitor: false,
            isGroupMember: true,
            parentVisitorId: visitor.user_id || visitor.visitor_id,
            memberIndex: index,
            // Add photo if available - check multiple possible photo fields
            photo:
              member.grp_user_photo ||
              member.grp_user_id_proof ||
              member.photo ||
              visitor.photo ||
              '',
          })
        })
      }
    })

    console.log(
      '📊 Expanded user data for cards:',
      expandedData.length,
      'items',
    )
    return expandedData
  }

  const expandedUserData = getExpandedUserData()
  console.log(
    '🔍 AllVisitorsAttendance - expandedUserData length:',
    expandedUserData.length,
  )
  console.log(
    '🔍 AllVisitorsAttendance - expandedUserData structure:',
    expandedUserData.map((u) => ({
      name: u.first_name,
      last_entry: formatDate(u.last_entry) || u.last_entry,
      last_exit: formatDate(u.last_exit) || u.last_exit,
      isMainVisitor: u.isMainVisitor,
      isGroupMember: u.isGroupMember,
    })),
  )
  const filteredData = expandedUserData.filter((user) => {
    // Add safety checks for user object and required fields
    if (!user || typeof user !== 'object') {
      return false
    }

    const firstName = user.first_name || ''
    const lastName = user.last_name || ''
    const fullName = `${firstName} ${lastName}`.trim()

    return fullName.toLowerCase().includes(filter.toLowerCase())
  })

  console.log(
    '🔍 AllVisitorsAttendance - final filteredData length:',
    filteredData.length,
  )
  console.log(
    '🔍 AllVisitorsAttendance - final filteredData structure:',
    filteredData.map((u) => ({
      name: u.first_name,
      last_entry: formatDate(u.last_entry) || u.last_entry,
      last_exit: formatDate(u.last_exit) || u.last_exit,
      isMainVisitor: u.isMainVisitor,
      isGroupMember: u.isGroupMember,
    })),
  )

  return (
    <div>
      {filteredData.length > 0 ? (
        <div>
          <div className="flex items-center space-x-4 mb-4">
            {/* Toggle Button */}
            <button
              onClick={handleToggle}
              className="bg-gray-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-gray-600 transition-colors"
            >
              {isPDF ? (
                <>
                  <FontAwesomeIcon
                    icon={faToggleOn}
                    className="mr-1.5 text-xs"
                  />
                  Switch to CSV
                </>
              ) : (
                <>
                  <FontAwesomeIcon
                    icon={faToggleOff}
                    className="mr-1.5 text-xs"
                  />
                  Switch to PDF
                </>
              )}
            </button>

            {/* Conditional Buttons */}
            {isPDF ? (
              <>
                <button
                  onClick={downloadPDF}
                  className="bg-green-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-green-600 transition-colors"
                >
                  Download PDF
                  <FontAwesomeIcon
                    icon={faDownload}
                    className="ml-1.5 text-xs"
                  />
                </button>
                <button
                  onClick={downloadDetailedPDF}
                  className="bg-green-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-green-600 transition-colors"
                >
                  Download Detailed PDF
                  <FontAwesomeIcon
                    icon={faDownload}
                    className="ml-1.5 text-xs"
                  />
                </button>
                <button
                  onClick={downloadGroupBookingPDF}
                  className="bg-green-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-green-600 transition-colors"
                >
                  Download Group Booking PDF
                  <FontAwesomeIcon
                    icon={faDownload}
                    className="ml-1.5 text-xs"
                  />
                </button>
                <button
                  onClick={downloadVehicleMaterialPDF}
                  className="bg-green-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-green-600 transition-colors"
                >
                  Download Vehicle/Material PDF
                  <FontAwesomeIcon
                    icon={faDownload}
                    className="ml-1.5 text-xs"
                  />
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={downloadCSV}
                  className="bg-blue-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-blue-600 transition-colors"
                >
                  Download CSV
                  <FontAwesomeIcon
                    icon={faDownload}
                    className="ml-1.5 text-xs"
                  />
                </button>
                <button
                  onClick={downloadAllCSV}
                  className="bg-blue-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-blue-600 transition-colors"
                >
                  Download All Details CSV
                  <FontAwesomeIcon
                    icon={faDownload}
                    className="ml-1.5 text-xs"
                  />
                </button>
                <button
                  onClick={downloadGroupBookingCSV}
                  className="bg-blue-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-blue-600 transition-colors"
                >
                  Download Group Booking CSV
                  <FontAwesomeIcon
                    icon={faDownload}
                    className="ml-1.5 text-xs"
                  />
                </button>
                <button
                  onClick={downloadVehicleMaterialCSV}
                  className="bg-blue-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-blue-600 transition-colors"
                >
                  Download Vehicle/Material CSV
                  <FontAwesomeIcon
                    icon={faDownload}
                    className="ml-1.5 text-xs"
                  />
                </button>
              </>
            )}

            {/* Search Input */}
            <div className="relative">
              <input
                type="text"
                className="w-64 px-4 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                placeholder="Search visitors..."
                value={filter}
                onChange={handleFilterChange}
              />
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 16 16"
                fill="currentColor"
                className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400"
              >
                <path
                  fillRule="evenodd"
                  d="M9.965 11.026a5 5 0 1 1 1.06-1.06l2.755 2.754a.75.75 0 1 1-1.06 1.06l-2.755-2.754ZM10.5 7a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Z"
                  clipRule="evenodd"
                />
              </svg>
            </div>
          </div>

          {/* User Cards */}
          <div className="visitor-cards-grid grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5">
            {filteredData.map((user, index) => {
              try {
                return (
                  <UserCard
                    key={user.user_id || user.visitor_id || Math.random()}
                    user={{
                      userDetails: [user],
                      attendanceData: user.attendanceData || [],
                    }}
                  />
                )
              } catch (error) {
                console.error(`🔍 Error rendering UserCard ${index}:`, error)
                return (
                  <div
                    key={user.user_id || user.visitor_id || Math.random()}
                    className="p-4 border border-red-300 rounded-lg bg-red-50"
                  >
                    <p className="text-red-600 text-sm">
                      Error loading visitor card
                    </p>
                    <p className="text-gray-500 text-xs">
                      ID: {user.user_id || user.visitor_id}
                    </p>
                  </div>
                )
              }
            })}
          </div>
        </div>
      ) : (
        <div>
          <div className="flex items-center space-x-4 mb-4">
            <button
              onClick={downloadPDF}
              className="bg-green-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-green-600 transition-colors"
            >
              Download PDF
              <FontAwesomeIcon icon={faDownload} className="ml-1.5 text-xs" />
            </button>
            <button
              onClick={downloadCSV}
              className="bg-blue-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-blue-600 transition-colors"
            >
              Download CSV
              <FontAwesomeIcon icon={faDownload} className="ml-1.5 text-xs" />
            </button>
            <div className="relative">
              <input
                type="text"
                className="w-64 px-4 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                placeholder="Search visitors..."
                value={filter}
                onChange={handleFilterChange}
              />
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 16 16"
                fill="currentColor"
                className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400"
              >
                <path
                  fillRule="evenodd"
                  d="M9.965 11.026a5 5 0 1 1 1.06-1.06l2.755 2.754a.75.75 0 1 1-1.06 1.06l-2.755-2.754ZM10.5 7a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Z"
                  clipRule="evenodd"
                />
              </svg>
            </div>
          </div>
          <div className="mt-8 col-span-full text-center text-gray-500">
            No data available
          </div>
        </div>
      )}
    </div>
  )
}

export default AllVisitorsAttendance
