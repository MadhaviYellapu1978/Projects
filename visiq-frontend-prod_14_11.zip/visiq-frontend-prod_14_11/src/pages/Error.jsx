import React from 'react'
import image from '../assets/OOPS.png'

const Error = () => {
  const clickHandler = () => {
    window.location.reload()
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen">
      <img src={image} alt="Error" className="w-1/3 h-auto mb-4" />
      <button
        onClick={clickHandler}
        className="px-4 py-2 bg-blue-400 text-white rounded hover:bg-blue-600"
      >
        Reload
      </button>
    </div>
  )
}

export default Error
