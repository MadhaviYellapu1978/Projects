import { Form, Formik } from 'formik'
import React, { useState, useEffect } from 'react'
import * as yup from 'yup'
import FormikTextField from '../../../../lib/Formik/FormikTextfield'
import PrimaryBtn from '../../../../shared/Buttons/PrimaryBtn'
import { useQueryClient } from '@tanstack/react-query'
import toast from 'react-hot-toast'
import { apiCall } from '../../../../utils/apiCall.js'
import { onBoardOrg as onBoardOrgService } from '../../../../services/orgService.js'

const OnBoardOrg = ({ closeModal }) => {
  const [file, setFile] = useState(null)
  const [loading, setLoading] = useState(false)
  const [isFileValid, setIsFileValid] = useState(true) // State for file validity
  const queryClient = useQueryClient()

  const initialValues = {
    name: '',
    theme: '',
    email: '',
    username: '',
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

  const validationSchema = yup.object().shape({
    name: yup.string().required('Organization name is required'),
    theme: yup.string().required('Theme is required'),
    email: yup
      .string()
      .required('Email is required')
      .matches(emailRegex, 'Enter a valid email'),
    username: yup
      .string()
      .required('Username is required')
      .min(6, 'Username must be at least 6 characters')
      .matches(/^\S*$/, 'Username should not contain spaces')
      .test(
        'checkUsernameAvailability',
        'Username is not available',
        async (value) => {
          if (value && value.length >= 6) {
            const response = await apiCall('/auth/availUser', 'POST', {
              username: value,
            })
            return !response.isAvail
          }
          return true
        },
      ),
  })

  const compressImage = (file, maxSizeMB = 1) => {
    return new Promise((resolve) => {
      const canvas = document.createElement('canvas')
      const ctx = canvas.getContext('2d')
      const img = new Image()

      img.onload = () => {
        // Calculate new dimensions (max 800x800 pixels)
        const maxWidth = 800
        const maxHeight = 800
        let { width, height } = img

        if (width > height) {
          if (width > maxWidth) {
            height = (height * maxWidth) / width
            width = maxWidth
          }
        } else {
          if (height > maxHeight) {
            width = (width * maxHeight) / height
            height = maxHeight
          }
        }

        canvas.width = width
        canvas.height = height

        // Draw and compress
        ctx.drawImage(img, 0, 0, width, height)

        // Convert to blob with quality 0.7 (70%)
        canvas.toBlob(
          (blob) => {
            resolve(blob)
          },
          'image/jpeg',
          0.7,
        )
      }

      img.src = URL.createObjectURL(file)
    })
  }

  const handleImageUpload = async (event) => {
    const file = event.target.files[0]
    if (file) {
      const validFormats = ['image/jpeg', 'image/png']
      const isValid = validFormats.includes(file.type)

      if (!isValid) {
        setIsFileValid(false)
        setFile(null)
        return
      }

      // Check file size (max 5MB before compression)
      const maxSizeMB = 5
      const maxSizeBytes = maxSizeMB * 1024 * 1024

      if (file.size > maxSizeBytes) {
        toast.error(
          `File size must be less than ${maxSizeMB}MB. Please select a smaller image.`,
          {
            className: 'toast-error',
            position: 'top-center',
          },
        )
        setIsFileValid(false)
        setFile(null)
        return
      }

      setIsFileValid(true)

      try {
        // Compress the image
        const compressedFile = await compressImage(file)

        // Create a new file object with the compressed data
        const compressedFileObj = new File([compressedFile], file.name, {
          type: 'image/jpeg',
          lastModified: Date.now(),
        })

        console.log(
          'Original file size:',
          (file.size / 1024 / 1024).toFixed(2),
          'MB',
        )
        console.log(
          'Compressed file size:',
          (compressedFileObj.size / 1024 / 1024).toFixed(2),
          'MB',
        )

        setFile(compressedFileObj)
      } catch (error) {
        console.error('Error compressing image:', error)
        // Fallback to original file if compression fails
        setFile(file)
      }
    } else {
      setFile(null)
      setIsFileValid(true)
    }
  }

  const onBoardOrg = async (values, resetForm) => {
    if (!file) {
      toast.dismiss()
      toast.error('Please Select a Valid Image', {
        className: 'toast-error',
        position: 'top-center',
      })
      setLoading(false)
      return
    }

    setLoading(true)

    try {
      // Create form data for file upload (as per production API)
      const formdata = new FormData()
      formdata.append('org_logo', file)
      formdata.append('org_name', values.name)
      formdata.append('theme', values.theme)
      formdata.append('org_admin_email', values.email)
      formdata.append('username', values.username)

      // Use the service function
      const result = await onBoardOrgService(formdata)

      if (result.statusCode === 400) {
        toast.error(result.message, {
          className: 'toast-error',
          position: 'top-center',
        })
        resetForm()
      } else {
        queryClient.invalidateQueries(['getAllOrgs'])
        toast.success('Onboard Successful', {
          className: 'toast-success',
          position: 'top-center',
        })
        resetForm()
      }

      setFile(null)
      document.getElementById('logo').value = ''

      // Close modal
      closeModal()
    } catch (error) {
      console.error('OnBoardOrg error:', error)
      toast.dismiss()

      // Handle specific error types
      if (
        error.message.includes('413') ||
        error.message.includes('PayloadTooLargeError')
      ) {
        toast.error(
          'File size too large. Please select a smaller image (max 1MB).',
          {
            className: 'toast-error',
            position: 'top-center',
          },
        )
      } else if (error.message.includes('400')) {
        toast.error('Invalid data. Please check your input and try again.', {
          className: 'toast-error',
          position: 'top-center',
        })
      } else {
        toast.error(`Onboard Failed: ${error.message}`, {
          className: 'toast-error',
          position: 'top-center',
        })
      }
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = (values, { resetForm }) => {
    onBoardOrg(values, resetForm)
  }

  const handleCancel = (resetForm) => {
    resetForm()
    setFile(null)
    document.getElementById('logo').value = ''
    setIsFileValid(true) // Reset file validity state
    closeModal()
  }

  useEffect(() => {
    // Reset file validity state when modal opens
    setIsFileValid(true)
  }, [])

  return (
    <>
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={handleSubmit}
      >
        {({ resetForm }) => (
          <Form className="flex flex-col gap-5">
            <label htmlFor="logo">Upload Logo</label>

            <input
              type="file"
              id="logo"
              className="file-input file-input-bordered w-full"
              onChange={handleImageUpload}
              required
              accept="image/jpeg, image/png"
            />
            <p className="text-sm text-gray-600 ml-2">
              Accepted formats: JPG, PNG (Max 5MB, will be compressed to
              ~800x800px)
            </p>
            {!isFileValid && (
              <p className="text-red-500 text-sm ml-2">
                Please select a valid image file (JPG or PNG, max 5MB)
              </p>
            )}
            {file && (
              <p className="text-green-600 text-sm ml-2">
                ✓ File selected: {file.name} (
                {(file.size / 1024 / 1024).toFixed(2)} MB)
              </p>
            )}
            <div className="grid grid-cols-2 gap-5 mt-5">
              <FormikTextField name="name" label="Organization Name *" />
              <FormikTextField name="theme" label="Color Theme *" />
              <FormikTextField name="email" label="Email *" />
              <FormikTextField name="username" label="Username *" />
            </div>
            <div className="flex gap-4">
              {loading ? (
                <PrimaryBtn text={'Registering...'} />
              ) : (
                <>
                  <PrimaryBtn type={'submit'} text="Register Organization" />
                  <button
                    type="button"
                    className="btn btn-sm btn-circle btn-ghost absolute right-2 top-2 bg-black text-white"
                    onClick={() => handleCancel(resetForm)}
                  >
                    X
                  </button>
                </>
              )}
            </div>
          </Form>
        )}
      </Formik>
    </>
  )
}

export default OnBoardOrg
