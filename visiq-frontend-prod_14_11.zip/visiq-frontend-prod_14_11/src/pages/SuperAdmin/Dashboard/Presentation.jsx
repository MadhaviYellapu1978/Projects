import React, { useState } from 'react'
import PrimaryBtn from '../../../shared/Buttons/PrimaryBtn'
import OnBoardOrg from './components/OnBoardOrg'
import toast from 'react-hot-toast'

const Presentation = (props) => {
  const { organizations } = props
  const handleClick = () => document.getElementById('my_modal_1').showModal()
  const [searchTerm, setSearchTerm] = useState('')

  // Filter organizations based on search term
  const filteredOrganizations = organizations.filter((org) =>
    org.organisation.org_name.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="px-5">
      <div className="flex justify-between py-12">
        <div className="flex items-center">
          <input
            type="text"
            placeholder="Search Organization"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-800 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500"
          />
        </div>
        <div className="flex items-center">
          <PrimaryBtn text="Register Organization" handleClick={handleClick} />
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {filteredOrganizations.map((org, index) => (
          // eslint-disable-next-line jsx-a11y/click-events-have-key-events, jsx-a11y/no-static-element-interactions
          <div
            key={org.organisation.org_id}
            className={`bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 ${
              index === filteredOrganizations.length - 1 ? 'mb-4' : 'mb-4'
            }`}
            // onClick={() => navigate(`/superAdmin/${org.organisation.org_id}`)}
            onClick={() => {
              toast.dismiss()
              toast.error('Not Allowed To View Organization Information')
            }}
          >
            <div className="flex items-center justify-center mb-4">
              <img
                src={org.organisation.org_logo}
                alt={`${org.organisation.org_name} logo`}
                className="w-20 h-20 object-contain"
              />
            </div>
            <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-2 text-center">
              {org.organisation.org_name?.toUpperCase()}
            </h3>
            <p className="text-gray-600 dark:text-gray-300 text-center">
              <strong>Theme:</strong> {org.organisation.theme}
            </p>
          </div>
        ))}
      </div>

      <dialog id="my_modal_1" className="modal">
        <div className="modal-box">
          <OnBoardOrg
            closeModal={() => document.getElementById('my_modal_1').close()}
          />
          <form method="dialog">
            <button
              type="button"
              onClick={() => document.getElementById('my_modal_1').close()}
            ></button>
          </form>
        </div>
      </dialog>
    </div>
  )
}

export default Presentation
