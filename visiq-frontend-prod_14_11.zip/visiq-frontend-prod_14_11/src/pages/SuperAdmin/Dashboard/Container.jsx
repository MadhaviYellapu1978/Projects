import React, { useContext } from 'react'
import Presentation from './Presentation'
import { useQuery } from '@tanstack/react-query'
import { AuthContext } from '../../../context/AuthContext'
import { getAllOrgs } from '../../../services/orgService'
import loading from '../../../assets/loading.json'
import LottieLoader from '../../../shared/LottieLoader'

const Container = () => {
  const auth = useContext(AuthContext)
  const values = { org_id: auth?.org_id || '', role: '1', branch_id: '' }
  const {
    data: organizations,
    isLoading,
    isError,
  } = useQuery({
    queryKey: ['getAllOrgs'],
    queryFn: () => getAllOrgs(values),
  })

  if (isLoading) {
    return <LottieLoader data={loading} />
  }

  if (isError) {
    return <div>Oops... Something went wrong!</div>
  }

  if (organizations) {
    return (
      <div>
        <Presentation organizations={organizations.organisationDetails} />
      </div>
    )
  }

  return null
}

export default Container
