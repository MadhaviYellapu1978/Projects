import React, { useContext } from 'react'
import Presentation from './Presentation'
import { AuthContext } from '../../../context/AuthContext'
import { useMutation } from '@tanstack/react-query'
import { otp } from '../../../services/authService'
import { useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'

function Container() {
  const auth = useContext(AuthContext)
  const name = auth?.username
  const navigate = useNavigate()
  const mutation = useMutation({
    mutationFn: (values) => otp(values),
    mutationKey: 'otp',
    onSuccess: (data) => {
      auth.setOptVerify(true)
      navigate('/dashboard')
      toast.dismiss()
      toast.success('Login Successful')
    },
    onError: (err) => {
      toast.dismiss()

      // Extract backend API response message - try multiple possible keys
      const backendMessage =
        err.response?.data?.message ||
        err.response?.data?.error ||
        err.response?.data?.msg ||
        err.response?.data?.errorMessage ||
        err.response?.data?.description

      if (backendMessage) {
        toast.error(backendMessage)
      } else {
        // Last resort: show the error message from the Error object
        toast.error(err.message || 'Invalid Otp')
      }
    },
  })
  const handleSignIn = (values) => {
    mutation.mutate(values)
  }

  return (
    <div>
      <Presentation
        handleSignIn={handleSignIn}
        name={name}
        isLoading={mutation.isPending}
      />
    </div>
  )
}

export default Container
