import { Form, Formik } from 'formik'
import React, { useContext } from 'react'
import FormikTextField from '../../../lib/Formik/FormikTextfield'
import * as yup from 'yup'
import PrimaryBtn from '../../../shared/Buttons/PrimaryBtn'
import Logo from '../../../shared/Logo'
import { AuthContext } from '../../../context/AuthContext'

const Presentation = (props) => {
  const auth = useContext(AuthContext)

  const { handleSignIn, name, isLoading } = props
  const initialValues = {
    otp: '',
    username: name,
  }

  const validationSchema = yup.object().shape({
    otp: yup
      .string()
      .matches(/^\d+$/, 'OTP must be a number')
      .required('OTP is required'),
  })

  return (
    <div className="max-w-80 m-auto flex flex-col justify-center h-screen gap-10">
      <Logo />
      <h1>{auth?.mask_email}</h1>
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={handleSignIn}
      >
        <Form className="flex flex-col gap-8">
          <FormikTextField name={'otp'} label="Enter OTP*" type="text" />
          <PrimaryBtn
            text={isLoading ? 'Verifying...' : 'Login'}
            type={'submit'}
            disabled={isLoading}
            loading={isLoading}
          />
        </Form>
      </Formik>
    </div>
  )
}

export default Presentation
