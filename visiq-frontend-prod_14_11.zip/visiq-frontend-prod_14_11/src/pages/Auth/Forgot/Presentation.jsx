import { Form, Formik } from 'formik'
import React from 'react'
import { Link } from 'react-router-dom'
import FormikTextField from '../../../lib/Formik/FormikTextfield'
import * as yup from 'yup'
import PrimaryBtn from '../../../shared/Buttons/PrimaryBtn'
import Logo from '../../../shared/Logo'

const Presentation = (props) => {
  const { handleForgot, isLoading } = props
  const initialValues = {
    username: '',
  }

  const validationSchema = yup.object().shape({
    username: yup.string().required('Enter username'),
  })
  return (
    <div className="max-w-80 m-auto flex flex-col justify-center h-screen gap-10">
      <Logo />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={handleForgot}
      >
        <Form className="flex flex-col gap-5">
          <FormikTextField name={'username'} label="Enter Username *" />
          <PrimaryBtn
            text={isLoading ? 'Sending...' : 'Reset'}
            type={'submit'}
            disabled={isLoading}
            loading={isLoading}
          />
        </Form>
      </Formik>
      <div className="text-right">
        <Link to="/auth/login" className="text-blue-500 text-right ">
          Back to Login
        </Link>
      </div>
    </div>
  )
}

export default Presentation
