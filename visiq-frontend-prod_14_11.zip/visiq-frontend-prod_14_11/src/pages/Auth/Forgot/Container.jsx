import React from 'react'
import Presentation from './Presentation'
import { useMutation } from '@tanstack/react-query'
import { forgotPassword } from '../../../services/authService'
import toast from 'react-hot-toast'
import { useNavigate } from 'react-router-dom'
const Container = () => {
  const navigate = useNavigate()

  const mutation = useMutation({
    mutationFn: (values) => forgotPassword(values),
    mutationKey: 'forgotPassword',
    onSuccess: (data) => {
      navigate('/auth/login')
      toast.success(
        'New password has been sent to your registered email address.',
      )
    },
    onError: (err) => {
      toast.dismiss()

      // Extract backend API response message - try multiple possible keys
      const backendMessage =
        err.response?.data?.message ||
        err.response?.data?.error ||
        err.response?.data?.msg ||
        err.response?.data?.errorMessage ||
        err.response?.data?.description

      if (backendMessage) {
        toast.error(backendMessage)
      } else {
        // Last resort: show the error message from the Error object
        toast.error(err.message || 'Invalid username')
      }
    },
  })
  const handleForgot = (values) => {
    mutation.mutate(values)
  }

  return (
    <div>
      <Presentation
        handleForgot={handleForgot}
        isLoading={mutation.isPending}
      />
    </div>
  )
}

export default Container
