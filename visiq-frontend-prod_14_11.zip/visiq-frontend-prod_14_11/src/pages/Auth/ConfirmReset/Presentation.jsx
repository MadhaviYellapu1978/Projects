import { Form, Formik } from 'formik'
import React from 'react'
import FormikTextField from '../../../lib/Formik/FormikTextfield'
import * as yup from 'yup'
import PrimaryBtn from '../../../shared/Buttons/PrimaryBtn'
import Logo from '../../../shared/Logo'

const Presentation = (props) => {
  const { handleSignIn } = props
  const initialValues = {
    newPassword: '',
    confirmPassword: '',
  }

  const validationSchema = yup.object().shape({
    newPassword: yup.string().required('Enter password'),
    confirmPassword: yup
      .string()
      .oneOf([yup.ref('newPassword'), null], 'Passwords must match')
      .required('Enter newPassword'),
  })

  return (
    <div className="max-w-80 m-auto flex flex-col justify-center h-screen gap-10">
      <Logo />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={handleSignIn}
      >
        <Form className="flex flex-col gap-5">
          <div className="flex relative">
            <FormikTextField
              name={'newPassword'}
              label="New Password *"
              type={'password'}
            />
          </div>
          <div className="flex relative">
            <FormikTextField
              name={'confirmPassword'}
              label=" Confirm Password *"
              type={'password'}
            />
          </div>
          <PrimaryBtn text={'Reset Password'} type={'submit'} />
        </Form>
      </Formik>
    </div>
  )
}

export default Presentation
