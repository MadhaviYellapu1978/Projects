import React from 'react'
import Presentation from './Presentation'

const Container = () => {
  return (
    <div>
      <Presentation />
    </div>
  )
}

export default Container
