import Container from './Container'
import './animations.css'

export default Container
