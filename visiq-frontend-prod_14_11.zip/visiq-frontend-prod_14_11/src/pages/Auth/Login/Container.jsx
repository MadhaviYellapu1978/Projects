import React, { useContext, useState } from 'react'
import Presentation from './Presentation'
import { useMutation } from '@tanstack/react-query'
import { signIn } from '../../../services/authService'
import { useNavigate } from 'react-router-dom'
import { AuthContext } from '../../../context/AuthContext'
import toast from 'react-hot-toast'
import CorsTest from '../../../components/CorsTest'
const Container = () => {
  const [isLoading, setIsLoading] = useState(false)
  const { setAuth } = useContext(AuthContext)
  const navigate = useNavigate()
  const mutation = useMutation({
    mutationFn: (values) => signIn(values),
    mutationKey: 'signIn',
    onSuccess: (data) => {
      setIsLoading(false)
      if (data.role === '1') {
        const req_data = {
          org_id: data.org_id || 'super_admin',
          org_name: data?.org_name || 'Super Admin',
          theme: 'rainbow',
          org_logo: '',
          cog_id: '',
          role: data.role,
          organizationDetails: [],
          username: data?.username,
          mask_email: data?.mask_email || '',
          isOtpVerify: true,
        }
        setAuth(req_data)
        localStorage.setItem('userData', JSON.stringify(req_data))
        navigate('/superAdmin/dashboard')
        toast.success('Login Successful')
      } else if (data.role === '2') {
        const req_data = {
          org_id: data.org_id,
          org_name: data?.org_name,
          theme: 'rainbowsss',
          org_logo: data?.org_logo || '',
          cog_id: '',
          role: data.role,
          branch_id: data.branch_id,
          organizationDetails: data?.organisationDetails || [],
          username: data?.username,
          mask_email: data?.mask_email || '',
        }
        setAuth(req_data)
        localStorage.setItem('userData', JSON.stringify(req_data))
        navigate('/auth/otp', { state: { from: 'login' } })
      } else if (data.role === '3') {
        const req_data = {
          org_id: data.org_id,
          org_name: data?.org_name,
          theme: 'rainbow',
          org_logo: data?.org_logo || '',
          cog_id: '',
          role: data.role,
          branch_id: data.branch_id,
          organizationDetails: data?.organisationDetails || [],
          username: data?.username,
          mask_email: data?.mask_email || '',
        }
        setAuth(req_data)
        localStorage.setItem('userData', JSON.stringify(req_data))
        navigate('/auth/otp', { state: { from: 'login' } })
      } else if (data.role === '4') {
        const req_data = {
          org_id: data.org_id,
          org_name: data?.org_name,
          theme: 'rainbow',
          org_logo: data?.org_logo || '',
          cog_id: '',
          role: data.role,
          branch_id: data.branch_id,
          organizationDetails: data?.organisationDetails || [],
          username: data?.username,
          mask_email: data?.mask_email || '',
        }
        setAuth(req_data)
        localStorage.setItem('userData', JSON.stringify(req_data))
        navigate('/auth/otp', { state: { from: 'login' } })
      } else {
        toast.error('Invalid username or password')
      }
    },
    onError: (err) => {
      setIsLoading(false)
      toast.dismiss()

      // Enhanced error logging for debugging
      console.error('Login Error Details:', {
        message: err.message,
        response: err.response,
        stack: err.stack,
      })

      // Extract backend API response message - for signin, prioritize 'error' key
      const backendMessage =
        err.response?.data?.error ||
        err.response?.data?.message ||
        err.response?.data?.msg ||
        err.response?.data?.errorMessage ||
        err.response?.data?.description

      if (backendMessage) {
        // Show the exact message from backend API
        toast.error(backendMessage)
      } else {
        // Last resort: show the error message from the Error object (which contains backend message)
        toast.error(err.message || 'Login failed')
      }
    },
  })
  const handleSignIn = (values) => {
    console.log('=== HANDLE SIGNIN DEBUG ===')
    console.log('Received values:', values)
    console.log('Values type:', typeof values)
    console.log('Username:', values.username)
    console.log('Password:', values.password)
    console.log('isWeb:', values.isWeb)
    console.log('Username length:', values.username?.length)
    console.log('Password length:', values.password?.length)
    console.log('=== END HANDLE SIGNIN DEBUG ===')

    setIsLoading(true)
    mutation.mutate(values)
  }

  const handleImageUpload = (e) => {}
  return (
    <div>
      <Presentation
        handleSignIn={handleSignIn}
        handleImageUpload={handleImageUpload}
        isLoading={isLoading}
      />

      {/* CORS Test Component - Only show in development */}
      {import.meta.env.DEV && (
        <div className="mt-8 max-w-2xl mx-auto">
          <CorsTest />
        </div>
      )}
    </div>
  )
}

export default Container
