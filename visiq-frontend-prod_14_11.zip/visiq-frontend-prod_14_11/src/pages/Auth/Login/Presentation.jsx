/* eslint-disable jsx-a11y/no-noninteractive-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import { Form, Formik } from 'formik'
import React, { useCallback, useState } from 'react'
import { Link } from 'react-router-dom'
import FormikTextField from '../../../lib/Formik/FormikTextfield'
import * as yup from 'yup'
import PrimaryBtn from '../../../shared/Buttons/PrimaryBtn'
import { view, hide } from '../../../assets'
import Logo from '../../../shared/Logo'
import loading from '../../../assets/loading.json'
import LottieLoader from '../../../shared/LottieLoader_Login'

const Presentation = (props) => {
  const [canSee, setView] = useState(false)
  const { handleSignIn, isLoading } = props

  const initialValues = {
    username: '',
    password: '',
    isWeb: true,
  }

  const handlePasswordToggle = useCallback(() => {
    setView(!canSee)
  }, [canSee])

  const validationSchema = yup.object().shape({
    username: yup.string().required('Enter username'),
    password: yup.string().required('Enter password'),
  })

  const handleFormSubmit = (values, { setSubmitting }) => {
    console.log('Form submitted with values:', values)
    console.log('Username length:', values.username?.length)
    console.log('Password length:', values.password?.length)

    // Check if values are actually present
    if (!values.username || values.username.trim() === '') {
      console.error('Username is empty or whitespace only')
      return
    }

    if (!values.password || values.password.trim() === '') {
      console.error('Password is empty or whitespace only')
      return
    }

    console.log('Calling handleSignIn with:', values)
    handleSignIn(values)
    setSubmitting(false)
  }

  return (
    <div>
      {isLoading ? (
        <div className="h-screen flex items-center justify-center ">
          <LottieLoader data={loading} />
        </div>
      ) : (
        <div className="max-w-md mx-auto flex flex-col justify-center h-screen gap-4 animate-fadeInSmall ">
          <Logo className="animate-logoBounce" />
          <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={handleFormSubmit}
          >
            <Form className=" p-4 rounded-md  flex flex-col gap-3 animate-fadeInSmall">
              <div className="flex flex-col gap-1">
                <label
                  htmlFor="username"
                  className="text-gray-700 text-sm font-semibold ml-3"
                >
                  Enter Username *
                </label>
                <FormikTextField
                  placeholder=" Username"
                  id="username"
                  name="username"
                  className="p-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-300 text-sm"
                />
              </div>

              <div className="flex flex-col gap-1 relative">
                <label
                  htmlFor="password"
                  className="text-gray-700 text-sm font-semibold ml-3"
                >
                  Enter Password *
                </label>
                <FormikTextField
                  placeholder=" Password"
                  name="password"
                  type={canSee ? 'text' : 'password'}
                  icon={{
                    src: canSee ? hide : view,
                    alt: 'toggle visibility',
                    onClick: () => handlePasswordToggle(),
                  }}
                />
              </div>

              <div className="text-right">
                <Link
                  to="/auth/forgot"
                  className="text-blue-500 text-sm mb-1 animate-linkFadeIn inline"
                >
                  Forgot Password?
                </Link>
              </div>

              <PrimaryBtn
                text={'Login'}
                type={'submit'}
                className="text-sm animate-buttonBounce"
              />
            </Form>
          </Formik>
        </div>
      )}
    </div>
  )
}

export default Presentation
