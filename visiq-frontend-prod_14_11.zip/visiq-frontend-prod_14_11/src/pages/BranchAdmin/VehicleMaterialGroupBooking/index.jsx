import React from 'react'
import VehicleMaterialGroupBookingPresentation from './Presentation'

const VehicleMaterialGroupBookingBranchAdmin = () => {
  return <VehicleMaterialGroupBookingPresentation />
}

export default VehicleMaterialGroupBookingBranchAdmin
