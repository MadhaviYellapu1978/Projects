import React, { useCallback, useContext, useState } from 'react'
import PrimaryBtn from '../../../../shared/Buttons/PrimaryBtn'
import * as yup from 'yup'
import { Form, Formik } from 'formik'
import FormikTextField from '../../../../lib/Formik/FormikTextfield'
import { AuthContext } from '../../../../context/AuthContext'
import FormikSelect from '../../../../lib/Formik/FormikSelect'
import { Box, Modal } from '@mui/material'
import { styles } from '../../../../constants/styes'
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query'
import {
  createAdmin,
  listOfCountriesExt,
} from '../../../../services/adminService'
import toast from 'react-hot-toast'
import { apiCall } from '../../../../utils/apiCall.js'

const phoneRegexIndia = /^[0-9]{10}$/
const phoneRegexDubai = /^[0-9]+$/

const validationSchema = yup.object().shape({
  first_name: yup
    .string()
    .required('First name is required')
    .matches(/[a-zA-Z]/, 'First name must contain at least one letter'),
  last_name: yup
    .string()
    .required('Last name is required')
    .matches(/[a-zA-Z]/, 'Last name must contain at least one letter'),
  branch_id: yup.string().required('Branch is required'),
  email: yup
    .string()
    .email('Enter a valid email')
    .required('Branch admin email is required'),
  role: yup.string().required('Role is required'),
  phone: yup
    .string()
    .required('Phone number is required')
    .min(5, 'Phone number must be at least 5 digits')
    .max(10, 'Phone number must not exceed 10 digits')
    .matches(/^[0-9]+$/, 'Phone number must contain only numbers'),
  phone_ext: yup.string().required('Country code is required'),
  username: yup
    .string()
    .required('Username is a required field')
    .min(6, 'Username must be at least 6 characters')
    .test(
      'checkUsernameAvailability',
      'Username is not available',
      async (value) => {
        if (value && value.length >= 6) {
          const response = await apiCall('/auth/availUser', 'POST', {
            username: value,
          })
          return !response.isAvail
        }
        return true
      },
    ),
})

const AddAdmin = ({ branches }) => {
  const [selectedBranch, setSelectedBranch] = useState('')
  const [phoneExt, setPhoneExt] = useState('') // Default Country Code set to empty
  const queryClient = useQueryClient()
  const [isOpen, setIsOpen] = useState(false)
  const auth = useContext(AuthContext)
  const isAdmin = auth?.role === '1' || '2'

  const { data: countrycodes, isCountryCodesLoading } = useQuery({
    queryFn: () => listOfCountriesExt(),
  })
  const mutate = useMutation({
    mutationFn: (values) => createAdmin(values),
    mutationKey: 'createAdmin',
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ['createAdmin'],
      })
      toast.success('Admin Create Successful')
      setIsOpen(false) // Close modal on success
    },
    onError: () => {
      toast.dismiss()
      toast.error('Admin Create Failed')
    },
  })

  const handleClick = useCallback(() => {
    setSelectedBranch('')
    setPhoneExt('') // Ensure phoneExt is reset
    setIsOpen(true)
  }, [])

  const initialValues = {
    first_name: '',
    last_name: '',
    org_id: branches[0]?.org_id || '',
    role: '',
    email: '',
    branch_id: '',
    branch_name: '',
    phone: '',
    phone_ext: phoneExt, // This will be an empty string by default
    username: '',
  }

  return (
    <div>
      <PrimaryBtn text="Add Admin" type={'button'} handleClick={handleClick} />
      <Modal open={isOpen} onClose={() => setIsOpen(false)}>
        <Box sx={styles.modal}>
          <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={(values, { resetForm }) => {
              mutate.mutate(values)
              resetForm()
              setIsOpen(false) // Close modal after successful submit
            }}
          >
            {({ setFieldValue, values }) => (
              <Form style={{ flex: 1 }}>
                <div className="grid grid-cols-2 gap-5">
                  <div>
                    <FormikTextField name="first_name" label="First Name *" />
                  </div>
                  <div>
                    <FormikTextField name="last_name" label="Last Name *" />
                  </div>
                  <div>
                    {/* <FormikSelect
                      name="phone_ext"
                      label="Country Code *"
                      options={[
                        { value: '', label: 'Select Country Code' }, // Default option
                        { value: '+91', label: '+91' },
                        { value: '+971', label: '+971' },
                      ]}
                      onChange={(e) => {
                        const newExt = e.target.value
                        setFieldValue('phone_ext', newExt)
                        setPhoneExt(newExt) // Update phoneExt state
                        setFieldValue('phone', '') // Clear phone number to trigger validation
                      }}
                      value={values.phone_ext}
                    /> */}
                    <FormikSelect
                      name="phone_ext"
                      label="Country Code *"
                      options={
                        isCountryCodesLoading
                          ? [{ value: '', label: 'Loading...' }]
                          : countrycodes.map((country) => ({
                              value: country.code,
                              label: `${country.country} (${country.code})`,
                            }))
                      }
                      onChange={(e) => {
                        setFieldValue('phone_ext', e.target.value) // Properly use setFieldValue from context
                        setFieldValue('phone', '') // Clear phone number to trigger validation
                      }}
                      value={values.phone_ext} // Use values directly
                      disabled={isCountryCodesLoading}
                      MenuProps={{
                        PaperProps: {
                          style: {
                            maxHeight: 200, // Limit dropdown height
                            maxWidth: 200, // Set a smaller dropdown width
                          },
                        },
                      }}
                      InputProps={{
                        style: { width: '200px' }, // Set the input field width
                      }}
                    />
                  </div>
                  <div>
                    <FormikTextField name="phone" label="Phone *" />
                  </div>
                  <div>
                    <FormikTextField name="email" label="Email *" />
                  </div>
                  <div>
                    <FormikTextField name="username" label="Username *" />
                  </div>
                  {isAdmin && (
                    <div>
                      <FormikSelect
                        name="branch_id"
                        label="Branches *"
                        onChange={(e) => {
                          setFieldValue('branch_id', e.target.value)
                          setSelectedBranch(e.target.value)
                        }}
                        value={selectedBranch}
                        options={branches.map((branch) => ({
                          value: branch.branch_id,
                          label: branch.branch_name,
                        }))}
                      />
                    </div>
                  )}
                  <div>
                    <FormikSelect
                      name="role"
                      label="Role *"
                      options={[
                        // { value: '3', label: 'Branch Level Admin' },
                        { value: '4', label: 'Security Level Admin' },
                      ]}
                      onChange={(e) => {
                        setFieldValue('role', e.target.value)
                      }}
                      value={values.role}
                    />
                  </div>
                </div>
                <br />
                <PrimaryBtn text="Add Admin" />
                <button
                  className="btn btn-sm btn-circle btn-ghost absolute right-2 top-2"
                  onClick={() => {
                    setIsOpen(false)
                    setSelectedBranch('')
                    setPhoneExt('') // Reset phoneExt state
                  }}
                >
                  ✕
                </button>
              </Form>
            )}
          </Formik>
        </Box>
      </Modal>
    </div>
  )
}

export default AddAdmin
