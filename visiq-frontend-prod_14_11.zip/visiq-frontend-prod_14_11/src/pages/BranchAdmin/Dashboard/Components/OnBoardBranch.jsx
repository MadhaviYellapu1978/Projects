import React, { useCallback, useContext, useState } from 'react'
import PrimaryBtn from '../../../../shared/Buttons/PrimaryBtn'
import * as yup from 'yup'
import { Form, Formik } from 'formik'
import FormikTextField from '../../../../lib/Formik/FormikTextfield'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { onBoardBranches } from '../../../../services/adminService'
import { AuthContext } from '../../../../context/AuthContext'
import FormikSelect from '../../../../lib/Formik/FormikSelect'
import { Box, Modal } from '@mui/material'
import { styles } from '../../../../constants/styes'
import toast from 'react-hot-toast'

const OnBoardBranch = (props) => {
  const [isOpen, setIsOpen] = useState(false)
  const queryClient = useQueryClient()
  const auth = useContext(AuthContext)
  const mutate = useMutation({
    mutationFn: (values) => onBoardBranches(values),
    mutationKey: 'onBoardBranch',
    onSuccess: (data) => {
      queryClient.invalidateQueries({
        queryKey: ['getBranches'],
      })
      toast.success('Register Branch Successful')
    },
    onError: (err) => {
      toast.dismiss()
      toast.error('Register Branch Failed')
    },
  })

  const handleClick = useCallback(() => {
    setIsOpen(true)
  }, [])

  const validationSchema = yup.object().shape({
    branch_name: yup.string().required('Branch Name is Required'),
    timezone: yup.string().required('Timezone is Required'),
    phone: yup.string().required('Phone Number is Required'),
    phone_ext: yup.string().required('Country code is Required'),
    address: yup
      .string()
      .required('Address is Required')
      .matches(/[a-zA-Z]/, 'Address must contain at least one letter'),
  })

  const initialValues = {
    branch_name: '',
    timezone: '',
    phone: '',
    phone_ext: '',
    address: '',
    branchAdminEmail: '',
  }
  const timezoneOptions = [
    { value: 'IST', label: 'Indian Standard Time (IST)' },
    { value: 'UTC', label: 'Coordinated Universal Time (UTC)' },
  ]

  return (
    <div>
      <PrimaryBtn
        text="Register Branch"
        type={'button'}
        handleClick={handleClick}
      />
      <Modal
        open={isOpen}
        onClose={() => {
          setIsOpen(false)
        }}
      >
        <Box sx={styles.modal}>
          <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={(values, { resetForm }) => {
              const body = {
                org_id: auth.role == '2' ? auth.org_id : props.orgId,
                branches: [values],
              }
              mutate.mutate(body)
              document.getElementById('my_modal_2_btn').click()
              resetForm()
            }}
          >
            {(props) => (
              <Form style={{ flex: 1 }}>
                <FormikTextField name="branch_name" label="Branch Name" />
                <div className="grid grid-cols-2 gap-5">
                  <FormikSelect
                    name={'timezone'}
                    label={'Time'}
                    options={timezoneOptions}
                  />
                  <FormikTextField name="phone" label="Phone" />
                  <FormikTextField name="phone_ext" label="Country Code" />
                  <FormikTextField name="address" label="Address" />
                </div>
                <PrimaryBtn text="Register Branch" />
                <form method="dialog">
                  <button
                    className="btn btn-sm btn-circle btn-ghost absolute right-2 top-2"
                    id="my_modal_2_btn"
                    onClick={() => {
                      props.resetForm()
                      setIsOpen(false)
                    }}
                  >
                    ✕
                  </button>
                </form>
              </Form>
            )}
          </Formik>
        </Box>
      </Modal>
    </div>
  )
}

export default OnBoardBranch
