import React, { useContext, useState } from 'react'
import Attendance from './Components/Attendance'
import VisitorsTable from '../../../shared/VisitorsTable'
import { Tilt } from 'react-tilt'
import BookAVisit from './Components/BookAVisit'
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Typography,
  IconButton,
  Box,
  CircularProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
  Avatar,
  Chip,
  Tooltip,
} from '@mui/material'
import CloseIcon from '@mui/icons-material/Close'
import ExpandLessIcon from '@mui/icons-material/ExpandLess'
import ExpandMoreIcon from '@mui/icons-material/ExpandMore'
import InfoIcon from '@mui/icons-material/Info'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import {
  CheckInCheckOut,
  getAttendance,
  getAllVisitors,
} from '../../../services/adminService'
import { AuthContext } from '../../../context/AuthContext'
import eventEmitter from '../../../utils/eventEmitter'
import DatePicker from 'react-datepicker'
import 'react-datepicker/dist/react-datepicker.css'
import { format } from 'date-fns'
import TotalLoding from '../../../shared/TotalLoding'
import loading from '../../../assets/loading.json'
import { CalendarIcon } from '@mui/x-date-pickers'
// import Marquee from '../../../Marquee'
const Presentation = (props) => {
  const auth = useContext(AuthContext)
  const [isLoading, setIsLoading] = useState(false)
  const [isLoadingVisitors, setisLoadingVisitors] = useState(false)
  const [data_of_visit, set_data_of_visit] = useState(new Date())
  const { branches, orgId } = props
  const [selectedBranch] = useState(branches[0])
  const [branch_id] = useState(branches[0].branch_id)
  const [totalEntryData, setTotalEntryData] = useState([])
  const [checkInData, setCheckenData] = useState([])
  const [checkOutData, setCheckOutData] = useState([])
  const [, setShowVisitorsGrid] = useState(false)
  const [isCheckedIn, setisCheckedIn] = useState(false)
  const [isCheckedOut, setisCheckedOut] = useState(false)
  const [isTotalEntry, setisTotalEntry] = useState(false)
  const [filteredArrivedVisitors, setFilteredArrivedVisitors] = useState([])
  const [_filteredExpectedVisitors, setFilteredExpectedVisitors] = useState([])
  const [visitorType, setVisitorType] = useState('')
  const [vehicleModalOpen, setVehicleModalOpen] = useState(false)
  const [groupModalOpen, setGroupModalOpen] = useState(false)
  const [selectedVisitorForModal, setSelectedVisitorForModal] = useState(null)
  const [expandedVehicles, setExpandedVehicles] = useState({})
  const [expandedCheckinDropdowns, setExpandedCheckinDropdowns] = useState({})
  const [vehicleLoading, setVehicleLoading] = useState(false)
  const [groupLoading, setGroupLoading] = useState(false)
  const [apiData, setApiData] = useState({
    vehicleMaterial: null,
    groupBooking: null,
  })
  const queryClient = useQueryClient()

  // Modal handlers
  const handleOpenVehicleModal = (visitorData) => {
    setSelectedVisitorForModal(visitorData)
    setVehicleModalOpen(true)
    setVehicleLoading(true)

    try {
      // Use data directly from visitor data
      setApiData((prev) => ({
        ...prev,
        vehicleMaterial: {
          vm_bool: visitorData.vm_bool || false,
          mm_bool: visitorData.mm_bool || false,
          vm_details: visitorData.vm_details || [],
          mm_details: visitorData.mm_details || [],
        },
      }))
    } catch (error) {
      console.error('🚗 Error setting vehicle/material data:', error)
    } finally {
      setVehicleLoading(false)
    }
  }

  // Helper function to extract visitor code number
  const extractVisitorCodeNumber = (visitorCode) => {
    if (!visitorCode || typeof visitorCode !== 'string') return null
    const parts = visitorCode.split('-')
    if (parts.length >= 2) {
      return parts[parts.length - 1]
    }
    return null
  }

  // Helper function to check if visitor codes match
  const doVisitorCodesMatch = (mainVisitorCode, groupVisitorCode) => {
    const mainCode = extractVisitorCodeNumber(mainVisitorCode)
    const groupCode = extractVisitorCodeNumber(groupVisitorCode)
    return mainCode !== null && groupCode !== null && mainCode === groupCode
  }

  const handleOpenGroupModal = (visitorData) => {
    setSelectedVisitorForModal(visitorData)
    setGroupModalOpen(true)
    setGroupLoading(true)

    try {
      const mainVisitorName = `${visitorData.first_name || ''} ${
        visitorData.last_name || ''
      }`.trim()
      const mainVisitorCode = visitorData.visitor_code
      const mainVisitorDate =
        visitorData.date_of_visit || visitorData.start_date

      // First, use groupMembers from processed data (same as accordion uses)
      // This is the most reliable source as it's already matched correctly
      const groupMembersFromProcessed = visitorData.groupMembers || []

      // Get all visitors from the getAllVisitors API response for phone number lookup
      const allVisitorsList = visitors?.visitors_List || []
      const arrivedVisitorsList = visitors?.arrivedVisitorsList || []
      const allVisitors = [...allVisitorsList, ...arrivedVisitorsList]

      // Map group members from processed data to grp_details format
      const groupDetailsFromProcessed = groupMembersFromProcessed.map(
        (member) => {
          // Extract email - check multiple possible fields
          const email =
            member.email ||
            member.grp_user_email ||
            member.grp_user_grp_user_email ||
            ''

          // Extract phone number - first try to get from raw API data if available
          let phoneNumber = ''
          // Try to find the visitor in raw API data to get accurate phone number
          const rawVisitor = allVisitors.find(
            (v) =>
              v.visitor_id === member.visitor_id ||
              (v.first_name === member.first_name &&
                v.last_name === member.last_name &&
                v.visitor_code === member.visitor_code),
          )

          if (rawVisitor) {
            // Use phone number from raw API data
            if (
              rawVisitor.phNo &&
              rawVisitor.phNo !== 'undefined' &&
              typeof rawVisitor.phNo !== 'undefined'
            ) {
              phoneNumber = `${rawVisitor.ph_ext || ''}-${
                rawVisitor.phNo
              }`.replace(/^-/, '')
            } else if (
              rawVisitor.ph_no &&
              rawVisitor.ph_no !== 'undefined' &&
              typeof rawVisitor.ph_no !== 'undefined'
            ) {
              phoneNumber = `${rawVisitor.ph_ext || ''}-${
                rawVisitor.ph_no
              }`.replace(/^-/, '')
            } else if (rawVisitor.grp_user_phno) {
              phoneNumber = rawVisitor.grp_user_phno
            }
          }

          // Fallback to processed data if raw API data doesn't have phone number
          if (!phoneNumber) {
            // First check phNos (already formatted), but validate it doesn't contain "undefined"
            if (member.phNos && !member.phNos.includes('undefined')) {
              phoneNumber = member.phNos
            } else if (
              member.phNo &&
              member.phNo !== 'undefined' &&
              typeof member.phNo !== 'undefined'
            ) {
              // Use phNo with ph_ext if available and valid
              phoneNumber = `${member.ph_ext || ''}-${member.phNo}`.replace(
                /^-/,
                '',
              )
            } else if (member.grp_user_phno) {
              // Use grp_user_phno if available
              phoneNumber = member.grp_user_phno
            } else if (
              member.ph_no &&
              member.ph_no !== 'undefined' &&
              typeof member.ph_no !== 'undefined'
            ) {
              // Use ph_no with ph_ext if available and valid
              phoneNumber = `${member.ph_ext || ''}-${member.ph_no}`.replace(
                /^-/,
                '',
              )
            }
          }

          return {
            grp_user_name: `${member.first_name || ''} ${
              member.last_name || ''
            }`.trim(),
            grp_user_email: email,
            grp_user_phno: phoneNumber,
            grp_user_id_proof:
              member.id_proof || member.grp_user_id_proof || null,
            main_visitor_name: mainVisitorName,
            // Include attendance data if available
            attendanceData: member.attendanceData || [],
          }
        },
      )

      // allVisitors already defined above

      // Find group visitors from the API that match this main visitor
      const matchingGroupVisitors = allVisitors.filter((visitor) => {
        // Must be a group visitor
        if (visitor.visitor_type !== 'group_visitor') {
          return false
        }

        // Match by visitor_code (numeric part) and date
        const codesMatch = doVisitorCodesMatch(
          mainVisitorCode,
          visitor.visitor_code,
        )
        const visitorDate = visitor.date_of_visit || visitor.start_date
        const datesMatch = mainVisitorDate === visitorDate

        return codesMatch && datesMatch
      })

      // Map group visitors from API to grp_details format
      const groupDetailsFromAPI = matchingGroupVisitors.map((visitor) => {
        // Extract phone number from API data - check multiple fields
        let phoneNumber = ''
        if (
          visitor.phNo &&
          visitor.phNo !== 'undefined' &&
          typeof visitor.phNo !== 'undefined'
        ) {
          phoneNumber = `${visitor.ph_ext || ''}-${visitor.phNo}`.replace(
            /^-/,
            '',
          )
        } else if (visitor.grp_user_phno) {
          phoneNumber = visitor.grp_user_phno
        } else if (
          visitor.ph_no &&
          visitor.ph_no !== 'undefined' &&
          typeof visitor.ph_no !== 'undefined'
        ) {
          phoneNumber = `${visitor.ph_ext || ''}-${visitor.ph_no}`.replace(
            /^-/,
            '',
          )
        }

        return {
          grp_user_name: `${visitor.first_name || ''} ${
            visitor.last_name || ''
          }`.trim(),
          grp_user_email: visitor.email || visitor.grp_user_email || '',
          grp_user_phno: phoneNumber,
          grp_user_id_proof: visitor.id_proof || visitor.grp_user_id_proof || null,
          main_visitor_name: mainVisitorName,
          // Include attendance data if available
          attendanceData: visitor.attendanceData || [],
        }
      })

      // Use processed group members first (most reliable), then API, then booking grp_details
      let finalGroupDetails = []
      if (groupDetailsFromProcessed.length > 0) {
        finalGroupDetails = groupDetailsFromProcessed
      } else if (groupDetailsFromAPI.length > 0) {
        finalGroupDetails = groupDetailsFromAPI
      } else {
        finalGroupDetails = visitorData.grp_details || []
      }

      setApiData((prev) => ({
        ...prev,
        groupBooking: {
          grp_book_bool:
            visitorData.grp_book_bool ||
            finalGroupDetails.length > 0 ||
            visitorData.mm_bool === true,
          grp_details: finalGroupDetails,
          main_visitor_name: mainVisitorName,
        },
      }))
    } catch (error) {
      console.error('👥 Error setting group booking data:', error)
    } finally {
      setGroupLoading(false)
    }
  }

  const handleCloseModals = () => {
    setVehicleModalOpen(false)
    setGroupModalOpen(false)
    setSelectedVisitorForModal(null)
    setExpandedVehicles({})
    setExpandedCheckinDropdowns({})
  }

  // Set up global window functions for VisitorsTable
  React.useEffect(() => {
    window.openVehicleMaterialModal = handleOpenVehicleModal
    window.openGroupBookingModal = handleOpenGroupModal

    return () => {
      delete window.openVehicleMaterialModal
      delete window.openGroupBookingModal
    }
  }, [])

  const { data: visitors } = useQuery({
    queryKey: [
      'getAllVisitors',
      branch_id,
      format(data_of_visit, 'dd-MM-yyyy'),
    ],
    queryFn: () =>
      getAllVisitors({
        org_id: auth.org_id || orgId,
        branch_id,
        role: '',
        data_of_visit: format(data_of_visit, 'dd-MM-yyyy'),
      }),
    enabled: !!branch_id,
    retry: (failureCount, error) => {
      // Don't retry on 404 errors (endpoint doesn't exist)
      if (error?.response?.status === 404) {
        return false
      }
      // Retry up to 3 times for other errors
      return failureCount < 3
    },
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000), // Exponential backoff
    staleTime: 5 * 60 * 1000, // 5 minutes
    refetchOnWindowFocus: false, // Don't refetch on window focus
    refetchOnMount: false, // Don't refetch on mount if data is fresh
    onSuccess: () => {
      setisLoadingVisitors(false)
      setIsLoading(false)
    },
    onError: () => {
      setisLoadingVisitors(false)
      setIsLoading(false)
    },
  })

  // Listen for booking success events and refetch data
  React.useEffect(() => {
    const handleBookingSuccess = (data) => {
      console.log(
        '🔄 Booking success event received, refetching visitors data...',
        data,
      )
      // Force refetch of visitors data
      queryClient.invalidateQueries({
        queryKey: ['getAllVisitors'],
        exact: false,
      })
      // Also refetch attendance data
      queryClient.invalidateQueries({
        queryKey: ['getAttendance'],
        exact: false,
      })
    }

    eventEmitter.on('bookingSuccess', handleBookingSuccess)

    return () => {
      eventEmitter.off('bookingSuccess', handleBookingSuccess)
    }
  }, [queryClient])

  const mutationAttendance = useMutation({
    mutationFn: (values) => getAttendance(values),
    mutationKey: 'getAttendance',
    onSuccess: (data) => {
      setTotalEntryData(data?.userdata)
      setIsLoading(false)
    },
    onError: () => {
      setIsLoading(false)
    },
  })

  // Temporarily disabled to prevent CORS issues after bookAVisit success
  // useEffect(() => {
  //   console.log(visitors, 'visitors')
  //   getAllVisitors({
  //     org_id: auth.org_id || orgId,
  //     branch_id,
  //     role: '',
  //     data_of_visit: format(data_of_visit, 'dd-MM-yyyy'),
  //   })
  // }, [auth.org_id, orgId, branch_id, data_of_visit, visitors])

  const mutationCheckOut = useMutation({
    mutationFn: (values) => CheckInCheckOut(values),
    onSuccess: (data) => {
      setCheckOutData(data?.userData)
      setIsLoading(false)
    },
    onError: () => {
      setIsLoading(false)
    },
  })

  const mutationCheckIn = useMutation({
    mutationFn: (values) => CheckInCheckOut(values),
    onSuccess: (data) => {
      setCheckenData(data?.userData)
      setIsLoading(false)
    },
    onError: () => {
      setIsLoading(false)
    },
  })

  // Temporarily disabled to prevent CORS issues after bookAVisit success
  // useEffect(() => {
  //   setIsLoading(true)
  //   mutationAttendance.mutate({
  //     org_id: auth.org_id || orgId,
  //     branch_id: selectedBranch.branch_id,
  //     date: format(data_of_visit, 'dd-MM-yyyy'),
  //   })
  // }, [
  //   auth.org_id,
  //   orgId,
  //   selectedBranch.branch_id,
  //   data_of_visit,
  //   mutationAttendance,
  // ])

  const defaultOptions = {
    reverse: false,
    max: 35,
    perspective: 1000,
    scale: 1.05,
    speed: 1000,
    transition: true,
    axis: null,
    reset: true,
    easing: 'cubic-bezier(.03,.98,.52,.99)',
  }

  const handleExpectedVisitorsClick = () => {
    console.log('🔍 DEBUG - Expected visitors clicked (BranchAdmin)')
    console.log('🔍 DEBUG - Current visitors data:', visitors)

    try {
      setIsLoading(true)
      setShowVisitorsGrid(true)
      setVisitorType('expected')

      // Use noShowVisitorsOnlyFalse array from getAllVisitors API for Expected Visitors
      const noShowVisitorsOnlyFalse = visitors?.noShowVisitorsOnlyFalse || []
      const arrivedVisitorsOnlyTrue = visitors?.arrivedVisitorsOnlyTrue || []

      console.log('🔍 DEBUG - Processing noShowVisitorsOnlyFalse array:', {
        totalVisitors: noShowVisitorsOnlyFalse.length,
        currentDate: format(data_of_visit, 'dd-MM-yyyy'),
        visitors: noShowVisitorsOnlyFalse.map((v) => ({
          name: v.first_name,
          date: v.date_of_visit,
          isVisited: v.isVisited,
          visitor_type: v.visitor_type,
          main_visitor_name: v.main_visitor_name,
          main_visitor_email: v.main_visitor_email,
        })),
      })

      console.log(
        '🔍 DEBUG - Full noShowVisitorsOnlyFalse array:',
        noShowVisitorsOnlyFalse,
      )

      console.log('🔍 DEBUG - Processing arrivedVisitorsOnlyTrue array:', {
        totalArrivedVisitors: arrivedVisitorsOnlyTrue.length,
        visitors: arrivedVisitorsOnlyTrue.map((v) => ({
          name: v.first_name,
          email: v.email,
          isVisited: v.isVisited,
        })),
      })

      console.log(
        '🔍 DEBUG - Full arrivedVisitorsOnlyTrue array:',
        arrivedVisitorsOnlyTrue,
      )

      // Filter for current date and process visitors
      const expectedVisitors = []

      // Helper function to expand group members from grp_details
      const expandGroupMembers = (visitor) => {
        const expanded = [visitor] // Always include the main visitor

        // If visitor has group details, expand them into separate visitor entries
        if (
          visitor.grp_details &&
          Array.isArray(visitor.grp_details) &&
          visitor.grp_details.length > 0 &&
          visitor.grp_book_bool
        ) {
          visitor.grp_details.forEach((member) => {
            // Parse group member name
            const fullName = member.grp_user_name || ''
            const nameParts = fullName.split(' ')
            const firstName = nameParts[0] || ''
            const lastName = nameParts.slice(1).join(' ') || ''

            // Create group member visitor entry
            const groupMember = {
              ...visitor,
              first_name: firstName,
              last_name: lastName,
              email: member.grp_user_email || '',
              phNo: member.grp_user_phno || '',
              ph_ext: member.grp_user_phext || '',
              role_name:
                member.grp_user_role_name || member.grp_user_role || '',
              visitor_type: 'group_visitor',
              main_visitor_email: visitor.email || '',
              main_visitor_name:
                `${visitor.first_name} ${visitor.last_name}`.trim(),
              isGroupMember: true,
              grp_user_name: member.grp_user_name,
              grp_user_email: member.grp_user_email,
              grp_user_phno: member.grp_user_phno,
              grp_user_phext: member.grp_user_phext,
              grp_user_role_name: member.grp_user_role_name,
              grp_user_id_proof: member.grp_user_id_proof,
              id_proof: member.grp_user_id_proof,
            }
            expanded.push(groupMember)
          })
        }

        return expanded
      }

      noShowVisitorsOnlyFalse.forEach((visitor) => {
        const dateMatch =
          visitor.date_of_visit === format(data_of_visit, 'dd-MM-yyyy')

        if (!dateMatch) {
          return
        }

        // Keep dates as-is from API response (no formatting)
        const formattedVisitor = {
          ...visitor,
          // Keep dates exactly as they come from API
          start_date: visitor.start_date,
          end_date: visitor.end_date,
        }

        // Expand group members if present
        const expandedVisitors = expandGroupMembers(formattedVisitor)
        // Group members inherit dates from parent visitor via spread operator
        const formattedExpandedVisitors = expandedVisitors.map((v) => ({
          ...v,
          // Keep dates as-is from API
          start_date: v.start_date || formattedVisitor.start_date,
          end_date: v.end_date || formattedVisitor.end_date,
        }))
        expectedVisitors.push(...formattedExpandedVisitors)
      })

      console.log(
        '🔍 DEBUG - Final expected visitors count:',
        expectedVisitors.length,
      )
      console.log(
        '🔍 DEBUG - Expected visitors details:',
        expectedVisitors.map((v) => ({
          name: v.first_name,
          isVisited: v.isVisited,
          visitor_type: v.visitor_type,
          isGroupMember: v.isGroupMember,
          mainVisitorName: v.main_visitor_name,
        })),
      )
      setFilteredExpectedVisitors(expectedVisitors)
    } catch (error) {
      console.error('🔍 ERROR - Error in handleExpectedVisitorsClick:', error)
      setFilteredExpectedVisitors([])
    } finally {
      setIsLoading(false)
    }
  }
  const _updateFilteredArrivedVisitors = async () => {
    const updatedVisitors = await getAttendance({
      org_id: auth.org_id || orgId,
      branch_id,
      date: format(data_of_visit, 'dd-MM-yyyy'),
    })

    // Filter arrived visitors based on the new data
    const arrivedVisitors = updatedVisitors.arrivedVisitorsList.filter(
      (visitor) => {
        // Primary check: isVisited field
        const isVisited = visitor.isVisited === true

        // Fallback checks for legacy data
        const hasLegacyCheckIn =
          visitor.action === 'Arrived' ||
          (visitor.attendanceData &&
            Array.isArray(visitor.attendanceData) &&
            visitor.attendanceData.length > 0) ||
          visitor.entry_time ||
          visitor.last_entry !== '--'

        const hasCheckedIn = isVisited || hasLegacyCheckIn

        return (
          hasCheckedIn &&
          visitor.date_of_visit === format(data_of_visit, 'dd-MM-yyyy')
        )
      },
    )
    setFilteredArrivedVisitors(arrivedVisitors)
  }

  const handleArrivedVisitorsClick = () => {
    console.log('🔍 DEBUG - Arrived visitors clicked')
    console.log('🔍 DEBUG - Current visitors data:', visitors)

    try {
      setIsLoading(true)
      setShowVisitorsGrid(true)
      setVisitorType('arrived')

      // Use arrivedVisitorsOnlyTrue array from getAllVisitors API for Arrived Visitors
      const arrivedVisitorsOnlyTrue = visitors?.arrivedVisitorsOnlyTrue || []

      // Helper function to expand group members from grp_details
      const expandGroupMembers = (visitor) => {
        const expanded = [visitor] // Always include the main visitor

        // If visitor has group details, expand them into separate visitor entries
        if (
          visitor.grp_details &&
          Array.isArray(visitor.grp_details) &&
          visitor.grp_details.length > 0 &&
          visitor.grp_book_bool
        ) {
          visitor.grp_details.forEach((member) => {
            // Parse group member name
            const fullName = member.grp_user_name || ''
            const nameParts = fullName.split(' ')
            const firstName = nameParts[0] || ''
            const lastName = nameParts.slice(1).join(' ') || ''

            // Create group member visitor entry
            const groupMember = {
              ...visitor,
              first_name: firstName,
              last_name: lastName,
              email: member.grp_user_email || '',
              phNo: member.grp_user_phno || '',
              ph_ext: member.grp_user_phext || '',
              role_name:
                member.grp_user_role_name || member.grp_user_role || '',
              visitor_type: 'group_visitor',
              main_visitor_email: visitor.email || '',
              main_visitor_name:
                `${visitor.first_name} ${visitor.last_name}`.trim(),
              isGroupMember: true,
              grp_user_name: member.grp_user_name,
              grp_user_email: member.grp_user_email,
              grp_user_phno: member.grp_user_phno,
              grp_user_phext: member.grp_user_phext,
              grp_user_role_name: member.grp_user_role_name,
              grp_user_id_proof: member.grp_user_id_proof,
              id_proof: member.grp_user_id_proof,
            }
            expanded.push(groupMember)
          })
        }

        return expanded
      }

      // Process arrivedVisitorsOnlyTrue array
      if (arrivedVisitorsOnlyTrue && arrivedVisitorsOnlyTrue.length > 0) {
        // Filter for current date and expand group members
        const arrivedVisitors = []
        arrivedVisitorsOnlyTrue.forEach((visitor) => {
          const dateMatch =
            visitor.date_of_visit === format(data_of_visit, 'dd-MM-yyyy')
          if (!dateMatch) return

          // Keep dates as-is from API response (no formatting)
          const formattedVisitor = {
            ...visitor,
            // Keep dates exactly as they come from API
            start_date: visitor.start_date,
            end_date: visitor.end_date,
          }

          // Expand group members if present
          const expandedVisitors = expandGroupMembers(formattedVisitor)
          // Group members inherit dates from parent visitor via spread operator
          const formattedExpandedVisitors = expandedVisitors.map((v) => ({
            ...v,
            // Keep dates as-is from API
            start_date: v.start_date || formattedVisitor.start_date,
            end_date: v.end_date || formattedVisitor.end_date,
          }))
          arrivedVisitors.push(...formattedExpandedVisitors)
        })

        console.log('🔍 DEBUG - Filtered arrived visitors:', arrivedVisitors)
        console.log(
          '🔍 DEBUG - Arrived visitors count:',
          arrivedVisitors.length,
        )

        setFilteredArrivedVisitors(arrivedVisitors)
      } else {
        console.log('🔍 DEBUG - No arrived visitors data available')
        setFilteredArrivedVisitors([])
      }
    } catch (error) {
      console.error('🔍 ERROR - Error in handleArrivedVisitorsClick:', error)
      setFilteredArrivedVisitors([])
    } finally {
      setIsLoading(false)
    }
  }

  const handleCheckOut = () => {
    setTotalEntryData([])
    setCheckOutData([])
    setCheckenData([])
    setIsLoading(true)
    setisTotalEntry(false)
    setisCheckedIn(false)
    setShowVisitorsGrid(false)
    mutationCheckOut.mutate({
      org_id: auth.org_id || orgId,
      branch_id: selectedBranch.branch_id,
      isCheckedIn: false,
      role: auth?.role || '',
      date: format(data_of_visit, 'dd-MM-yyyy'),
    })
    setisCheckedOut(true)
    setVisitorType('') // Reset visitorType
  }

  const handleCheckIn = () => {
    setTotalEntryData([])
    setCheckOutData([])
    setCheckenData([])
    setIsLoading(true)
    setisCheckedOut(false)
    setisTotalEntry(false)
    setShowVisitorsGrid(false)
    mutationCheckIn.mutate({
      org_id: auth.org_id || orgId,
      branch_id: selectedBranch.branch_id,
      isCheckedIn: true,
      role: auth?.role || '',
      date: format(data_of_visit, 'dd-MM-yyyy'),
    })
    setisCheckedIn(true)
    setVisitorType('') // Reset visitorType
  }

  const handleTotalEntries = () => {
    setIsLoading(true)
    setisCheckedIn(false)
    setisCheckedOut(false)
    setShowVisitorsGrid(false)
    setVisitorType('')
    mutationAttendance.mutate({
      org_id: auth.org_id || orgId,
      branch_id: selectedBranch.branch_id,
      date: format(data_of_visit, 'dd-MM-yyyy'),
    })
    setisTotalEntry(true)
  }

  const handleKeyPress = (event) => {
    if (event.key === 'Enter') {
      handleExpectedVisitorsClick()
    }
  }

  const handleKeyPressCheckout = (event) => {
    if (event.key === 'Enter') {
      handleCheckOut()
    }
  }

  const handleKeyPressCheckIn = (event) => {
    if (event.key === 'Enter') {
      handleCheckIn()
    }
  }

  const handleKeyPressTotalEntries = (event) => {
    if (event.key === 'Enter') {
      handleTotalEntries()
    }
  }
  const CustomInput = React.forwardRef(({ value, onClick }, ref) => (
    <button
      className="btn bg-secondary min-w-36"
      onClick={onClick}
      ref={ref}
      // Ensure the input is not editable
      readOnly
    >
      {value || 'Select a date'}
      <CalendarIcon />
    </button>
  ))
  CustomInput.displayName = 'CustomInput'

  const handleDateChange = (date) => {
    setTotalEntryData([])
    setCheckOutData([])
    setCheckenData([])
    setisCheckedOut(false)
    setisCheckedIn(false)
    setShowVisitorsGrid(false)
    setIsLoading(true)
    set_data_of_visit(date)
    setisLoadingVisitors(true)
    setFilteredArrivedVisitors([])
    setFilteredExpectedVisitors([])
    queryClient.invalidateQueries({
      queryKey: ['getAttendance', branch_id, format(date, 'dd-MM-yyyy')],
    })
    queryClient.invalidateQueries({
      queryKey: ['getAllVisitors', branch_id, format(date, 'dd-MM-yyyy')],
    })
    setisLoadingVisitors(false)
    mutationAttendance.mutate(
      {
      org_id: auth.org_id || orgId,
      branch_id: branch_id,
      date: format(date, 'dd-MM-yyyy'),
      },
      {
        onSuccess: async () => {
          // Wait for getAllVisitors query to refetch with new date
          await queryClient.refetchQueries({
            queryKey: ['getAllVisitors', branch_id, format(date, 'dd-MM-yyyy')],
          })
          
          // Get the updated visitors data
          const updatedVisitors = queryClient.getQueryData([
            'getAllVisitors',
            branch_id,
            format(date, 'dd-MM-yyyy'),
          ])
          
          // If visitorType is set, automatically update table data for the new date
          if (visitorType === 'arrived') {
            // Process arrived visitors for the new date
            const arrivedVisitorsOnlyTrue = updatedVisitors?.arrivedVisitorsOnlyTrue || []
            const arrivedVisitors = []
            
            const expandGroupMembers = (visitor) => {
              const expanded = [visitor]
              if (
                visitor.grp_details &&
                Array.isArray(visitor.grp_details) &&
                visitor.grp_details.length > 0 &&
                visitor.grp_book_bool
              ) {
                visitor.grp_details.forEach((member) => {
                  const fullName = member.grp_user_name || ''
                  const nameParts = fullName.split(' ')
                  const firstName = nameParts[0] || ''
                  const lastName = nameParts.slice(1).join(' ') || ''
                  const groupMember = {
                    ...visitor,
                    first_name: firstName,
                    last_name: lastName,
                    email: member.grp_user_email || '',
                    phNo: member.grp_user_phno || '',
                    ph_ext: member.grp_user_phext || '',
                    role_name: member.grp_user_role_name || member.grp_user_role || '',
                    visitor_type: 'group_visitor',
                    main_visitor_email: visitor.email || '',
                    main_visitor_name: `${visitor.first_name} ${
                      visitor.last_name
                    }`.trim(),
                    isGroupMember: true,
                  }
                  expanded.push(groupMember)
                })
              }
              return expanded
            }
            
            arrivedVisitorsOnlyTrue.forEach((visitor) => {
              const dateMatch = visitor.date_of_visit === format(date, 'dd-MM-yyyy')
              if (!dateMatch) return
              
              const formattedVisitor = {
                ...visitor,
                start_date: visitor.start_date,
                end_date: visitor.end_date,
              }
              
              const expandedVisitors = expandGroupMembers(formattedVisitor)
              const formattedExpandedVisitors = expandedVisitors.map((v) => ({
                ...v,
                start_date: v.start_date || formattedVisitor.start_date,
                end_date: v.end_date || formattedVisitor.end_date,
              }))
              arrivedVisitors.push(...formattedExpandedVisitors)
            })
            
            setFilteredArrivedVisitors(arrivedVisitors)
          } else if (visitorType === 'expected') {
            // Process expected/no show visitors for the new date
            const noShowVisitorsOnlyFalse = updatedVisitors?.noShowVisitorsOnlyFalse || []
            const expectedVisitors = []
            
            const expandGroupMembers = (visitor) => {
              const expanded = [visitor]
              if (
                visitor.grp_details &&
                Array.isArray(visitor.grp_details) &&
                visitor.grp_details.length > 0 &&
                visitor.grp_book_bool
              ) {
                visitor.grp_details.forEach((member) => {
                  const fullName = member.grp_user_name || ''
                  const nameParts = fullName.split(' ')
                  const firstName = nameParts[0] || ''
                  const lastName = nameParts.slice(1).join(' ') || ''
                  const groupMember = {
                    ...visitor,
                    first_name: firstName,
                    last_name: lastName,
                    email: member.grp_user_email || '',
                    phNo: member.grp_user_phno || '',
                    ph_ext: member.grp_user_phext || '',
                    role_name: member.grp_user_role_name || member.grp_user_role || '',
                    visitor_type: 'group_visitor',
                    main_visitor_email: visitor.email || '',
                    main_visitor_name: `${visitor.first_name} ${
                      visitor.last_name
                    }`.trim(),
                    isGroupMember: true,
                  }
                  expanded.push(groupMember)
                })
              }
              return expanded
            }
            
            noShowVisitorsOnlyFalse.forEach((visitor) => {
              const dateMatch = visitor.date_of_visit === format(date, 'dd-MM-yyyy')
              if (!dateMatch) return
              
              const formattedVisitor = {
                ...visitor,
                start_date: visitor.start_date,
                end_date: visitor.end_date,
              }
              
              const expandedVisitors = expandGroupMembers(formattedVisitor)
              const formattedExpandedVisitors = expandedVisitors.map((v) => ({
                ...v,
                start_date: v.start_date || formattedVisitor.start_date,
                end_date: v.end_date || formattedVisitor.end_date,
              }))
              expectedVisitors.push(...formattedExpandedVisitors)
            })
            
            setFilteredExpectedVisitors(expectedVisitors)
          }
          setIsLoading(false)
        },
        onError: () => {
          setIsLoading(false)
        },
      },
    )
  }
  console.log(data_of_visit, 'data_of_visit')
  console.log(new Date(data_of_visit), 'Date_of_visit_Date')
  console.log(new Date(), 'Today Dateee')
  return (
    <div className="px-5 py-4">
      <div className="overflow-hidden whitespace-nowrap">
        <div className="animate-marquee inline-block">
          Welcome to VisiQ! Keep your workforce safe and manage your visitors at
          any scale with a simple yet effective AI-based visitor management
          system.
        </div>
      </div>
      <div className="my-12 gap-12 hidden md:grid md:grid-cols-6">
        <Tilt options={defaultOptions}>
          <div className="bg-card-bg p-[2px] rounded-xl bg-cover">
            <div className="bg-white h-full rounded-xl p-5 flex flex-col items-center justify-center">
              <h2 className="card-title text-center text-lg">Total Branches</h2>
              <p className="text-5xl mt-2 text-center">{branches.length}</p>
            </div>
          </div>
        </Tilt>
        <Tilt options={defaultOptions}>
          <div
            className="bg-card-bg p-[2px] rounded-xl bg-cover"
            role="button"
            tabIndex={0}
            onClick={handleTotalEntries}
            onKeyPress={handleKeyPressTotalEntries}
          >
            <div className="bg-white h-full rounded-xl p-5 flex flex-col items-center justify-center">
              <h2 className="card-title text-lg">Total Entries</h2>
              <p className="text-5xl mt-2">{visitors?.totalEntries || 0}</p>
            </div>
          </div>
        </Tilt>
        <Tilt options={defaultOptions}>
          <div
            className="bg-card-bg p-[2px] rounded-xl bg-cover"
            role="button"
            tabIndex={0}
            onClick={handleCheckIn}
            onKeyPress={handleKeyPressCheckIn}
          >
            <div className="bg-white h-full rounded-xl p-5 flex flex-col items-center justify-center">
              <h2 className="card-title text-lg">Check-Ins</h2>
              <p className="text-5xl mt-2">{visitors?.totalCheckIns || 0}</p>
            </div>
          </div>
        </Tilt>
        <Tilt options={defaultOptions}>
          <div
            className="bg-card-bg p-[2px] rounded-xl bg-cover "
            role="button"
            tabIndex={0}
            onClick={handleCheckOut}
            onKeyPress={handleKeyPressCheckout}
          >
            <div className="bg-white h-full rounded-xl p-5 flex flex-col items-center justify-center">
              <h2 className="card-title text-lg"> Check-Outs</h2>
              <p className="text-5xl mt-2">{visitors?.totalCheckOuts || 0}</p>
            </div>
          </div>
        </Tilt>
        <Tilt options={defaultOptions}>
          <div
            className="bg-card-bg p-[2px] rounded-xl bg-cover"
            role="button"
            tabIndex={0}
            onClick={handleExpectedVisitorsClick}
            onKeyPress={handleKeyPress}
          >
            <div className="bg-white h-full rounded-xl p-5 flex flex-col items-center justify-center">
              <h2 className="card-title text-lg">
                {visitors?.noShowVisitorsDate === true
                  ? 'No Show Visitors'
                  : 'Expected Visitors'}{' '}
              </h2>
              <p className="text-5xl mt-2">{visitors?.expectedVisitors || 0}</p>
            </div>
          </div>
        </Tilt>
        <Tilt options={defaultOptions}>
          <div
            className="bg-card-bg p-[2px] rounded-xl bg-cover"
            role="button"
            tabIndex={0}
            onClick={handleArrivedVisitorsClick}
            onKeyPress={(event) => {
              if (event.key === 'Enter') handleArrivedVisitorsClick()
            }}
          >
            <div className="bg-white h-full rounded-xl p-5 flex flex-col items-center justify-center">
              <h2 className="card-title text-lg">Arrived Visitors</h2>
              <p className="text-5xl mt-2">{visitors?.arrivedVisitors || 0}</p>
            </div>
          </div>
        </Tilt>
      </div>
      <div className="flex justify-between gap-6">
        <div className="flex gap-5 items-end justify-center">
          <div className="flex flex-col justify-between">
            <p className="text-sm font-bold mb-2">Your Branch Name :</p>
            <div className="btn  bg-secondary">
              {selectedBranch?.branch_name}
            </div>
          </div>
          <div className="flex flex-col justify-between">
            <p className="text-sm font-bold mb-2 ml-2">Select Date :</p>
            <DatePicker
              selected={data_of_visit}
              onChange={(date) => handleDateChange(date)}
              dateFormat="dd-MM-yyyy"
              className="btn m-1 bg-secondary"
              customInput={<CustomInput />}
              onKeyDown={(e) => e.preventDefault()}
            />
          </div>
        </div>
        <div className="flex gap-3 mt-4">
          {branches.length !== 0 && <BookAVisit branches={branches} />}
        </div>
      </div>
      <div className="py-12">
        {isLoadingVisitors || isLoading ? (
          <div className="text-xl text-center">
            <TotalLoding data={loading} height="20vh" />
          </div>
        ) : visitorType === 'arrived' && filteredArrivedVisitors.length > 0 ? (
          <VisitorsTable
            data={filteredArrivedVisitors}
            allVisitorsData={visitors}
            orgId={orgId}
            branch_id={branch_id}
            branch={selectedBranch}
            data_of_visit={data_of_visit}
            visitorType={visitorType}
            name={auth?.username}
            report_name="Arrived Visitors Reports"
          />
        ) : visitorType === 'expected' &&
          _filteredExpectedVisitors?.length > 0 ? (
          <VisitorsTable
            data={_filteredExpectedVisitors}
            allVisitorsData={visitors}
            dataOfVisit={data_of_visit}
            orgId={orgId}
            branch_id={branch_id}
            branch={selectedBranch}
            data_of_visit={data_of_visit}
            visitorType={visitorType}
            name={auth?.username}
            report_name="Expected Visitors Reports"
          />
        ) : isTotalEntry && totalEntryData.length > 0 ? (
          <Attendance
            userData={totalEntryData}
            branch={selectedBranch}
            data_of_visit={data_of_visit}
            name={auth?.username}
            report_name="Total Entries Reports"
          />
        ) : isCheckedIn && checkInData?.length > 0 ? (
          <Attendance
            userData={checkInData}
            branch={selectedBranch}
            data_of_visit={data_of_visit}
            name={auth?.username}
            report_name="Check-In's Reports"
          />
        ) : isCheckedOut && checkOutData?.length > 0 ? (
          <Attendance
            userData={checkOutData}
            branch={selectedBranch}
            data_of_visit={data_of_visit}
            name={auth?.username}
            report_name="Check-Out's Reports"
          />
        ) : totalEntryData && totalEntryData.length > 0 ? (
          <Attendance
            userData={totalEntryData}
            branch={selectedBranch}
            data_of_visit={data_of_visit}
            name={auth?.username}
            report_name="Total Entries Reports"
          />
        ) : (
          <div className="text-xl text-center">No Attendance Data</div>
        )}
      </div>

      {/* Vehicle/Material Details Modal */}
      <Dialog
        open={vehicleModalOpen}
        onClose={handleCloseModals}
        maxWidth="lg"
        fullWidth
        PaperProps={{
          sx: {
            borderRadius: 2,
            boxShadow: '0 8px 32px rgba(0,0,0,0.12)',
          },
        }}
      >
        <DialogTitle
          sx={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            backgroundColor: '#f5f5f5',
            borderBottom: '1px solid #e0e0e0',
          }}
        >
          <Box>
            <Typography
              variant="h5"
              component="div"
              sx={{ fontWeight: 'bold' }}
            >
              Vehicle & Material Records
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Manage your vehicle and material information
            </Typography>
          </Box>
          <IconButton onClick={handleCloseModals} size="small">
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        <DialogContent dividers sx={{ p: 0 }}>
          {selectedVisitorForModal && (
            <Box>
              {vehicleLoading ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
                  <CircularProgress />
                  <Typography variant="body1" sx={{ ml: 2 }}>
                    Loading vehicle/material details...
                  </Typography>
                </Box>
              ) : (
                <Box sx={{ p: 2 }}>
                  {/* Expandable Vehicle Table */}
                  {apiData.vehicleMaterial?.vm_bool &&
                    apiData.vehicleMaterial?.vm_details &&
                    apiData.vehicleMaterial?.vm_details.length > 0 && (
                      <TableContainer component={Paper} sx={{ mb: 2 }}>
                        <Table>
                          <TableHead>
                            <TableRow sx={{ backgroundColor: '#f5f5f5' }}>
                              <TableCell sx={{ width: 50 }}></TableCell>
                              <TableCell sx={{ fontWeight: 'bold' }}>
                                Vehicle Name
                              </TableCell>
                              <TableCell sx={{ fontWeight: 'bold' }}>
                                Vehicle Type
                              </TableCell>
                              <TableCell sx={{ fontWeight: 'bold' }}>
                                Driver Licence Number
                              </TableCell>
                              <TableCell sx={{ fontWeight: 'bold' }}>
                                Insurance Provider
                              </TableCell>
                              <TableCell sx={{ fontWeight: 'bold' }}>
                                Insurance Number
                              </TableCell>
                              <TableCell sx={{ fontWeight: 'bold' }}>
                                RC Numbers
                              </TableCell>
                              <TableCell sx={{ fontWeight: 'bold' }}>
                                Vehicle Comments
                              </TableCell>
                              <TableCell sx={{ fontWeight: 'bold' }}>
                                Status
                              </TableCell>
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            {apiData.vehicleMaterial?.vm_details.map(
                              (vehicle, vehicleIndex) => (
                                <React.Fragment key={vehicleIndex}>
                                  <TableRow>
                                    <TableCell>
                                      <IconButton
                                        size="small"
                                        onClick={() => {
                                          const newExpanded = {
                                            ...expandedVehicles,
                                          }
                                          newExpanded[vehicleIndex] =
                                            !newExpanded[vehicleIndex]
                                          setExpandedVehicles(newExpanded)
                                        }}
                                      >
                                        {expandedVehicles[vehicleIndex] ? (
                                          <ExpandLessIcon fontSize="small" />
                                        ) : (
                                          <ExpandMoreIcon fontSize="small" />
                                        )}
                                      </IconButton>
                                    </TableCell>
                                    <TableCell>
                                      {vehicle.vehicle_name}
                                    </TableCell>
                                    <TableCell>
                                      {vehicle.vehicle_type}
                                    </TableCell>
                                    <TableCell>
                                      {vehicle.driver_licence}
                                    </TableCell>
                                    <TableCell>
                                      {vehicle.insurance_provider}
                                    </TableCell>
                                    <TableCell>
                                      {vehicle.insurance_no}
                                    </TableCell>
                                    <TableCell>{vehicle.rc_no}</TableCell>
                                    <TableCell>
                                      {vehicle.vehicle_comments}
                                    </TableCell>
                                    <TableCell>
                                      <Box
                                        sx={{
                                          display: 'flex',
                                          alignItems: 'center',
                                          gap: 1,
                                        }}
                                      >
                                        <Chip
                                          label={
                                            vehicle.vehicle_status ||
                                            vehicle.status ||
                                            'Pending'
                                          }
                                          color={
                                            vehicle.vehicle_status ===
                                              'Approved' ||
                                            vehicle.status === 'Approved'
                                              ? 'success'
                                              : vehicle.vehicle_status ===
                                                    'Rejected' ||
                                                  vehicle.status === 'Rejected'
                                                ? 'error'
                                                : vehicle.vehicle_status ===
                                                      'pending' ||
                                                    vehicle.status === 'pending'
                                                  ? 'warning'
                                                  : 'default'
                                          }
                                          size="small"
                                          variant="outlined"
                                        />
                                        {(() => {
                                          const isRejected =
                                            (vehicle.vehicle_status &&
                                              vehicle.vehicle_status.toLowerCase() ===
                                                'rejected') ||
                                            (vehicle.status &&
                                              vehicle.status.toLowerCase() ===
                                                'rejected')
                                          console.log(
                                            'BranchAdmin Vehicle rejection check:',
                                            {
                                              vehicle_status:
                                                vehicle.vehicle_status,
                                              status: vehicle.status,
                                              isRejected,
                                              vehicle_name:
                                                vehicle.vehicle_name,
                                            },
                                          )
                                          return isRejected
                                        })() && (
                                          <Tooltip
                                            title={
                                              vehicle.rejected_reason ||
                                              vehicle.vehicle_comments ||
                                              'No rejection reason provided'
                                            }
                                            arrow
                                          >
                                            <div
                                              style={{
                                                display: 'inline-block',
                                                marginLeft: '8px',
                                                cursor: 'pointer',
                                              }}
                                            >
                                              <InfoIcon
                                                sx={{
                                                  fontSize: 16,
                                                  color: 'error.main',
                                                  cursor: 'pointer',
                                                }}
                                              />
                                            </div>
                                          </Tooltip>
                                        )}
                                      </Box>
                                    </TableCell>
                                  </TableRow>
                                  {expandedVehicles[vehicleIndex] && (
                                    <TableRow>
                                      <TableCell colSpan={9}>
                                        <Box sx={{ p: 2 }}>
                                          <Typography
                                            variant="h6"
                                            sx={{ mb: 2, fontWeight: 'bold' }}
                                          >
                                            Material Details
                                          </Typography>
                                          {apiData.vehicleMaterial?.mm_bool &&
                                            apiData.vehicleMaterial
                                              ?.mm_details &&
                                            apiData.vehicleMaterial?.mm_details.filter(
                                              (material) =>
                                                material.material_vehicle_id ===
                                                vehicle.vehicle_id,
                                            ).length > 0 && (
                                              <TableContainer component={Paper}>
                                                <Table size="small">
                                                  <TableHead>
                                                    <TableRow
                                                      sx={{
                                                        backgroundColor:
                                                          '#f8f9fa',
                                                      }}
                                                    >
                                                      <TableCell
                                                        sx={{
                                                          fontWeight: 'bold',
                                                        }}
                                                      >
                                                        Material Name
                                                      </TableCell>
                                                      <TableCell
                                                        sx={{
                                                          fontWeight: 'bold',
                                                        }}
                                                      >
                                                        Device Model
                                                      </TableCell>
                                                      <TableCell
                                                        sx={{
                                                          fontWeight: 'bold',
                                                        }}
                                                      >
                                                        Material Description
                                                      </TableCell>
                                                      <TableCell
                                                        sx={{
                                                          fontWeight: 'bold',
                                                        }}
                                                      >
                                                        Quantity
                                                      </TableCell>
                                                      <TableCell
                                                        sx={{
                                                          fontWeight: 'bold',
                                                        }}
                                                      >
                                                        Number of Units
                                                      </TableCell>
                                                      <TableCell
                                                        sx={{
                                                          fontWeight: 'bold',
                                                        }}
                                                      >
                                                        Serial Number
                                                      </TableCell>
                                                      <TableCell
                                                        sx={{
                                                          fontWeight: 'bold',
                                                        }}
                                                      >
                                                        Status
                                                      </TableCell>
                                                    </TableRow>
                                                  </TableHead>
                                                  <TableBody>
                                                    {apiData.vehicleMaterial?.mm_details
                                                      .filter(
                                                        (material) =>
                                                          material.material_vehicle_id ===
                                                          vehicle.vehicle_id,
                                                      )
                                                      .map(
                                                        (
                                                          material,
                                                          materialIndex,
                                                        ) => (
                                                          <TableRow
                                                            key={materialIndex}
                                                          >
                                                            <TableCell>
                                                              {
                                                                material.material_name
                                                              }
                                                            </TableCell>
                                                            <TableCell>
                                                              {
                                                                material.material_device_model
                                                              }
                                                            </TableCell>
                                                            <TableCell>
                                                              {
                                                                material.material_description
                                                              }
                                                            </TableCell>
                                                            <TableCell>
                                                              {
                                                                material.material_quantity
                                                              }
                                                            </TableCell>
                                                            <TableCell>
                                                              {
                                                                material.material_no_of_units
                                                              }
                                                            </TableCell>
                                                            <TableCell>
                                                              {
                                                                material.material_s_n
                                                              }
                                                            </TableCell>
                                                            <TableCell>
                                                              <Box
                                                                sx={{
                                                                  display:
                                                                    'flex',
                                                                  flexDirection:
                                                                    'column',
                                                                  gap: 0.5,
                                                                }}
                                                              >
                                                                <Typography
                                                                  variant="body2"
                                                                  sx={{
                                                                    color:
                                                                      material.status ===
                                                                      'rejected'
                                                                        ? 'error.main'
                                                                        : material.status ===
                                                                            'approved'
                                                                          ? 'success.main'
                                                                          : 'warning.main',
                                                                    fontWeight:
                                                                      'bold',
                                                                  }}
                                                                >
                                                                  {material.status ||
                                                                    'pending'}
                                                                </Typography>
                                                                {material.status ===
                                                                  'rejected' && (
                                                                  <Tooltip
                                                                    title={
                                                                      material.rejected_reason ||
                                                                      material.material_comments ||
                                                                      'No rejection reason provided'
                                                                    }
                                                                    arrow
                                                                  >
                                                                    <InfoIcon
                                                                      sx={{
                                                                        fontSize: 14,
                                                                        color:
                                                                          'error.main',
                                                                        cursor:
                                                                          'pointer',
                                                                      }}
                                                                    />
                                                                  </Tooltip>
                                                                )}
                                                              </Box>
                                                            </TableCell>
                                                          </TableRow>
                                                        ),
                                                      )}
                                                  </TableBody>
                                                </Table>
                                              </TableContainer>
                                            )}
                                        </Box>
                                      </TableCell>
                                    </TableRow>
                                  )}
                                </React.Fragment>
                              ),
                            )}
                          </TableBody>
                        </Table>
                      </TableContainer>
                    )}
                </Box>
              )}
            </Box>
          )}
        </DialogContent>
        <DialogActions
          sx={{ backgroundColor: '#f5f5f5', borderTop: '1px solid #e0e0e0' }}
        >
          <Button
            onClick={handleCloseModals}
            color="primary"
            variant="contained"
          >
            Close
          </Button>
        </DialogActions>
      </Dialog>

      {/* Group Booking Details Modal */}
      <Dialog
        open={groupModalOpen}
        onClose={handleCloseModals}
        maxWidth="lg"
        fullWidth
        PaperProps={{
          sx: {
            borderRadius: 2,
            boxShadow: '0 8px 32px rgba(0,0,0,0.12)',
            maxHeight: '85vh',
            height: '80vh',
            overflow: 'auto',
            overflowX: 'auto',
            overflowY: 'auto',
          },
        }}
      >
        <DialogTitle
          sx={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            backgroundColor: '#f5f5f5',
            borderBottom: '1px solid #e0e0e0',
          }}
        >
          <Box>
            <Typography
              variant="h5"
              component="div"
              sx={{ fontWeight: 'bold' }}
            >
              {selectedVisitorForModal?.fullName || 'Group Visit Members'}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Manage your group visit members
            </Typography>
          </Box>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <Box
              sx={{
                backgroundColor: '#E3F2FD',
                color: '#1976D2',
                padding: '8px 16px',
                borderRadius: '20px',
                display: 'flex',
                alignItems: 'center',
                gap: 1,
                fontSize: '0.875rem',
                fontWeight: 500,
              }}
            >
              <Typography variant="body2" sx={{ fontWeight: 'bold' }}>
                {apiData.groupBooking?.grp_details?.length || 0} Total
              </Typography>
            </Box>
            <IconButton onClick={handleCloseModals} size="small">
              <CloseIcon />
            </IconButton>
          </Box>
        </DialogTitle>
        <DialogContent dividers sx={{ p: 0 }}>
          {selectedVisitorForModal && (
            <Box>
              {groupLoading ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
                  <CircularProgress />
                  <Typography variant="body1" sx={{ ml: 2 }}>
                    Loading group booking details...
                  </Typography>
                </Box>
              ) : (
                <Box sx={{ p: 2 }}>
                  {/* Group Members Table */}
                  {apiData.groupBooking?.grp_book_bool &&
                    apiData.groupBooking?.grp_details &&
                    apiData.groupBooking?.grp_details.length > 0 && (
                      <TableContainer component={Paper} sx={{ mb: 2 }}>
                        <Table>
                          <TableHead>
                            <TableRow sx={{ backgroundColor: '#f5f5f5' }}>
                              <TableCell sx={{ fontWeight: 'bold' }}>
                                Member Details
                              </TableCell>
                              <TableCell sx={{ fontWeight: 'bold' }}>
                                Contact Information
                              </TableCell>
                              <TableCell sx={{ fontWeight: 'bold' }}>
                                ID Proof
                              </TableCell>
                              {visitorType === 'arrived' && (
                                <TableCell sx={{ fontWeight: 'bold' }}>
                                  Check-in/out
                                </TableCell>
                              )}
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            {apiData.groupBooking?.grp_details.map(
                              (member, index) => (
                                <TableRow
                                  key={index}
                                  sx={{
                                    '&:not(:last-child)': {
                                      borderBottom: '2px solid #f0f0f0',
                                    },
                                  }}
                                >
                                  <TableCell>
                                    <Box
                                      sx={{
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: 2,
                                      }}
                                    >
                                      <Avatar
                                        sx={{
                                          backgroundColor: '#00BCD4',
                                          width: 40,
                                          height: 40,
                                        }}
                                      >
                                        {member.grp_user_name
                                          ?.charAt(0)
                                          ?.toUpperCase() || 'M'}
                                      </Avatar>
                                      <Box>
                                        <Typography
                                          variant="body1"
                                          sx={{ fontWeight: 'bold' }}
                                        >
                                          {member.grp_user_name}
                                        </Typography>
                                        <Typography
                                          variant="body2"
                                          color="text.secondary"
                                        >
                                          Member #{index + 1}
                                        </Typography>
                                      </Box>
                                    </Box>
                                  </TableCell>
                                  <TableCell>
                                    <Box>
                                      {member.grp_user_email ? (
                                      <Typography variant="body2">
                                        {member.grp_user_email}
                                      </Typography>
                                      ) : (
                                        <Typography
                                          variant="body2"
                                          color="text.secondary"
                                        >
                                          N/A
                                        </Typography>
                                      )}
                                      {member.grp_user_phno ? (
                                      <Typography variant="body2">
                                        {member.grp_user_phno}
                                      </Typography>
                                      ) : (
                                        <Typography
                                          variant="body2"
                                          color="text.secondary"
                                        >
                                          N/A
                                        </Typography>
                                      )}
                                      {member.main_visitor_name && (
                                        <Typography
                                          variant="caption"
                                          color="text.secondary"
                                          sx={{ mt: 0.5, display: 'block' }}
                                        >
                                          Main Visitor:{' '}
                                          {member.main_visitor_name}
                                        </Typography>
                                      )}
                                    </Box>
                                  </TableCell>
                                  <TableCell>
                                    {member.grp_user_id_proof ? (
                                      <Button
                                        variant="text"
                                        color="primary"
                                        size="small"
                                        sx={{
                                          textTransform: 'none',
                                          color: '#1976d2',
                                          textDecoration: 'underline',
                                          '&:hover': {
                                            color: '#1565c0',
                                            backgroundColor:
                                              'rgba(25, 118, 210, 0.04)',
                                          },
                                        }}
                                        onClick={() => {
                                          if (member.grp_user_id_proof) {
                                            window.open(
                                              member.grp_user_id_proof,
                                              '_blank',
                                            )
                                          }
                                        }}
                                      >
                                        View ID proof
                                      </Button>
                                    ) : (
                                      <Typography
                                        variant="body2"
                                        color="text.secondary"
                                      >
                                        No ID proof
                                      </Typography>
                                    )}
                                  </TableCell>
                                  {visitorType === 'arrived' && (
                                    <TableCell>
                                      <Box
                                        sx={{
                                          display: 'flex',
                                          alignItems: 'center',
                                          gap: 1,
                                        }}
                                      >
                                        <Typography variant="body2">
                                          {(() => {
                                            // Get latest entry and exit times
                                            const latestEntry =
                                              member.attendanceData
                                                ?.filter((att) => att.isEntry)
                                                ?.sort(
                                                  (a, b) =>
                                                    new Date(b.entry_time) -
                                                    new Date(a.entry_time),
                                                )?.[0]
                                            const latestExit =
                                              member.attendanceData
                                                ?.filter((att) => !att.isEntry)
                                                ?.sort(
                                                  (a, b) =>
                                                    new Date(b.exit_time) -
                                                    new Date(a.exit_time),
                                                )?.[0]

                                            const entryTime =
                                              latestEntry?.entry_time
                                                ? new Date(
                                                    latestEntry.entry_time,
                                                  ).toLocaleTimeString(
                                                    'en-GB',
                                                    {
                                                      hour12: false,
                                                      hour: '2-digit',
                                                      minute: '2-digit',
                                                      second: '2-digit',
                                                    },
                                                  )
                                                : '--'
                                            const exitTime =
                                              latestExit?.exit_time
                                                ? new Date(
                                                    latestExit.exit_time,
                                                  ).toLocaleTimeString(
                                                    'en-GB',
                                                    {
                                                      hour12: false,
                                                      hour: '2-digit',
                                                      minute: '2-digit',
                                                      second: '2-digit',
                                                    },
                                                  )
                                                : '--'

                                            return `${entryTime} - ${exitTime}`
                                          })()}
                                        </Typography>
                                        <IconButton
                                          size="small"
                                          onClick={() => {
                                            const newExpanded = {}
                                            newExpanded[index] =
                                              !expandedCheckinDropdowns[index]
                                            setExpandedCheckinDropdowns(
                                              newExpanded,
                                            )
                                          }}
                                        >
                                          {expandedCheckinDropdowns[index] ? (
                                            <ExpandLessIcon fontSize="small" />
                                          ) : (
                                            <ExpandMoreIcon fontSize="small" />
                                          )}
                                        </IconButton>
                                      </Box>
                                      {expandedCheckinDropdowns[index] && (
                                        <Box
                                          sx={{
                                            mt: 1,
                                            p: 2,
                                            backgroundColor: '#fafafa',
                                            borderRadius: 1,
                                          }}
                                        >
                                          {member.attendanceData &&
                                          member.attendanceData.length > 0 ? (
                                            <Box>
                                              {member.attendanceData
                                                .sort(
                                                  (a, b) =>
                                                    new Date(
                                                      a.entry_time ||
                                                        a.exit_time,
                                                    ) -
                                                    new Date(
                                                      b.entry_time ||
                                                        b.exit_time,
                                                    ),
                                                )
                                                .map((attendance, attIndex) => (
                                                  <Box
                                                    key={attIndex}
                                                    sx={{
                                                      mb: 2,
                                                      display: 'flex',
                                                      alignItems: 'center',
                                                      justifyContent:
                                                        'space-between',
                                                      padding: '8px',
                                                      backgroundColor:
                                                        '#fafafa',
                                                      borderRadius: '4px',
                                                    }}
                                                  >
                                                    <Typography
                                                      variant="body2"
                                                      color="primary.main"
                                                      sx={{
                                                        fontSize: '0.75rem',
                                                      }}
                                                    >
                                                      🔵 IN:{' '}
                                                      {attendance.isEntry &&
                                                      attendance.entry_time
                                                        ? new Date(
                                                            attendance.entry_time,
                                                          ).toLocaleTimeString(
                                                            'en-GB',
                                                            {
                                                              hour12: false,
                                                              hour: '2-digit',
                                                              minute: '2-digit',
                                                              second: '2-digit',
                                                            },
                                                          )
                                                        : '--'}
                                                    </Typography>
                                                    <Typography
                                                      variant="body2"
                                                      color="error.main"
                                                      sx={{
                                                        fontSize: '0.75rem',
                                                      }}
                                                    >
                                                      🔴 OUT:{' '}
                                                      {!attendance.isEntry &&
                                                      attendance.exit_time
                                                        ? new Date(
                                                            attendance.exit_time,
                                                          ).toLocaleTimeString(
                                                            'en-GB',
                                                            {
                                                              hour12: false,
                                                              hour: '2-digit',
                                                              minute: '2-digit',
                                                              second: '2-digit',
                                                            },
                                                          )
                                                        : '--'}
                                                    </Typography>
                                                  </Box>
                                                ))}
                                            </Box>
                                          ) : (
                                            <Typography
                                              variant="body2"
                                              color="text.secondary"
                                            >
                                              No attendance data available
                                            </Typography>
                                          )}
                                        </Box>
                                      )}
                                    </TableCell>
                                  )}
                                </TableRow>
                              ),
                            )}
                          </TableBody>
                        </Table>
                      </TableContainer>
                    )}
                </Box>
              )}
            </Box>
          )}
        </DialogContent>
        <DialogActions
          sx={{ backgroundColor: '#f5f5f5', borderTop: '1px solid #e0e0e0' }}
        >
          <Button
            onClick={handleCloseModals}
            color="primary"
            variant="contained"
          >
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  )
}

export default Presentation
