import React, { useContext } from 'react'
import Presentation from './Presentation'
import { useQuery } from '@tanstack/react-query'
import { getBranchesByOrgId } from '../../../services/adminService'
import { AuthContext } from '../../../context/AuthContext'
import { useParams } from 'react-router-dom'
import loading from '../../../assets/loading.json'
import LottieLoader from '../../../shared/LottieLoader'
import BookAVisit from './Components/BookAVisit'
import AddAdmin from './Components/AddAdmin'

const Container = () => {
  const auth = useContext(AuthContext)
  const { orgId } = useParams()

  const values = {
    org_id: auth.org_id || orgId,
    role: auth.role == '1' ? '' : auth.role,
    branch_id: auth?.branch_id || '',
  }

  const {
    data: branches,
    isLoading,
    isError,
  } = useQuery({
    queryKey: ['getBranches', values.org_id],
    queryFn: () => getBranchesByOrgId(values),
    staleTime: 5 * 60 * 1000, // 5 minutes
    cacheTime: 10 * 60 * 1000, // 10 minutes
  })

  // Show loading state while data is being fetched
  if (isLoading) return <LottieLoader data={loading} />

  // Show error state if query failed
  if (isError) {
    return (
      <div className="flex flex-col items-center justify-center h-64">
        <p className="text-red-500 text-lg mb-4">
          Error loading data. Please try again.
        </p>
      </div>
    )
  }

  if (branches) {
    if (branches.organisationDetails?.branches?.length > 0) {
      return (
        <Presentation
          branches={branches.organisationDetails.branches}
          orgId={orgId}
        />
      )
    } else {
      return (
        <div className="flex justify-end py-12 px-5">
          <div className="flex space-x-4">
            <BookAVisit branches={[]} />
          </div>
        </div>
      )
    }
  }
}

export default Container
