import React from 'react'
import VehicleMaterialGroupBookingPresentation from './Presentation'

const VehicleMaterialGroupBookingSecurityAdmin = () => {
  return <VehicleMaterialGroupBookingPresentation />
}

export default VehicleMaterialGroupBookingSecurityAdmin
