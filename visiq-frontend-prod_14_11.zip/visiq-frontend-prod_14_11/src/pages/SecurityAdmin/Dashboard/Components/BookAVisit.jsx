import React, { useCallback, useContext, useEffect, useState } from 'react'
import PrimaryBtn from '../../../../shared/Buttons/PrimaryBtn'
import * as yup from 'yup'
import dayjs from 'dayjs'
import { Form, Formik } from 'formik'
import FormikTextField from '../../../../lib/Formik/FormikTextfield'
import { AuthContext } from '../../../../context/AuthContext'
import { Box, Modal } from '@mui/material'
import DirectionsCarIcon from '@mui/icons-material/DirectionsCar'
import GroupIcon from '@mui/icons-material/Group'
import { styles } from '../../../../constants/styes'
import FormikDatePicker from '../../../../lib/Formik/FormikDatePicker'
import FormikTimePicker from '../../../../lib/Formik/FormikTimePicker'
import FormikSelect from '../../../../lib/Formik/FormikSelect'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  AreasByBranchId,
  bookAVisit,
  listOfCountriesExt,
} from '../../../../services/adminService'
import toast from 'react-hot-toast'
import { getBranchTime } from '../../../../services/orgService'
import MultiSelectForm from '../../../../lib/Formik/MultiSelectForm'
import VehicleDetailsModal from './VehicleDetailsModal'
import GroupVisitModal from './GroupVisitModal'
import ProgressLine from '../../../../shared/ProgressLine'
import eventEmitter from '../../../../utils/eventEmitter'

const BookAVisit = ({ branches }) => {
  const [isOpen, setIsOpen] = useState(false)
  const [vehicleModalOpen, setVehicleModalOpen] = useState(false)
  const [groupModalOpen, setGroupModalOpen] = useState(false)
  const [apiTime, setApiTime] = useState(null) // State to store API time
  // const queryClient = useQueryClient() // Removed since no longer needed
  const auth = useContext(AuthContext)
  const isAdmin = auth?.role === '1' || '2'
  const [selectedBranch, setSelectedBranch] = useState('')
  const [_vehicleMaterialEnabled, setVehicleMaterialEnabled] = useState(false)
  const [emailList, setEmailList] = useState([])
  const [formValues, setFormValues] = useState(null)
  const [vehicleData, setVehicleData] = useState(null)
  const [groupData, setGroupData] = useState(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isBranchTimeLoading, setIsBranchTimeLoading] = useState(false)
  const queryClient = useQueryClient()

  const mutate = useMutation({
    mutationFn: (values) => bookAVisit(values),
    mutationKey: 'bookAVisit',
    onMutate: () => {
      setIsSubmitting(true)
    },
    onSuccess: (data, variables, context) => {
      toast.success(data.message)
      console.log(
        '✅ Booking successful - Expected visitors data will be refreshed',
      )

      // Refresh visitors data after successful booking
      // Invalidate all getAllVisitors queries to refresh the dashboard
      queryClient.invalidateQueries({
        queryKey: ['getAllVisitors'],
        exact: false, // This will invalidate all queries that start with 'getAllVisitors'
      })

      // Also invalidate any attendance-related queries
      queryClient.invalidateQueries({
        queryKey: ['getAttendance'],
        exact: false,
      })

      // Emit global refresh event for dashboard components
      eventEmitter.emit('bookingSuccess', {
        message: 'New booking added successfully',
        timestamp: new Date().toISOString(),
      })

      // Reset form and close modal for fresh book visit window
      setIsOpen(false)
      setIsSubmitting(false)
      // Minimal state reset to prevent interfering with other APIs
      setFormValues(null)
      setVehicleData(null)
      setGroupData(null)

      // Hard refresh the page to update all content
      setTimeout(() => {
        window.location.reload()
      }, 500)
      // Reset form if we have access to the formik instance
      if (context?.resetForm) {
        context.resetForm()
      }
    },
    onError: (err) => {
      console.error('=== MUTATION ERROR ===')
      console.error('Error object:', err)
      console.error('Error message:', err.message)
      console.error('Error response:', err.response)
      console.error('Error response data:', err.response?.data)
      console.error('Error response status:', err.response?.status)
      setIsSubmitting(false)

      // Extract the message from API response - handle different response structures
      let errorMessage = 'Something went wrong while booking the visit'

      if (err.response?.data) {
        // Check if the response has a 'message' field
        if (err.response.data.message) {
          errorMessage = err.response.data.message
        } else if (err.response.data.error) {
          errorMessage = err.response.data.error
        } else if (typeof err.response.data === 'string') {
          errorMessage = err.response.data
        }
      } else if (err.message) {
        errorMessage = err.message
      }

      console.log('=== TOAST ERROR MESSAGE ===')
      console.log('API error response:', err.response?.data)
      console.log('Message to show:', errorMessage)
      console.log('=== END TOAST ERROR ===')

      // Show only the message from API response
      toast.error(errorMessage)
    },
  })

  // const { data: visitorsData, isLoading } = useQuery({
  //   queryKey: ['AreasByBranchId', selectedBranch],
  //   queryFn: () =>
  //     AreasByBranchId({
  //       branch_id: "9cb0aa04-fe71-46f0-97c9-9a2e4a8704c1",
  //     }),
  //   enabled: !!selectedBranch, // Only fetch data if a branch is selected
  // })

  // // Ensure visitorsData.areasOfBranch is an array
  // const areas = visitorsData?.areasOfBranch || []

  const { data: visitorsData, isLoading } = useQuery({
    queryKey: ['AreasByBranchId', selectedBranch],
    queryFn: () =>
      AreasByBranchId({
        branch_id: selectedBranch,
      }),
    enabled: !!selectedBranch,
  })

  const { data: countrycodes, isCountryCodesLoading } = useQuery({
    queryFn: () => listOfCountriesExt(),
  })

  const areas = visitorsData?.areasOfBranch || []
  const purpose_of_visits = visitorsData?.puporse_of_visits || []
  const roles = visitorsData?.roles || [] // Use roles from the new API

  // useEffect(() => {
  //   // Set the API time on component mount if needed
  //   // You might call an API here if necessary
  // }, [])

  useEffect(() => {
    if (visitorsData) {
      const branchAdminEmails =
        visitorsData?.branchAdmins?.map(
          (admin) => `${admin.first_name}(${admin.email})`,
        ) || []
      const securityAdminEmails =
        visitorsData?.securityAdmins?.map(
          (admin) => `${admin.first_name}(${admin.email})`,
        ) || []
      const combinedEmails = [
        ...new Set([...branchAdminEmails, ...securityAdminEmails]),
      ]
      setEmailList(combinedEmails)
    }
  }, [visitorsData])

  const handleClick = useCallback(() => {
    setSelectedBranch('')
    setVehicleMaterialEnabled(false)
    setIsOpen(true)
  }, [])

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  // const timeRegex = /^([01]\d|2[0-3]):([0-5]\d)$/

  const validationSchema = yup.object().shape({
    first_name: yup
      .string()
      .max(75, 'First name cannot exceed 75 characters')
      .required('First name is required')
      .matches(/[a-zA-Z]/, 'First name must contain at least one letter'),
    last_name: yup
      .string()
      .max(75, 'Last name cannot exceed 75 characters')
      .required('Last name is required')
      .matches(/[a-zA-Z]/, 'Last name must contain at least one letter'),
    purpose_of_visit: yup
      .string()
      .max(75, 'Purpose of visit cannot exceed 75 characters')
      .required('Purpose of visit is required')
      .matches(/[a-zA-Z]/, 'Purpose of visit must contain at least one letter'),
    date_of_visit: yup
      .mixed()
      .required('Please select start date')
      .test('is-valid-date', 'Invalid start date', function (value) {
        if (!value) return false
        // Handle both string and dayjs object formats
        const date =
          typeof value === 'string'
            ? dayjs(value, 'DD-MM-YYYY', true)
            : dayjs(value)
        return date.isValid()
      }),

    end_date_of_visit: yup
      .mixed()
      .required('Please select end date')
      .test('is-valid-date', 'Invalid end date', function (value) {
        if (!value) return false
        // Handle both string and dayjs object formats
        const date =
          typeof value === 'string'
            ? dayjs(value, 'DD-MM-YYYY', true)
            : dayjs(value)
        return date.isValid()
      }),

    time_of_visit: yup
      .string()
      .required('Time is required')
      .test(
        'is-not-in-past',
        `Start time cannot be before ${apiTime}`,
        function (value) {
          const { date_of_visit } = this.parent
          if (!value || !apiTime) return true
          const today = new Date()
          const selectedDate = new Date(date_of_visit)
          const isToday = selectedDate.toDateString() === today.toDateString()

          if (isToday) {
            const [startHours, startMinutes] = value.split(':').map(Number)
            const [apiHours, apiMinutes] = apiTime.split(':').map(Number)
            return (
              startHours > apiHours ||
              (startHours === apiHours && startMinutes >= apiMinutes)
            )
          }
          return true
        },
      ),
    email: yup
      .string()
      .test(
        'email-or-phone-required',
        'Either email or phone number is required',
        function (value) {
          const { phNo } = this.parent
          return value || phNo
        },
      )
      .test('email-format', 'Enter a valid email', function (value) {
        if (!value) return true // Skip validation if empty
        return yup.string().email().isValidSync(value) && emailRegex.test(value)
      }),
    branch_id: yup.string().required('Branch is required'),
    area_of_permit: yup
      .array()
      .min(1, 'Please select at least one area')
      .required('Area is required'),
    role: yup.string().required('Category is required'), // Add validation for role
    visitorOrgName: yup
      .string()
      .max(75, 'Visitor organization name cannot exceed 75 characters')
      .required('Visitor organization name is required')
      .matches(/[a-zA-Z]/, 'visitorOrgName must contain at least one letter'),
    time_to_exit: yup
      .string()
      .required('Time is required')
      .test(
        'is-greater-than-start-time',
        'End time must be greater than the start time',
        function (value) {
          const { time_of_visit } = this.parent
          if (time_of_visit && value) {
            const [startHours, startMinutes] = time_of_visit
              .split(':')
              .map(Number)
            const [endHours, endMinutes] = value.split(':').map(Number)
            return (
              endHours > startHours ||
              (endHours === startHours && endMinutes > startMinutes)
            )
          }
          return true
        },
      ),
    phNo: yup
      .string()
      .test(
        'email-or-phone-required',
        'Either email or phone number is required',
        function (value) {
          const { email } = this.parent
          return value || email
        },
      )
      .test('is-valid-phone', 'Enter a valid phone number', function (value) {
        // Only validate phone format if phone number is provided
        if (!value) return true
        const { ph_ext } = this.parent
        const countryCode = countrycodes.find((c) => c.code === ph_ext) // Match the selected country code
        if (!countryCode) return false // If no matching code, fail validation
        const isValidLength = value.length >= 5 && value.length <= 10 // Adjust length based on your needs
        const isNumeric = /^[0-9]+$/.test(value) // Ensure it's numeric
        const doesNotStartWithZero = !value.startsWith('0') // Check if it doesn't start with 0

        if (!doesNotStartWithZero) {
          return this.createError({
            message: 'Phone number cannot start with 0',
          })
        }

        return isValidLength && isNumeric && doesNotStartWithZero
      }),
    ph_ext: yup
      .string()
      .test(
        'country-code-required',
        'Country code is required when phone number is provided',
        function (value) {
          const { phNo } = this.parent
          return !phNo || value // Only required if phone number is provided
        },
      ),
  })

  const initialValues = {
    first_name: '',
    last_name: '',
    purpose_of_visit: '',
    date_of_visit: null,
    time_of_visit: '',
    end_date_of_visit: null,
    email: '',
    branch_name: '',
    branch_id: '',
    org_name: '',
    org_id: branches[0]?.org_id || '',
    area_of_permit: [],
    visit_duration: '',
    visitorOrgName: '',
    phNo: '',
    ph_ext: '',
    time_to_exit: '',
    meetTo: '',
    role: '',
    reason: '',
    vm_bool: false,
    mm_bool: false,
    vm_details: [],
    mm_details: [],
    grp_book_bool: false,
    grp_details: [],
  }
  const handleBranchChange = async (branchId, setFieldValue, date_of_visit) => {
    setSelectedBranch(branchId)
    setIsBranchTimeLoading(true) // Start loading

    // Get vehicle movement state from branch data
    const selectedBranchData = branches.find(
      (branch) => branch.branch_id === branchId,
    )
    const isVehicleMovementEnabled = selectedBranchData?.vm_boolean || false

    console.log('=== VEHICLE MOVEMENT DEBUG ===')
    console.log('Branch ID:', branchId)
    console.log('Selected branch data:', selectedBranchData)
    console.log('Vehicle movement enabled:', isVehicleMovementEnabled)
    console.log('=== END DEBUG ===')

    setVehicleMaterialEnabled(isVehicleMovementEnabled)

    try {
      const res = await getBranchTime(branchId)
      const { currentTime } = res

      // Store API time in state
      setApiTime(currentTime)

      // Extract hours and minutes from currentTime
      const [hours, minutes] = currentTime.split(':').map(Number)
      const today = new Date()
      const selectedDate = new Date(date_of_visit)
      const isToday = selectedDate.toDateString() === today.toDateString()

      if (isToday) {
        // Set the start time to current time
        setFieldValue(
          'time_of_visit',
          `${hours}:${minutes.toString().padStart(2, '0')}`,
        )

        // Add 10 minutes to the current time
        let newMinutes = minutes + 10
        let newHours = hours

        if (newMinutes >= 60) {
          newMinutes -= 60
          newHours += 1
          if (newHours >= 24) {
            newHours = 0
          }
        }
        setFieldValue(
          'time_to_exit',
          `${newHours}:${newMinutes.toString().padStart(2, '0')}`,
        )
      } else {
        // For future dates, clear time fields
        setFieldValue('time_of_visit', '')
        setFieldValue('time_to_exit', '')
      }
      // Clear selection when changing branch
      setFieldValue('area_of_permit', [])
    } catch (error) {
      console.error('Error fetching branch time:', error)
    } finally {
      setIsBranchTimeLoading(false) // End loading
    }
  }

  // Vehicle/Material button state is now controlled by localStorage in handleBranchChange
  // This ensures the button is only enabled for branches where vehicle movement is ON

  // Initialize vehicle material state when component mounts with selected branch
  useEffect(() => {
    if (selectedBranch) {
      // Get vehicle movement state from branch data
      const selectedBranchData = branches.find(
        (branch) => branch.branch_id === selectedBranch,
      )
      const isVehicleMovementEnabled = selectedBranchData?.vm_boolean || false

      console.log('=== INITIALIZATION DEBUG ===')
      console.log('Selected Branch:', selectedBranch)
      console.log('Selected branch data:', selectedBranchData)
      console.log('Setting to:', isVehicleMovementEnabled)
      console.log('=== END INIT DEBUG ===')

      setVehicleMaterialEnabled(isVehicleMovementEnabled)
    }
  }, [selectedBranch, branches])

  // Debug logging
  console.log('Selected Branch:', selectedBranch)
  console.log('Visitors Data:', visitorsData)
  console.log('Roles from AreasByBranchId:', visitorsData?.roles)
  console.log('Final roles array:', roles)
  console.log('Is Loading:', isLoading)
  console.log('Selected Branch exists:', !!selectedBranch)
  console.log(
    'Category options:',
    selectedBranch && !isLoading
      ? (roles || []).map((role) => ({
          value: role.role_name,
          label: role.roleInDays,
        }))
      : [],
  )

  return (
    <div>
      <PrimaryBtn text="Book Visit" type="button" handleClick={handleClick} />
      <Modal
        open={isOpen}
        onClose={(event, reason) => {
          // Only allow closing via escape key or explicit close button
          if (reason === 'backdropClick') {
            return // Prevent closing on backdrop click
          }
          setIsOpen(false)
        }}
      >
        <Box sx={styles.modal}>
          <h2 className="text-2xl font-bold mb-4">Book Visit</h2>
          <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={(values, { resetForm }) => {
              // Format the data according to API specification
              const formattedValues = {
                ...values,
                // Ensure area_of_permit has the correct structure with proper null checks
                area_of_permit: (values.area_of_permit || []).map((area) => {
                  if (!area) return { area_name: '' }
                  return {
                    area_name:
                      typeof area === 'string'
                        ? area
                        : area.area_name || area.label || area || '',
                  }
                }),
                // Ensure dates are in string format (DD-MM-YYYY)
                date_of_visit: values.date_of_visit
                  ? typeof values.date_of_visit === 'string'
                    ? values.date_of_visit
                    : dayjs(values.date_of_visit).format('DD-MM-YYYY')
                  : '',
                end_date_of_visit: values.end_date_of_visit
                  ? typeof values.end_date_of_visit === 'string'
                    ? values.end_date_of_visit
                    : dayjs(values.end_date_of_visit).format('DD-MM-YYYY')
                  : '',
                // Include vehicle and material data
                vm_details: vehicleData?.vm_details || [],
                mm_details: vehicleData?.mm_details || [],
                // Include group data
                grp_details: groupData?.grp_details || [],
                // Set boolean flags based on whether vehicle/material data exists
                vm_bool:
                  vehicleData?.vm_details && vehicleData.vm_details.length > 0,
                mm_bool:
                  vehicleData?.mm_details && vehicleData.mm_details.length > 0,
                grp_book_bool:
                  groupData?.grp_details && groupData.grp_details.length > 0,
              }

              console.log('Submitting formatted values:', formattedValues)
              mutate.mutate(formattedValues, {
                context: {
                  resetForm: () => {
                    setFormValues(null)
                    setVehicleData(null)
                    setGroupData(null)
                    setIsOpen(false)
                    setSelectedBranch('')
                  },
                },
              })
            }}
          >
            {(props) => (
              <Form style={{ flex: 1 }}>
                <div className="grid grid-cols-2 gap-x-6 gap-y-6">
                  <FormikTextField
                    name="first_name"
                    label="First Name *"
                    className="error-text"
                  />
                  <FormikTextField
                    name="last_name"
                    label="Last Name *"
                    className="error-text"
                  />
                  <div>
                    {isAdmin && (
                      <FormikSelect
                        name="branch_id"
                        label="Branch *"
                        // placeholder="Select Branch"
                        onChange={async (e) => {
                          const branchId = e.target.value
                          props.setFieldValue('branch_id', branchId)
                          await handleBranchChange(
                            branchId,
                            props.setFieldValue,
                            props.values.date_of_visit,
                          )
                        }}
                        value={selectedBranch}
                        options={branches.map((branch) => ({
                          value: branch.branch_id,
                          label: branch.branch_name,
                        }))}
                        className="error-text"
                        disabled={isBranchTimeLoading}
                        loading={isBranchTimeLoading}
                      />
                    )}
                  </div>
                  <FormikSelect
                    name="role"
                    label="Category *"
                    placeholder="Select Category"
                    options={
                      selectedBranch && !isLoading
                        ? (roles || []).map((role) => ({
                            value: role.role_name,
                            label: role.roleInDays,
                          }))
                        : []
                    }
                    onChange={(e) => {
                      props.setFieldValue('role', e.target.value)
                    }}
                    disabled={
                      !selectedBranch || isLoading || isBranchTimeLoading
                    }
                  />
                  <FormikDatePicker
                    name="date_of_visit"
                    label="Start Date *"
                    className="error-text"
                    onChange={async (date) => {
                      props.setFieldValue('date_of_visit', date)
                      if (props.values.branch_id) {
                        await handleBranchChange(
                          props.values.branch_id,
                          props.setFieldValue,
                          date,
                        )
                      }
                    }}
                    disabled={isBranchTimeLoading}
                    loading={isBranchTimeLoading}
                  />
                  <FormikDatePicker
                    name="end_date_of_visit"
                    label="End Date *"
                    className="error-text"
                  />
                  <FormikTextField
                    name="visitorOrgName"
                    label="Organization Name *"
                  />
                  <MultiSelectForm
                    name="area_of_permit"
                    label="Select Area *"
                    options={areas.map((area) => ({
                      value: area.area_id,
                      label: area.area_name,
                    }))}
                    onChange={(selectedValues) => {
                      props.setFieldValue('area_of_permit', selectedValues)
                    }}
                    disabled={
                      !selectedBranch || isLoading || isBranchTimeLoading
                    }
                    loading={isLoading || isBranchTimeLoading}
                  />
                  <FormikTimePicker
                    name="time_of_visit"
                    label="Start Time *"
                    disabled={!selectedBranch || isBranchTimeLoading}
                    loading={isBranchTimeLoading}
                  />
                  <FormikTimePicker
                    name="time_to_exit"
                    label="End Time *"
                    disabled={!selectedBranch || isBranchTimeLoading}
                    loading={isBranchTimeLoading}
                  />
                  <div className="col-span-2">
                    <FormikTextField
                      name="email"
                      label="Email"
                      InputProps={{
                        value:
                          props.values.email.slice(0) +
                          (props.values.email.length > 50 ? '...' : ''),
                        title: props.values.email,
                      }}
                    />
                  </div>
                  <FormikSelect
                    name="ph_ext"
                    label="Country Code"
                    placeholder="Code"
                    options={
                      isCountryCodesLoading
                        ? [{ value: '', label: 'Loading...' }]
                        : countrycodes.map((country) => ({
                            value: country.code,
                            label: `${country.country} (${country.code})`,
                          }))
                    }
                    onChange={(e) => {
                      props.setFieldValue('ph_ext', e.target.value)
                      props.setFieldValue('phNo', '')
                    }}
                    value={props.values.ph_ext}
                    disabled={isCountryCodesLoading}
                    loading={isCountryCodesLoading}
                    MenuProps={{
                      PaperProps: {
                        style: {
                          maxHeight: 200, // Limit dropdown height
                          maxWidth: 200, // Set a smaller dropdown width
                        },
                      },
                    }}
                    InputProps={{
                      style: { width: '200px' }, // Set the input field width
                    }}
                  />
                  <FormikTextField name="phNo" label="Phone" />
                  <div className="col-span-2">
                    <FormikSelect
                      name="purpose_of_visit"
                      label="Purpose of Visit *"
                      placeholder="Select Purpose"
                      options={purpose_of_visits.map((area) => ({
                        value: area.pov,
                        label: area.pov,
                      }))}
                      onChange={(e) => {
                        props.setFieldValue('purpose_of_visit', e.target.value)
                      }}
                      disabled={!selectedBranch}
                    />
                  </div>
                  {props.values.purpose_of_visit === 'Meetings' && (
                    <div className="col-span-2">
                      <FormikSelect
                        name="meetTo"
                        label="Person Meet To *"
                        options={emailList.map((email) => {
                          // Split the label and extract the email
                          const match = email.match(/\(([^)]+)\)$/) // Extract the email inside parentheses
                          const extractedEmail = match ? match[1] : email // Default to full email if no match
                          return {
                            value: extractedEmail, // Only pass the email as value
                            label: email, // Display firstname(email) as label
                          }
                        })}
                        onChange={(e) =>
                          props.setFieldValue('meetTo', e.target.value)
                        }
                      />
                    </div>
                  )}
                </div>
                <br />
                {props.values.purpose_of_visit === 'Others' && (
                  <div className="col-span-2">
                    <FormikTextField
                      name="reason"
                      label="Reason for Visit *"
                      placeholder="Please provide a reason for your visit"
                      multiline // Enables multiline text input
                      rows={4} // Adjust the number of rows for a larger input field
                      fullWidth // Expands the text field to take the full width of its container
                      InputProps={{
                        style: {
                          fontSize: '1rem', // Adjust font size for better readability
                          padding: '10px', // Add padding for a larger input area
                        },
                      }}
                    />
                  </div>
                )}
                <br />
                <div className="flex gap-4">
                  <button
                    type="button"
                    className="btn bg-white border border-gray-300 text-gray-700 flex-1 disabled:bg-gray-100 disabled:text-gray-400 disabled:border-gray-200"
                    disabled={!selectedBranch || !_vehicleMaterialEnabled}
                    onClick={() => {
                      setFormValues(props.values)
                      setVehicleModalOpen(true)
                    }}
                  >
                    <DirectionsCarIcon fontSize="small" className="mr-2" />
                    Vehicle/Material
                    {!_vehicleMaterialEnabled && selectedBranch && (
                      <span className="text-xs text-red-500 ml-1">
                        (Disabled - Vehicle Movement OFF)
                      </span>
                    )}
                  </button>
                  <button
                    type="button"
                    className="btn bg-white border border-gray-300 text-gray-700 flex-1"
                    onClick={() => {
                      setFormValues(props.values)
                      setGroupModalOpen(true)
                    }}
                  >
                    <GroupIcon fontSize="small" className="mr-2" />
                    Group Booking
                  </button>
                </div>
                <div className="mt-4">
                  <PrimaryBtn
                    text={isSubmitting ? 'Booking...' : 'Book Visit'}
                    type="submit"
                    disabled={isSubmitting}
                    loading={isSubmitting}
                  />
                  <ProgressLine
                    isActive={isSubmitting}
                    color="primary"
                    height={4}
                  />
                </div>
                <button
                  className="btn btn-sm btn-circle btn-ghost absolute right-2 top-2"
                  id="my_modal_2_btn"
                  onClick={() => {
                    props.resetForm()
                    setIsOpen(false)
                    setSelectedBranch('')
                  }}
                >
                  ✕
                </button>
              </Form>
            )}
          </Formik>
        </Box>
      </Modal>
      <VehicleDetailsModal
        isOpen={vehicleModalOpen}
        onClose={() => setVehicleModalOpen(false)}
        onBack={() => {
          setVehicleModalOpen(false)
          setIsOpen(true) // Go back to the Book Visit modal
        }}
        onVehicleDataSubmit={(vehicleData) => {
          setVehicleData(vehicleData)
          setVehicleModalOpen(false)
          setIsOpen(true) // Go back to Book Visit modal
        }}
        bookVisitData={formValues}
      />
      <GroupVisitModal
        isOpen={groupModalOpen}
        onClose={() => setGroupModalOpen(false)}
        onBack={() => {
          setGroupModalOpen(false)
          setIsOpen(true) // Go back to the Book Visit modal
        }}
        onGroupDataSubmit={(groupData) => {
          setGroupData(groupData)
          setGroupModalOpen(false)
          setIsOpen(true) // Go back to Book Visit modal
        }}
        selectedBranch={selectedBranch}
        bookVisitData={formValues}
      />
    </div>
  )
}

export default BookAVisit
