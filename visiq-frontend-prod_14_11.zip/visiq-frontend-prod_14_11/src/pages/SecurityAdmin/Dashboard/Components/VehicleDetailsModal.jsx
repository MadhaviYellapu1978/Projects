import React, { useState } from 'react'
import { Box, Modal, IconButton } from '@mui/material'
import { Close, ArrowBack } from '@mui/icons-material'
import ExpandMoreIcon from '@mui/icons-material/ExpandMore'
import ExpandLessIcon from '@mui/icons-material/ExpandLess'
import DirectionsCarIcon from '@mui/icons-material/DirectionsCar'
import InventoryIcon from '@mui/icons-material/Inventory'
import { styles } from '../../../../constants/styes'
import { styled } from '@mui/material/styles'
import { Button } from '@mui/material'

const FooterButton = styled(Button)(({ theme, variant }) => ({
  textTransform: 'none',
  padding: theme.spacing(1.5, 3),
  borderRadius: 8,
  fontWeight: 500,
  minWidth: 100,
  ...(variant === 'primary' && {
    backgroundColor: '#051737',
    color: 'white',
    '&:hover': {
      backgroundColor: '#0a2a5a',
    },
  }),
  ...(variant === 'secondary' && {
    backgroundColor: 'white',
    color: '#1976D2',
    border: '1px solid #1976D2',
    '&:hover': {
      backgroundColor: '#F5F5F5',
    },
  }),
}))

const VehicleMaterialRecords = ({
  vehicles,
  onEdit,
  onDelete,
  onSubmit,
  onCancel,
}) => {
  const [expandedRows, setExpandedRows] = useState([])

  const toggleExpand = (id) => {
    setExpandedRows((prev) =>
      prev.includes(id) ? prev.filter((rowId) => rowId !== id) : [...prev, id],
    )
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-xl font-bold text-gray-800 mb-1">
        Vehicle & Material Records
      </h2>
      <p className="text-xs text-gray-400 mb-4">
        Manage your vehicle and material information
      </p>

      {vehicles.length === 0 ? (
        <div className="p-6 bg-white rounded-lg shadow-md text-center">
          <div className="text-gray-300 text-6xl mb-4">📄</div>
          <h3 className="text-lg font-semibold text-gray-700 mb-2">
            No records added yet
          </h3>
          <p className="text-sm text-gray-500">
            Start by adding your first vehicle and material record using the
            form above
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full border border-gray-200 table-fixed">
            <thead className="bg-gray-50">
              <tr>
                <th className="p-2 border text-left w-12"></th>
                <th
                  className="p-2 border text-left text-xs font-medium text-gray-700"
                  style={{ width: '15%', minWidth: '120px' }}
                >
                  Vehicle Name
                </th>
                <th
                  className="p-2 border text-left text-xs font-medium text-gray-700"
                  style={{ width: '12%', minWidth: '100px' }}
                >
                  Vehicle Type
                </th>
                <th
                  className="p-2 border text-left text-xs font-medium text-gray-700"
                  style={{ width: '15%', minWidth: '120px' }}
                >
                  Driver Licence
                </th>
                <th
                  className="p-2 border text-left text-xs font-medium text-gray-700"
                  style={{ width: '15%', minWidth: '120px' }}
                >
                  Insurance Provider
                </th>
                <th
                  className="p-2 border text-left text-xs font-medium text-gray-700"
                  style={{ width: '15%', minWidth: '120px' }}
                >
                  Insurance Number
                </th>
                <th
                  className="p-2 border text-left text-xs font-medium text-gray-700"
                  style={{ width: '12%', minWidth: '100px' }}
                >
                  RC Number
                </th>
                <th
                  className="p-2 border text-left text-xs font-medium text-gray-700"
                  style={{ width: '20%', minWidth: '150px' }}
                >
                  Vehicle Comments
                </th>
                <th
                  className="p-2 border text-center text-xs font-medium text-gray-700"
                  style={{ width: '12%', minWidth: '100px' }}
                >
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {vehicles.map((vehicle) => (
                <React.Fragment key={vehicle.vehicle_id}>
                  <tr className="bg-white">
                    <td className="p-2 border">
                      {vehicle.materials?.length > 0 && (
                        <button
                          onClick={() => toggleExpand(vehicle.vehicle_id)}
                        >
                          {expandedRows.includes(vehicle.vehicle_id) ? (
                            <ExpandLessIcon className="h-4 w-4 text-gray-600" />
                          ) : (
                            <ExpandMoreIcon className="h-4 w-4 text-gray-600" />
                          )}
                        </button>
                      )}
                    </td>
                    <td className="p-2 border font-semibold text-xs text-gray-800 break-words">
                      <div className="max-w-full overflow-hidden">
                        {vehicle.vehicle_name}
                      </div>
                    </td>
                    <td className="p-2 border text-xs text-gray-600 break-words">
                      <div className="max-w-full overflow-hidden">
                        {vehicle.vehicle_type}
                      </div>
                    </td>
                    <td className="p-2 border text-xs text-gray-600 break-words">
                      <div className="max-w-full overflow-hidden">
                        {vehicle.driver_licence}
                      </div>
                    </td>
                    <td className="p-2 border text-xs text-gray-600 break-words">
                      <div className="max-w-full overflow-hidden">
                        {vehicle.insurance_provider}
                      </div>
                    </td>
                    <td className="p-2 border text-xs text-gray-600 break-words">
                      <div className="max-w-full overflow-hidden">
                        {vehicle.insurance_no}
                      </div>
                    </td>
                    <td className="p-2 border text-xs text-gray-600 break-words">
                      <div className="max-w-full overflow-hidden">
                        {vehicle.rc_no}
                      </div>
                    </td>
                    <td className="p-2 border text-xs text-gray-600 break-words">
                      <div
                        className="max-w-full overflow-hidden"
                        title={vehicle.vehicle_comments}
                      >
                        {vehicle.vehicle_comments}
                      </div>
                    </td>
                    <td className="p-2 border text-center align-middle">
                      <div className="flex flex-col gap-1 justify-center items-center h-full">
                        <button
                          onClick={() => onEdit(vehicle)}
                          className="px-1.5 py-0.5 border border-blue-500 text-blue-500 rounded hover:bg-blue-50 text-xs whitespace-nowrap w-[50px] flex-shrink-0"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => onDelete(vehicle.vehicle_id)}
                          className="px-1.5 py-0.5 border border-red-500 text-red-500 rounded hover:bg-red-50 text-xs whitespace-nowrap w-[50px] flex-shrink-0"
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>

                  {expandedRows.includes(vehicle.vehicle_id) &&
                    vehicle.materials?.length > 0 && (
                      <tr>
                        <td colSpan="9" className="p-0">
                          <div className="overflow-x-auto">
                            <table className="w-full border border-gray-200 table-fixed">
                              <thead className="bg-gray-100">
                                <tr>
                                  <th
                                    className="p-2 border text-left text-xs font-medium text-gray-700"
                                    style={{ width: '20%', minWidth: '120px' }}
                                  >
                                    Material Name
                                  </th>
                                  <th
                                    className="p-2 border text-left text-xs font-medium text-gray-700"
                                    style={{ width: '18%', minWidth: '120px' }}
                                  >
                                    Device Model
                                  </th>
                                  <th
                                    className="p-2 border text-left text-xs font-medium text-gray-700"
                                    style={{ width: '25%', minWidth: '150px' }}
                                  >
                                    Material Description
                                  </th>
                                  <th
                                    className="p-2 border text-left text-xs font-medium text-gray-700"
                                    style={{ width: '12%', minWidth: '80px' }}
                                  >
                                    Quantity
                                  </th>
                                  <th
                                    className="p-2 border text-left text-xs font-medium text-gray-700"
                                    style={{ width: '12%', minWidth: '80px' }}
                                  >
                                    Number of Units
                                  </th>
                                  <th
                                    className="p-2 border text-left text-xs font-medium text-gray-700"
                                    style={{ width: '13%', minWidth: '100px' }}
                                  >
                                    Serial Number
                                  </th>
                                </tr>
                              </thead>
                              <tbody>
                                {vehicle.materials.map((mat) => (
                                  <tr
                                    key={mat.material_id}
                                    className="bg-white"
                                  >
                                    <td className="p-2 border text-xs text-gray-600 break-words">
                                      <div
                                        className="max-w-full overflow-hidden"
                                        title={mat.material_name}
                                      >
                                        {mat.material_name}
                                      </div>
                                    </td>
                                    <td className="p-2 border text-xs text-gray-600 break-words">
                                      <div
                                        className="max-w-full overflow-hidden"
                                        title={mat.material_device_model}
                                      >
                                        {mat.material_device_model}
                                      </div>
                                    </td>
                                    <td className="p-2 border text-xs text-gray-600 break-words">
                                      <div
                                        className="max-w-full overflow-hidden"
                                        title={mat.material_description}
                                      >
                                        {mat.material_description}
                                      </div>
                                    </td>
                                    <td className="p-2 border text-xs text-gray-600 break-words">
                                      <div className="max-w-full overflow-hidden">
                                        {mat.material_quantity}
                                      </div>
                                    </td>
                                    <td className="p-2 border text-xs text-gray-600 break-words">
                                      <div className="max-w-full overflow-hidden">
                                        {mat.material_no_of_units}
                                      </div>
                                    </td>
                                    <td className="p-2 border text-xs text-gray-600 break-words">
                                      <div
                                        className="max-w-full overflow-hidden"
                                        title={mat.material_s_n}
                                      >
                                        {mat.material_s_n}
                                      </div>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </td>
                      </tr>
                    )}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <div className="flex justify-end gap-2 mt-4">
        <FooterButton variant="secondary" onClick={onCancel}>
          Cancel
        </FooterButton>
        <FooterButton variant="primary" onClick={onSubmit}>
          Submit
        </FooterButton>
      </div>
    </div>
  )
}

const VehicleDetailsModal = ({
  isOpen,
  onClose,
  onBack,
  onVehicleDataSubmit,
  bookVisitData,
}) => {
  const [vehicles, setVehicles] = useState([])
  const [showMaterial, setShowMaterial] = useState(false)
  const [materials, setMaterials] = useState([])
  const [materialIdCounter, setMaterialIdCounter] = useState(1)
  const [isEditing, setIsEditing] = useState(false)
  const [editingVehicleId, setEditingVehicleId] = useState(null)
  const [originalVehicleData, setOriginalVehicleData] = useState(null)

  // Vehicle form state
  const [vehicle, setVehicle] = useState({
    name: '',
    type: '',
    license: '',
    insuranceProvider: '',
    insuranceNumber: '',
    rcNumber: '',
    comments: '',
  })

  // Material form state
  const [material, setMaterial] = useState({
    name: '',
    model: '',
    natureOfWork: '',
    quantity: '',
    units: '',
    serial: '',
    comments: '',
  })

  const handleVehicleChange = (e) => {
    const { name, value } = e.target
    setVehicle((prev) => ({ ...prev, [name]: value }))
  }

  const handleMaterialChange = (e) => {
    const { name, value } = e.target
    setMaterial((prev) => ({ ...prev, [name]: value }))
  }

  const handleAddMoreMaterial = () => {
    const newMaterial = {
      id: materialIdCounter,
      name: '',
      model: '',
      natureOfWork: '',
      quantity: '',
      units: '',
      serial: '',
      comments: '',
    }
    setMaterials((prev) => [...prev, newMaterial])
    setMaterialIdCounter((prev) => prev + 1)
  }

  const handleMaterialFormChange = (id, field, value) => {
    setMaterials((prev) =>
      prev.map((mat) => (mat.id === id ? { ...mat, [field]: value } : mat)),
    )
  }

  const handleRemoveMaterial = (id) => {
    setMaterials((prev) => prev.filter((mat) => mat.id !== id))
  }

  const handleAddRecords = () => {
    // Collect missing vehicle fields
    const missingVehicleFields = []
    if (!vehicle.name) missingVehicleFields.push('Vehicle Name')
    if (!vehicle.type) missingVehicleFields.push('Vehicle Type')
    if (!vehicle.license) missingVehicleFields.push('Driver License')

    if (missingVehicleFields.length > 0) {
      alert(
        `Please fill in the following required vehicle fields:\n\n${missingVehicleFields.join('\n')}`,
      )
      return
    }

    // Create vehicle with materials
    const newVehicle = {
      vehicle_id: isEditing ? editingVehicleId : Date.now().toString(),
      vehicle_name: vehicle.name,
      vehicle_type: vehicle.type,
      driver_licence: vehicle.license,
      insurance_provider: vehicle.insuranceProvider,
      insurance_no: vehicle.insuranceNumber,
      rc_no: vehicle.rcNumber,
      vehicle_comments: vehicle.comments,
      materials: [],
    }

    // Check if there's any material data (regardless of showMaterial state)
    const hasMaterialData =
      material.name ||
      material.natureOfWork ||
      material.quantity ||
      materials.some((mat) => mat.name || mat.natureOfWork || mat.quantity)

    // Collect missing material fields if there's any material data
    if (hasMaterialData) {
      const missingMaterialFields = []
      if (!material.name) missingMaterialFields.push('Material Name')
      if (!material.natureOfWork)
        missingMaterialFields.push('Material Description')
      if (!material.quantity) missingMaterialFields.push('Material Quantity')

      if (missingMaterialFields.length > 0) {
        alert(
          `Please fill in the following required material fields:\n\n${missingMaterialFields.join('\n')}`,
        )
        return
      }
    }

    // Add current material if it has data (regardless of showMaterial state)
    if (material.name) {
      newVehicle.materials.push({
        material_id: Date.now().toString(),
        material_name: material.name,
        material_device_model: material.model,
        material_description: material.natureOfWork,
        material_quantity: material.quantity,
        material_no_of_units: material.units,
        material_s_n: material.serial,
        material_comments: material.comments,
        material_vehicle_id: newVehicle.vehicle_id,
      })
    }

    // Add additional materials
    materials.forEach((mat) => {
      if (mat.name) {
        // Validate required material fields for additional materials
        const missingMaterialFields = []
        if (!mat.name) missingMaterialFields.push('Material Name')
        if (!mat.natureOfWork)
          missingMaterialFields.push('Material Description')
        if (!mat.quantity) missingMaterialFields.push('Material Quantity')

        if (missingMaterialFields.length > 0) {
          alert(
            `Please fill in the following required material fields:\n\n${missingMaterialFields.join('\n')}`,
          )
          return
        }

        newVehicle.materials.push({
          material_id: (Date.now() + Math.random()).toString(),
          material_name: mat.name,
          material_device_model: mat.model,
          material_description: mat.natureOfWork,
          material_quantity: mat.quantity,
          material_no_of_units: mat.units,
          material_s_n: mat.serial,
          material_comments: mat.comments,
          material_vehicle_id: newVehicle.vehicle_id,
        })
      }
    })

    setVehicles((prev) => [...prev, newVehicle])

    // Reset forms and editing state
    setIsEditing(false)
    setEditingVehicleId(null)
    setVehicle({
      name: '',
      type: '',
      license: '',
      insuranceProvider: '',
      insuranceNumber: '',
      rcNumber: '',
      comments: '',
    })
    setMaterial({
      name: '',
      model: '',
      natureOfWork: '',
      quantity: '',
      units: '',
      serial: '',
      comments: '',
    })
    setMaterials([])
    setShowMaterial(false)
  }

  const handleDeleteVehicle = (id) => {
    setVehicles((prev) => prev.filter((v) => v.vehicle_id !== id))
  }

  const handleEditVehicle = (vehicleToEdit) => {
    // Store original vehicle data for potential restoration
    setOriginalVehicleData(vehicleToEdit)

    // Set editing mode
    setIsEditing(true)
    setEditingVehicleId(vehicleToEdit.vehicle_id)

    // Populate form with vehicle data
    setVehicle({
      name: vehicleToEdit.vehicle_name,
      type: vehicleToEdit.vehicle_type,
      license: vehicleToEdit.driver_licence,
      insuranceProvider: vehicleToEdit.insurance_provider,
      insuranceNumber: vehicleToEdit.insurance_no,
      rcNumber: vehicleToEdit.rc_no,
      comments: vehicleToEdit.vehicle_comments,
    })

    // Populate materials if they exist
    if (vehicleToEdit.materials && vehicleToEdit.materials.length > 0) {
      setShowMaterial(true)
      // Set the first material in the main material form
      const firstMaterial = vehicleToEdit.materials[0]
      setMaterial({
        name: firstMaterial.material_name,
        model: firstMaterial.material_device_model,
        natureOfWork: firstMaterial.material_description,
        quantity: firstMaterial.material_quantity,
        units: firstMaterial.material_no_of_units,
        serial: firstMaterial.material_s_n,
        comments: firstMaterial.material_comments,
      })

      // Set additional materials if there are more than one
      const additionalMaterials = vehicleToEdit.materials
        .slice(1)
        .map((mat, index) => ({
          id: index + 1,
          name: mat.material_name,
          model: mat.material_device_model,
          natureOfWork: mat.material_description,
          quantity: mat.material_quantity,
          units: mat.material_no_of_units,
          serial: mat.material_s_n,
          comments: mat.material_comments,
        }))
      setMaterials(additionalMaterials)
      setMaterialIdCounter(additionalMaterials.length + 2)
    } else {
      setShowMaterial(false)
      setMaterial({
        name: '',
        model: '',
        natureOfWork: '',
        quantity: '',
        units: '',
        serial: '',
        comments: '',
      })
      setMaterials([])
    }

    // Remove the vehicle being edited from the list
    setVehicles((prev) =>
      prev.filter((v) => v.vehicle_id !== vehicleToEdit.vehicle_id),
    )
  }

  const handleCancelEdit = () => {
    // Restore original vehicle data to the table
    if (originalVehicleData) {
      setVehicles((prevVehicles) => [...prevVehicles, originalVehicleData])
    }

    setIsEditing(false)
    setEditingVehicleId(null)

    // Reset form
    setVehicle({
      name: '',
      type: '',
      license: '',
      insuranceProvider: '',
      insuranceNumber: '',
      rcNumber: '',
      comments: '',
    })
    setMaterial({
      name: '',
      model: '',
      natureOfWork: '',
      quantity: '',
      units: '',
      serial: '',
      comments: '',
    })
    setMaterials([])
    setShowMaterial(false)
    setOriginalVehicleData(null)
  }

  const handleCancelAndClear = () => {
    // Clear all vehicle data from the table
    setVehicles([])
    // Reset form
    setVehicle({
      name: '',
      type: '',
      license: '',
      insuranceProvider: '',
      insuranceNumber: '',
      rcNumber: '',
      comments: '',
    })
    setMaterial({
      name: '',
      model: '',
      natureOfWork: '',
      quantity: '',
      units: '',
      serial: '',
      comments: '',
    })
    setMaterials([])
    setShowMaterial(false)
    setIsEditing(false)
    setEditingVehicleId(null)
    // Close the modal
    onClose()
  }

  const handleSubmit = () => {
    // Prepare data for submission
    const allVehicles = vehicles
    const allMaterials = vehicles.flatMap((v) => v.materials || [])

    const vehicleData = {
      vm_details: allVehicles.map((v) => ({
        vehicle_id: v.vehicle_id,
        vehicle_name: v.vehicle_name,
        vehicle_type: v.vehicle_type,
        driver_id: v.driver_id || '',
        driver_licence: v.driver_licence,
        insurance_provider: v.insurance_provider,
        insurance_no: v.insurance_no,
        rc_no: v.rc_no,
        vehicle_comments: v.vehicle_comments,
        vehicle_status: v.vehicle_status || v.status || 'Pending',
      })),
      mm_details: allMaterials.map((m) => ({
        material_id: String(m.material_id),
        material_name: m.material_name,
        material_description: m.material_description,
        material_device_model: m.material_device_model,
        material_no_of_units: String(m.material_no_of_units),
        material_quantity: String(m.material_quantity),
        material_s_n: m.material_s_n,
        material_vehicle_id:
          m.material_vehicle_id ||
          (() => {
            // Find the vehicle that contains this material
            const parentVehicle = allVehicles.find(
              (v) =>
                v.materials &&
                v.materials.some((mat) => mat.material_id === m.material_id),
            )
            return parentVehicle ? String(parentVehicle.vehicle_id) : ''
          })(),
        material_comments: m.material_comments || '',
      })),
    }

    console.log('Vehicle data submitted:', vehicleData)

    if (onVehicleDataSubmit) {
      onVehicleDataSubmit(vehicleData)
    } else {
      onClose()
    }
  }

  return (
    <Modal
      open={isOpen}
      onClose={(event, reason) => {
        // Prevent closing when clicking outside the modal
        if (reason !== 'backdropClick') {
          onClose()
        }
      }}
    >
      <Box sx={styles.modal}>
        <div className="p-6 bg-gray-50 min-h-screen">
          {/* Header with Title and Navigation Icons */}
          <div className="flex items-center justify-between mb-6 bg-white p-4 shadow-sm">
            <div className="flex items-center">
              {onBack && (
                <IconButton
                  onClick={onBack}
                  className="mr-3"
                  sx={{
                    backgroundColor: '#f3f4f6',
                    '&:hover': { backgroundColor: '#e5e7eb' },
                    padding: '8px',
                    borderRadius: '8px',
                  }}
                  title="Back to Book Visit"
                >
                  <ArrowBack />
                </IconButton>
              )}
              <h1 className="text-xl font-bold text-gray-800">
                Vehicle Details & Materials
                {isEditing && (
                  <span className="ml-2 text-sm font-normal text-blue-600">
                    (Editing Mode)
                  </span>
                )}
              </h1>
            </div>
            <IconButton
              onClick={onClose}
              sx={{
                backgroundColor: '#f3f4f6',
                '&:hover': { backgroundColor: '#e5e7eb' },
                padding: '8px',
                borderRadius: '8px',
              }}
              title="Close"
            >
              <Close />
            </IconButton>
          </div>

          {/* Vehicle Details Section */}
          <div className="p-6 bg-white rounded-lg shadow-md mb-6">
            {isEditing && (
              <div className="mb-4 p-3 bg-blue-50 border-l-4 border-blue-400 rounded">
                <p className="text-blue-800 font-medium">
                  Edit Vehicle Details
                </p>
              </div>
            )}
            <div className="flex items-center mb-4">
              <span className="w-6 h-6 flex items-center justify-center rounded bg-sky-100 text-sky-600 mr-3">
                <DirectionsCarIcon sx={{ fontSize: 16 }} />
              </span>
              <h2 className="font-semibold text-gray-700">
                Vehicle Details Section
              </h2>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="vehicle-name"
                  className="block text-sm font-medium"
                >
                  Vehicle Name *
                </label>
                <input
                  id="vehicle-name"
                  type="text"
                  name="name"
                  value={vehicle.name}
                  onChange={handleVehicleChange}
                  placeholder="Enter vehicle name or model"
                  className="border border-gray-300 rounded-md p-2 w-full"
                />
              </div>
              <div>
                <label
                  htmlFor="vehicle-type"
                  className="block text-sm font-medium"
                >
                  Vehicle Type *
                </label>
                <select
                  id="vehicle-type"
                  name="type"
                  value={vehicle.type}
                  onChange={handleVehicleChange}
                  className="border border-gray-300 rounded-md p-2 w-full bg-gray-100"
                >
                  <option value="">Select vehicle type</option>
                  <option value="Truck">Truck</option>
                  <option value="Car">Car</option>
                  <option value="Bike">Bike</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium">
                  Driver License Number *
                </label>
                <input
                  type="text"
                  name="license"
                  value={vehicle.license}
                  onChange={handleVehicleChange}
                  placeholder="Enter valid license number"
                  className="border border-gray-300 rounded-md p-2 w-full"
                />
              </div>
              <div>
                <label className="block text-sm font-medium">
                  Insurance Provider
                </label>
                <input
                  type="text"
                  name="insuranceProvider"
                  value={vehicle.insuranceProvider}
                  onChange={handleVehicleChange}
                  placeholder="Enter insurance company name"
                  className="border border-gray-300 rounded-md p-2 w-full"
                />
              </div>
              <div>
                <label className="block text-sm font-medium">
                  Insurance Number
                </label>
                <input
                  type="text"
                  name="insuranceNumber"
                  value={vehicle.insuranceNumber}
                  onChange={handleVehicleChange}
                  placeholder="Enter policy number"
                  className="border border-gray-300 rounded-md p-2 w-full"
                />
              </div>
              <div>
                <label className="block text-sm font-medium">RC Number</label>
                <input
                  type="text"
                  name="rcNumber"
                  value={vehicle.rcNumber}
                  onChange={handleVehicleChange}
                  placeholder="Enter registration certificate number"
                  className="border border-gray-300 rounded-md p-2 w-full"
                />
              </div>
              <div className="col-span-2">
                <label className="block text-sm font-medium">
                  Vehicle Comments
                </label>
                <textarea
                  name="comments"
                  value={vehicle.comments}
                  onChange={handleVehicleChange}
                  placeholder="Enter comments"
                  className="border border-gray-300 rounded-md p-2 w-full"
                />
              </div>
            </div>

            {/* Add Material Details Button */}
            <button
              onClick={() => setShowMaterial(!showMaterial)}
              type="button"
              className="flex items-center justify-center w-full mt-4 border border-gray-800 text-gray-800 rounded-md py-2 font-medium hover:bg-gray-100 transition"
            >
              <span className="mr-2 text-lg">{showMaterial ? '-' : '+'}</span>
              {isEditing
                ? showMaterial
                  ? 'Hide Edit Material'
                  : 'Edit Materials'
                : showMaterial
                  ? 'Hide Material Details'
                  : 'Add Material Details'}
            </button>
          </div>

          {/* Material Movement Details Section */}
          {showMaterial && (
            <div className="p-6 bg-white rounded-lg shadow-md mb-6">
              <div className="flex justify-between items-center mb-4">
                <div className="flex items-center">
                  <span className="w-6 h-6 flex items-center justify-center rounded bg-sky-100 text-sky-600 mr-3">
                    <InventoryIcon sx={{ fontSize: 16 }} />
                  </span>
                  <h2 className="font-semibold text-gray-700">
                    Material Movement (MM) Details Section
                  </h2>
                </div>
                <button
                  onClick={handleAddMoreMaterial}
                  className="flex items-center px-3 py-1 border border-gray-300 rounded-md text-gray-600 hover:bg-gray-100 transition"
                >
                  <span className="mr-1 font-bold text-lg">+</span> Add More
                  Material
                </button>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium">
                    Material Name *
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={material.name}
                    onChange={handleMaterialChange}
                    placeholder="Enter material name"
                    className="border border-gray-300 rounded-md p-2 w-full"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium">
                    Device Model
                  </label>
                  <input
                    type="text"
                    name="model"
                    value={material.model}
                    onChange={handleMaterialChange}
                    placeholder="Enter device model/number"
                    className="border border-gray-300 rounded-md p-2 w-full"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-sm font-medium">
                    Material Description *
                  </label>
                  <textarea
                    name="natureOfWork"
                    value={material.natureOfWork}
                    onChange={handleMaterialChange}
                    placeholder="Enter material description"
                    className="border border-gray-300 rounded-md p-2 w-full"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium">
                    Quantity *
                  </label>
                  <input
                    type="number"
                    name="quantity"
                    value={material.quantity}
                    onChange={handleMaterialChange}
                    placeholder="Enter material quantity"
                    className="border border-gray-300 rounded-md p-2 w-full"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium">
                    Number of Units
                  </label>
                  <input
                    type="number"
                    name="units"
                    value={material.units}
                    onChange={handleMaterialChange}
                    placeholder="Enter number of units"
                    className="border border-gray-300 rounded-md p-2 w-full"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-sm font-medium">
                    Serial Number (S/N)
                  </label>
                  <input
                    type="text"
                    name="serial"
                    value={material.serial}
                    onChange={handleMaterialChange}
                    placeholder="Enter serial number"
                    className="border border-gray-300 rounded-md p-2 w-full"
                  />
                </div>
                {/*  */}
                <div className="col-span-2">
                  <label className="block text-sm font-medium">
                    Material Comments
                  </label>
                  <textarea
                    name="comments"
                    value={material.comments}
                    onChange={handleMaterialChange}
                    placeholder="Enter material comments"
                    className="border border-gray-300 rounded-md p-2 w-full"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Additional Material Forms */}
          {materials.map((mat, index) => (
            <div
              key={mat.id}
              className="p-6 bg-white rounded-lg shadow-md mb-6"
            >
              <div className="flex justify-between items-center mb-4">
                <div className="flex items-center">
                  <span className="w-6 h-6 flex items-center justify-center rounded bg-sky-100 text-sky-600 mr-3">
                    <InventoryIcon sx={{ fontSize: 16 }} />
                  </span>
                  <h2 className="font-semibold text-gray-700">
                    Material Movement (MM) Details Section {index + 2}
                  </h2>
                </div>
                <button
                  onClick={() => handleRemoveMaterial(mat.id)}
                  className="px-3 py-1 border border-red-300 rounded-md text-red-600 hover:bg-red-50 transition"
                >
                  Remove
                </button>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium">
                    Material Name *
                  </label>
                  <input
                    type="text"
                    value={mat.name}
                    onChange={(e) =>
                      handleMaterialFormChange(mat.id, 'name', e.target.value)
                    }
                    placeholder="Enter material name"
                    className="border border-gray-300 rounded-md p-2 w-full"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium">
                    Device Model
                  </label>
                  <input
                    type="text"
                    value={mat.model}
                    onChange={(e) =>
                      handleMaterialFormChange(mat.id, 'model', e.target.value)
                    }
                    placeholder="Enter device model/number"
                    className="border border-gray-300 rounded-md p-2 w-full"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-sm font-medium">
                    Material Description *
                  </label>
                  <textarea
                    value={mat.natureOfWork}
                    onChange={(e) =>
                      handleMaterialFormChange(
                        mat.id,
                        'natureOfWork',
                        e.target.value,
                      )
                    }
                    placeholder="Enter material description"
                    className="border border-gray-300 rounded-md p-2 w-full"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium">
                    Quantity *
                  </label>
                  <input
                    type="number"
                    value={mat.quantity}
                    onChange={(e) =>
                      handleMaterialFormChange(
                        mat.id,
                        'quantity',
                        e.target.value,
                      )
                    }
                    placeholder="Enter material quantity"
                    className="border border-gray-300 rounded-md p-2 w-full"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium">
                    Number of Units
                  </label>
                  <input
                    type="number"
                    value={mat.units}
                    onChange={(e) =>
                      handleMaterialFormChange(mat.id, 'units', e.target.value)
                    }
                    placeholder="Enter number of units"
                    className="border border-gray-300 rounded-md p-2 w-full"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-sm font-medium">
                    Serial Number (S/N)
                  </label>
                  <input
                    type="text"
                    value={mat.serial}
                    onChange={(e) =>
                      handleMaterialFormChange(mat.id, 'serial', e.target.value)
                    }
                    placeholder="Enter serial number"
                    className="border border-gray-300 rounded-md p-2 w-full"
                  />
                </div>
                {/*  */}
                <div className="col-span-2">
                  <label className="block text-sm font-medium">
                    Material Comments
                  </label>
                  <textarea
                    value={mat.comments}
                    onChange={(e) =>
                      handleMaterialFormChange(
                        mat.id,
                        'comments',
                        e.target.value,
                      )
                    }
                    placeholder="Enter material comments"
                    className="border border-gray-300 rounded-md p-2 w-full"
                  />
                </div>
              </div>
            </div>
          ))}

          {/* Add/Update Records Button - Always Visible */}
          <div className="mt-4 flex justify-center mb-6 gap-3">
            {isEditing && (
              <button
                onClick={handleCancelEdit}
                className="px-4 py-0.5 border border-gray-300 text-gray-700 rounded hover:bg-gray-50 transition"
              >
                Cancel Edit
              </button>
            )}
            <button
              onClick={handleAddRecords}
              className="flex items-center justify-center w-full bg-sky-100 text-sky-800 rounded-md py-0.5 font-medium border border-sky-200 hover:bg-sky-200 transition"
            >
              <span className="mr-2 text-lg">{isEditing ? '✓' : '+'}</span>
              {isEditing ? 'Update Records' : 'Add Records'}
            </button>
          </div>

          {/* Vehicle & Material Records */}
          <VehicleMaterialRecords
            vehicles={vehicles}
            onEdit={handleEditVehicle}
            onDelete={handleDeleteVehicle}
            onSubmit={handleSubmit}
            onCancel={handleCancelAndClear}
          />
        </div>
      </Box>
    </Modal>
  )
}

export default VehicleDetailsModal
