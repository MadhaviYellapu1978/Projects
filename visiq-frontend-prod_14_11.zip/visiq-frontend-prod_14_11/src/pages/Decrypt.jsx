import { Button } from '@mui/material'
import { Form, Formik } from 'formik'
import React, { useState } from 'react'
import * as Yup from 'yup'
import FormikTextField from '../lib/Formik/FormikTextfield'
import { decrypt } from '../utils/crypto.js'
const Decrypt = () => {
  const [res, setRes] = useState('')
  const initialValues = {
    ivBase64: '',
    encryptedBase64: '',
  }
  const validationSchema = Yup.object({
    ivBase64: Yup.string().required('Required'),
    encryptedBase64: Yup.string().required('Required'),
  })
  return (
    <div className="max-w-xl mx-auto h-screen ">
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={async (values) => {
          // The decrypt function from crypto.js takes only the encryptedBase64 string
          const res = await decrypt(values.encryptedBase64)
          setRes(res)
        }}
      >
        <Form className="flex flex-col gap-5">
          <FormikTextField name="ivBase64" label="ivBase64" />
          <FormikTextField name="encryptedBase64" label="encryptedBase64" />
          <Button type="submit">Decrypt</Button>
        </Form>
      </Formik>
      <div>
        <pre>{JSON.stringify(res, null, 2)}</pre>
      </div>
    </div>
  )
}

export default Decrypt
