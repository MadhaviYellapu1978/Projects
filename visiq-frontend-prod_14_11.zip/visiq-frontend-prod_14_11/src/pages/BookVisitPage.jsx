import React from 'react'
import BookVisitForm from '../components/BookVisitForm'

const BookVisitPage = () => {
  return (
    <div className="min-h-screen bg-gray-100 py-8">
      <div className="container mx-auto px-4">
        <BookVisitForm />
      </div>
    </div>
  )
}

export default BookVisitPage
