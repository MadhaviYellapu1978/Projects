import React, { Suspense } from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import { RouterProvider } from 'react-router-dom'
import { router } from './routes/routes.jsx'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { Toaster } from 'react-hot-toast'
import { AuthProvider } from './context/AuthContext.jsx'
import loading from './assets/loading.json'
import { ThemeProvider, createTheme } from '@mui/material/styles'
import CssBaseline from '@mui/material/CssBaseline'

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      refetchOnMount: false,
      staleTime: 1 * 60 * 60 * 1000, // 1 hour
      retry: false,
    },
  },
})

// Create a basic Material-UI theme
const theme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: '#051737',
    },
    secondary: {
      main: '#76E5F0',
    },
  },
})

import LottieLoader from './shared/LottieLoader.jsx'
import '@fortawesome/fontawesome-free/css/all.min.css'
import 'ag-grid-community/styles/ag-grid.css'
import 'ag-grid-community/styles/ag-theme-material.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <AuthProvider>
        <QueryClientProvider client={queryClient}>
          <Suspense fallback={<LottieLoader data={loading} />}>
            {/* <Toaster position="top-center" /> */}
            <Toaster
              toastOptions={{
                className: 'toaster',
                success: {
                  duration: 3000,
                  style: {
                    background: 'green',
                    color: 'white',
                    textTransform: 'capitalize',
                  },
                },
                error: {
                  duration: 3000,
                  style: {
                    background: 'red',
                    color: 'white',
                    textTransform: 'capitalize',
                  },
                },
              }}
            />
            <RouterProvider router={router} />
          </Suspense>
        </QueryClientProvider>
      </AuthProvider>
    </ThemeProvider>
  </React.StrictMode>,
)
