import React from 'react'
import Navbar from '../shared/SuperAdmin/Navbar'

const SuperAdminLayout = ({ children }) => {
  return (
    <div>
      <Navbar />
      {children}
    </div>
  )
}

export default SuperAdminLayout
