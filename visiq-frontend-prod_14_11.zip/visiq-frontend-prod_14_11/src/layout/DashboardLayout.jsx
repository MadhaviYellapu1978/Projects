import React, { useContext, lazy } from 'react'
import { Navigate } from 'react-router-dom'
import AdminLayout from '../layout/AdminLayout'
import { AuthContext } from '../context/AuthContext'
const SuperAdminDashboard = lazy(() => import('../pages/SuperAdmin/Dashboard'))
const AdminDashboard = lazy(() => import('../pages/Admin/Dashboard'))
const BranchAdmin = lazy(() => import('../pages/BranchAdmin/Dashboard'))
const SecurityAdmin = lazy(() => import('../pages/SecurityAdmin/Dashboard'))
const BranchAdminLayout = lazy(() => import('./BranchAdminLayout'))
const SecurityLayout = lazy(() => import('./SecurityLevelLayout'))
const SuperAdminLayout = lazy(() => import('./SuperAdminLayout'))

const DashboardLayout = () => {
  const auth = useContext(AuthContext)
  if (auth.role === '1') {
    return (
      <div>
        <SuperAdminLayout>
          <SuperAdminDashboard />
        </SuperAdminLayout>
      </div>
    )
  } else if (auth.role === '2' && auth.isOtpVerify) {
    return (
      <div>
        <AdminLayout>
          <AdminDashboard />
        </AdminLayout>
      </div>
    )
  } else if (auth.role === '3' && auth.isOtpVerify) {
    return (
      <div>
        <BranchAdminLayout>
          <BranchAdmin />
        </BranchAdminLayout>
      </div>
    )
  } else if (auth.role === '4' && auth.isOtpVerify) {
    return (
      <div>
        <SecurityLayout>
          <SecurityAdmin />
        </SecurityLayout>
      </div>
    )
  } else {
    return <Navigate to="/auth/login" />
    // <Outlet />
  }
}

export default DashboardLayout
