import React, { useContext } from 'react'
import { Navigate, Outlet } from 'react-router-dom'
import { AuthContext } from '../context/AuthContext'

const AuthLayout = () => {
  const auth = useContext(AuthContext)

  console.log('AuthLayout - Auth state:', auth)

  // If user is already authenticated, redirect to appropriate dashboard
  if (auth.org_id && auth.isOtpVerify) {
    console.log(
      'User already authenticated in AuthLayout, redirecting to dashboard',
    )
    switch (auth.role) {
      case '1': // Super Admin
        return <Navigate to="/superAdmin/dashboard" replace />
      case '2': // Organization Admin
        return <Navigate to="/admin/dashboard" replace />
      case '3': // Branch Admin
        return <Navigate to="/branchAdmin/dashboard" replace />
      case '4': // Security Admin
        return <Navigate to="/securityLevelAdmin/dashboard" replace />
      default:
        // If role is unknown, clear auth and stay on login
        console.log('Unknown role in AuthLayout, clearing auth')
        auth.logout()
        break
    }
  }

  // If not authenticated, show auth pages (login, forgot, otp, etc.)
  console.log('User not authenticated in AuthLayout, showing auth pages')
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 w-full">
      <div className="hidden md:block h-screen w-full bg-login-left bg-cover bg-no-repeat bg-center"></div>
      <Outlet />
    </div>
  )
}

export default AuthLayout
