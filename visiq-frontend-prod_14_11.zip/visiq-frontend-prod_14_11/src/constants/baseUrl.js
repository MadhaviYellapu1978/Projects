// Always use the development API server directly
// export const baseUrl = 'https://api-dev.myvisiq.com/api'
export const baseUrl = 'https://api.myvisiq.com/api'
