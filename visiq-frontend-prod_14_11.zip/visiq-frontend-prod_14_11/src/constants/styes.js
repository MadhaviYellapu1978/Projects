// import zIndex from '@mui/material/styles/zIndex'

export const styles = {
  modal: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    maxWidth: 800, // Updated to 800px as requested
    width: '85%', // Decreased from 90%
    maxHeight: '95vh', // Set a maximum height for the modal
    overflowY: 'auto', // Enable vertical scrolling if content exceeds height
    bgcolor: 'background.paper',
    boxShadow: 24,
    borderRadius: 0, // Removed border radius
    pt: 4,
    px: 4,
    pb: 2,
  },
}

export const stylees = {
  modal: {
    position: 'fixed',
    zIndex: 1300, // Keep it below the date picker dropdown
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    maxWidth: 600,
    width: '100%',
    maxHeight: '95vh',
    overflowY: 'auto',
    bgcolor: 'background.paper',
    boxShadow: 24,
    pt: 5,
    px: 5,
    pb: 3,
  },
}
