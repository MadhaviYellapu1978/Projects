import view from './view.svg'
import hide from './hide.svg'
import user from './user.svg'
import dropdown from './dropdown.svg'
import logout from './logout.svg'
import entry from './entry.svg'
import exit from './exit.svg'
import id from './5659.jpg'
export { view, hide, user, dropdown, logout, entry, exit, id }
