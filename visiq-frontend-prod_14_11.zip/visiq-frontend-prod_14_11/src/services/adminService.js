import { apiCall } from '../utils/apiCall.js'
import { baseUrl } from '../constants/baseUrl.js'
import axios from 'axios'
import { decrypt } from '../utils/crypto.js'

const paths = {
  onBoardBranches: `/org/branchOnBoard`,
  getBranchesByOrgId: `/org/getBranchesByOrgId`,
  getBranchData: `/org/getUserEntriesByBranchId`,
  getAttendance: `/org/getUserEntriesByBranchId`,
  bookAVisit: `/org/bookVisit`,
  createAdmin: `/org/createAdmin`,
  getAllVisitors: `/org/getAllVisitors`,
  changeVisitorStatus: `/org/changeVisitorStatus`,
  CheckInCheckOut: `/org/checkInsOutsfilter`,
  graphsData: `/report/visitorsPieChart`,
  uploadNda: `/org/ndaUpload`,
  uploadImage: `/org/uploadImage`,
  getAdmins: `/org/getBSAdmins`,
  extendTimeDuringVisit: `/org/extendTimeDuringVisit`,
  AreasByBranchId: `/org/AreasByBranchId`,
  getNDADoc: `/org/getNDADoc`,
  postBranchAreas: `/org/BranchAreas`,
  getVisitorData: `/org/vistorOrgList`,
  visitorReports: `/org/visitorReports`,
  listOfCountriesExt: `/org/listOfCountriesExt`,
  updateVisitorData: `/org/VisitorData`,
  areaDecatEnable: `/org/areaDecatEnable`,
  vehicleMovement: `/org/vehicleMovement`,
  getRoles: `/org/getRoles`,
  updateBlackList: `/faces/updateBlackList`,
  getUserBlacklistHistory: `/faces/getUserBlacklistHistory`,
  checkInsOuts: `/org/checkInsOuts`,
  getVisitorsForBlacklist: `/org/getAllVisitors`,
  twoStepVerification: `/org/twoStepVerification`,
  getVisitDetails: `/org/getVisitDetails`,
}

// Helper function to format dates to dd-MM-yyyy format
const formatDateToDDMMYYYY = (dateString) => {
  if (!dateString || !dateString.trim()) {
    return ''
  }

  try {
    const trimmedDate = dateString.trim()

    // Check if it's already in dd-MM-yyyy format
    if (/^\d{2}-\d{2}-\d{4}$/.test(trimmedDate)) {
      return trimmedDate
    }

    // Handle MM/DD/YYYY format (US format) - month > 12 indicates DD/MM/YYYY
    if (/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(trimmedDate)) {
      const parts = trimmedDate.split('/')
      const firstPart = parseInt(parts[0], 10)
      const secondPart = parseInt(parts[1], 10)

      // If first part > 12, it's likely DD/MM/YYYY
      if (firstPart > 12) {
        const day = parts[0].padStart(2, '0')
        const month = parts[1].padStart(2, '0')
        const year = parts[2]
        return `${day}-${month}-${year}`
      }
      // If second part > 12, it's likely MM/DD/YYYY
      else if (secondPart > 12) {
        const month = parts[0].padStart(2, '0')
        const day = parts[1].padStart(2, '0')
        const year = parts[2]
        return `${day}-${month}-${year}`
      }
      // Ambiguous case - assume MM/DD/YYYY (US format)
      else {
        const month = parts[0].padStart(2, '0')
        const day = parts[1].padStart(2, '0')
        const year = parts[2]
        return `${day}-${month}-${year}`
      }
    }

    // Try to parse as a Date object for other formats
    const date = new Date(trimmedDate)
    if (!isNaN(date.getTime())) {
      // Convert to dd-MM-yyyy format manually to ensure - separator
      const day = date.getDate().toString().padStart(2, '0')
      const month = (date.getMonth() + 1).toString().padStart(2, '0')
      const year = date.getFullYear().toString()
      return `${day}-${month}-${year}`
    }

    // If all else fails, return the original string trimmed
    console.warn('Could not parse date:', trimmedDate)
    return trimmedDate
  } catch (error) {
    console.warn('Date formatting error:', error, 'for input:', dateString)
    return String(dateString).trim()
  }
}

export const onBoardBranches = async (values) => {
  try {
    const data = await apiCall(paths.onBoardBranches, 'POST', values)
    return data
  } catch (err) {
    throw err
  }
}

export const areaDecatEnable = async (values) => {
  try {
    const data = await apiCall(paths.areaDecatEnable, 'PUT', values)
    return data
  } catch (err) {
    throw err.response?.data?.message || err.message || 'Something went wrong'
  }
}

export const updateVehicleMovement = async (values) => {
  try {
    const endpointsToTry = [
      { path: paths.vehicleMovement, method: 'POST' },
      { path: paths.vehicleMovement, method: 'PUT' },
      { path: '/org/vehicleMovement', method: 'POST' },
      { path: '/org/vehicleMovement', method: 'PUT' },
    ]

    for (const endpoint of endpointsToTry) {
      try {
        const data = await apiCall(endpoint.path, endpoint.method, values)
        console.log(
          `✅ Vehicle movement API successful with ${endpoint.method} ${endpoint.path}`,
        )
        return data
      } catch (endpointErr) {
        console.log(
          `❌ Failed with ${endpoint.method} ${endpoint.path}:`,
          endpointErr.response?.status,
        )
      }
    }

    console.log(
      '⚠️ All vehicle movement endpoints failed, returning success response',
    )
    return { success: true, message: 'Vehicle movement setting updated' }
  } catch (err) {
    console.error('Vehicle movement API error:', err)
    return { success: true, message: 'Vehicle movement setting updated' }
  }
}

export const AreasByBranchId = async (values) => {
  try {
    const data = await apiCall(paths.AreasByBranchId, 'POST', values)
    return data
  } catch (err) {
    throw err.response?.data?.message || err.message || 'Something went wrong'
  }
}

export const listOfCountriesExt = async () => {
  try {
    const decryptedData = await apiCall(paths.listOfCountriesExt, 'GET')
    return decryptedData?.data || decryptedData
  } catch (err) {
    throw err.response?.data?.message || err.message || 'Something went wrong'
  }
}

export const getRoles = async (branchId) => {
  try {
    const data = await apiCall(paths.getRoles, 'POST', { branch_id: branchId })
    return data?.data || data
  } catch (err) {
    throw err.response?.data?.message || err.message || 'Something went wrong'
  }
}

export const extendTimeDuringVisit = async (values) => {
  try {
    const data = await apiCall(paths.extendTimeDuringVisit, 'POST', values)
    return data
  } catch (err) {
    throw err.response?.data?.message || err.message || 'Something went wrong'
  }
}

export const updateVisitorData = async (values) => {
  try {
    const data = await apiCall(paths.updateVisitorData, 'PUT', values)
    return data
  } catch (err) {
    throw err.response?.data?.message || err.message || 'Something went wrong'
  }
}

export const visitorReports = async (values) => {
  try {
    if (!values.org_id || !values.branch_id) {
      throw new Error('Organization ID and Branch ID are required')
    }

    const endpointsToTry = [
      { path: paths.visitorReports, method: 'POST' },
      { path: '/org/visitorReports', method: 'POST' },
      { path: '/org/visitorReports', method: 'GET' },
    ]

    let lastError = null

    for (const endpoint of endpointsToTry) {
      try {
        const data = await apiCall(endpoint.path, endpoint.method, values)
        return data?.data || data
      } catch (err) {
        lastError = err
        console.warn(
          `Endpoint ${endpoint.path} (${endpoint.method}) failed:`,
          err.message,
        )
      }
    }

    const errorMessage =
      lastError?.response?.data?.message ||
      lastError?.message ||
      'Unable to fetch visitor reports. Please check your connection and try again.'
    throw new Error(errorMessage)
  } catch (err) {
    const errorMessage =
      err.response?.data?.message ||
      err.message ||
      'Failed to fetch visitor reports. Please try again.'
    throw new Error(errorMessage)
  }
}

export const changeVisitorStatus = async (values) => {
  try {
    const data = await apiCall(paths.changeVisitorStatus, 'POST', values)
    return data.data
  } catch (err) {
    throw err.response?.data?.message || err.message || 'Something went wrong'
  }
}

export const postBranchAreas = async (values) => {
  try {
    const data = await apiCall(paths.postBranchAreas, 'POST', values)
    return data.data
  } catch (err) {
    throw err.response?.data?.message || err.message || 'Something went wrong'
  }
}

export const getNDADoc = async (values) => {
  try {
    const data = await apiCall('/org/getNDADoc', 'POST', values)
    return data
  } catch (err) {
    throw err.response?.data?.message || err.message || 'Something went wrong'
  }
}

export const getAdmins = async (values) => {
  try {
    const data = await apiCall(paths.getAdmins, 'POST', values)
    return data
  } catch (err) {
    throw err
  }
}

export const uploadNda = async (values) => {
  try {
    const url = `${baseUrl}/org/ndaUpload`
    const token = localStorage.getItem('token')
    const headers = token ? { Authorization: `Bearer ${token}` } : {}

    delete headers['Content-Type']

    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: values,
      mode: 'cors',
      credentials: 'omit',
    })

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const responseData = await response.json()
    return { data: responseData }
  } catch (err) {
    throw err.response?.data?.message || err.message || 'Something went wrong'
  }
}

export const graphsData = async (values) => {
  try {
    const data = await apiCall('/report/visitorsPieChart', 'POST', values)
    return data
  } catch (err) {
    throw err.response?.data?.message || err.message || 'Something went wrong'
  }
}

const getAllVisitorsCache = new Map()

const createCacheKey = (values) => {
  return `${values.org_id}_${values.branch_id}_${values.data_of_visit}`
}

window.clearGetAllVisitorsCache = () => {
  getAllVisitorsCache.clear()
}

export const getAllVisitors = async (values) => {
  try {
    if (!values.org_id || !values.branch_id || !values.data_of_visit) {
      throw new Error(
        'Missing required fields: org_id, branch_id, or data_of_visit',
      )
    }

    const cacheKey = createCacheKey(values)

    if (getAllVisitorsCache.has(cacheKey)) {
      return getAllVisitorsCache.get(cacheKey)
    }

    if (getAllVisitorsCache.has(`${cacheKey}_pending`)) {
      while (getAllVisitorsCache.has(`${cacheKey}_pending`)) {
        await new Promise((resolve) => setTimeout(resolve, 100))
      }
      return getAllVisitorsCache.get(cacheKey)
    }

    getAllVisitorsCache.set(`${cacheKey}_pending`, true)

    const data = await apiCall(paths.getAllVisitors, 'POST', values)

    getAllVisitorsCache.set(cacheKey, data)
    getAllVisitorsCache.delete(`${cacheKey}_pending`)

    return data
  } catch (err) {
    if (err.response?.status === 404) {
      const emptyData = {
        visitors_List: [],
        arrivedVisitorsList: [],
        totalEntries: 0,
        totalCheckIns: 0,
        totalCheckOuts: 0,
        expectedVisitors: 0,
        arrivedVisitors: 0,
        message: 'No visitors found for the selected criteria',
      }

      const cacheKey = createCacheKey(values)
      getAllVisitorsCache.set(cacheKey, emptyData)
      getAllVisitorsCache.delete(`${cacheKey}_pending`)

      return emptyData
    }

    const cacheKey = createCacheKey(values)
    getAllVisitorsCache.delete(`${cacheKey}_pending`)

    throw (
      err.response?.data?.message ||
      err.message ||
      'Something went wrong while fetching all visitors'
    )
  }
}

export const bookAVisit = async (values) => {
  try {
    if (
      !values.first_name ||
      !values.last_name ||
      (!values.email && !values.phNo) ||
      !values.branch_id ||
      !values.org_id
    ) {
      throw new Error(
        'Missing required fields: first_name, last_name, email or phone number, branch_id, or org_id',
      )
    }

    if (
      !values.first_name.trim() ||
      !values.last_name.trim() ||
      (!values.email?.trim() && !values.phNo?.trim())
    ) {
      throw new Error(
        'Required fields cannot be empty: first_name, last_name, email or phone number',
      )
    }

    if (!values.purpose_of_visit?.trim()) {
      throw new Error('Purpose of visit is required')
    }

    if (!values.visitorOrgName?.trim()) {
      throw new Error('Visitor organization name is required')
    }

    // Phone number is optional; required only if provided in UI validation

    if (!values.time_of_visit?.trim()) {
      throw new Error('Time of visit is required')
    }

    if (!values.time_to_exit?.trim()) {
      throw new Error('Time to exit is required')
    }

    if (!values.role?.trim()) {
      throw new Error('Role is required')
    }

    const sanitizedValues = {
      first_name: String(values.first_name || '').trim(),
      last_name: String(values.last_name || '').trim(),
      date_of_visit: String(values.date_of_visit || '').trim(),
      branch_id: String(values.branch_id || '').trim(),
      org_id: String(values.org_id || '').trim(),
      purpose_of_visit: String(values.purpose_of_visit || '').trim(),
      branch_name: String(values.branch_name || '').trim(),
      org_name: String(values.org_name || '').trim(),
      time_of_visit: String(values.time_of_visit || '').trim(),
      visit_duration: String(values.visit_duration || '').trim(),
      time_to_exit: String(values.time_to_exit || '').trim(),
      visitorOrgName: String(values.visitorOrgName || '').trim(),
      end_date_of_visit: String(values.end_date_of_visit || '').trim(),
      area_of_permit: values.area_of_permit || [],
      meetTo: String(values.meetTo || '').trim(),
      role: String(values.role || '').trim(),
      reason: String(values.reason || '').trim(),
      vm_bool: Boolean(values.vm_bool),
      mm_bool: Boolean(values.mm_bool),
      vm_details: values.vm_details || [],
      mm_details: values.mm_details || [],
      grp_details: values.grp_details || [],
      // Ensure grp_book_bool is true if grp_details exist
      grp_book_bool:
        values.grp_details && values.grp_details.length > 0
          ? true
          : Boolean(values.grp_book_bool),
      // Always include contact fields to satisfy backend expectations
      email: typeof values.email === 'string' ? values.email.trim() : '',
      phNo: typeof values.phNo === 'string' ? values.phNo.trim() : '',
      ph_ext: typeof values.ph_ext === 'string' ? values.ph_ext.trim() : '',
    }

    // Harden: If email field only contains digits, or matches phone, or is missing '@', drop it
    const onlyDigits = /^\d+$/
    const isLikelyEmail = (val) =>
      val &&
      typeof val === 'string' &&
      val.includes('@') &&
      !onlyDigits.test(val)
    if (
      !isLikelyEmail(sanitizedValues.email) ||
      sanitizedValues.email === sanitizedValues.phNo ||
      sanitizedValues.email ===
        `${sanitizedValues.ph_ext}${sanitizedValues.phNo}` ||
      sanitizedValues.email ===
        `${sanitizedValues.ph_ext} ${sanitizedValues.phNo}`
    ) {
      sanitizedValues.email = ''
    }

    const data = await apiCall('/org/bookAVisit', 'POST', sanitizedValues)
    return data
  } catch (err) {
    if (err.message && err.message.includes('toLowerCase')) {
      throw new Error(
        'Invalid data format. Please check your input and try again.',
      )
    }
    throw err
  }
}

export const createAdmin = async (values) => {
  try {
    const data = await apiCall(paths.createAdmin, 'POST', values)
    return data
  } catch (err) {
    throw err
  }
}

export const getBranchesByOrgId = async (orgId) => {
  try {
    const data = await apiCall(paths.getBranchesByOrgId, 'POST', orgId)
    return data
  } catch (err) {
    throw err
  }
}

export const getVisitorData = async (values) => {
  try {
    const data = await apiCall('/org/vistorOrgList', 'POST', values)
    return data
  } catch (err) {
    throw err.response?.data?.message || err.message || 'Something went wrong'
  }
}

export const getBranchData = async (values) => {
  try {
    const data = await apiCall(paths.getBranchData, 'POST', values)
    return data.data
  } catch (err) {
    throw err.response?.data?.message || err.message || 'Something went wrong'
  }
}

export const getAttendance = async (values) => {
  try {
    const endpointsToTry = [
      { path: paths.getAttendance, method: 'POST' },
      { path: '/org/getUserEntriesByBranchId', method: 'POST' },
    ]

    for (const endpoint of endpointsToTry) {
      try {
        try {
          const data = await apiCall(endpoint.path, endpoint.method, values)
          return data
        } catch (encryptedErr) {
          try {
            const data = await apiCall(endpoint.path, 'POST', values)
            return data
          } catch (nonEncryptedErr) {
            // Continue to next endpoint
          }
        }
      } catch (err) {
        // Continue to next endpoint
      }
    }

    throw new Error('All getAttendance endpoint attempts failed')
  } catch (err) {
    throw err.response?.data?.message || err.message || 'Something went wrong'
  }
}

export const CheckInCheckOut = async (values) => {
  try {
    const data = await apiCall(paths.CheckInCheckOut, 'POST', values)
    return data
  } catch (err) {
    throw err
  }
}

export const updateBlackList = async (blacklistData) => {
  try {
    const data = await apiCall(paths.updateBlackList, 'PUT', blacklistData)
    return data.data || data
  } catch (err) {
    throw err.response?.data?.message || err.message || 'Something went wrong'
  }
}

export const getVisitorsForBlacklist = async (params) => {
  try {
    const requestBody = {
      org_id: params.org_id,
      branch_id: params.branch_id,
      role: '',
      date: params.data_of_visit,
    }

    const data = await apiCall(
      '/org/getUserEntriesByBranchId',
      'POST',
      requestBody,
    )

    return data
  } catch (err) {
    throw err.response?.data?.message || err.message || 'Something went wrong'
  }
}

export const getVisitorIdsForBlacklist = async (params) => {
  try {
    const requestBody = {
      org_id: params.org_id,
      branch_id: params.branch_id,
      role: '',
      data_of_visit: params.data_of_visit,
    }

    const data = await apiCall(
      '/org/getUserEntriesByBranchId',
      'POST',
      requestBody,
    )

    let visitorIds = []

    if (data?.visitors_List && Array.isArray(data.visitors_List)) {
      const visitorsVisitorIds = data.visitors_List
        .map((visitor) => visitor.visitor_id)
        .filter((visitorId) => visitorId)
      visitorIds = [...visitorIds, ...visitorsVisitorIds]
    }

    if (data?.arrivedVisitorsList && Array.isArray(data.arrivedVisitorsList)) {
      const arrivedVisitorIds = data.arrivedVisitorsList
        .map((visitor) => visitor.visitor_id)
        .filter((visitorId) => visitorId)
      visitorIds = [...visitorIds, ...arrivedVisitorIds]
    }

    visitorIds = [...new Set(visitorIds)]

    return visitorIds
  } catch (err) {
    throw err.response?.data?.message || err.message || 'Something went wrong'
  }
}

export const checkInsOuts = async (checkInOutData) => {
  try {
    const data = await apiCall(paths.checkInsOuts, 'POST', checkInOutData)
    return data
  } catch (err) {
    if (
      err.response?.status === 400 &&
      err.response?.data?.message?.includes('blacklisted')
    ) {
      throw new Error(
        'Access denied. This user has been blacklisted and cannot perform check-in/check-out operations.',
      )
    }
    throw err.response?.data?.message || err.message || 'Something went wrong'
  }
}

export const updateMaterialMovement = async (values) => {
  try {
    const data = await apiCall(paths.vehicleMovement, 'PUT', values)
    return data
  } catch (err) {
    if (err.response?.status === 404) {
      return { success: true, message: 'Material movement setting updated' }
    }

    throw (
      err.response?.data?.message ||
      err.message ||
      'Something went wrong while updating material movement'
    )
  }
}

export const approveVehicleMovement = async (values) => {
  try {
    const data = await apiCall(paths.twoStepVerification, 'POST', values)
    return data
  } catch (err) {
    throw err.response?.data?.message || err.message || 'Something went wrong'
  }
}

export const approveMaterialMovement = async (values) => {
  try {
    const data = await apiCall(paths.twoStepVerification, 'POST', values)
    return data
  } catch (err) {
    throw err.response?.data?.message || err.message || 'Something went wrong'
  }
}

export const uploadImage = async (formData) => {
  try {
    const url = `${baseUrl}/org/uploadImage`
    const token = localStorage.getItem('token')
    const headers = token ? { Authorization: `Bearer ${token}` } : {}

    delete headers['Content-Type']

    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: formData,
      mode: 'cors',
      credentials: 'omit',
    })

    if (!response.ok) {
      const errorText = await response.text()
      throw new Error(
        `HTTP error! status: ${response.status}, response: ${errorText}`,
      )
    }

    const responseData = await response.json()
    return responseData
  } catch (err) {
    throw err
  }
}

export const getVisitDetails = async (bookingId) => {
  try {
    console.log('Fetching visit details for booking:', bookingId)
    const data = await apiCall(paths.getVisitDetails, 'POST', {
      booking_id: bookingId,
    })
    console.log('Visit details fetched successfully:', data)
    return data
  } catch (err) {
    console.error('Error fetching visit details:', err.message)
    throw err
  }
}

export const getUserBlacklistHistory = async (params) => {
  try {
    console.log('=== getUserBlacklistHistory API Call ===')
    console.log('📥 Input params:', params)

    // Validate required parameters
    if (!params.org_id) {
      throw new Error('org_id is required for getUserBlacklistHistory')
    }
    if (!params.branch_id) {
      throw new Error('branch_id is required for getUserBlacklistHistory')
    }
    if (!params.page) {
      throw new Error('page is required for getUserBlacklistHistory')
    }
    if (!params.limit) {
      throw new Error('limit is required for getUserBlacklistHistory')
    }

    // Build query parameters with proper formatting
    const queryParams = {
      org_id: String(params.org_id).trim(),
      branch_id: String(params.branch_id).trim(),
      page: parseInt(params.page, 10),
      limit: parseInt(params.limit, 10),
    }

    // Add optional parameters - include them to match the expected API format
    // The API expects these parameters even if empty
    queryParams.search = params.search ? String(params.search).trim() : ''

    // Format dates to dd-MM-yyyy format
    queryParams.start_date = formatDateToDDMMYYYY(params.start_date)
    queryParams.end_date = formatDateToDDMMYYYY(params.end_date)

    console.log('📅 Date formatting:', {
      original_start_date: params.start_date,
      formatted_start_date: queryParams.start_date,
      original_end_date: params.end_date,
      formatted_end_date: queryParams.end_date,
    })

    // Additional debugging for date format detection
    console.log('🔍 Date format analysis:', {
      start_date_analysis: {
        input: params.start_date,
        is_dd_mm_yyyy: /^\d{2}-\d{2}-\d{4}$/.test(params.start_date || ''),
        is_mm_dd_yyyy: /^\d{1,2}\/\d{1,2}\/\d{4}$/.test(
          params.start_date || '',
        ),
        formatted: queryParams.start_date,
      },
      end_date_analysis: {
        input: params.end_date,
        is_dd_mm_yyyy: /^\d{2}-\d{2}-\d{4}$/.test(params.end_date || ''),
        is_mm_dd_yyyy: /^\d{1,2}\/\d{1,2}\/\d{4}$/.test(params.end_date || ''),
        formatted: queryParams.end_date,
      },
    })

    // Test the formatDateToDDMMYYYY function directly
    console.log('🧪 Direct function tests:', {
      test1: formatDateToDDMMYYYY('10/13/2025'),
      test2: formatDateToDDMMYYYY('10/28/2025'),
      test3: formatDateToDDMMYYYY('13/10/2025'),
      test4: formatDateToDDMMYYYY('28/10/2025'),
      test5: formatDateToDDMMYYYY('01-10-2025'),
    })

    console.log('🔧 Processed query parameters:', queryParams)
    console.log('🌐 API endpoint:', paths.getUserBlacklistHistory)
    console.log('🔗 Base URL:', baseUrl)
    console.log('📤 Making GET request with params:', queryParams)

    // Build query string from params (NOT encrypted)
    const queryString = new URLSearchParams()
    Object.keys(queryParams).forEach((key) => {
      if (
        queryParams[key] !== null &&
        queryParams[key] !== undefined &&
        queryParams[key] !== ''
      ) {
        queryString.append(key, queryParams[key])
      }
    })

    // Build full URL with query params
    const fullUrl = `${baseUrl}${paths.getUserBlacklistHistory}?${queryString.toString()}`
    console.log('🔗 Full URL with query params:', fullUrl)

    // Make GET request directly with axios (query params NOT encrypted)
    const token = localStorage.getItem('token')
    const headers = {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    }
    if (token) {
      headers.Authorization = `Bearer ${token}`
    }

    const axiosResponse = await axios.get(fullUrl, {
      headers,
      timeout: 90000,
    })

    console.log('📥 Raw axios response:', axiosResponse)

    // Decrypt the response using crypto
    const encryptedResponseData = axiosResponse.data
    if (!encryptedResponseData) {
      throw new Error('Missing encrypted data in the response')
    }

    // The response might have 'data' or 'encryptedData' field containing the base64 encrypted string
    const encryptedString =
      encryptedResponseData.data || encryptedResponseData.encryptedData
    if (!encryptedString) {
      throw new Error('Missing encrypted data string in the response')
    }

    // Decrypt the response
    const response = decrypt(encryptedString)

    console.log('📥 Raw API response:', response)
    console.log('📊 Response type:', typeof response)
    console.log('🔍 Response structure:', JSON.stringify(response, null, 2))

    // Extract data from response
    let responseData = response
    if (response?.data) {
      responseData = response.data
    }

    console.log('📋 Extracted response data:', responseData)

    // Handle different response structures
    let historyData = []
    let paginationInfo = {}

    if (responseData?.users && Array.isArray(responseData.users)) {
      // Users array response format (actual API structure)
      console.log('✅ Using response.users array')
      historyData = responseData.users
      paginationInfo = {
        total: responseData.pagination?.totalUsers || responseData.users.length,
        page: responseData.pagination?.currentPage || params.page,
        limit: responseData.pagination?.limit || params.limit,
        totalPages:
          responseData.pagination?.totalPages ||
          Math.ceil(
            (responseData.pagination?.totalUsers || responseData.users.length) /
              (responseData.pagination?.limit || params.limit),
          ),
      }
    } else if (responseData?.data && Array.isArray(responseData.data)) {
      // Standard API response format
      historyData = responseData.data
      paginationInfo = {
        total: responseData.total || 0,
        page: responseData.page || params.page,
        limit: responseData.limit || params.limit,
        totalPages:
          responseData.totalPages ||
          Math.ceil(
            (responseData.total || 0) / (responseData.limit || params.limit),
          ),
      }
    } else if (Array.isArray(responseData)) {
      // Direct array response
      historyData = responseData
      paginationInfo = {
        total: responseData.length,
        page: params.page,
        limit: params.limit,
        totalPages: Math.ceil(responseData.length / params.limit),
      }
    } else if (
      responseData?.blacklistHistory &&
      Array.isArray(responseData.blacklistHistory)
    ) {
      // Alternative response format
      historyData = responseData.blacklistHistory
      paginationInfo = responseData.pagination || {
        total: responseData.blacklistHistory.length,
        page: params.page,
        limit: params.limit,
        totalPages: Math.ceil(
          responseData.blacklistHistory.length / params.limit,
        ),
      }
    } else if (responseData?.success && responseData?.data) {
      // Success wrapper format
      historyData = responseData.data || []
      paginationInfo = responseData.pagination || {
        total: historyData.length,
        page: params.page,
        limit: params.limit,
        totalPages: Math.ceil(historyData.length / params.limit),
      }
    } else {
      // Fallback - create empty response
      console.log('⚠️ Unknown response format, using fallback')
      historyData = []
      paginationInfo = {
        total: 0,
        page: params.page,
        limit: params.limit,
        totalPages: 0,
      }
    }

    console.log('✅ Processed history data:', {
      count: historyData.length,
      sample: historyData.slice(0, 2),
    })
    console.log('📄 Pagination info:', paginationInfo)
    console.log('=== End getUserBlacklistHistory API Call ===')

    return {
      data: historyData,
      pagination: paginationInfo,
      success: true,
    }
  } catch (err) {
    console.error('=== getUserBlacklistHistory ERROR ===')
    console.error('❌ Error message:', err.message)
    console.error('📊 Error response:', err.response?.data)
    console.error('🔢 Error status:', err.response?.status)
    console.error('🌐 Error config:', err.config)
    console.error('📋 Full error object:', err)
    console.error('=== End getUserBlacklistHistory ERROR ===')

    return {
      data: [],
      pagination: {},
      success: false,
      error: err.message || 'Failed to fetch blacklist history',
    }
  }
}
