import { apiCall } from '../utils/apiCall.js'
import { baseUrl } from '../constants/baseUrl.js'

const paths = {
  onBoardOrg: `/org/onBoard`,
  getBranchesByOrgId: `/org/getBranchesByOrgId`,
  getTimeByBranchId: `/org/branchCurrentTime`,
  bookVisit: `/org/bookVisit`,
}

export const onBoardOrg = async (values) => {
  try {
    // Check if values is FormData (for file upload)
    if (values instanceof FormData) {
      // Use direct fetch for FormData to ensure proper handling
      const token = localStorage.getItem('token')
      const response = await fetch(`${baseUrl}${paths.onBoardOrg}`, {
        method: 'POST',
        headers: {
          ...(token && { Authorization: `Bearer ${token}` }),
        },
        body: values, // Send FormData directly
      })

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        throw new Error(
          errorData.message || `HTTP error! status: ${response.status}`,
        )
      }

      const data = await response.json()
      return data
    } else {
      // Use apiCall with encryption for regular JSON data
      const data = await apiCall(paths.onBoardOrg, 'POST', values)
      return data
    }
  } catch (err) {
    throw err
  }
}

export const getAllOrgs = async (orgId) => {
  try {
    console.log('Fetching organizations for org:', orgId.org_id || orgId)
    // Use apiCall with encryption for super admin APIs
    const data = await apiCall(paths.getBranchesByOrgId, 'POST', orgId)
    console.log('Organizations fetched successfully:', data)
    return data
  } catch (err) {
    console.error('Error fetching organizations:', err.message)
    throw err
  }
}

export const getBranchTime = async (branch) => {
  try {
    const data = await apiCall(paths.getTimeByBranchId, 'POST', {
      branch_id: branch,
    })
    return data
  } catch (err) {
    throw err
  }
}

export const bookVisit = async (visitData) => {
  try {
    console.log('Booking visit with data:', visitData)
    const data = await apiCall(paths.bookVisit, 'POST', visitData)
    console.log('Visit booked successfully:', data)
    return data
  } catch (err) {
    console.error('Error booking visit:', err.message)
    throw err
  }
}
