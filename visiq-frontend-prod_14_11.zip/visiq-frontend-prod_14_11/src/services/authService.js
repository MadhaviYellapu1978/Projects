import { apiCall } from '../utils/apiCall.js'
// import { apiClient } from '../utils/apiClient.js'
import { baseUrl } from '../constants/baseUrl.js'
// import { encrypt  as cryptoEncrypt , decrypt as cryptoDecrypt} from '../utils/crypto.js'

const paths = {
  signIn: `/auth/signin`,
  signUp: `/auth/signup`,
  ChangePassword: `/auth/changepswd`,
  forgotPassword: `/auth/forgotpswd`,
  otp: `/auth/verifyOTP`,
  // Alternative endpoints to try
  login: `/auth/login`,
  authenticate: `/auth/authenticate`,
}

export const signIn = async (values) => {
  try {
    // const encryptedValues = cryptoEncrypt(values)
    // console.log('Encrypted values:', encryptedValues)
    console.log('=== SIGNIN DEBUG ===')
    // console.log('Signin values:', values)
    console.log('API endpoint:', paths.signIn)
    console.log('Full URL:', `${baseUrl}${paths.signIn}`)
    console.log('Environment:', import.meta.env.MODE)
    console.log('Base URL:', baseUrl)

    localStorage.setItem('username', values.username)
    localStorage.setItem('password', values.password)

    // Log the exact data being sent
    console.log('Data being sent to API:', JSON.stringify(values, null, 2))

    // Use apiClient for signin since the API expects plain JSON, not encrypted data
    const data = await apiCall(paths.signIn, 'post', values)

    console.log('Signin response:', data)
    console.log('=== END SIGNIN DEBUG ===')
    return data
  } catch (error) {
    console.error('=== SIGNIN ERROR DEBUG ===')
    console.error('Signin error:', error)
    console.error('Error message:', error.message)
    console.error('Error response:', error.response)

    // Enhanced 401 error debugging
    if (error.response?.status === 401) {
      console.error('=== 401 UNAUTHORIZED ERROR ===')
      console.error(
        'This means the request reached the API but authentication failed',
      )
      console.error('Possible causes:')
      console.error('1. Invalid username/password')
      console.error('2. API expects different field names')
      console.error('3. Missing required fields')
      console.error('4. API expects encrypted data instead of plain text')
      console.error('5. Different authentication method required')

      // Log the exact request that was made
      console.error('Request details:')
      console.error('- URL:', `${baseUrl}${paths.signIn}`)
      console.error('- Method: POST')
      console.error('- Data sent:', JSON.stringify(values, null, 2))
      console.error('- Response status:', error.response?.status)
      console.error('- Response data:', error.response?.data)
    }

    // Check if it's a CORS error
    if (error.message.includes('CORS') || error.message.includes('cors')) {
      console.error(
        'CORS ERROR DETECTED - Check proxy configuration and API server CORS settings',
      )
    }

    // Check if it's a network error
    if (
      error.message.includes('Failed to fetch') ||
      error.message.includes('NetworkError')
    ) {
      console.error(
        'NETWORK ERROR - Check if API server is accessible and proxy is working',
      )
    }

    console.error('=== END SIGNIN ERROR DEBUG ===')
    throw error
  }
}

export const signUp = async (values) => {
  try {
    console.log('=== SIGNUP DEBUG ===')
    console.log('Signup values:', values)

    // Use apiCall (encrypted) for signup since the API expects encrypted data
    const data = await apiCall(paths.signUp, 'POST', values)

    console.log('Signup response:', data)
    console.log('=== END SIGNUP DEBUG ===')
    return data
  } catch (error) {
    console.error('=== SIGNUP ERROR DEBUG ===')
    console.error('Signup error:', error)
    console.error('=== END SIGNUP ERROR DEBUG ===')
    throw error
  }
}

export const otp = async (values) => {
  try {
    console.log('=== OTP VERIFICATION DEBUG ===')
    console.log('OTP request values:', values)
    console.log('API endpoint:', paths.otp)
    console.log('Full URL:', `${baseUrl}${paths.otp}`)

    // Get stored password from localStorage
    const storedPassword = localStorage.getItem('password')
    console.log('Stored password available:', !!storedPassword)

    // Include password in the request if available
    const requestData = {
      ...values,
      password: storedPassword,
    }

    console.log('Final request data:', requestData)

    // Use apiCall (encrypted) for OTP verification since it expects encrypted data
    const data = await apiCall(paths.otp, 'POST', requestData)
    console.log('OTP response:', data)
    console.log('=== END OTP DEBUG ===')
    return data
  } catch (error) {
    console.error('=== OTP ERROR DEBUG ===')
    console.error('OTP error:', error)
    console.error('=== END OTP ERROR DEBUG ===')
    throw error
  }
}

export const changePassword = async (values) => {
  console.log('=== CHANGE PASSWORD DEBUG ===')
  console.log('Change password with data:', values)
  console.log('API endpoint:', paths.ChangePassword)
  console.log('Full URL:', `${baseUrl}${paths.ChangePassword}`)
  try {
    const data = await apiCall(paths.ChangePassword, 'post', values)
    console.log('Change password response:', data)
    console.log('=== END CHANGE PASSWORD DEBUG ===')
    return data
  } catch (error) {
    console.error('=== CHANGE PASSWORD ERROR DEBUG ===')
    console.error('Change password error:', error)
    console.error('Error message:', error.message)
    console.error('Error response:', error.response)

    // Check if it's a CORS error
    if (error.message.includes('CORS') || error.message.includes('cors')) {
      console.error(
        'CORS ERROR DETECTED - Check proxy configuration and API server CORS settings',
      )
    }

    // Check if it's a network error
    if (
      error.message.includes('Failed to fetch') ||
      error.message.includes('NetworkError')
    ) {
      console.error(
        'NETWORK ERROR - Check if API server is accessible and proxy is working',
      )
    }

    console.error('=== END CHANGE PASSWORD ERROR DEBUG ===')
    throw error
  }
}

export const forgotPassword = async (values) => {
  try {
    console.log('=== FORGOT PASSWORD DEBUG ===')
    console.log('Forgot password with data:', values)

    const data = await apiCall(paths.forgotPassword, 'POST', values)

    console.log('Forgot password response:', data)
    console.log('=== END FORGOT PASSWORD DEBUG ===')
    return data
  } catch (error) {
    console.error('=== FORGOT PASSWORD ERROR DEBUG ===')
    console.error('Forgot password error:', error)
    console.error('=== END FORGOT PASSWORD ERROR DEBUG ===')
    throw error
  }
}
