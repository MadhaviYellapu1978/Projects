import React, { useContext, useEffect } from 'react'
import { Navigate } from 'react-router-dom'
import { AuthContext } from '../context/AuthContext'

const Root = () => {
  const auth = useContext(AuthContext)

  useEffect(() => {
    console.log('Root component - Auth state:', auth)
    console.log('Root component - org_id:', auth.org_id)
    console.log('Root component - role:', auth.role)
    console.log('Root component - isOtpVerify:', auth.isOtpVerify)
  }, [auth])

  // If user is not authenticated, redirect to login page
  if (!auth.org_id || !auth.isOtpVerify) {
    console.log('User not authenticated, redirecting to login')
    return <Navigate to="/auth/login" replace />
  }

  // If authenticated, redirect to appropriate dashboard based on role
  console.log(
    'User authenticated, redirecting to dashboard based on role:',
    auth.role,
  )
  switch (auth.role) {
    case '1': // Super Admin
      return <Navigate to="/superAdmin/dashboard" replace />
    case '2': // Organization Admin
      return <Navigate to="/admin/dashboard" replace />
    case '3': // Branch Admin
      return <Navigate to="/branchAdmin/dashboard" replace />
    case '4': // Security Admin
      return <Navigate to="/securityLevelAdmin/dashboard" replace />
    default:
      console.log('Unknown role, redirecting to login')
      return <Navigate to="/auth/login" replace />
  }
}

export default Root
