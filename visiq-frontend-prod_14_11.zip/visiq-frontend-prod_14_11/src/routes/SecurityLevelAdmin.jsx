/* eslint-disable prettier/prettier */
import React, { useContext } from 'react'
import { Navigate, Outlet } from 'react-router-dom'
import { AuthContext } from '../context/AuthContext'
import SecurityLayout from '../layout/SecurityLevelLayout'

const SecurityLevelAdmin = () => {
  const auth = useContext(AuthContext)
  if (auth.role === '4' && auth.isOtpVerify) {
    return (
      <div>
        <SecurityLayout>
          <Outlet />
        </SecurityLayout>
      </div>
    )
  } else {
    return <Navigate to="/auth/login" />
  }
}

export default SecurityLevelAdmin
