/* eslint-disable prettier/prettier */
import React, { useContext } from 'react'
import { Navigate, Outlet } from 'react-router-dom'
import SuperAdminLayout from '../layout/SuperAdminLayout'
import { AuthContext } from '../context/AuthContext'

const SuperAdminRoutes = () => {
  const auth = useContext(AuthContext)
  if (auth.role === '1') {
    return (
      <div>
        <SuperAdminLayout>
          <Outlet />
        </SuperAdminLayout>
      </div>
    )
  } else {
    return <Navigate to="/auth/login" />
  }
}

export default SuperAdminRoutes
