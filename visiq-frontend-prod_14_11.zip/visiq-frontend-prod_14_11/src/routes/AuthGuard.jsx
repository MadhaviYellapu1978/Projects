import React, { useContext, useEffect } from 'react'
import { Navigate } from 'react-router-dom'
import { AuthContext } from '../context/AuthContext'
import LottieLoader from '../shared/LottieLoader'
import loading from '../assets/loading.json'

const AuthGuard = ({ children }) => {
  const auth = useContext(AuthContext)
  const [isLoading, setIsLoading] = React.useState(true)

  useEffect(() => {
    // Small delay to ensure auth context is properly initialized
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 100)

    return () => clearTimeout(timer)
  }, [])

  // Show loading while checking auth
  if (isLoading) {
    return <LottieLoader data={loading} />
  }

  // If user is authenticated, redirect to appropriate dashboard
  if (auth.org_id && auth.isOtpVerify) {
    console.log(
      'User authenticated, redirecting to dashboard based on role:',
      auth.role,
    )

    switch (auth.role) {
      case '1': // Super Admin
        return <Navigate to="/superAdmin/dashboard" replace />
      case '2': // Organization Admin
        return <Navigate to="/admin/dashboard" replace />
      case '3': // Branch Admin
        return <Navigate to="/branchAdmin/dashboard" replace />
      case '4': // Security Admin
        return <Navigate to="/securityLevelAdmin/dashboard" replace />
      default:
        console.log('Unknown role, redirecting to login')
        return <Navigate to="/auth/login" replace />
    }
  }

  // If not authenticated, show the children (login page)
  return children
}

export default AuthGuard
