import { lazy } from 'react'
import { createBrowserRouter } from 'react-router-dom'
import BranchAdminRoutes from './BranchAdminRoute'
import SecurityLevelAdmin from './SecurityLevelAdmin'
import AuthGuard from './AuthGuard'
// import SuperAdminRoutes from "./SuperAdminRoutes";
const SuperAdminRoutes = lazy(() => import('../routes/SuperAdminRoutes'))
const AdminRoutes = lazy(() => import('../routes/AdminRoutes'))
const Root = lazy(() => import('./Root'))
const Login = lazy(() => import('../pages/Auth/Login'))
const Forgot = lazy(() => import('../pages/Auth/Forgot'))
const Reset = lazy(() => import('../pages/Auth/ConfirmReset'))
const ChangePassword = lazy(() => import('../pages/Admin/ChangePassword'))

import Decrypt from '../pages/Decrypt'
const AllAdmins = lazy(() => import('../pages/Admin/AllAdmins/index'))
const Download = lazy(() => import('../pages/Admin/Download_file/index'))
const UploadPolices = lazy(() => import('../pages/Admin/Upload_polices/index'))
const UploadPolicesAndNda = lazy(
  () => import('../pages/Admin/TabbedUpload/index'),
)
const Error = lazy(() => import('../pages/Error'))
const Otp = lazy(() => import('../pages/Auth/Otp'))
const AuthLayout = lazy(() => import('../layout/AuthLayout'))
const SuperAdminDashboard = lazy(() => import('../pages/SuperAdmin/Dashboard'))
const AdminDashboard = lazy(() => import('../pages/Admin/Dashboard'))
const BranchAdmin = lazy(() => import('../pages/BranchAdmin/Dashboard'))
const BranchAdminGraphs = lazy(() => import('../pages/BranchAdmin/Graphs'))
const SecurityAdmin = lazy(() => import('../pages/SecurityAdmin/Dashboard'))
const DashboardLayout = lazy(() => import('../layout/DashboardLayout'))
const VisitorReportsAdmin = lazy(
  () => import('../pages/Admin/Visitor_Reports/index'),
)
const BlacklistManagementAdmin = lazy(
  () => import('../pages/Admin/BlacklistManagement/Container'),
)
const VehicleMovementAdmin = lazy(
  () => import('../pages/Admin/Building_blocks/Container'),
)
const VehicleMovementBranchAdmin = lazy(
  () => import('../pages/BranchAdmin/Dashboard/Building_blocks/Container'),
)
const GraphsAdmin = lazy(() => import('../pages/Admin/Graphs'))
const TestBookVisitPage = lazy(() => import('../pages/BookVisitPage'))
const VehicleMaterialGroupBookingAdmin = lazy(
  () => import('../pages/Admin/VehicleMaterialGroupBooking'),
)
const VehicleMaterialGroupBookingBranchAdmin = lazy(
  () => import('../pages/BranchAdmin/VehicleMaterialGroupBooking'),
)
const VehicleMaterialGroupBookingSecurityAdmin = lazy(
  () => import('../pages/SecurityAdmin/VehicleMaterialGroupBooking'),
)

export const router = createBrowserRouter([
  {
    path: '/',
    element: (
      <AuthGuard>
        <AuthLayout />
      </AuthGuard>
    ),
    errorElement: <Error />,
    children: [
      {
        path: '/',
        element: <Login />,
      },
      {
        path: '/auth/login',
        element: <Login />,
      },
      {
        path: '/auth/forgot',
        element: <Forgot />,
      },
      {
        path: '/auth/confirm-reset',
        element: <Reset />,
      },
      {
        path: '/auth/otp',
        element: <Otp />,
      },
    ],
  },
  { path: '/dashboard', element: <DashboardLayout /> },
  {
    path: '/admin',
    element: <AdminRoutes />,
    errorElement: <Error />,
    children: [
      {
        path: '/admin/dashboard',
        element: <AdminDashboard />,
      },
      {
        path: '/admin/dashboard-graphs',
        element: <GraphsAdmin />,
      },
      {
        path: '/admin/change-password',
        element: <ChangePassword />,
      },

      {
        path: '/admin/download',
        element: <Download />,
      },
      {
        path: '/admin/polices',
        element: <UploadPolices />,
      },
      {
        path: '/admin/UploadPolicesAndNda',
        element: <UploadPolicesAndNda />,
      },
      {
        path: '/admin/all-admins',
        element: <AllAdmins />,
      },

      {
        path: '/admin/visitorReports',
        element: <VisitorReportsAdmin />,
      },
      {
        path: '/admin/vehicle-movement',
        element: <VehicleMovementAdmin />,
      },
      {
        path: '/admin/blacklist-management',
        element: <BlacklistManagementAdmin />,
      },
      {
        path: '/admin/vehicle-material-group-booking',
        element: <VehicleMaterialGroupBookingAdmin />,
      },
    ],
  },
  {
    path: '/branchAdmin',
    element: <BranchAdminRoutes />,
    errorElement: <Error />,
    children: [
      {
        path: '/branchAdmin/dashboard',
        element: <BranchAdmin />,
      },
      {
        path: '/branchAdmin/dashboard-graphs',
        element: <BranchAdminGraphs />,
      },
      {
        path: '/branchAdmin/change-password',
        element: <ChangePassword />,
      },

      {
        path: '/branchAdmin/visitorReports',
        element: <VisitorReportsAdmin />,
      },
      {
        path: '/branchAdmin/vehicle-movement',
        element: <VehicleMovementBranchAdmin />,
      },
      {
        path: '/branchAdmin/UploadPolicesAndNda',
        element: <UploadPolicesAndNda />,
      },
      {
        path: '/branchAdmin/all-admins',
        element: <AllAdmins />,
      },
      {
        path: '/branchAdmin/vehicle-material-group-booking',
        element: <VehicleMaterialGroupBookingBranchAdmin />,
      },
    ],
  },
  {
    path: '/securityLevelAdmin',
    element: <SecurityLevelAdmin />,
    errorElement: <Error />,
    children: [
      {
        path: '/securityLevelAdmin/dashboard',
        element: <SecurityAdmin />,
      },
      {
        path: '/securityLevelAdmin/dashboard-graphs',
        element: <GraphsAdmin />,
      },
      {
        path: '/securityLevelAdmin/change-password',
        element: <ChangePassword />,
      },
      {
        path: '/securityLevelAdmin/UploadPolicesAndNda',
        element: <UploadPolicesAndNda />,
      },
      {
        path: '/securityLevelAdmin/all-admins',
        element: <AllAdmins />,
      },
      {
        path: '/securityLevelAdmin/visitorReports',
        element: <VisitorReportsAdmin />,
      },
      {
        path: '/securityLevelAdmin/vehicle-movement',
        element: <VehicleMovementAdmin />,
      },
      {
        path: '/securityLevelAdmin/vehicle-material-group-booking',
        element: <VehicleMaterialGroupBookingSecurityAdmin />,
      },
    ],
  },
  {
    path: '/superAdmin',
    element: <SuperAdminRoutes />,
    errorElement: <Error />,
    children: [
      {
        path: '/superAdmin/dashboard',
        element: <SuperAdminDashboard />,
      },
      {
        path: '/superAdmin/:orgId',
        element: <AdminDashboard />,
      },
    ],
  },
  {
    path: '/decrypt',
    element: <Decrypt />,
  },
  {
    path: '/test-book-visit',
    element: <TestBookVisitPage />,
  },
  {
    path: '*',
    element: <Root />,
  },
])
