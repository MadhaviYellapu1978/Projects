import React, { useContext } from 'react'
import { Navigate, Outlet } from 'react-router-dom'
import BranchAdminLayout from '../layout/BranchAdminLayout'
import { AuthContext } from '../context/AuthContext'

const BranchAdminRoutes = () => {
  const auth = useContext(AuthContext)

  if (auth.role === '3' && auth.isOtpVerify) {
    return (
      <div>
        <BranchAdminLayout>
          <Outlet />
        </BranchAdminLayout>
      </div>
    )
  } else {
    return <Navigate to="/auth/login" />
  }
}

export default BranchAdminRoutes
