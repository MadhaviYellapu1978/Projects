import React, { useContext } from 'react'
import { Navigate, Outlet } from 'react-router-dom'
import AdminLayout from '../layout/AdminLayout'
import { AuthContext } from '../context/AuthContext'

const AdminRoutes = () => {
  const auth = useContext(AuthContext)

  if (auth.role === '2' && auth.isOtpVerify) {
    return (
      <div>
        <AdminLayout>
          <Outlet />
        </AdminLayout>
      </div>
    )
  } else {
    return <Navigate to="/auth/login" />
  }
}

export default AdminRoutes
