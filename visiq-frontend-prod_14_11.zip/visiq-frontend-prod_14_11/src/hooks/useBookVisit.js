import { useState } from 'react'
import { bookVisit } from '../services/orgService'
import toast from 'react-hot-toast'

export const useBookVisit = () => {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const submitBooking = async (visitData) => {
    setLoading(true)
    setError(null)

    try {
      // Validate required fields
      const requiredFields = [
        'first_name',
        'last_name',
        'email',
        'date_of_visit',
        'branch_id',
        'org_id',
        'purpose_of_visit',
        'branch_name',
        'org_name',
        'time_of_visit',
        'visit_duration',
        'time_to_exit',
        'visitorOrgName',
        'phNo',
        'end_date_of_visit',
        'meetTo',
        'role',
        'reason',
      ]

      const missingFields = requiredFields.filter((field) => !visitData[field])
      if (missingFields.length > 0) {
        throw new Error(`Missing required fields: ${missingFields.join(', ')}`)
      }

      // Ensure boolean fields are properly set
      const formattedData = {
        ...visitData,
        vm_bool: Boolean(visitData.vm_bool),
        mm_bool: Boolean(visitData.mm_bool),
        grp_book_bool: Boolean(visitData.grp_book_bool),
        area_of_permit: visitData.area_of_permit || [{ area_name: '' }],
        vm_details: visitData.vm_details || [],
        mm_details: visitData.mm_details || [],
        grp_details: visitData.grp_details || [],
      }

      const response = await bookVisit(formattedData)

      if (response.statusCode === 200) {
        toast.success(response.message)
        return { success: true, data: response }
      } else {
        throw new Error(response.message || 'Failed to book visit')
      }
    } catch (err) {
      const errorMessage = err.message || 'Failed to book visit'
      setError(errorMessage)
      toast.error(errorMessage)
      return { success: false, error: errorMessage }
    } finally {
      setLoading(false)
    }
  }

  return {
    submitBooking,
    loading,
    error,
  }
}

// Helper function to create a basic visit data structure
export const createVisitData = (basicInfo) => {
  return {
    first_name: basicInfo.first_name || '',
    last_name: basicInfo.last_name || '',
    email: basicInfo.email || '',
    date_of_visit: basicInfo.date_of_visit || '',
    branch_id: basicInfo.branch_id || '',
    org_id: basicInfo.org_id || '',
    purpose_of_visit: basicInfo.purpose_of_visit || '',
    branch_name: basicInfo.branch_name || '',
    org_name: basicInfo.org_name || '',
    time_of_visit: basicInfo.time_of_visit || '',
    visit_duration: basicInfo.visit_duration || '',
    time_to_exit: basicInfo.time_to_exit || '',
    visitorOrgName: basicInfo.visitorOrgName || '',
    phNo: basicInfo.phNo || '',
    ph_ext: basicInfo.ph_ext || '',
    end_date_of_visit: basicInfo.end_date_of_visit || '',
    area_of_permit: basicInfo.area_of_permit || [{ area_name: '' }],
    meetTo: basicInfo.meetTo || '',
    role: basicInfo.role || '',
    reason: basicInfo.reason || '',
    vm_bool: Boolean(basicInfo.vm_bool),
    mm_bool: Boolean(basicInfo.mm_bool),
    vm_details: basicInfo.vm_details || [],
    mm_details: basicInfo.mm_details || [],
    grp_book_bool: Boolean(basicInfo.grp_book_bool),
    grp_details: basicInfo.grp_details || [],
  }
}
