import React, { createContext, useState } from 'react'
import { userData, setUserData } from '../utils/user_data'

// const defaultAuthState = {
//   org_id: '',
//   org_name: '',
//   theme: 'rainbow',
//   org_logo: '',
//   cog_id: '',
//   role: '',
//   organizationDetails: [],
//   setAuth: () => {},
//   isOtpVerify: false,
//   setOptVerify: () => {},
// }
export const AuthContext = createContext(userData)

export const AuthProvider = ({ children }) => {
  const [authState, setAuthState] = useState(userData)

  const setAuth = (authInfo) => {
    setAuthState((prevState) => ({
      ...prevState,
      ...authInfo,
    }))
    setUserData(authInfo)
  }
  const setOptVerify = (otpVerifyFlag) => {
    setAuthState((prevState) => ({
      ...prevState,
      isOtpVerify: otpVerifyFlag,
    }))
    setUserData({ ...authState, isOtpVerify: otpVerifyFlag })
  }

  const logout = () => {
    // Preserve only blacklist states for each branch (vehicle movement should come from backend)
    const blacklistKeys = []

    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i)
      if (key && key.startsWith('blacklist_')) {
        blacklistKeys.push(key)
      }
    }

    // Store the blacklist states temporarily
    const blacklistStates = {}

    blacklistKeys.forEach((key) => {
      blacklistStates[key] = localStorage.getItem(key)
    })

    // Debug: Log preserved states
    console.log('Preserving blacklist states during logout:', blacklistStates)
    console.log('Number of blacklist keys preserved:', blacklistKeys.length)

    // Clear all localStorage data
    localStorage.clear()

    // Restore blacklist states
    Object.entries(blacklistStates).forEach(([key, value]) => {
      localStorage.setItem(key, value)
    })

    // Debug: Log restored states
    console.log('Restored blacklist states after logout:', blacklistStates)

    // Reset auth state
    const resetState = {
      org_id: '',
      org_name: '',
      theme: 'rainbow',
      org_logo: '',
      cog_id: '',
      role: '',
      organizationDetails: [],
      isOtpVerify: false,
    }

    setAuthState(resetState)

    // Redirect to login page
    window.location.href = '/auth/login'
  }

  return (
    <AuthContext.Provider
      value={{ ...authState, setAuth, setOptVerify, logout }}
    >
      {children}
    </AuthContext.Provider>
  )
}
