// Centralized date formatting function
// Formats dates to DD-MM-YYYY format regardless of input format
// IMPORTANT: This function assumes dates from API are in MM-DD-YYYY format
// If a date is already in DD-MM-YYYY format, it should not be passed through this function again
export const formatDate = (date) => {
  if (!date || (typeof date === 'string' && !date.trim())) {
    return ''
  }

  try {
    const dateStr = String(date).trim()

    // Handle YYYY-MM-DD format (ISO format) - most reliable, parse explicitly
    if (/^\d{4}-\d{2}-\d{2}/.test(dateStr)) {
      const match = dateStr.match(/^(\d{4})-(\d{2})-(\d{2})/)
      if (match) {
        const [, year, month, day] = match
        return `${day}-${month}-${year}`
      }
    }

    // Handle MM/DD/YYYY or DD/MM/YYYY format (with slashes)
    if (/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(dateStr)) {
      const parts = dateStr.split('/')
      const firstPart = parseInt(parts[0], 10)
      const secondPart = parseInt(parts[1], 10)

      // If first part > 12, it's definitely DD/MM/YYYY
      if (firstPart > 12) {
        const day = parts[0].padStart(2, '0')
        const month = parts[1].padStart(2, '0')
        const year = parts[2]
        return `${day}-${month}-${year}`
      }
      // If second part > 12, it's definitely MM/DD/YYYY
      if (secondPart > 12) {
        const month = parts[0].padStart(2, '0')
        const day = parts[1].padStart(2, '0')
        const year = parts[2]
        return `${day}-${month}-${year}`
      }
      // Ambiguous case (both <= 12) - assume MM/DD/YYYY and convert to DD-MM-YYYY
      const month = parts[0].padStart(2, '0')
      const day = parts[1].padStart(2, '0')
      const year = parts[2]
      return `${day}-${month}-${year}`
    }

    // Handle MM-DD-YYYY or DD-MM-YYYY format (with hyphens)
    // IMPORTANT: For ambiguous dates, we assume MM-DD-YYYY (US format) from API and convert to DD-MM-YYYY
    // This MUST be checked BEFORE using Date constructor to avoid misinterpretation
    if (/^\d{1,2}-\d{1,2}-\d{4}$/.test(dateStr)) {
      const parts = dateStr.split('-')
      const firstPart = parseInt(parts[0], 10)
      const secondPart = parseInt(parts[1], 10)

      // If first part > 12, it's definitely DD-MM-YYYY (day can't be > 12)
      // Return as-is but ensure proper padding
      if (firstPart > 12) {
        const day = parts[0].padStart(2, '0')
        const month = parts[1].padStart(2, '0')
        const year = parts[2]
        return `${day}-${month}-${year}`
      }
      // If second part > 12, it's definitely MM-DD-YYYY (month can't be > 12), convert to DD-MM-YYYY
      if (secondPart > 12) {
        const month = parts[0].padStart(2, '0')
        const day = parts[1].padStart(2, '0')
        const year = parts[2]
        return `${day}-${month}-${year}`
      }
      // Ambiguous case (both <= 12)
      // Check if it's already in DD-MM-YYYY format: if firstPart <= secondPart, it's likely DD-MM-YYYY
      // (e.g., "04-11-2025" = 4th of November, which is already DD-MM-YYYY)
      // Otherwise, assume MM-DD-YYYY from API and convert to DD-MM-YYYY
      if (firstPart <= secondPart) {
        // Likely already in DD-MM-YYYY format (day <= month), return as-is with proper padding
        const day = parts[0].padStart(2, '0')
        const month = parts[1].padStart(2, '0')
        const year = parts[2]
        return `${day}-${month}-${year}`
      }
      // firstPart > secondPart: Assume MM-DD-YYYY from API and convert to DD-MM-YYYY
      // (e.g., "11-04-2025" = November 4, convert to "04-11-2025")
      const month = parts[0].padStart(2, '0')
      const day = parts[1].padStart(2, '0')
      const year = parts[2]
      return `${day}-${month}-${year}`
    }

    // Try to parse as ISO date string or timestamp
    // Only use Date constructor for unambiguous formats
    if (/^\d{4}[-/]\d{2}[-/]\d{2}/.test(dateStr) || /^\d+$/.test(dateStr)) {
      const d = new Date(dateStr)
      if (!isNaN(d.getTime())) {
        const day = String(d.getDate()).padStart(2, '0')
        const month = String(d.getMonth() + 1).padStart(2, '0')
        const year = d.getFullYear()
        return `${day}-${month}-${year}`
      }
    }

    // For other formats (like date strings with time, timestamps, etc.), try Date constructor
    // But be cautious - JavaScript Date constructor may misinterpret ambiguous dates
    // Only use this for formats that are unambiguous or have already been handled above
    // Skip Date constructor for ambiguous MM-DD-YYYY formats to avoid misinterpretation
    if (!/^\d{1,2}-\d{1,2}-\d{4}/.test(dateStr)) {
      const d = new Date(dateStr)
      if (!isNaN(d.getTime())) {
        // Check if the parsed date makes sense (not too far in past/future)
        const year = d.getFullYear()
        if (year >= 1900 && year <= 2100) {
          // Extract date components - Date object always gives us correct day/month/year
          const day = String(d.getDate()).padStart(2, '0')
          const month = String(d.getMonth() + 1).padStart(2, '0')
          return `${day}-${month}-${year}`
        }
      }
    }

    // If all else fails, return the original string trimmed
    return dateStr
  } catch (error) {
    // If error occurs, try basic Date parsing as fallback
    // But avoid Date constructor for ambiguous MM-DD-YYYY formats
    try {
      const dateStr = String(date).trim()
      // If it's an ambiguous MM-DD-YYYY format, handle it explicitly
      if (/^\d{1,2}-\d{1,2}-\d{4}$/.test(dateStr)) {
        const parts = dateStr.split('-')
        const firstPart = parseInt(parts[0], 10)
        const secondPart = parseInt(parts[1], 10)

        // If both <= 12, assume MM-DD-YYYY and convert to DD-MM-YYYY
        if (firstPart <= 12 && secondPart <= 12) {
          const month = parts[0].padStart(2, '0')
          const day = parts[1].padStart(2, '0')
          const year = parts[2]
          return `${day}-${month}-${year}`
        }
        // If first > 12, it's DD-MM-YYYY, return as-is
        if (firstPart > 12) {
          return dateStr
        }
        // If second > 12, it's MM-DD-YYYY, convert to DD-MM-YYYY
        if (secondPart > 12) {
          const month = parts[0].padStart(2, '0')
          const day = parts[1].padStart(2, '0')
          const year = parts[2]
          return `${day}-${month}-${year}`
        }
      }

      // For other formats, try Date constructor
      const d = new Date(date)
      if (!isNaN(d.getTime())) {
        const year = d.getFullYear()
        if (year >= 1900 && year <= 2100) {
          const day = String(d.getDate()).padStart(2, '0')
          const month = String(d.getMonth() + 1).padStart(2, '0')
          return `${day}-${month}-${year}`
        }
      }
    } catch (e) {
      // Ignore error
    }
    return String(date).trim()
  }
}

// Centralized datetime formatting function
// Formats datetime to DD-MM-YYYY HH:mm:ss format regardless of input format
export const formatDateTime = (datetime) => {
  if (!datetime || (typeof datetime === 'string' && !datetime.trim())) {
    return ''
  }

  try {
    const dateStr = String(datetime).trim()
    const d = new Date(dateStr)

    if (isNaN(d.getTime())) {
      // If Date parsing fails, try to extract date and time separately
      // Handle formats like "DD-MM-YYYY HH:mm:ss" or "YYYY-MM-DD HH:mm:ss"
      const dateTimeMatch = dateStr.match(
        /(\d{1,2}[-/]\d{1,2}[-/]\d{4}|\d{4}[-/]\d{1,2}[-/]\d{1,2})\s+(\d{1,2}:\d{1,2}(?::\d{1,2})?)/,
      )
      if (dateTimeMatch) {
        const datePart = formatDate(dateTimeMatch[1])
        const timePart = dateTimeMatch[2]
        return `${datePart} ${timePart}`
      }
      return dateStr
    }

    // Format date part to DD-MM-YYYY
    const day = String(d.getDate()).padStart(2, '0')
    const month = String(d.getMonth() + 1).padStart(2, '0')
    const year = d.getFullYear()
    const datePart = `${day}-${month}-${year}`

    // Format time part to HH:mm:ss
    const hours = String(d.getHours()).padStart(2, '0')
    const minutes = String(d.getMinutes()).padStart(2, '0')
    const seconds = String(d.getSeconds()).padStart(2, '0')
    const timePart = `${hours}:${minutes}:${seconds}`

    return `${datePart} ${timePart}`
  } catch (error) {
    // If error occurs, try basic Date parsing as fallback
    try {
      const d = new Date(datetime)
      if (!isNaN(d.getTime())) {
        const day = String(d.getDate()).padStart(2, '0')
        const month = String(d.getMonth() + 1).padStart(2, '0')
        const year = d.getFullYear()
        const hours = String(d.getHours()).padStart(2, '0')
        const minutes = String(d.getMinutes()).padStart(2, '0')
        const seconds = String(d.getSeconds()).padStart(2, '0')
        return `${day}-${month}-${year} ${hours}:${minutes}:${seconds}`
      }
    } catch (e) {
      // Ignore error
    }
    return String(datetime).trim()
  }
}

// Extract time part (HH:mm:ss) from datetime string
export const formatTime = (datetime) => {
  if (!datetime || (typeof datetime === 'string' && !datetime.trim())) {
    return ''
  }

  try {
    const dateStr = String(datetime).trim()

    // Try to extract time from formats like "DD-MM-YYYY HH:mm:ss" or "YYYY-MM-DD HH:mm:ss"
    const timeMatch = dateStr.match(/(\d{1,2}:\d{1,2}(?::\d{1,2})?)/)
    if (timeMatch) {
      const timePart = timeMatch[1]
      // Ensure it's in HH:mm:ss format
      const parts = timePart.split(':')
      if (parts.length === 2) {
        return `${parts[0].padStart(2, '0')}:${parts[1].padStart(2, '0')}:00`
      }
      return timePart
    }

    // Try Date constructor to extract time
    const d = new Date(dateStr)
    if (!isNaN(d.getTime())) {
      const hours = String(d.getHours()).padStart(2, '0')
      const minutes = String(d.getMinutes()).padStart(2, '0')
      const seconds = String(d.getSeconds()).padStart(2, '0')
      return `${hours}:${minutes}:${seconds}`
    }

    return ''
  } catch (error) {
    return ''
  }
}
