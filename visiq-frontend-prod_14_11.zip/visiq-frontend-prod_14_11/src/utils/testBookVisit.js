import { bookVisit } from '../services/orgService'

// Test function to verify the book visit API matches the exact specification
export const testBookVisitAPI = async (customData = null) => {
  // Default test data that matches the API specification exactly
  const defaultTestData = {
    first_name: 'John',
    last_name: 'Doe',
    email: 'john.doe@example.com',
    date_of_visit: '2025-08-20',
    branch_id: 'branch123',
    org_id: 'org123',
    purpose_of_visit: 'Business Meeting',
    branch_name: 'Main Branch',
    org_name: 'Test Organization',
    time_of_visit: '10:00',
    visit_duration: '2 hours',
    time_to_exit: '12:00',
    visitorOrgName: 'Visitor Company',
    phNo: '1234567890',
    ph_ext: '123',
    end_date_of_visit: '2025-08-20',
    area_of_permit: [
      { area_name: 'Reception' },
      { area_name: 'Conference Room' },
    ],
    meetTo: 'Jane Smith',
    role: 'Manager',
    reason: 'Project Discussion',
    vm_bool: true,
    mm_bool: false,
    vm_details: [
      {
        vehicle_id: 'v001',
        vehicle_name: 'Toyota Camry',
        vehicle_type: 'Sedan',
        driver_id: 'd001',
        driver_licence: 'DL123456789',
        insurance_provider: 'ABC Insurance',
        insurance_no: 'INS123456',
        rc_no: 'RC123456',
        vehicle_comments: 'Blue color vehicle',
      },
    ],
    mm_details: [],
    grp_book_bool: false,
    grp_details: [],
  }

  const testData = customData || defaultTestData

  try {
    console.log('🚀 Testing book visit API...')
    console.log('📤 Request URL: https://api-dev.myvisiq.com/api/org/bookVisit')
    console.log('📤 Request Data:', JSON.stringify(testData, null, 2))

    const response = await bookVisit(testData)

    console.log('✅ API Response:', response)

    // Validate expected response structure
    if (response.statusCode === 200 && response.message) {
      console.log('🎉 SUCCESS: Visit booked successfully!')
      console.log('📥 Response:', {
        statusCode: response.statusCode,
        message: response.message,
      })
      return { success: true, response }
    } else {
      console.log('⚠️ Unexpected response format:', response)
      return { success: false, response }
    }
  } catch (error) {
    console.error('❌ API Test Error:', error.message)
    console.error('📋 Full Error:', error)
    return { success: false, error: error.message }
  }
}

// Test with minimal required data
export const testMinimalBookVisit = async () => {
  const minimalData = {
    first_name: 'Test',
    last_name: 'User',
    email: 'test@example.com',
    date_of_visit: '2025-08-20',
    branch_id: 'test-branch',
    org_id: 'test-org',
    purpose_of_visit: 'Testing',
    branch_name: 'Test Branch',
    org_name: 'Test Organization',
    time_of_visit: '10:00',
    visit_duration: '1 hour',
    time_to_exit: '11:00',
    visitorOrgName: 'Test Visitor Org',
    phNo: '1234567890',
    ph_ext: '',
    end_date_of_visit: '2025-08-20',
    area_of_permit: [{ area_name: 'Reception' }],
    meetTo: 'Test Person',
    role: 'Visitor',
    reason: 'API Testing',
    vm_bool: false,
    mm_bool: false,
    vm_details: [],
    mm_details: [],
    grp_book_bool: false,
    grp_details: [],
  }

  return await testBookVisitAPI(minimalData)
}

// Test with group booking
export const testGroupBookVisit = async () => {
  const groupData = {
    first_name: 'Group',
    last_name: 'Leader',
    email: 'group@example.com',
    date_of_visit: '2025-08-20',
    branch_id: 'test-branch',
    org_id: 'test-org',
    purpose_of_visit: 'Group Meeting',
    branch_name: 'Test Branch',
    org_name: 'Test Organization',
    time_of_visit: '14:00',
    visit_duration: '3 hours',
    time_to_exit: '17:00',
    visitorOrgName: 'Group Organization',
    phNo: '1234567890',
    ph_ext: '',
    end_date_of_visit: '2025-08-20',
    area_of_permit: [{ area_name: 'Conference Room' }],
    meetTo: 'Meeting Host',
    role: 'Group Leader',
    reason: 'Team Meeting',
    vm_bool: false,
    mm_bool: false,
    vm_details: [],
    mm_details: [],
    grp_book_bool: true,
    grp_details: [
      {
        grp_id: 'grp001',
        grp_name: 'Development Team',
        grp_user_email: 'member1@example.com',
        grp_user_id_proof: 'ID123',
        grp_user_name: 'Team Member 1',
        grp_user_phno: '9876543210',
        grp_user_role: 'Developer',
        grp_user_role_name: 'Senior Developer',
        grp_user_unique_id: 'DEV001',
      },
    ],
  }

  return await testBookVisitAPI(groupData)
}

// Validate API response structure
export const validateAPIResponse = (response) => {
  const expectedFields = ['statusCode', 'message']
  const missingFields = expectedFields.filter((field) => !(field in response))

  if (missingFields.length > 0) {
    console.warn('⚠️ Missing expected fields in response:', missingFields)
    return false
  }

  if (response.statusCode !== 200) {
    console.warn('⚠️ Unexpected status code:', response.statusCode)
    return false
  }

  console.log('✅ Response structure is valid')
  return true
}

// Quick test functions you can call from browser console
if (typeof window !== 'undefined') {
  window.testBookVisit = testBookVisitAPI
  window.testMinimalBookVisit = testMinimalBookVisit
  window.testGroupBookVisit = testGroupBookVisit
  window.validateAPIResponse = validateAPIResponse
}
