export const userData = JSON.parse(
  localStorage.getItem('userData') || 'null',
) || {
  org_id: '',
  org_name: '',
  theme: 'rainbow',
  org_logo: '',
  cog_id: '',
  role: '',
  organizationDetails: [],
  isOtpVerify: false,
}

export const setUserData = (data) =>
  localStorage.setItem('userData', JSON.stringify(data))
