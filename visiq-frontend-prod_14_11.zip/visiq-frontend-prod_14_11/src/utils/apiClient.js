import { baseUrl } from '../constants/baseUrl.js'

// CORS configuration optimized for cross-origin requests
const corsConfig = {
  mode: 'cors',
  credentials: 'omit', // Use 'omit' for dev server compatibility
  headers: {
    'Content-Type': 'application/json',
    Accept: 'application/json',
    'Cache-Control': 'no-cache',
    Pragma: 'no-cache',
    // Additional headers for better compatibility
    'X-Requested-With': 'XMLHttpRequest',
    // REMOVED: Response headers (Access-Control-*) - these should NEVER be sent as request headers
  },
}

// Function to get authentication headers
const getAuthHeaders = () => {
  const token = localStorage.getItem('token')
  return token ? { Authorization: `Bearer ${token}` } : {}
}

// Enhanced error handling - always preserve backend response
const handleResponse = async (response) => {
  if (!response.ok) {
    let errorData
    try {
      errorData = await response.json()
    } catch (e) {
      // If we can't parse JSON, create minimal error data
      errorData = {
        statusCode: response.status,
        message: `HTTP error! status: ${response.status}`,
      }
    }

    // Enhanced error messages for specific status codes
    let errorMessage =
      errorData.message || `HTTP error! status: ${response.status}`

    if (response.status === 500) {
      errorMessage =
        'Server error: The server encountered an internal error. Please try again later.'
    } else if (response.status === 502) {
      errorMessage =
        'Bad Gateway: The server is temporarily unavailable. Please try again later.'
    } else if (response.status === 503) {
      errorMessage =
        'Service Unavailable: The server is temporarily unavailable. Please try again later.'
    } else if (response.status === 504) {
      errorMessage =
        'Gateway Timeout: The server is taking too long to respond. Please try again.'
    } else if (response.status === 0) {
      errorMessage =
        'Network error: Unable to connect to the server. This might be a CORS issue.'
    }

    // Always create error with backend data - no frontend message overrides
    const error = new Error(errorMessage)
    error.response = {
      status: response.status,
      data: errorData,
    }
    throw error
  }

  return await response.json()
}

export const apiClient = {
  async get(endpoint, options = {}) {
    let url = `${baseUrl}${endpoint}`

    // Handle query parameters
    if (options.params) {
      console.log('🔧 apiClient.get - Processing params:', options.params)
      const searchParams = new URLSearchParams()
      Object.keys(options.params).forEach((key) => {
        if (
          options.params[key] !== undefined &&
          options.params[key] !== null &&
          options.params[key] !== ''
        ) {
          searchParams.append(key, options.params[key])
          console.log(`  ✅ Added param: ${key} = ${options.params[key]}`)
        } else {
          console.log(
            `  ⏭️ Skipped param: ${key} = ${options.params[key]} (empty/null/undefined)`,
          )
        }
      })
      const queryString = searchParams.toString()
      if (queryString) {
        url += `?${queryString}`
        console.log('🔗 Final URL with query params:', url)
      } else {
        console.log('⚠️ No query parameters to add')
      }
    } else {
      console.log('⚠️ No params provided to apiClient.get')
    }

    const mergedHeaders = {
      ...corsConfig.headers,
      ...getAuthHeaders(),
      ...options.headers,
    }

    const response = await fetch(url, {
      method: 'GET',
      mode: corsConfig.mode,
      credentials: corsConfig.credentials,
      headers: mergedHeaders,
      ...options,
    })

    return await handleResponse(response)
  },

  async post(endpoint, data, options = {}) {
    const url = `${baseUrl}${endpoint}`

    // Handle FormData vs regular data
    let body
    let mergedHeaders = {
      ...corsConfig.headers,
      ...getAuthHeaders(),
      ...options.headers,
    }

    if (data instanceof FormData) {
      body = data
      // Remove Content-Type for FormData - let browser set it with boundary
      delete mergedHeaders['Content-Type']
    } else {
      body = JSON.stringify(data)
      mergedHeaders['Content-Type'] = 'application/json'
    }

    const response = await fetch(url, {
      method: 'POST',
      mode: corsConfig.mode,
      credentials: corsConfig.credentials,
      headers: mergedHeaders,
      body,
      ...options,
    })

    return await handleResponse(response)
  },

  async put(endpoint, data, options = {}) {
    const url = `${baseUrl}${endpoint}`

    // Handle FormData vs regular data
    let body
    let mergedHeaders = {
      ...corsConfig.headers,
      ...getAuthHeaders(),
      ...options.headers,
    }

    if (data instanceof FormData) {
      body = data
      // Remove Content-Type for FormData - let browser set it with boundary
      delete mergedHeaders['Content-Type']
    } else {
      body = JSON.stringify(data)
      mergedHeaders['Content-Type'] = 'application/json'
    }

    const response = await fetch(url, {
      method: 'PUT',
      mode: corsConfig.mode,
      credentials: corsConfig.credentials,
      headers: mergedHeaders,
      body,
      ...options,
    })

    return await handleResponse(response)
  },

  async delete(endpoint, options = {}) {
    const url = `${baseUrl}${endpoint}`

    const mergedHeaders = {
      ...corsConfig.headers,
      ...getAuthHeaders(),
      ...options.headers,
    }

    const response = await fetch(url, {
      method: 'DELETE',
      mode: corsConfig.mode,
      credentials: corsConfig.credentials,
      headers: mergedHeaders,
      ...options,
    })

    return await handleResponse(response)
  },
}

// Specific function for the getAllVisitorsReferrer endpoint
export const getAllVisitorsReferrer = async () => {
  return await apiClient.get('/org/getAllVisitorsReferrer')
}
