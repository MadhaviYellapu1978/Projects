import axios from 'axios'
import { baseUrl } from '../constants/baseUrl.js'
import { encrypt, decrypt as decryptFromCrypto } from './crypto.js'
// CORS configuration optimized for api-dev.myvisiq.com
const corsConfig = {
  withCredentials: false,
  headers: {
    'Content-Type': 'application/json',
    Accept: 'application/json',
  },
  timeout: 90000, // 90 seconds default timeout
}

// Create a custom axios instance with better timeout handling
const apiClient = axios.create({
  timeout: 90000, // 90 seconds default timeout
  ...corsConfig,
})

// Add request interceptor for logging and authentication
apiClient.interceptors.request.use(
  (config) => {
    console.log(`API Request: ${config.method?.toUpperCase()} ${config.url}`)
    // Add Authorization header if token exists
    const token = localStorage.getItem('token')
    if (token) {
      config.headers = config.headers || {}
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    console.error('Request interceptor error:', error)
    return Promise.reject(error)
  },
)

// Add response interceptor for better error handling
apiClient.interceptors.response.use(
  (response) => {
    console.log(`API Response: ${response.status} ${response.config.url}`)
    return response
  },
  (error) => {
    console.error('API Error:', {
      url: error.config?.url,
      method: error.config?.method,
      status: error.response?.status,
      message: error.message,
      code: error.code,
    })
    return Promise.reject(error)
  },
)

// function deriveKey(secret) {
//   return forge.md.sha256.create().update(secret).digest().getBytes(16) // 128-bit key
// }

// export const decrypt = (encryptedData, secret) => {
//   const { ivBase64, encryptedBase64 } = encryptedData

//   const key = deriveKey(secret)
//   const iv = forge.util.decode64(ivBase64)
//   const encrypted = forge.util.decode64(encryptedBase64)

//   const decipher = forge.cipher.createDecipher('AES-CBC', key)
//   decipher.start({ iv: iv })
//   decipher.update(forge.util.createBuffer(encrypted, 'binary'))
//   const result = decipher.finish()

//   if (result) {
//     const decryptedData = JSON.parse(decipher.output.toString('utf8'))
//     return decryptedData
//   } else {
//     throw new Error('Decryption failed')
//   }
// }

export const apiCall = async (url, method, payload = null, timeout = 90000) => {
  try {
    // If the URL doesn't start with http, prepend the base URL
    const fullUrl = url.startsWith('http') ? url : `${baseUrl}${url}`

    // Normalize method to lowercase for axios compatibility
    const normalizedMethod = method?.toLowerCase() || 'get'

    const config = {
      method: normalizedMethod, // Supports GET, POST, PUT, PATCH, DELETE, etc.
      url: fullUrl,
      timeout: timeout, // 90 seconds default timeout
    }

    // Encrypt payload for POST, PUT, PATCH methods (any method with a body)
    if (payload) {
      console.log('=== API CALL DEBUG ===')
      console.log(`Method: ${normalizedMethod}`)
      console.log('Original data:', payload)

      // Encrypt the payload using crypto (same for POST, PUT, PATCH, etc.)
      const data = encrypt(payload)
      console.log('Encrypted data:', data)

      // Send encrypted data in the request body
      config.data = { data: data }
      console.log('Final request data:', config.data)
      console.log('=== END API CALL DEBUG ===')
    }

    const response = await apiClient(config)

    if (response.status >= 400) {
      return { data: response.data, status: response.status }
    }
    const encryptedResponseData = response.data
    if (!encryptedResponseData) {
      throw new Error('Missing encrypted data in the response')
    }

    // The response might have 'data' or 'encryptedData' field containing the base64 encrypted string
    const encryptedString =
      encryptedResponseData.data || encryptedResponseData.encryptedData
    if (!encryptedString) {
      throw new Error('Missing encrypted data string in the response')
    }

    try {
      const decryptedData = decryptFromCrypto(encryptedString)
      return decryptedData
    } catch (decryptErr) {
      console.error('Decryption error:', decryptErr)
      console.error(
        'Encrypted string received:',
        encryptedString?.substring(0, 100),
      )
      throw new Error(
        'Failed to decrypt server response. Please try again or contact support.',
      )
    }
  } catch (err) {
    console.error('API Call Error:', {
      url: err.config?.url,
      method: err.config?.method,
      status: err.response?.status,
      message: err.message,
      code: err.code,
    })

    // Handle timeout specifically
    if (err.code === 'ECONNABORTED' || err.message.includes('timeout')) {
      throw new Error('Request timed out. Please try again.')
    }

    // Handle specific HTTP status codes
    if (err.response?.status === 500) {
      throw new Error(
        'Server error: The server encountered an internal error. Please try again later.',
      )
    } else if (err.response?.status === 502) {
      throw new Error(
        'Bad Gateway: The server is temporarily unavailable. Please try again later.',
      )
    } else if (err.response?.status === 503) {
      throw new Error(
        'Service Unavailable: The server is temporarily unavailable. Please try again later.',
      )
    } else if (err.response?.status === 504) {
      throw new Error(
        'Server is temporarily unavailable. Please try again in a few moments.',
      )
    } else if (err.response?.status === 0 || err.code === 'ERR_NETWORK') {
      throw new Error(
        'Network error: Unable to connect to the server. This might be a CORS issue.',
      )
    }

    // Handle CORS errors
    if (
      err.message.includes('CORS') ||
      err.message.includes('cors') ||
      err.message.includes('Cross-Origin')
    ) {
      throw new Error(
        'CORS error: Unable to connect to the server. Please check your network connection.',
      )
    }

    throw new Error(
      err.response?.data?.message || err.message || 'Something went wrong',
    )
  }
}

// API call for file upload
export const apiCallupload = async (url, method, data = null) => {
  try {
    // If the URL doesn't start with http, prepend the base URL
    const fullUrl = url.startsWith('http') ? url : `${baseUrl}${url}`

    const config = {
      method,
      url: fullUrl,
      headers: { 'Content-Type': 'multipart/form-data' },
    }

    if (data) {
      const encryptedData = encrypt(data)

      config.data = new FormData()
      config.data.append('encryptedData', encryptedData)
      // Append files or additional data if necessary
      // Example: config.data.append('file', file);
    }

    const response = await axios(config)

    if (response.status >= 400) {
      return { data: response.data, status: response.status }
    }

    const { encryptedData: encryptedResponseData } = response.data

    // Check if response has encrypted data
    if (!encryptedResponseData) {
      throw new Error('Missing encrypted data in the response')
    }

    const decryptedData = decryptFromCrypto(encryptedResponseData)
    return decryptedData // Return decrypted data directly
  } catch (err) {
    throw new Error(
      err.response?.data?.message || err.message || 'Something went wrong',
    )
  }
}
