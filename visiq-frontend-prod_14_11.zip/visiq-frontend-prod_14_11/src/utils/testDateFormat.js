// Test function to verify date formatting is working
export const testDateFormat = () => {
  const formatDateForAPI = (date) => {
    if (date) return date
    const today = new Date()
    const day = String(today.getDate()).padStart(2, '0')
    const month = String(today.getMonth() + 1).padStart(2, '0')
    const year = today.getFullYear()
    return `${day}-${month}-${year}`
  }

  console.log('Testing date formatting...')

  // Test with no date (should use today's date)
  const todayFormatted = formatDateForAPI()
  console.log('Today formatted:', todayFormatted)

  // Test with a specific date
  const specificDate = formatDateForAPI('19-08-2025')
  console.log('Specific date formatted:', specificDate)

  // Test the expected API payload structure
  const testPayload = {
    org_id: 'dd1e5df0-f413-4cbd-a56c-d96dca7976da',
    branch_id: '5b5444a0-8f2d-4f0c-8c1f-6109ebfb9da0',
    role: '',
    data_of_visit: formatDateForAPI('19-08-2025'),
  }

  console.log('Test payload with correct date format:', testPayload)

  return testPayload
}

// Export for use in browser console for testing
if (typeof window !== 'undefined') {
  window.testDateFormat = testDateFormat
}
