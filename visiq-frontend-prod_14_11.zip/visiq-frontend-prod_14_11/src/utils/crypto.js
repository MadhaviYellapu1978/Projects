import forge from 'node-forge'

// New CryptoHelper class based on the provided CommonJS example.
// Exported as ESM but keeps named `encrypt`/`decrypt` functions for compatibility.
// Uses node-forge for browser compatibility instead of Node.js crypto

class CryptoHelper {
  constructor() {
    // 32-byte key (UTF-8 string of length 32)
    const keyString = '0123456789abcdef0123456789abcdef'
    // 16-byte IV
    const ivString = 'abcdef9876543210'

    // Convert strings to byte arrays for forge
    this.keyBytes = forge.util.createBuffer(keyString, 'utf8').getBytes()
    this.ivBytes = forge.util.createBuffer(ivString, 'utf8').getBytes()

    if (this.keyBytes.length !== 32) {
      throw new Error(
        `Crypto key must be 32 bytes; got ${this.keyBytes.length}`,
      )
    }
    if (this.ivBytes.length !== 16) {
      throw new Error(`Crypto IV must be 16 bytes; got ${this.ivBytes.length}`)
    }
  }

  encrypt(jsonObj) {
    const jsonStr = JSON.stringify(jsonObj)
    const cipher = forge.cipher.createCipher('AES-CBC', this.keyBytes)
    cipher.start({ iv: this.ivBytes })
    cipher.update(forge.util.createBuffer(jsonStr, 'utf8'))
    cipher.finish()

    const encrypted = cipher.output
    const encryptedBase64 = forge.util.encode64(encrypted.getBytes())
    console.log('encryptedBuf', encryptedBase64)
    return encryptedBase64
  }

  decrypt(encryptedText) {
    const encryptedBytes = forge.util.decode64(encryptedText)
    const decipher = forge.cipher.createDecipher('AES-CBC', this.keyBytes)
    decipher.start({ iv: this.ivBytes })
    decipher.update(forge.util.createBuffer(encryptedBytes))
    const result = decipher.finish()

    if (result) {
      const jsonStr = decipher.output.toString('utf8')
      return JSON.parse(jsonStr)
    } else {
      throw new Error('Decryption failed')
    }
  }
}

const helper = new CryptoHelper()

export function encrypt(obj) {
  return helper.encrypt(obj)
}

export function decrypt(text) {
  return helper.decrypt(text)
}

export default helper
