import React, { useMemo, useState, useEffect, useRef, useContext } from 'react'
import { AgGridReact } from 'ag-grid-react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {
  faDownload,
  faToggleOn,
  faToggleOff,
} from '@fortawesome/free-solid-svg-icons'
import toast from 'react-hot-toast'
import { AuthContext } from '../context/AuthContext'
import { format } from 'date-fns'
import jsPDF from 'jspdf'
import 'jspdf-autotable'
import Papa from 'papaparse'
import { saveAs } from 'file-saver'
import { formatDate } from '../utils/dateFormat'

// Helper function to extract numeric code from visitor_code
// Main visitor: "GM-0022563" -> "0022563"
// Group visitor: "G-0022563" -> "0022563"
const extractVisitorCodeNumber = (visitorCode) => {
  if (!visitorCode || typeof visitorCode !== 'string') return null
  // Extract the numeric part after the last hyphen
  const parts = visitorCode.split('-')
  if (parts.length >= 2) {
    return parts[parts.length - 1] // Return the last part (numeric code)
  }
  return null
}

// Helper function to check if visitor codes match (by numeric part)
const doVisitorCodesMatch = (mainVisitorCode, groupVisitorCode) => {
  const mainCode = extractVisitorCodeNumber(mainVisitorCode)
  const groupCode = extractVisitorCodeNumber(groupVisitorCode)
  return mainCode !== null && groupCode !== null && mainCode === groupCode
}

const VisitorsTable = ({
  data,
  selectedBranch,
  start_date,
  to_date,
  name,
  report_name,
}) => {
  const auth = useContext(AuthContext)
  const [rowData, setRowData] = useState([])
  const [expandedVisitors, setExpandedVisitors] = useState({})
  const [loading] = useState(false)
  const [isPDF, setIsPDF] = useState(true) // Toggle state for PDF/CSV
  const gridApiRef = useRef(null)

  // Function to map visitor_type to display names
  const getVisitorTypeDisplay = (visitorType) => {
    switch (visitorType) {
      case 'group_visitor':
        return 'Group Visitor'
      case 'main_visitor':
        return 'Main Visitor'
      case 'individual_visitor':
        return 'Individual Visitor'
      case 'group_member':
        return 'Group Member'
      default:
        return visitorType || 'Individual Visitor'
    }
  }

  // Toggle function to match home page style
  const handleToggle = () => {
    setIsPDF(!isPDF)
  }
  useEffect(() => {
    if (data && data.length > 0) {
      // Data is already filtered noShowVisitors from API, so use it directly
      const noShowVisitors = data

      // Show all no-show visitors (both main visitors and group visitors)
      const allNoShowVisitors = noShowVisitors.filter((item) => {
        // Show all visitors who are no-show (isVisited: false)
        const shouldShow = item.first_name && item.isVisited === false
        return shouldShow
      })

      // For no-show visitors, show main visitors with accordion functionality
      // Group visitors will be shown as group members under their main visitors
      const mainVisitors = allNoShowVisitors.filter(
        (item) =>
          item.visitor_type === 'main_visitor' || item.isMainVisitor === true,
      )

      const groupVisitors = allNoShowVisitors.filter(
        (item) => item.visitor_type === 'group_visitor' && !item.isMainVisitor,
      )

      // Process main visitors with their group relationships using email mapping
      const mainVisitorData = mainVisitors.map((item) => {
        const fullName =
          `${item.first_name || ''} ${item.last_name || ''}`.trim()

        // Find group visitors that belong to this main visitor using visitor_code and date
        const mainVisitorCode = item.visitor_code || item.last_visited_code
        const mainVisitorDate = item.date_of_visit || item.start_date

        const associatedGroupVisitors = groupVisitors.filter((groupVisitor) => {
          // Match by visitor_code (numeric part) and date
          const codesMatch = doVisitorCodesMatch(
            mainVisitorCode,
            groupVisitor.visitor_code || groupVisitor.last_visited_code,
          )
          const groupVisitorDate =
            groupVisitor.date_of_visit || groupVisitor.start_date
          const datesMatch = mainVisitorDate === groupVisitorDate

          return codesMatch && datesMatch
        })

        const hasGroupMembers = associatedGroupVisitors.length > 0

        return {
          ...item,
          fullName,
          visitorType:
            getVisitorTypeDisplay(item.visitor_type) || 'Main Visitor',
          hasGroupMembers,
          checkedInGroupMembersCount: associatedGroupVisitors.length,
          grp_details: associatedGroupVisitors,
          // Map phone number fields properly
          phNo: item.ph_no || item.phone || item.phNo || '',
          ph_ext: item.ph_ext || '+91',
          // Map organization name fields properly
          visitorOrgName:
            item.visitor_company_name ||
            item.org_name ||
            item.visitorOrgName ||
            '',
          // Map visitor_code properly
          visitor_code: item.visitor_code || item.last_visited_code || '',
        }
      })

      // Find group visitors that don't have a matching main visitor
      const orphanedGroupVisitors = groupVisitors.filter((groupVisitor) => {
        // Check if this group visitor has a main visitor in our main visitors list
        const groupVisitorCode =
          groupVisitor.visitor_code || groupVisitor.last_visited_code
        const groupVisitorDate =
          groupVisitor.date_of_visit || groupVisitor.start_date

        const hasMatchingMainVisitor = mainVisitors.some((mainVisitor) => {
          // Match by visitor_code (numeric part) and date
          const mainVisitorCode =
            mainVisitor.visitor_code || mainVisitor.last_visited_code
          const mainVisitorDate =
            mainVisitor.date_of_visit || mainVisitor.start_date

          const codesMatch = doVisitorCodesMatch(
            mainVisitorCode,
            groupVisitorCode,
          )
          const datesMatch = mainVisitorDate === groupVisitorDate

          return codesMatch && datesMatch
        })
        return !hasMatchingMainVisitor
      })

      // Process orphaned group visitors as standalone entries
      const orphanedGroupVisitorData = orphanedGroupVisitors.map((item) => {
        const fullName =
          `${item.first_name || ''} ${item.last_name || ''}`.trim()

        return {
          ...item,
          fullName,
          visitorType:
            getVisitorTypeDisplay(item.visitor_type) || 'Group Visitor',
          hasGroupMembers: false, // No group members for standalone group visitors
          checkedInGroupMembersCount: 0,
          grp_details: [],
          // Map phone number fields properly
          phNo: item.ph_no || item.phone || item.phNo || '',
          ph_ext: item.ph_ext || '+91',
          // Map organization name fields properly
          visitorOrgName:
            item.visitor_company_name ||
            item.org_name ||
            item.visitorOrgName ||
            '',
          // Map visitor_code properly
          visitor_code: item.visitor_code || item.last_visited_code || '',
        }
      })

      // Combine main visitors and orphaned group visitors
      const updatedData = [...mainVisitorData, ...orphanedGroupVisitorData]

      setRowData(updatedData)
    }
  }, [data])

  // Function to toggle visitor expansion
  const toggleVisitorExpansion = (visitorId) => {
    setExpandedVisitors((prev) => {
      const currentState = prev[visitorId] || false
      const newState = {
        ...prev,
        [visitorId]: !currentState,
      }
      return newState
    })

    // Force grid refresh to update the UI
    setTimeout(() => {
      if (gridApiRef.current) {
        gridApiRef.current.refreshCells({ force: true })
      }
    }, 100)
  }

  // Function to get expanded row data including group members
  const getExpandedRowData = () => {
    const expandedData = []

    rowData.forEach((visitor) => {
      // Add main visitor row
      expandedData.push(visitor)

      // If visitor is expanded and has group members, add group member rows
      if (expandedVisitors[visitor.visitor_id] && visitor.hasGroupMembers) {
        visitor.grp_details.forEach((member, index) => {
          // For no-show visitors, the group members are already group visitors with proper names
          const fullName =
            `${member.first_name || ''} ${member.last_name || ''}`.trim()

          expandedData.push({
            ...member,
            fullName: fullName,
            // Map group member fields to form field names
            first_name: member.first_name || '',
            last_name: member.last_name || '',
            phNo: member.ph_no || member.phone || member.phNo || '',
            ph_ext: member.ph_ext || '+91',
            email: member.email || '',
            role: member.role_name || member.role || 'Group Member',
            purpose_of_visit:
              member.purpose_of_visit || visitor.purpose_of_visit,
            visitorOrgName:
              member.visitor_company_name ||
              member.org_name ||
              visitor.visitorOrgName,
            date_of_visit: member.date_of_visit || visitor.date_of_visit,
            isGroupMember: true, // Mark as group member
            parentVisitorId: visitor.visitor_id,
            memberIndex: index,
          })
        })
      }
    })

    return expandedData
  }

  // Date cell renderer for formatting dates to DD-MM-YYYY
  const dateCellRenderer = (params) => {
    if (!params.value) return 'N/A'
    return formatDate(params.value)
  }

  // Custom cell renderer for name column with accordion functionality
  const nameCellRenderer = (params) => {
    const isGroupMember = params.data.isGroupMember
    const isGroupVisitor = params.data.visitor_type === 'group_visitor'
    const hasGroupMembers = params.data.hasGroupMembers
    const isExpanded = expandedVisitors[params.data.visitor_id] || false

    // Only indent if this is actually a group member AND has a valid parent visitor
    const hasValidParent =
      params.data.parentVisitorId &&
      params.data.parentVisitorId !== params.data.visitor_id

    // Check if the parent visitor is expanded (only show children when parent is expanded)
    const parentVisitorId = params.data.parentVisitorId
    const isParentExpanded = parentVisitorId
      ? expandedVisitors[parentVisitorId]
      : false

    if (isGroupMember && hasValidParent && isParentExpanded) {
      // Group member row - show with indentation and main visitor email in brackets
      const mainVisitorEmail = params.data.main_visitor_email || ''
      const displayName = mainVisitorEmail
        ? `${params.data.fullName} (${mainVisitorEmail})`
        : params.data.fullName

      return (
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            paddingLeft: '16px',
            backgroundColor: '#f8f9fa',
            padding: '8px 0 8px 16px',
            margin: '2px 0',
            textAlign: 'left',
            width: '100%',
          }}
        >
          <span
            style={{
              fontSize: '0.9rem',
              color: '#666',
              fontWeight: '500',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              textAlign: 'left',
              width: '100%',
            }}
          >
            👤{' '}
            <span style={{ color: '#333', textAlign: 'left' }}>
              {displayName}
            </span>
          </span>
        </div>
      )
    }

    if (isGroupVisitor && hasValidParent && isParentExpanded) {
      // Group visitor row - show with main visitor email in brackets
      const mainVisitorEmail = params.data.main_visitor_email || ''
      const displayName = mainVisitorEmail
        ? `${params.data.fullName} (${mainVisitorEmail})`
        : params.data.fullName

      return (
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            paddingLeft: '8px',
            textAlign: 'left',
            width: '100%',
          }}
        >
          <span style={{ fontWeight: '600', textAlign: 'left' }}>
            {displayName}
          </span>
        </div>
      )
    }

    // Hide group members when parent is not expanded
    if (
      (isGroupMember || isGroupVisitor) &&
      hasValidParent &&
      !isParentExpanded
    ) {
      return <div style={{ width: '100%', height: '100%' }}></div>
    }

    // Main visitor row or standalone visitor - show with accordion button if has group members
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
        {hasGroupMembers && (
          <button
            style={{
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              padding: '4px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              width: '24px',
              height: '24px',
              borderRadius: '4px',
              backgroundColor: isExpanded ? '#e3f2fd' : 'transparent',
              transition: 'all 0.2s ease',
            }}
            onClick={(e) => {
              e.stopPropagation()
              toggleVisitorExpansion(params.data.visitor_id)
            }}
          >
            {!isExpanded ? '▶' : '▼'}
          </button>
        )}
        <span style={{ fontWeight: hasGroupMembers ? '600' : 'normal' }}>
          {params.value}
        </span>
      </div>
    )
  }

  const columnDefs = useMemo(
    () => [
      {
        headerName: 'Name',
        field: 'fullName',
        cellRenderer: nameCellRenderer,
        tooltipField: 'fullName',
        width: 250,
      },
      {
        headerName: 'Visitor Type',
        field: 'visitorType',
        tooltipField: 'visitorType',
        width: 150,
      },
      {
        headerName: 'Category',
        field: 'role',
        tooltipField: 'role',
      },
      {
        headerName: 'Phone Extension',
        field: 'ph_ext',
        tooltipField: 'ph_ext',
        cellRenderer: (params) => {
          // If phone number is empty, show N/A for phone extension
          const phNo = params.data?.phNo || params.data?.ph_no || ''
          if (!phNo || phNo.trim() === '') {
            return 'N/A'
          }
          return params.value || 'N/A'
        },
      },
      {
        headerName: 'Phone Number',
        field: 'phNo',
        tooltipField: 'phNo',
        cellRenderer: (params) => {
          return params.value || 'N/A'
        },
      },
      {
        headerName: 'Email',
        field: 'email',
        tooltipField: 'email',
        cellRenderer: (params) => {
          return params.value || 'N/A'
        },
      },
      {
        headerName: 'Purpose Of Visit',
        field: 'purpose_of_visit',
        tooltipField: 'purpose_of_visit',
      },
      {
        headerName: 'Organization Name',
        field: 'visitorOrgName',
        tooltipField: 'visitorOrgName',
      },
      {
        headerName: 'Visit Date',
        field: 'date_of_visit',
        tooltipValueGetter: (params) => {
          if (!params.value) return 'N/A'
          return formatDate(params.value)
        },
        cellRenderer: dateCellRenderer,
      },
    ],
    [nameCellRenderer],
  )

  const onGridReady = (params) => {
    gridApiRef.current = params.api
  }

  // Force grid refresh when expanded state changes
  useEffect(() => {
    if (gridApiRef.current) {
      gridApiRef.current.refreshCells()
    }
  }, [expandedVisitors])

  // Function to get ALL data including group members for export
  const getAllDataForExport = () => {
    const allData = []

    rowData.forEach((visitor) => {
      // Check blacklist status for main visitor
      const isBlacklisted =
        visitor.black_listed === true ||
        visitor.blacklisted === true ||
        visitor.blacklist_status === 'blacklisted' ||
        visitor.is_blacklisted === true ||
        visitor.status === 'Blacklisted'

      // Add main visitor row
      allData.push({
        ...visitor,
        visitorType: 'Main Visitor',
        visitor_code: visitor.visitor_code || visitor.last_visited_code || '',
        blacklist: isBlacklisted ? 'Yes' : 'No',
      })

      // Add all group members (regardless of expansion state)
      if (visitor.hasGroupMembers && visitor.grp_details) {
        visitor.grp_details.forEach((member, index) => {
          // For no-show visitors, the group members are already group visitors with proper names
          const fullName =
            `${member.first_name || ''} ${member.last_name || ''}`.trim()

          // Check blacklist status for group member
          const isMemberBlacklisted =
            member.black_listed === true ||
            member.blacklisted === true ||
            member.blacklist_status === 'blacklisted' ||
            member.is_blacklisted === true ||
            member.status === 'Blacklisted'

          allData.push({
            ...member,
            fullName: fullName,
            // Map group member fields to form field names
            first_name: member.first_name || '',
            last_name: member.last_name || '',
            phNo: member.ph_no || member.phone || member.phNo || '',
            ph_ext: member.ph_ext || '+91',
            email: member.email || '',
            role: member.role_name || member.role || 'Group Member',
            purpose_of_visit:
              member.purpose_of_visit || visitor.purpose_of_visit,
            visitorOrgName:
              member.visitor_company_name ||
              member.org_name ||
              visitor.visitorOrgName,
            date_of_visit: member.date_of_visit || visitor.date_of_visit,
            visitor_code:
              member.visitor_code ||
              member.last_visited_code ||
              visitor.visitor_code ||
              visitor.last_visited_code ||
              '',
            visitorType: getVisitorTypeDisplay('group_member'),
            blacklist: isMemberBlacklisted ? 'Yes' : 'No',
            isGroupMember: true,
            parentVisitorId: visitor.visitor_id,
            memberIndex: index,
          })
        })
      }
    })

    return allData
  }

  const onExport = () => {
    if (!gridApiRef.current) {
      toast.error('Export failed: Grid API not initialized.')
      return
    }

    const columnHeaders = [
      'Name',
      'Visitor Type',
      'Category',
      'Phone Extension',
      'Phone Number',
      'Email',
      'Purpose Of Visit',
      'Organization Name',
      'Visit Date',
      'Access Reference Code',
      'Blacklist',
    ]

    const columnKeys = [
      'fullName',
      'visitorType',
      'role',
      'ph_ext',
      'phNo',
      'email',
      'purpose_of_visit',
      'visitorOrgName',
      'date_of_visit',
      'visitor_code',
      'blacklist',
    ]

    let csvRows = []

    // Add report metadata header with date range in DD-MM-YYYY format
    csvRows.push(`"Report: ${report_name || 'Visitor Reports'}"`)
    csvRows.push(`"Admin: ${name || ''}"`)
    csvRows.push(`"Branch Name: ${selectedBranch?.branch_name || 'N/A'}"`)
    csvRows.push(
      `"Date Range: ${format(start_date, 'dd-MM-yyyy')} to ${format(to_date, 'dd-MM-yyyy')}"`,
    )
    csvRows.push('') // Empty row for spacing

    // Add the column headers
    csvRows.push(columnHeaders.join(','))

    // Use all data including group members for export
    const allData = getAllDataForExport()
    allData.forEach((rowData) => {
      let row = columnKeys.map((key) => {
        if (key === 'ph_ext') {
          // If phone number is empty, show N/A for phone extension
          const phNo = rowData.phNo || rowData.ph_no || ''
          if (!phNo || phNo.toString().trim() === '') {
            return '"N/A"'
          }
          return `"${rowData.ph_ext || 'N/A'}"`
        }
        
        if (key === 'phNo') {
          const ext = rowData.ph_ext ? rowData.ph_ext.toString() : ''
          const no = rowData.phNo ? rowData.phNo.toString() : ''
          if (ext && no) {
            const cleanedExt = ext.startsWith('+') ? ext : `${ext}`
            const formattedPhone = `\t${cleanedExt}-${no}`
            return `"${formattedPhone}"`
          }
          return '"N/A"'
        }
        
        if (key === 'email') {
          return `"${rowData.email || 'N/A'}"`
        }

        if (key === 'visitor_code') {
          const code =
            rowData.visitor_code || rowData.last_visited_code || 'N/A'
          return `"${code}"`
        }

        // Format date_of_visit to DD-MM-YYYY format
        if (key === 'date_of_visit') {
          const dateValue = rowData[key] || 'N/A'
          return `"${dateValue ? formatDate(dateValue) : 'N/A'}"`
        }

        const cellValue = rowData[key] || 'N/A'
        return `"${cellValue}"`
      })
      csvRows.push(row.join(','))
    })

    const csvContent = csvRows.join('\n')

    const blob = new Blob([csvContent], { type: 'text/csv' })
    const link = document.createElement('a')
    link.href = URL.createObjectURL(blob)
    link.download = 'No Show Visitors Report.csv'
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const onExportPDF = () => {
    if (!gridApiRef.current) {
      toast.error('Export failed: Grid API not initialized.')
      return
    }

    const doc = new jsPDF({
      orientation: 'landscape',
      unit: 'pt',
      format: [792, 612], // Standard landscape page size (11x8.5 inches)
    })

    // Calculate available width: page width (792pt) - left margin (14pt) - right margin (14pt) = 764pt
    // Total column widths: 55+35+40+50+70+80+65+75+60+65+30 = 665pt (fits comfortably)

    // Add a decorative header background
    doc.setFillColor(39, 174, 96) // Teal color
    doc.rect(0, 0, 792, 50, 'F') // Full width header bar

    // Add the "No Show Visitors Reports" heading - centered and white
    doc.setFontSize(22)
    doc.setTextColor(255, 255, 255) // White text color
    const pageWidth = doc.internal.pageSize.width
    const textWidth = doc.getTextWidth('No Show Visitors Reports')
    const centerX = (pageWidth - textWidth) / 2
    doc.text('No Show Visitors Reports', centerX, 32) // Centered title on colored background

    // Static data for branch name and date
    const Admin = `Admin: ${name || ''}`
    const branchName = `Branch Name: ${selectedBranch?.branch_name || 'N/A'}`
    const reportDate = `Date Range: ${format(start_date, 'dd-MM-yyyy')} to ${format(to_date, 'dd-MM-yyyy')}`

    // Add metadata in a clean layout - minimal left margin to reduce empty space
    const leftMargin = 14
    const now = new Date()
    const generatedDate = format(now, 'dd-MM-yyyy')
    const generatedTime = format(now, 'HH:mm:ss')
    const generatedOn = `Generated on: ${generatedDate} ${generatedTime}`
    
    doc.setFontSize(10)
    doc.setTextColor(0, 0, 0)
    doc.text(Admin, leftMargin, 70)
    doc.text(`Branch: ${selectedBranch?.branch_name || 'N/A'}`, leftMargin, 85)
    doc.text(reportDate, leftMargin, 100)

    // Add generated timestamp on the right side
    const rightMargin = pageWidth - 14
    const generatedWidth = doc.getTextWidth(generatedOn)
    doc.text(generatedOn, rightMargin - generatedWidth, 100)

    // Add a subtle line separator before table
    doc.setDrawColor(200, 200, 200)
    doc.setLineWidth(0.5)
    doc.line(leftMargin, 115, pageWidth - leftMargin, 115)

    // Adjust the layout below the header
    doc.setTextColor(0) // Reset text color for table content

    // Define table columns with new fields
    const tableColumns = [
      { header: 'Name', dataKey: 'fullName' },
      { header: 'Visitor Type', dataKey: 'visitorType' },
      { header: 'Category', dataKey: 'role' },
      { header: 'Phone Extension', dataKey: 'ph_ext' },
      { header: 'Phone Number', dataKey: 'phNo' },
      { header: 'Email', dataKey: 'email' },
      { header: 'Purpose Of Visit', dataKey: 'purpose_of_visit' },
      { header: 'Organization Name', dataKey: 'visitorOrgName' },
      { header: 'Visit Date', dataKey: 'date_of_visit' },
      { header: 'Access Reference Code', dataKey: 'visitor_code' },
      { header: 'Blacklist', dataKey: 'blacklist' },
    ]

    // Use all data including group members for PDF export
    const allData = getAllDataForExport()
    const tableRows = []
    allData.forEach((rowData) => {
      tableRows.push(
        tableColumns.map((col) => {
          const value = rowData[col.dataKey]

          // Special handling for Phone Extension - show N/A if phone number is empty
          if (col.dataKey === 'ph_ext') {
            const phNo = rowData.phNo || rowData.ph_no || ''
            if (!phNo || phNo.toString().trim() === '') {
              return 'N/A'
            }
            return value || 'N/A'
          }

          if (col.dataKey === 'phNo') {
            const ext = rowData['ph_ext'] || ''
            const cleanedExt = ext.startsWith('+') ? ext : `+${ext}`
            const phone = value || ''
            return phone ? `${cleanedExt}-${phone}` : 'N/A'
          }
          
          // Special handling for Email - show N/A if empty
          if (col.dataKey === 'email') {
            return value || 'N/A'
          }

          if (col.dataKey === 'visitor_code') {
            return rowData.visitor_code || rowData.last_visited_code || 'N/A'
          }

          // Format date_of_visit to DD-MM-YYYY format
          if (col.dataKey === 'date_of_visit') {
            return value ? formatDate(value) : 'N/A'
          }

          // Special handling for Blacklist - format as Yes/No
          if (col.dataKey === 'blacklist') {
            const isBlacklisted =
              rowData.black_listed === true ||
              rowData.blacklisted === true ||
              rowData.blacklist_status === 'blacklisted' ||
              rowData.is_blacklisted === true ||
              rowData.status === 'Blacklisted' ||
              value === true ||
              value === 'Yes' ||
              value === 'yes'
            return isBlacklisted ? 'Yes' : 'No'
          }

          return value || 'N/A'
        }),
      )
    })

    // Add the table to the PDF - optimized to fit all columns on one page with better spacing
    doc.autoTable({
      startY: 125, // Start closer to header for better space utilization
      head: [tableColumns.map((col) => col.header)],
      body: tableRows,
      styles: { 
        fontSize: 7, 
        cellPadding: 3,
        overflow: 'linebreak',
        cellWidth: 'wrap',
      },
      headStyles: {
        fillColor: [39, 174, 96], // Teal color for table header
        textColor: [255, 255, 255], // White text
        fontSize: 7,
        fontStyle: 'bold',
        cellPadding: 3,
        halign: 'left',
      },
      alternateRowStyles: {
        fillColor: [245, 245, 245], // Light gray for alternate rows
      },
      columnStyles: {
        0: { cellWidth: 60, halign: 'left' }, // Name
        1: { cellWidth: 40, halign: 'left' }, // Visitor Type
        2: { cellWidth: 45, halign: 'left' }, // Category
        3: { cellWidth: 55, halign: 'left' }, // Phone Extension
        4: { cellWidth: 75, halign: 'left' }, // Phone Number
        5: { cellWidth: 85, halign: 'left' }, // Email
        6: { cellWidth: 70, halign: 'left' }, // Purpose Of Visit
        7: { cellWidth: 80, halign: 'left' }, // Organization Name
        8: { cellWidth: 65, halign: 'center' }, // Visit Date
        9: { cellWidth: 70, halign: 'left' }, // Access Reference Code
        10: { cellWidth: 35, halign: 'center' }, // Blacklist
      },
      margin: { left: 14, right: 14, top: 125 }, // Reduced margins to minimize empty space
      tableWidth: 764, // Explicit width: 792 - 14 - 14 = 764pt
      showHead: 'everyPage',
      theme: 'striped', // Add striped theme for better readability
    })

    // Save the PDF
    doc.save('no_show_visitors_report.pdf')
  }

  // Download functions for Group Booking and Vehicle/Material PDF (removed - buttons no longer needed)
  const _downloadGroupBookingPDF = () => {
    const doc = new jsPDF()

    // Add title
    doc.setFontSize(16)
    doc.text('Group Booking Report', 14, 22)

    // Add date
    doc.setFontSize(10)
    doc.text(
      `Generated on: ${format(new Date(), 'yyyy-MM-dd HH:mm:ss')}`,
      14,
      30,
    )

    // Prepare table data - using grp_details data (matching image)
    const tableColumns = [
      'Group Member Name',
      'Role',
      'Phone Number',
      'Email',
      'Group ID',
      'Blacklist',
    ]

    // Collect all group members from all visitors
    const tableRows = []
    rowData.forEach((visitor) => {
      if (visitor.grp_details && visitor.grp_details.length > 0) {
        visitor.grp_details.forEach((member) => {
          // Check blacklist status for group member
          const isBlacklisted =
            member.black_listed === true ||
            member.blacklisted === true ||
            member.blacklist_status === 'blacklisted' ||
            member.is_blacklisted === true ||
            member.status === 'Blacklisted'

          tableRows.push([
            member.grp_user_name || 'N/A',
            member.grp_user_role_name || 'N/A',
            `${member.grp_user_phext || ''}-${member.grp_user_phno || ''}` ||
              'N/A',
            member.grp_user_email || 'N/A',
            member.grp_id || 'N/A',
            isBlacklisted ? 'Yes' : 'No',
          ])
        })
      }
    })

    // Add table
    doc.autoTable({
      startY: 40,
      head: [tableColumns],
      body: tableRows,
      styles: { fontSize: 9, cellPadding: 3 },
      headStyles: { fillColor: [39, 174, 96] },
      horizontalPageBreak: true,
    })

    doc.save('group_booking_report.pdf')
  }

  const _downloadVehicleMaterialPDF = () => {
    try {
      // Filter for visitors with vehicle/material data
      const vehicleMaterialBookings = rowData.filter(
        (booking) => booking.vm_bool || booking.mm_bool,
      )

      if (vehicleMaterialBookings.length === 0) {
        toast.error('No vehicle/material data available to download')
        return
      }

      // Additional check: verify that the filtered bookings actually have vm_details or mm_details
      const bookingsWithActualData = vehicleMaterialBookings.filter(
        (booking) =>
          (booking.vm_details && booking.vm_details.length > 0) ||
          (booking.mm_details && booking.mm_details.length > 0),
      )

      if (bookingsWithActualData.length === 0) {
        toast.error(
          'No actual vehicle/material details found in the filtered data',
        )
        return
      }

      // Create PDF in landscape orientation
      const doc = new jsPDF('landscape', 'mm', 'a4')

      // Add green header background
      doc.setFillColor(39, 174, 96) // Green color matching the image
      doc.rect(0, 0, doc.internal.pageSize.width, 25, 'F') // Fill the top area with green

      // Add admin details on the left side of header (white text)
      doc.setFontSize(10)
      doc.setTextColor(255, 255, 255) // White text
      doc.text('Admin: Organization Admin', 10, 10)
      doc.text('Branch Name: All Branches', 10, 16)
      doc.text(`Date: ${format(new Date(), 'dd-MM-yyyy')}`, 10, 22)

      // Add report title on the right side of header (white text)
      doc.setFontSize(14)
      doc.setTextColor(255, 255, 255) // White text
      const pageWidth = doc.internal.pageSize.width
      const textWidth = doc.getTextWidth('Vehicle/Material Reports')
      const centerX = pageWidth - textWidth - 10 // Right align
      doc.text('Vehicle/Material Reports', centerX, 16)

      // Prepare table data - using visitor data with vehicle/material related fields (matching image)
      const tableColumns = [
        'Visitor Name',
        'Vehicle Name',
        'Vehicle Type',
        'Driver License',
        'RC Number',
        'Insurance Provider',
        'Insurance Number',
        'Material Name',
        'Material Description',
      ]
      // Filter out group members - only show main visitors for Vehicle/Material reports
      const mainVisitorsOnly = rowData.filter((user) => !user.isGroupMember)

      // Process the data to create table rows
      const tableRows = []

      mainVisitorsOnly.forEach((user) => {
        // Get the correct name - show actual main visitor names
        const displayName =
          `${user.first_name || ''} ${user.last_name || ''}`.trim() || 'N/A'

        // Check if user has vehicle/material data
        const hasVehicleDetails = user.vm_details && user.vm_details.length > 0
        const hasMaterialDetails = user.mm_details && user.mm_details.length > 0

        if (hasVehicleDetails) {
          // Process each vehicle and its associated materials
          user.vm_details.forEach((vehicle) => {
            // Find materials associated with this specific vehicle
            const associatedMaterials = hasMaterialDetails
              ? user.mm_details.filter(
                  (material) =>
                    material.material_vehicle_id === vehicle.vehicle_id,
                )
              : []

            if (associatedMaterials.length > 0) {
              // Vehicle has associated materials - create one row per material
              associatedMaterials.forEach((material) => {
                const rowData = [
                  displayName,
                  vehicle.vehicle_name || 'N/A',
                  vehicle.vehicle_type || 'N/A',
                  vehicle.driver_licence || 'N/A',
                  vehicle.rc_no || 'N/A',
                  vehicle.insurance_provider || 'N/A',
                  vehicle.insurance_no || 'N/A',
                  material.material_name || 'N/A',
                  material.material_description || 'N/A',
                ]
                tableRows.push(rowData)
              })
            } else {
              // Vehicle exists but no associated materials
              const rowData = [
                displayName,
                vehicle.vehicle_name || 'N/A',
                vehicle.vehicle_type || 'N/A',
                vehicle.driver_licence || 'N/A',
                vehicle.rc_no || 'N/A',
                vehicle.insurance_provider || 'N/A',
                vehicle.insurance_no || 'N/A',
                'N/A', // No material
                'N/A', // No material
              ]
              tableRows.push(rowData)
            }
          })
        }

        // Handle materials that are not associated with any vehicle
        if (hasMaterialDetails) {
          const materialsHandledByVehicles = new Set()
          if (hasVehicleDetails) {
            user.vm_details.forEach((vehicle) => {
              const associatedMaterials = user.mm_details.filter(
                (material) =>
                  material.material_vehicle_id === vehicle.vehicle_id,
              )
              associatedMaterials.forEach((material) => {
                materialsHandledByVehicles.add(material.material_id)
              })
            })
          }

          // Add materials that are not associated with any vehicle
          user.mm_details.forEach((material) => {
            if (!materialsHandledByVehicles.has(material.material_id)) {
              const rowData = [
                displayName,
                'N/A', // No vehicle
                'N/A', // No vehicle
                'N/A', // No vehicle
                'N/A', // No vehicle
                'N/A', // No vehicle
                'N/A', // No vehicle
                material.material_name || 'N/A',
                material.material_description || 'N/A',
              ]
              tableRows.push(rowData)
            }
          })
        }

        // If no vehicle or material data at all, add a single row with N/A for everything
        if (!hasVehicleDetails && !hasMaterialDetails) {
          const rowData = [
            displayName,
            'N/A',
            'N/A',
            'N/A',
            'N/A',
            'N/A',
            'N/A', // Vehicle fields
            'N/A',
            'N/A',
          ]
          tableRows.push(rowData)
        }
      })

      if (tableRows.length > 0 && tableRows[0]) {
        if (!Array.isArray(tableRows[0])) {
          console.error(
            '🔍 CRITICAL ERROR: tableRows[0] is NOT an array!',
            tableRows[0],
          )
          toast.error(
            'PDF generation failed: Data format error. Please check console for details.',
          )
          return
        }
      } else {
        toast.error('No data available to generate PDF')
        return
      }

      // Create PDF document
      const vehicleDoc = new jsPDF('landscape', 'mm', 'a4')

      // Add green header background
      vehicleDoc.setFillColor(39, 174, 96)
      vehicleDoc.rect(0, 0, vehicleDoc.internal.pageSize.width, 25, 'F')

      // Add admin details
      vehicleDoc.setFontSize(10)
      vehicleDoc.setTextColor(255, 255, 255)
      vehicleDoc.text('Admin: Organization Admin', 10, 10)
      vehicleDoc.text('Branch Name: All Branches', 10, 16)
      vehicleDoc.text(`Date: ${format(new Date(), 'dd-MM-yyyy')}`, 10, 22)

      // Add report title
      vehicleDoc.setFontSize(14)
      vehicleDoc.setTextColor(255, 255, 255)
      const vehiclePageWidth = vehicleDoc.internal.pageSize.width
      const vehicleTextWidth = vehicleDoc.getTextWidth(
        'Vehicle/Material Reports',
      )
      const vehicleCenterX = vehiclePageWidth - vehicleTextWidth - 10
      vehicleDoc.text('Vehicle/Material Reports', vehicleCenterX, 16)

      // Add table
      vehicleDoc.autoTable({
        startY: 30, // Start after the green header
        head: [tableColumns],
        body: tableRows,
        styles: {
          fontSize: 8,
          cellPadding: 3,
          overflow: 'linebreak',
          halign: 'left',
          textColor: [0, 0, 0], // Black text for data rows
        },
        headStyles: {
          fillColor: [39, 174, 96], // Green header matching the image
          fontSize: 9,
          fontStyle: 'bold',
          textColor: [255, 255, 255], // White text for header
        },
        columnStyles: {
          // Optimized column widths to fit all columns on single page (6 columns including blacklist)
          0: { cellWidth: 50 }, // Group Member Name
          1: { cellWidth: 40 }, // Role
          2: { cellWidth: 60 }, // Phone Number
          3: { cellWidth: 80 }, // Email
          4: { cellWidth: 40 }, // Group ID
          5: { cellWidth: 30, halign: 'center' }, // Blacklist
        },
        horizontalPageBreak: true,
        margin: { left: 2, right: 2 },
      })

      vehicleDoc.save('vehicle_material_report.pdf')
      toast.success('Vehicle/Material PDF downloaded successfully!')
    } catch (error) {
      console.error('🔍 Error in Vehicle/Material PDF generation:', error)
      toast.error(`Error generating PDF: ${error.message}`)
    }
  }

  // Download functions for Group Booking and Vehicle/Material CSV
  const _downloadGroupBookingCSV = () => {
    // Collect all group members from all visitors
    const csvData = []
    rowData.forEach((visitor) => {
      if (visitor.grp_details && visitor.grp_details.length > 0) {
        visitor.grp_details.forEach((member) => {
          // Check blacklist status for group member
          const isBlacklisted =
            member.black_listed === true ||
            member.blacklisted === true ||
            member.blacklist_status === 'blacklisted' ||
            member.is_blacklisted === true ||
            member.status === 'Blacklisted'

          csvData.push({
            'Group Member Name': member.grp_user_name || 'N/A',
            Role: member.grp_user_role_name || 'N/A',
            'Phone Number':
              `${member.grp_user_phext || ''}-${member.grp_user_phno || ''}` ||
              'N/A',
            Email: member.grp_user_email || 'N/A',
            'Group ID': member.grp_id || 'N/A',
            Blacklist: isBlacklisted ? 'Yes' : 'No',
          })
        })
      }
    })

    // Convert to CSV format
    const csv = Papa.unparse(csvData)
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    saveAs(blob, 'Group Booking Report.csv')
  }

  const _downloadVehicleMaterialCSV = () => {
    // Filter out group members - only show main visitors for Vehicle/Material reports
    const mainVisitorsOnly = rowData.filter((user) => !user.isGroupMember)

    // Check if we have any visitors with vehicle/material data
    const visitorsWithVehicleMaterial = mainVisitorsOnly.filter(
      (user) =>
        (user.vm_details && user.vm_details.length > 0) ||
        (user.mm_details && user.mm_details.length > 0),
    )

    if (visitorsWithVehicleMaterial.length === 0) {
      toast.error('No vehicle/material data found in the selected visitors')
      return
    }

    const csvData = mainVisitorsOnly.flatMap((user) => {
      // Get the correct name - show actual main visitor names
      const displayName =
        user.fullName ||
        (user.first_name && user.last_name
          ? `${user.first_name} ${user.last_name}`.trim()
          : user.first_name || user.last_name || 'N/A')

      // Check if user has vehicle/material data
      const userRows = []
      const hasVehicleDetails = user.vm_details && user.vm_details.length > 0
      const hasMaterialDetails = user.mm_details && user.mm_details.length > 0

      if (hasVehicleDetails) {
        // Process each vehicle and its associated materials
        user.vm_details.forEach((vehicle) => {
          // Find materials associated with this specific vehicle
          const associatedMaterials = hasMaterialDetails
            ? user.mm_details.filter(
                (material) =>
                  material.material_vehicle_id === vehicle.vehicle_id,
              )
            : []

          if (associatedMaterials.length > 0) {
            // Vehicle has associated materials - create one row per material
            associatedMaterials.forEach((material) => {
              const csvRow = {
                'Visitor Name': displayName,
                'Vehicle Name': vehicle.vehicle_name || 'N/A',
                'Vehicle Type': vehicle.vehicle_type || 'N/A',
                'Driver License': vehicle.driver_licence || 'N/A',
                'RC Number': vehicle.rc_no || 'N/A',
                'Insurance Provider': vehicle.insurance_provider || 'N/A',
                'Insurance Number': vehicle.insurance_no || 'N/A',
                'Material Name': material.material_name || 'N/A',
                'Material Description': material.material_description || 'N/A',
              }
              userRows.push(csvRow)
            })
          } else {
            // Vehicle exists but no associated materials
            const csvRow = {
              'Visitor Name': displayName,
              'Vehicle Name': vehicle.vehicle_name || 'N/A',
              'Vehicle Type': vehicle.vehicle_type || 'N/A',
              'Driver License': vehicle.driver_licence || 'N/A',
              'RC Number': vehicle.rc_no || 'N/A',
              'Insurance Provider': vehicle.insurance_provider || 'N/A',
              'Insurance Number': vehicle.insurance_no || 'N/A',
              'Material Name': 'N/A',
              'Material Description': 'N/A',
            }
            userRows.push(csvRow)
          }
        })
      }

      // Handle materials that are not associated with any vehicle
      if (hasMaterialDetails) {
        const materialsHandledByVehicles = new Set()
        if (hasVehicleDetails) {
          user.vm_details.forEach((vehicle) => {
            const associatedMaterials = user.mm_details.filter(
              (material) => material.material_vehicle_id === vehicle.vehicle_id,
            )
            associatedMaterials.forEach((material) => {
              materialsHandledByVehicles.add(material.material_id)
            })
          })
        }

        // Add materials that are not associated with any vehicle
        user.mm_details.forEach((material) => {
          if (!materialsHandledByVehicles.has(material.material_id)) {
            const csvRow = {
              'Visitor Name': displayName,
              'Vehicle Name': 'N/A',
              'Vehicle Type': 'N/A',
              'Driver License': 'N/A',
              'RC Number': 'N/A',
              'Insurance Provider': 'N/A',
              'Insurance Number': 'N/A',
              'Material Name': material.material_name || 'N/A',
              'Material Description': material.material_description || 'N/A',
            }
            userRows.push(csvRow)
          }
        })
      }

      // If no vehicle or material data at all, add a single row with N/A for everything
      if (!hasVehicleDetails && !hasMaterialDetails) {
        const csvRow = {
          'Visitor Name': displayName,
          'Vehicle Name': 'N/A',
          'Vehicle Type': 'N/A',
          'Driver License': 'N/A',
          'RC Number': 'N/A',
          'Insurance Provider': 'N/A',
          'Insurance Number': 'N/A',
          'Material Name': 'N/A',
          'Material Description': 'N/A',
        }
        userRows.push(csvRow)
      }

      return userRows
    })

    // Convert to CSV format
    const csv = Papa.unparse(csvData)
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    saveAs(blob, 'Vehicle Material Report.csv')
  }

  return (
    <div>
      {auth.role !== '5' && (
        <div>
          <div className="flex items-center space-x-4 mb-4">
            {/* Toggle Button */}
            <button
              onClick={handleToggle}
              className="bg-gray-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-gray-600 transition-colors"
            >
              {isPDF ? (
                <>
                  <FontAwesomeIcon
                    icon={faToggleOn}
                    className="mr-1.5 text-xs"
                  />
                  Switch to CSV
                </>
              ) : (
                <>
                  <FontAwesomeIcon
                    icon={faToggleOff}
                    className="mr-1.5 text-xs"
                  />
                  Switch to PDF
                </>
              )}
            </button>

            {/* Conditional Buttons */}
            {isPDF ? (
              <>
                <button
                  onClick={onExportPDF}
                  className="bg-green-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-green-600 transition-colors"
                >
                  Download PDF
                  <FontAwesomeIcon
                    icon={faDownload}
                    className="ml-1.5 text-xs"
                  />
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={onExport}
                  className="bg-blue-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-blue-600 transition-colors"
                >
                  Download CSV
                  <FontAwesomeIcon
                    icon={faDownload}
                    className="ml-1.5 text-xs"
                  />
                </button>
              </>
            )}
          </div>
        </div>
      )}
      <br />
      {loading ? (
        <div>Loading...</div>
      ) : (
        <div
          className="ag-theme-material"
          style={{ height: 500, width: '100%' }}
        >
          <AgGridReact
            rowData={getExpandedRowData()}
            columnDefs={columnDefs}
            pagination={true}
            paginationPageSize={20}
            onGridReady={onGridReady}
            rowHeight={60}
            getRowStyle={(params) => {
              if (params.data.isGroupMember) {
                return { backgroundColor: '#f8f9fa' }
              }
              return null
            }}
          />
        </div>
      )}
    </div>
  )
}

export default VisitorsTable
