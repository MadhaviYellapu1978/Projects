import React, { useMemo, useState, useEffect, useRef, useContext } from 'react'
import { AgGridReact } from 'ag-grid-react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {
  faDownload,
  faToggleOn,
  faToggleOff,
} from '@fortawesome/free-solid-svg-icons'
import TextField from '@mui/material/TextField'
import { Formik, Form } from 'formik'
import FormikTextField from '../lib/Formik/FormikTextfield'
import FormikTimePicker from '../lib/Formik/FormikTimePicker'
import FormikDatePicker from '../lib/Formik/FormikDatePicker'
import Modal from '@mui/material/Modal'
import Box from '@mui/material/Box'
import * as Yup from 'yup'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { extendTimeDuringVisit, getAllVisitors } from '../services/adminService'
import toast from 'react-hot-toast'
import { AuthContext } from '../context/AuthContext'
import { format } from 'date-fns'
import { styles, stylees } from '../constants/styes.js'
import jsPDF from 'jspdf'
import 'jspdf-autotable'

const timeToMinutes = (timeStr) => {
  const [hours, minutes] = timeStr.split(':').map(Number)
  return hours * 60 + minutes
}

const validationSchema = Yup.object().shape({
  time_to_exit: Yup.string()
    .test(
      'is-greater',
      'Visit End Time must be greater than Visit Start Time',
      function (value) {
        const { time_of_visit } = this.parent
        return timeToMinutes(value) > timeToMinutes(time_of_visit)
      },
    )
    .required('Visit End Time is required'),
})

const VisitorsTable = ({
  data,
  selectedBranch,
  start_date,
  to_date,
  name,
  report_name,
}) => {
  const auth = useContext(AuthContext)
  const [rowData, setRowData] = useState([])
  const [selectedVisitor, setSelectedVisitor] = useState(null)
  const [loading, setLoading] = useState(false)
  const [openModal, setOpenModal] = useState(false)
  const [isPDF, setIsPDF] = useState(true) // Toggle state for PDF/CSV
  const queryClient = useQueryClient()
  const gridApiRef = useRef(null)

  const handleToggle = () => {
    setIsPDF(!isPDF)
  }
  useEffect(() => {
    if (data && data.length > 0) {
      const updatedData = data.map((item) => ({
        ...item,
        fullName: `${item.first_name} ${item.last_name}`, // Compute full name
      }))
      setRowData(updatedData)
    }
  }, [data])
  const columnDefs = useMemo(
    () => [
      {
        headerName: 'Name',
        field: 'fullName',
        tooltipField: 'fullName',
      },
      {
        headerName: 'Category',
        field: 'role',
        tooltipField: 'role',
      },
      {
        headerName: 'Phone Extension',
        field: 'ph_ext',
        tooltipField: 'ph_ext',
      },
      {
        headerName: 'Phone Number',
        field: 'ph_no',
        tooltipField: 'ph_no',
      },
      {
        headerName: 'Email',
        field: 'email',
        tooltipField: 'email',
      },
      {
        headerName: 'Purpose Of Visit',
        field: 'purpose_of_visit',
        tooltipField: 'purpose_of_visit',
      },
      {
        headerName: 'Organization Name',
        field: 'visitorOrgName',
        tooltipField: 'visitorOrgName',
      },
      {
        headerName: 'Last Entry',
        field: 'last_entry',
        tooltipField: 'last_entry',
      },
      {
        headerName: 'Last Exit',
        field: 'last_exit',
        tooltipField: 'last_exit',
      },
      {
        headerName: 'Photo',
        field: 'photo',
        tooltipField: 'photo',
      },
    ],
    [],
  )

  const onGridReady = (params) => {
    gridApiRef.current = params.api
  }

  const onExport = () => {
    if (!gridApiRef.current) {
      toast.error('Export failed: Grid API not initialized.')
      return
    }

    // Manually extract data from the grid and format it for CSV export
    // Column order matches PDF: Name, Category, Phone Extension, Phone Number, Email, Purpose Of Visit, Organization Name, Last Entry, Last Exit, Access Reference code, Photo, KYC Type, KYC ID
    const columnHeaders = [
      'Name',
      'Category',
      'Phone Extension',
      'Phone Number',
      'Email',
      'Purpose Of Visit',
      'Organization Name',
      'Last Entry',
      'Last Exit',
      'Access Reference Code',
      'Photo',
      'KYC Type',
      'KYC ID',
    ]

    const columnKeys = [
      'fullName',
      'role',
      'ph_ext',
      'ph_no',
      'email',
      'purpose_of_visit',
      'visitorOrgName',
      'last_entry',
      'last_exit',
      'last_visited_code',
      'photo',
      'kyc_type',
      'kyc_id',
    ]

    // Fetch displayed rows from the grid
    let csvRows = []

    // Add the column headers
    csvRows.push(columnHeaders.join(','))

    gridApiRef.current.forEachNodeAfterFilterAndSort((rowNode) => {
      let row = columnKeys.map((key) => {
        let cellValue = rowNode.data[key] || 'N/A' // Handle missing data
        
        // Special handling for Phone Number - show N/A if empty
        if (key === 'ph_no') {
          const phExt = rowNode.data['ph_ext'] || ''
          const phNo = rowNode.data['ph_no'] || ''
          cellValue = phNo && phExt ? `${phExt}-${phNo}` : 'N/A'
        }
        
        // Special handling for Email - show N/A if empty
        if (key === 'email') {
          cellValue = cellValue || 'N/A'
        }
        
        return `"${cellValue}"` // Ensure values are properly formatted
      })
      csvRows.push(row.join(','))
    })

    // Convert array to CSV format
    const csvContent = csvRows.join('\n')

    // Create a downloadable CSV file
    const blob = new Blob([csvContent], { type: 'text/csv' })
    const link = document.createElement('a')
    link.href = URL.createObjectURL(blob)
    link.download = 'Visitor Reports.csv'
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  // Helper function to convert image URL to base64
  const convertImageToBase64 = async (url) => {
    try {
      if (!url || url === 'N/A' || !url.startsWith('http')) {
        return null
      }
      
      // Handle different S3 URL formats
      let imageUrl = url
      if (url.includes('ap-south-1')) {
        imageUrl = url
      } else if (url.includes('https://visiqbucket.s3.')) {
        imageUrl = `https://visiqbucket.s3.us-east-1.${url.split('https://visiqbucket.s3.')[1]}`
      }
      
      const response = await fetch(imageUrl)
      if (!response.ok) {
        return null
      }
      const blob = await response.blob()
      
      return await new Promise((resolve, reject) => {
        const reader = new FileReader()
        reader.onloadend = () => resolve(reader.result)
        reader.onerror = reject
        reader.readAsDataURL(blob)
      })
    } catch (error) {
      console.error('Error converting image to base64:', error)
      return null
    }
  }

  const onExportPDF = async () => {
    if (!gridApiRef.current) {
      toast.error('Export failed: Grid API not initialized.')
      return
    }

    // Fetch displayed rows from grid and convert photos to base64
    const tableRowsData = []
    gridApiRef.current.forEachNodeAfterFilterAndSort((rowNode) => {
      tableRowsData.push(rowNode.data)
    })

    // Convert all photo URLs to base64
    const rowsWithImages = await Promise.all(
      tableRowsData.map(async (rowData) => {
        let base64Photo = null
        if (rowData.photo && rowData.photo !== 'N/A') {
          base64Photo = await convertImageToBase64(rowData.photo)
        }
        return {
          ...rowData,
          base64Photo: base64Photo,
        }
      }),
    )

    const doc = new jsPDF({
      orientation: 'landscape',
      unit: 'pt',
      format: [1700, 700], // Custom page size
    })

    // Add a teal background for the header
    doc.setFillColor(39, 174, 96) // Teal color
    doc.rect(0, 0, doc.internal.pageSize.width, 100, 'F') // Fill the top area with teal color

    // Add the "Visitors Report" heading in the middle
    doc.setFontSize(20)
    doc.setTextColor(255, 255, 255) // White text color
    const pageWidth = doc.internal.pageSize.width
    const textWidth = doc.getTextWidth('Visitors Report')
    const centerX = (pageWidth - textWidth) / 2
    doc.text(`${report_name}`, centerX, 40) // Centered title

    // Static data for branch name and date
    const Admin = `Admin: ${name || ''}`
    const branchName = `Branch Name: ${selectedBranch?.branch_name || 'N/A'}`
    const reportDate = `Date Range: ${format(start_date, 'dd-MM-yyyy')} to ${format(to_date, 'dd-MM-yyyy')}`

    // Add the branch name below the title
    doc.setFontSize(14)
    doc.setTextColor(255, 255, 255) // White text color
    doc.text(Admin, 40, 40)
    doc.text(branchName, 40, 60) // Branch name on the left

    // Add the date below the branch name
    doc.text(reportDate, 40, 80) // Report date on the left

    // Adjust the layout below the header
    doc.setTextColor(0) // Reset text color for table content

    // Define table columns
    const tableColumns = [
      { header: 'Name', dataKey: 'fullName' },
      { header: 'Category', dataKey: 'role' },
      { header: 'Phone Extension', dataKey: 'ph_ext' },
      { header: 'Phone Number', dataKey: 'ph_no' },
      { header: 'Email', dataKey: 'email' },
      { header: 'Purpose Of Visit', dataKey: 'purpose_of_visit' },
      { header: 'Organization Name', dataKey: 'visitorOrgName' },
      { header: 'Last Entry', dataKey: 'last_entry' },
      { header: 'Last Exit', dataKey: 'last_exit' },
      { header: 'Acess Reference code', dataKey: 'last_visited_code' },
      { header: 'Photo', dataKey: 'photo' },
      { header: 'KYC Type', dataKey: 'kyc_type' },
      { header: 'KYC ID', dataKey: 'kyc_id' },
    ]

    // Prepare table rows with placeholder for images
    const tableRows = rowsWithImages.map((rowData) => {
      return tableColumns.map((col) => {
        let cellValue = rowData[col.dataKey] || 'N/A'
        
        // Special handling for Phone Number - show N/A if empty
        if (col.dataKey === 'ph_no') {
          const phExt = rowData['ph_ext'] || ''
          const phNo = rowData['ph_no'] || ''
          cellValue = phNo && phExt ? `${phExt}-${phNo}` : 'N/A'
        }
        
        // Special handling for Email - show N/A if empty
        if (col.dataKey === 'email') {
          cellValue = cellValue || 'N/A'
        }
        
        // Special handling for Photo - use placeholder if image exists
        if (col.dataKey === 'photo') {
          if (rowData.base64Photo) {
            cellValue = 'IMAGE_PLACEHOLDER'
          } else {
            cellValue = 'N/A'
          }
        }
        
        return cellValue
      })
    })

    // Add the table to the PDF
    doc.autoTable({
      startY: 120, // Start after the header
      head: [tableColumns.map((col) => col.header)],
      body: tableRows,
      styles: { fontSize: 9, cellPadding: 3 },
      columnStyles: {
        0: { cellWidth: 80 }, // Adjust column widths as needed
        1: { cellWidth: 100 },
        2: { cellWidth: 100 },
        3: { cellWidth: 80 },
        4: { cellWidth: 80 },
        5: { cellWidth: 100 },
        6: { cellWidth: 120 },
        7: { cellWidth: 100 },
        8: { cellWidth: 80 },
        10: { cellWidth: 80 }, // Photo column
      },
      headStyles: { fillColor: [39, 174, 96] }, // Teal color for table header
      horizontalPageBreak: true, // Automatically add page breaks
      didDrawCell: (data) => {
        // Handle image rendering in Photo column (column index 10)
        if (data.column.index === 10 && data.cell.raw === 'IMAGE_PLACEHOLDER') {
          const rowIndex = data.row.index
          const rowData = rowsWithImages[rowIndex]
          
          if (rowData && rowData.base64Photo) {
            try {
              // Clear the cell
              data.doc.setFillColor(255, 255, 255)
              data.doc.rect(
                data.cell.x,
                data.cell.y,
                data.cell.width,
                data.cell.height,
                'F',
              )
              
              // Extract base64 data
              const base64Data = rowData.base64Photo.split(',')[1]
              
              // Determine image format
              let imageFormat = 'JPEG'
              if (rowData.base64Photo.includes('data:image/png')) {
                imageFormat = 'PNG'
              } else if (rowData.base64Photo.includes('data:image/jpeg')) {
                imageFormat = 'JPEG'
              }
              
              // Calculate image size to fit in cell
              const cellWidth = data.cell.width
              const cellHeight = data.cell.height
              const padding = 4
              const imgWidth = Math.max(10, cellWidth - padding * 2)
              const imgHeight = Math.max(10, cellHeight - padding * 2)
              const x = data.cell.x + padding
              const y = data.cell.y + padding
              
              // Add image to PDF
              data.doc.addImage(
                base64Data,
                imageFormat,
                x,
                y,
                imgWidth,
                imgHeight,
              )
            } catch (error) {
              console.error('Error rendering image in PDF:', error)
            }
          }
        }
      },
    })

    // Save the PDF
    doc.save('visitors_report_custom_styled.pdf')
  }

  // Download functions for Group Booking and Vehicle/Material PDF
  const downloadGroupBookingPDF = () => {
    if (!gridApiRef.current) {
      toast.error('Export failed: Grid API not initialized.')
      return
    }

    const doc = new jsPDF({
      orientation: 'landscape',
      unit: 'pt',
      format: [1700, 700], // Custom page size
    })

    // Add a teal background for the header
    doc.setFillColor(39, 174, 96) // Teal color
    doc.rect(0, 0, doc.internal.pageSize.width, 100, 'F') // Fill the top area with teal color

    // Add the "Group Booking Report" heading in the middle
    doc.setFontSize(20)
    doc.setTextColor(255, 255, 255) // White text color
    const pageWidth = doc.internal.pageSize.width
    const textWidth = doc.getTextWidth('Group Booking Report')
    const centerX = (pageWidth - textWidth) / 2
    doc.text('Group Booking Report', centerX, 40) // Centered title

    // Static data for branch name and date
    const Admin = `Admin: ${name || ''}`
    const branchName = `Branch Name: ${selectedBranch?.branch_name || 'N/A'}`
    const reportDate = `Date Range: ${format(start_date, 'dd-MM-yyyy')} to ${format(to_date, 'dd-MM-yyyy')}`

    // Add the branch name below the title
    doc.setFontSize(14)
    doc.setTextColor(255, 255, 255) // White text color
    doc.text(Admin, 40, 40)
    doc.text(branchName, 40, 60) // Branch name on the left

    // Add the date below the branch name
    doc.text(reportDate, 40, 80) // Report date on the left

    // Adjust the layout below the header
    doc.setTextColor(0) // Reset text color for table content

    // Define table columns for group booking
    const tableColumns = [
      { header: 'Name', dataKey: 'fullName' },
      { header: 'Category', dataKey: 'role' },
      { header: 'Phone Extension', dataKey: 'ph_ext' },
      { header: 'Phone Number', dataKey: 'ph_no' },
      { header: 'Email', dataKey: 'email' },
      { header: 'Purpose Of Visit', dataKey: 'purpose_of_visit' },
      { header: 'Organization Name', dataKey: 'visitorOrgName' },
      { header: 'Last Entry', dataKey: 'last_entry' },
      { header: 'Last Exit', dataKey: 'last_exit' },
    ]

    // Fetch displayed rows from grid
    const tableRows = []
    gridApiRef.current.forEachNodeAfterFilterAndSort((rowNode) => {
      tableRows.push(
        tableColumns.map((col) => rowNode.data[col.dataKey] || 'N/A'), // Handle missing data with 'N/A'
      )
    })

    // Check if there's no data
    if (tableRows.length === 0) {
      // Show message instead of empty table
      doc.setFontSize(14)
      doc.setTextColor(0, 0, 0)
      doc.text('No Group Booking Data Available', 40, 140)
      doc.save('group_booking_report.pdf')
      return
    }

    // Add the table to the PDF
    doc.autoTable({
      startY: 120, // Start after the header
      head: [tableColumns.map((col) => col.header)],
      body: tableRows,
      styles: { fontSize: 9, cellPadding: 3 },
      columnStyles: {
        0: { cellWidth: 80 }, // Adjust column widths as needed
        1: { cellWidth: 100 },
        2: { cellWidth: 100 },
        3: { cellWidth: 80 },
        4: { cellWidth: 80 },
        5: { cellWidth: 100 },
        6: { cellWidth: 120 },
        7: { cellWidth: 100 },
        8: { cellWidth: 80 },
      },
      headStyles: { fillColor: [39, 174, 96] }, // Teal color for table header
      horizontalPageBreak: true, // Automatically add page breaks
    })

    // Save the PDF
    doc.save('group_booking_report.pdf')
  }

  const downloadVehicleMaterialPDF = () => {
    if (!gridApiRef.current) {
      toast.error('Export failed: Grid API not initialized.')
      return
    }

    const doc = new jsPDF({
      orientation: 'landscape',
      unit: 'pt',
      format: [1700, 700], // Custom page size
    })

    // Add green header background matching the image
    doc.setFillColor(39, 174, 96) // Green color matching the image
    doc.rect(0, 0, doc.internal.pageSize.width, 100, 'F') // Fill the top area with green

    // Add admin details on the left side of header (white text)
    doc.setFontSize(12)
    doc.setTextColor(255, 255, 255) // White text
    const Admin = `Admin: ${name || 'Organization Admin'}`
    const branchName = `Branch Name: ${selectedBranch?.branch_name || 'All Branches'}`
    const reportDate = `Date: ${format(new Date(), 'dd-MM-yyyy')}`

    doc.text(Admin, 40, 30)
    doc.text(branchName, 40, 50)
    doc.text(reportDate, 40, 70)

    // Add report title on the right side of header (white text)
    doc.setFontSize(16)
    doc.setTextColor(255, 255, 255) // White text
    const pageWidth = doc.internal.pageSize.width
    const textWidth = doc.getTextWidth('Vehicle/Material Reports')
    const centerX = pageWidth - textWidth - 40 // Right align
    doc.text('Vehicle/Material Reports', centerX, 50)

    // Adjust the layout below the header
    doc.setTextColor(0) // Reset text color for table content

    // Define table columns for vehicle/material with proper fields
    const tableColumns = [
      'Visitor Name',
      'Vehicle Name',
      'Vehicle Type',
      'Driver License',
      'RC Number',
      'Insurance Provider',
      'Insurance Number',
      'Material Name',
      'Material Description',
      'Material Quantity',
      'Material Serial Number',
      'Vehicle Comments',
      'Material Comments',
    ]

    // Fetch displayed rows from grid and expand vehicle/material details
    const tableRows = []
    gridApiRef.current.forEachNodeAfterFilterAndSort((rowNode) => {
      const visitor = rowNode.data

      // Skip group members - only process main visitors for Vehicle/Material reports
      if (visitor.isGroupMember) {
        return
      }

      const visitorRows = []
      const hasVehicleDetails =
        visitor.vm_details && visitor.vm_details.length > 0
      const hasMaterialDetails =
        visitor.mm_details && visitor.mm_details.length > 0

      // Get the correct name - show actual main visitor names
      const displayName = visitor.fullName || 'N/A'

      if (hasVehicleDetails) {
        // Process each vehicle and its associated materials
        visitor.vm_details.forEach((vehicle) => {
          // Find materials associated with this specific vehicle
          const associatedMaterials = hasMaterialDetails
            ? visitor.mm_details.filter(
                (material) =>
                  material.material_vehicle_id === vehicle.vehicle_id,
              )
            : []

          if (associatedMaterials.length > 0) {
            // Vehicle has associated materials - create one row per material
            associatedMaterials.forEach((material) => {
              visitorRows.push([
                displayName,
                vehicle.vehicle_name || 'N/A',
                vehicle.vehicle_type || 'N/A',
                vehicle.driver_licence || 'N/A',
                vehicle.rc_no || 'N/A',
                vehicle.insurance_provider || 'N/A',
                vehicle.insurance_no || 'N/A',
                material.material_name || 'N/A',
                material.material_description || 'N/A',
                material.material_quantity || 'N/A',
                material.material_s_n || 'N/A',
                vehicle.vehicle_comments || 'N/A',
                material.material_comments || 'N/A',
              ])
            })
          } else {
            // Vehicle exists but no associated materials
            visitorRows.push([
              displayName,
              vehicle.vehicle_name || 'N/A',
              vehicle.vehicle_type || 'N/A',
              vehicle.driver_licence || 'N/A',
              vehicle.rc_no || 'N/A',
              vehicle.insurance_provider || 'N/A',
              vehicle.insurance_no || 'N/A',
              'N/A', // No material
              'N/A', // No material
              'N/A', // No material
              'N/A', // No material
              vehicle.vehicle_comments || 'N/A',
              'N/A', // No material
            ])
          }
        })
      }

      // Handle materials that are not associated with any vehicle
      if (hasMaterialDetails) {
        const materialsHandledByVehicles = new Set()
        if (hasVehicleDetails) {
          visitor.vm_details.forEach((vehicle) => {
            const associatedMaterials = visitor.mm_details.filter(
              (material) => material.material_vehicle_id === vehicle.vehicle_id,
            )
            associatedMaterials.forEach((material) => {
              materialsHandledByVehicles.add(material.material_id)
            })
          })
        }

        // Add materials that are not associated with any vehicle
        visitor.mm_details.forEach((material) => {
          if (!materialsHandledByVehicles.has(material.material_id)) {
            visitorRows.push([
              displayName,
              'N/A', // No vehicle
              'N/A', // No vehicle
              'N/A', // No vehicle
              'N/A', // No vehicle
              'N/A', // No vehicle
              'N/A', // No vehicle
              material.material_name || 'N/A',
              material.material_description || 'N/A',
              material.material_quantity || 'N/A',
              material.material_s_n || 'N/A',
              'N/A', // No vehicle
              material.material_comments || 'N/A',
            ])
          }
        })
      }

      // If no vehicle or material data at all, add a single row with N/A for everything
      if (!hasVehicleDetails && !hasMaterialDetails) {
        visitorRows.push([
          displayName,
          'N/A',
          'N/A',
          'N/A',
          'N/A',
          'N/A',
          'N/A', // Vehicle fields
          'N/A',
          'N/A',
          'N/A',
          'N/A', // Material fields
          'N/A',
          'N/A', // Comments
        ])
      }

      // Add all visitor rows to the main table rows
      tableRows.push(...visitorRows)
    })

    // Add the table to the PDF
    doc.autoTable({
      startY: 110, // Start after the green header
      head: [tableColumns],
      body: tableRows,
      styles: {
        fontSize: 8,
        cellPadding: 3,
        overflow: 'linebreak',
        halign: 'left',
        textColor: [0, 0, 0], // Black text for data rows
      },
      headStyles: {
        fillColor: [39, 174, 96], // Green header matching the image
        fontSize: 9,
        fontStyle: 'bold',
        textColor: [255, 255, 255], // White text for header
      },
      columnStyles: {
        // Increased column widths to utilize more landscape space (custom page size)
        0: { cellWidth: 120 }, // Visitor Name
        1: { cellWidth: 100 }, // Vehicle Name
        2: { cellWidth: 90 }, // Vehicle Type
        3: { cellWidth: 120 }, // Driver License
        4: { cellWidth: 100 }, // RC Number
        5: { cellWidth: 120 }, // Insurance Provider
        6: { cellWidth: 120 }, // Insurance Number
        7: { cellWidth: 100 }, // Material Name
        8: { cellWidth: 150 }, // Material Description
        9: { cellWidth: 90 }, // Material Quantity
        10: { cellWidth: 120 }, // Material Serial Number
        11: { cellWidth: 120 }, // Vehicle Comments
        12: { cellWidth: 120 }, // Material Comments
      },
      horizontalPageBreak: true, // Automatically add page breaks
    })

    // Save the PDF
    doc.save('vehicle_material_report.pdf')
  }

  // Download functions for Group Booking and Vehicle/Material CSV
  const downloadGroupBookingCSV = () => {
    if (!gridApiRef.current) {
      toast.error('Export failed: Grid API not initialized.')
      return
    }

    // Manually extract data from the grid and format it for CSV export
    const columnHeaders = [
      'Name',
      'Category',
      'Phone Extension',
      'Phone Number',
      'Email',
      'Purpose Of Visit',
      'Organization Name',
      'Last Entry',
      'Last Exit',
    ]

    const columnKeys = [
      'fullName',
      'role',
      'ph_ext',
      'ph_no',
      'email',
      'purpose_of_visit',
      'visitorOrgName',
      'last_entry',
      'last_exit',
    ]

    // Fetch displayed rows from the grid
    let csvRows = []
    let hasData = false

    gridApiRef.current.forEachNodeAfterFilterAndSort((rowNode) => {
      hasData = true
      let row = columnKeys.map((key) => {
        let cellValue = rowNode.data[key] || 'N/A' // Handle missing data
        return `"${cellValue}"` // Ensure values are properly formatted
      })
      csvRows.push(row.join(','))
    })

    // Check if there's no data
    if (!hasData || csvRows.length === 0) {
      toast.error('No group booking data available to download')
      return
    }

    // Add the column headers at the beginning
    csvRows.unshift(columnHeaders.join(','))

    // Convert array to CSV format
    const csvContent = csvRows.join('\n')

    // Create a downloadable CSV file
    const blob = new Blob([csvContent], { type: 'text/csv' })
    const link = document.createElement('a')
    link.href = URL.createObjectURL(blob)
    link.download = 'Group Booking Report.csv'
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const downloadVehicleMaterialCSV = () => {
    if (!gridApiRef.current) {
      toast.error('Export failed: Grid API not initialized.')
      return
    }

    console.log('🔍 VisitorReportsTable - Starting CSV download')

    // Define column headers for vehicle/material data
    const columnHeaders = [
      'Visitor Name',
      'Vehicle Name',
      'Vehicle Type',
      'Driver License',
      'RC Number',
      'Insurance Provider',
      'Insurance Number',
      'Material Name',
      'Material Description',
      'Material Quantity',
      'Material Serial Number',
      'Vehicle Comments',
      'Material Comments',
    ]

    // Fetch displayed rows from the grid and expand vehicle/material details
    let csvRows = []

    // Add the column headers
    csvRows.push(columnHeaders.join(','))

    gridApiRef.current.forEachNodeAfterFilterAndSort((rowNode) => {
      const visitor = rowNode.data

      // Skip group members - only process main visitors for Vehicle/Material reports
      if (visitor.isGroupMember) {
        return
      }

      console.log(
        '🔍 VisitorReportsTable - Processing visitor:',
        visitor.fullName,
        'Data:',
        visitor,
      )
      console.log(
        '🔍 VisitorReportsTable - vm_details:',
        visitor.vm_details,
        'mm_details:',
        visitor.mm_details,
      )

      // Check if visitor has vehicle/material data
      if (visitor.vm_details && visitor.vm_details.length > 0) {
        // Process vehicle details
        visitor.vm_details.forEach((vehicle) => {
          if (visitor.mm_details && visitor.mm_details.length > 0) {
            // Process material details for each vehicle
            visitor.mm_details.forEach((material) => {
              const row = [
                displayName,
                vehicle.vehicle_name || 'N/A',
                vehicle.vehicle_type || 'N/A',
                vehicle.driver_licence || 'N/A',
                vehicle.rc_no || 'N/A',
                vehicle.insurance_provider || 'N/A',
                vehicle.insurance_no || 'N/A',
                material.material_name || 'N/A',
                material.material_description || 'N/A',
                material.material_quantity || 'N/A',
                material.material_s_n || 'N/A',
                vehicle.vehicle_comments || 'N/A',
                material.material_comments || 'N/A',
              ]
              csvRows.push(row.map((cell) => `"${cell}"`).join(','))
            })
          } else {
            // Only vehicle data, no materials
            const row = [
              displayName,
              vehicle.vehicle_name || 'N/A',
              vehicle.vehicle_type || 'N/A',
              vehicle.driver_licence || 'N/A',
              vehicle.rc_no || 'N/A',
              vehicle.insurance_provider || 'N/A',
              vehicle.insurance_no || 'N/A',
              'N/A', // No material
              'N/A', // No material
              'N/A', // No material
              'N/A', // No material
              vehicle.vehicle_comments || 'N/A',
              'N/A', // No material
            ]
            csvRows.push(row.map((cell) => `"${cell}"`).join(','))
          }
        })
      } else if (visitor.mm_details && visitor.mm_details.length > 0) {
        // Only material data, no vehicles
        visitor.mm_details.forEach((material) => {
          const row = [
            displayName,
            'N/A', // No vehicle
            'N/A', // No vehicle
            'N/A', // No vehicle
            'N/A', // No vehicle
            'N/A', // No vehicle
            'N/A', // No vehicle
            material.material_name || 'N/A',
            material.material_description || 'N/A',
            material.material_quantity || 'N/A',
            material.material_s_n || 'N/A',
            'N/A', // No vehicle
            material.material_comments || 'N/A',
          ]
          csvRows.push(row.map((cell) => `"${cell}"`).join(','))
        })
      } else {
        // No vehicle/material data - show what we have
        console.log(
          '🔍 No vehicle/material data found for visitor:',
          visitor.fullName,
          'Available fields:',
          Object.keys(visitor),
        )
        const row = [
          displayName,
          'N/A',
          'N/A',
          'N/A',
          'N/A',
          'N/A',
          'N/A',
          'N/A',
          'N/A',
          'N/A',
          'N/A',
          'N/A',
          'N/A',
        ]
        csvRows.push(row.map((cell) => `"${cell}"`).join(','))
      }
    })

    // Convert array to CSV format
    const csvContent = csvRows.join('\n')

    // Create a downloadable CSV file
    const blob = new Blob([csvContent], { type: 'text/csv' })
    const link = document.createElement('a')
    link.href = URL.createObjectURL(blob)
    link.download = 'Vehicle Material Report.csv'
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  return (
    <div>
      <div className="flex items-center space-x-4 mb-4">
        {/* Toggle Button */}
        <button
          onClick={handleToggle}
          className="bg-gray-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-gray-600 transition-colors"
        >
          {isPDF ? (
            <>
              <FontAwesomeIcon icon={faToggleOn} className="mr-1.5 text-xs" />
              Switch to CSV
            </>
          ) : (
            <>
              <FontAwesomeIcon icon={faToggleOff} className="mr-1.5 text-xs" />
              Switch to PDF
            </>
          )}
        </button>

        {/* Conditional Buttons */}
        {isPDF ? (
          <>
            <button
              onClick={onExportPDF}
              className="bg-green-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-green-600 transition-colors"
            >
              Download PDF
              <FontAwesomeIcon icon={faDownload} className="ml-1.5 text-xs" />
            </button>
            <button
              onClick={downloadGroupBookingPDF}
              className="bg-green-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-green-600 transition-colors"
            >
              Download Group Booking PDF
              <FontAwesomeIcon icon={faDownload} className="ml-1.5 text-xs" />
            </button>
            <button
              onClick={downloadVehicleMaterialPDF}
              className="bg-green-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-green-600 transition-colors"
            >
              Download Vehicle/Material PDF
              <FontAwesomeIcon icon={faDownload} className="ml-1.5 text-xs" />
            </button>
          </>
        ) : (
          <>
            <button
              onClick={onExport}
              className="bg-blue-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-blue-600 transition-colors"
            >
              Download CSV
              <FontAwesomeIcon icon={faDownload} className="ml-1.5 text-xs" />
            </button>
            <button
              onClick={downloadGroupBookingCSV}
              className="bg-blue-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-blue-600 transition-colors"
            >
              Download Group Booking CSV
              <FontAwesomeIcon icon={faDownload} className="ml-1.5 text-xs" />
            </button>
            <button
              onClick={downloadVehicleMaterialCSV}
              className="bg-blue-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-blue-600 transition-colors"
            >
              Download Vehicle/Material CSV
              <FontAwesomeIcon icon={faDownload} className="ml-1.5 text-xs" />
            </button>
          </>
        )}
      </div>
      <br />
      {loading ? (
        <div>Loading...</div>
      ) : (
        <div
          className="ag-theme-material"
          style={{ height: 500, width: '100%' }}
        >
          <AgGridReact
            rowData={rowData}
            columnDefs={columnDefs}
            pagination={true}
            paginationPageSize={20}
            onGridReady={onGridReady}
            rowHeight={60}
          />
        </div>
      )}
    </div>
  )
}

export default VisitorsTable
