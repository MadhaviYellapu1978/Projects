import React from 'react'

const Logo = () => {
  return (
    <h1 className="text-4xl font-bold text-primary text-center">
      Visi<span className="text-secondary">Q</span>
    </h1>
  )
}

export default Logo
