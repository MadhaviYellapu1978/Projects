import React from 'react'
import { useField, useFormikContext } from 'formik'
import FormikTextField from '../lib/Formik/FormikTextfield'
import { apiCall } from '../utils/apiCall.js'

const ValidateUsername = () => {
  const { setFieldError, validateField } = useFormikContext()
  const [field] = useField('username')

  const validateUsername = async (username) => {
    if (username?.length > 6) {
      try {
        const response = await apiCall(`/auth/availUser`, 'POST', {
          username,
        })
        if (!response.isAvail) {
          setFieldError('username', 'Username is already taken')
        }
      } catch (error) {
        console.error('Error checking username availability:', error)
      }
    }
  }

  const handleBlur = async (e) => {
    field.onBlur(e)
    await validateUsername(e.target.value)
    validateField('username')
  }

  return (
    <FormikTextField
      name="username"
      label="Username"
      sx={{ minWidth: 350 }}
      onBlur={handleBlur}
    />
  )
}

export default ValidateUsername
