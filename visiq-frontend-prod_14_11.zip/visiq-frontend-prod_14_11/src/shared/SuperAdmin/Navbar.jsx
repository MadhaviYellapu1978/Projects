// eslint-disable-next-line no-unused-vars
import React, { useContext } from 'react'
import Logo from '../Logo'
import { logout } from '../../assets'
import { useNavigate } from 'react-router-dom'
import Pick from '../../assets/profile2.svg'
import { AuthContext } from '../../context/AuthContext'
// import { userData } from '../../utils/user_data'

const getRoleName = (role) => {
  switch (role) {
    case '1':
      return 'SuperAdmin'
    case '2':
      return 'Admin'
    case '3':
      return 'BranchAdmin'
    case '4':
      return 'securityLevelAdmin'
    default:
      return 'User' // Default role name if role is not recognized
  }
}

const Navbar = () => {
  const navigate = useNavigate()
  const auth = useContext(AuthContext)
  return (
    <>
      <nav className="navbar bg-base-100 drop-shadow sticky top-0 z-50">
        <div className="flex-1">
          <a className=" text-xl">
            <Logo />
          </a>
        </div>
        <div className="flex-none flex items-center gap-4">
          <div className="flex items-center gap-2">
            <img
              src={Pick} // Example avatar URL
              alt="avatar"
              className="h-12 w-12 rounded-full"
            />

            <span>{getRoleName(auth.role)}</span>
          </div>
          <button
            className="btn btn-ghost"
            onClick={() => {
              auth.logout()
              navigate('/auth/login')
            }}
          >
            <img src={logout} alt="logout" className="h-4" />
          </button>
        </div>
      </nav>
    </>
  )
}

export default Navbar
