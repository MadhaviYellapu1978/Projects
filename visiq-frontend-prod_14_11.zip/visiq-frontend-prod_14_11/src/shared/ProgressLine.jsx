import React from 'react'
import { Box, LinearProgress } from '@mui/material'

/**
 * Animated progress line component for upload operations
 * @param {boolean} isActive - Whether the progress line should be active
 * @param {string} color - Color of the progress line (default: 'primary')
 * @param {number} height - Height of the progress line (default: 4)
 */
const ProgressLine = ({ isActive, color = 'primary', height = 4 }) => {
  return (
    <Box
      sx={{
        width: '100%',
        position: 'relative',
        mt: 1,
        opacity: isActive ? 1 : 0,
        transition: 'opacity 0.3s ease-in-out',
      }}
    >
      <LinearProgress
        variant="indeterminate"
        color={color}
        sx={{
          height: height,
          borderRadius: height / 2,
          backgroundColor: 'rgba(0, 0, 0, 0.1)',
          '& .MuiLinearProgress-bar': {
            borderRadius: height / 2,
            background: `linear-gradient(90deg, 
              ${color === 'primary' ? '#1976d2' : color === 'success' ? '#2e7d32' : '#1976d2'}, 
              ${color === 'primary' ? '#42a5f5' : color === 'success' ? '#4caf50' : '#42a5f5'})`,
            animation: 'progress-animation 2s ease-in-out infinite',
          },
        }}
      />
      <style jsx>{`
        @keyframes progress-animation {
          0% {
            transform: translateX(-100%);
          }
          50% {
            transform: translateX(0%);
          }
          100% {
            transform: translateX(100%);
          }
        }
      `}</style>
    </Box>
  )
}

export default ProgressLine
