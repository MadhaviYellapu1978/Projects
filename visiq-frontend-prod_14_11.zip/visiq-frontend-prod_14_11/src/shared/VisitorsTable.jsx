import React, { useMemo, useState, useEffect, useRef, useContext } from 'react'
import jsPDF from 'jspdf'
import 'jspdf-autotable'
import Papa from 'papaparse'
import { saveAs } from 'file-saver'
import { formatDate, formatDateTime } from '../utils/dateFormat'
import { format } from 'date-fns'
import { AgGridReact } from 'ag-grid-react'
import * as yup from 'yup'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {
  faDownload,
  faEdit,
  faToggleOn,
  faToggleOff,
} from '@fortawesome/free-solid-svg-icons'
import TextField from '@mui/material/TextField'
import { Formik, Form } from 'formik'
import FormikTextField from '../lib/Formik/FormikTextfield'
import FormikTimePicker from '../lib/Formik/FormikTimePicker'
import FormikDatePicker from '../lib/Formik/FormikDatePicker'
import Modal from '@mui/material/Modal'
import Box from '@mui/material/Box'
import * as Yup from 'yup'
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query'
import {
  extendTimeDuringVisit,
  getAllVisitors,
  listOfCountriesExt,
  updateVisitorData,
} from '../services/adminService'
import toast from 'react-hot-toast'
import { AuthContext } from '../context/AuthContext'
import { styles, stylees } from '../constants/styes.js'
import FormikSelect from '../lib/Formik/FormikSelect'
import MultiSelectForm from '../lib/Formik/MultiSelectForm.jsx'

const timeToMinutes = (timeStr) => {
  const [hours, minutes] = timeStr.split(':').map(Number)
  return hours * 60 + minutes
}

// Helper function to extract numeric code from visitor_code
// Main visitor: "GM-0022563" -> "0022563"
// Group visitor: "G-0022563" -> "0022563"
const extractVisitorCodeNumber = (visitorCode) => {
  if (!visitorCode || typeof visitorCode !== 'string') return null
  // Extract the numeric part after the last hyphen
  const parts = visitorCode.split('-')
  if (parts.length >= 2) {
    return parts[parts.length - 1] // Return the last part (numeric code)
  }
  return null
}

// Helper function to check if visitor codes match (by numeric part)
const doVisitorCodesMatch = (mainVisitorCode, groupVisitorCode) => {
  const mainCode = extractVisitorCodeNumber(mainVisitorCode)
  const groupCode = extractVisitorCodeNumber(groupVisitorCode)
  return mainCode !== null && groupCode !== null && mainCode === groupCode
}

const validationSchemas = Yup.object().shape({
  time_to_exit: Yup.string()
    .test(
      'is-greater',
      'Visit End Time must be greater than Visit Start Time',
      function (value) {
        const { time_of_visit } = this.parent
        return timeToMinutes(value) > timeToMinutes(time_of_visit)
      },
    )
    .required('Visit End Time is required'),
  phNo: Yup.string(),
  ph_ext: Yup.string(),
})

const VisitorsTable = ({
  data,
  allVisitorsData,
  onUpdateVisitors,
  orgId,
  branch_id,
  data_of_visit,
  branch,
  visitorType,
  name,
  report_name,
}) => {
  const auth = useContext(AuthContext)
  const [rowData, setRowData] = useState([])
  const [selectedVisitor, setSelectedVisitor] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [openModal, setOpenModal] = useState(false)
  const [expandedVisitors, setExpandedVisitors] = useState({})
  const [isPDF, setIsPDF] = useState(true) // Toggle state for PDF/CSV
  const queryClient = useQueryClient()
  const gridApiRef = useRef(null)

  // Helper function to normalize email (ensure it contains @)
  const normalizeEmail = (val) =>
    typeof val === 'string' && val.includes('@') ? val : ''

  // Helper function to map visitor_type to display name
  const getVisitorTypeDisplay = (visitorType, isGroupMember, isMainVisitor) => {
    if (isGroupMember) {
      return 'Group Visitor'
    }
    if (isMainVisitor) {
      return 'Main Visitor'
    }
    switch (visitorType) {
      case 'main_visitor':
        return 'Main Visitor'
      case 'group_visitor':
        return 'Group Visitor'
      case 'group_member':
        return 'Group Visitor'
      case 'individual_visitor':
        return 'Individual Visitor'
      default:
        return visitorType || 'Individual Visitor'
    }
  }

  useEffect(() => {
    try {
      setError(null) // Clear any previous errors

      if (!data) {
        setError('No data available')
        setRowData([])
        return
      }

      if (data.length === 0) {
        setError('No visitors found')
        setRowData([])
        return
      }

      // Process visitors for accordion functionality using visitor_type and main_visitor_name
      const processedData = []
      const mainVisitors = []
      const groupVisitors = []

      // First pass: separate main visitors and group visitors based on visitor_type
      data.forEach((item) => {
        // Check if this is a main visitor based on visitor_type
        const isMainVisitor =
          item.visitor_type === 'main_visitor' || item.isMainVisitor === true

        if (isMainVisitor) {
          // Check if main visitor has group details
          const hasGroupDetails =
            item.grp_book_bool &&
            item.grp_details &&
            item.grp_details.length > 0
          mainVisitors.push({
            ...item,
            fullName: `${item.first_name} ${item.last_name}`,
            phNos: `${item.ph_ext}-${item.phNo}`,
            action: item.isVisited ? 'Arrived' : 'Yet To Arrive',
            time_extended: '',
            isMainVisitor: true,
            hasGroupMembers: true, // Will be determined by actual group members
            checkedInGroupMembersCount: 0, // Will be calculated
            email: normalizeEmail(item.email),
            // Dates are already formatted in Dashboard Presentation files
            start_date: item.start_date,
            end_date: item.end_date,
            // Set mm_bool to true when group visitors are present
            mm_bool: hasGroupDetails ? true : item.mm_bool,
            mm_details: hasGroupDetails
              ? item.mm_details || []
              : item.mm_details,
          })
        } else if (item.visitor_type === 'group_visitor') {
          // This is a group visitor
          // Get email from item.email or item.grp_user_email (for group visitors)
          const groupVisitorEmail =
            normalizeEmail(item.email) ||
            normalizeEmail(item.grp_user_email) ||
            ''
          groupVisitors.push({
            ...item,
            fullName: `${item.first_name} ${item.last_name}`,
            phNos: `${item.ph_ext}-${item.phNo}`,
            action: item.isVisited ? 'Arrived' : 'Yet To Arrive',
            time_extended: '',
            isMainVisitor: false,
            isGroupMember: true,
            hasGroupMembers: false,
            email: groupVisitorEmail,
            // Dates are already formatted in Dashboard Presentation files
            start_date: item.start_date,
            end_date: item.end_date,
            // Set mm_bool to true when group visitors are present
            mm_bool: true,
            mm_details: item.mm_details || [],
          })
        } else {
          // Standalone visitor (no group relationship)
          processedData.push({
            ...item,
            fullName: `${item.first_name} ${item.last_name}`,
            phNos: `${item.ph_ext}-${item.phNo}`,
            action: item.isVisited ? 'Arrived' : 'Yet To Arrive',
            time_extended: '',
            isMainVisitor: false,
            hasGroupMembers: false,
            isGroupMember: false,
            email: normalizeEmail(item.email),
            // Dates are already formatted in Dashboard Presentation files
            start_date: item.start_date,
            end_date: item.end_date,
          })
        }
      })

      // Second pass: group visitors under their main visitors using visitor_code and date
      mainVisitors.forEach((mainVisitor) => {
        // Get main visitor's visitor_code and date for matching
        const mainVisitorCode = mainVisitor.visitor_code
        const mainVisitorDate =
          mainVisitor.date_of_visit || mainVisitor.start_date

        // Find group members for this main visitor using visitor_code (numeric part) and date
        const groupMembers = groupVisitors.filter((groupVisitor) => {
          // Match by visitor_code (numeric part) and date
          const codesMatch = doVisitorCodesMatch(
            mainVisitorCode,
            groupVisitor.visitor_code,
          )
          const groupVisitorDate =
            groupVisitor.date_of_visit || groupVisitor.start_date
          const datesMatch = mainVisitorDate === groupVisitorDate

          return codesMatch && datesMatch
        })

        // Update main visitor with group member count
        mainVisitor.checkedInGroupMembersCount = groupMembers.length
        mainVisitor.hasGroupMembers = groupMembers.length > 0
        mainVisitor.groupMembers = groupMembers // Store group members for accordion
        // Set mm_bool to true when group visitors are present
        if (groupMembers.length > 0) {
          mainVisitor.mm_bool = true
          mainVisitor.mm_details = mainVisitor.mm_details || []
        }

        processedData.push(mainVisitor)
      })

      // Add standalone group visitors whose main visitor is not in the current data set
      const standaloneGroupVisitors = groupVisitors.filter((groupVisitor) => {
        // Check if the main visitor is not in the current data set using visitor_code and date
        const groupVisitorCode = groupVisitor.visitor_code
        const groupVisitorDate =
          groupVisitor.date_of_visit || groupVisitor.start_date

        const mainVisitorExists = data.some((visitor) => {
          const isMainVisitor =
            visitor.visitor_type === 'main_visitor' ||
            visitor.isMainVisitor === true

          if (!isMainVisitor) return false

          // Match by visitor_code (numeric part) and date
          const codesMatch = doVisitorCodesMatch(
            visitor.visitor_code,
            groupVisitorCode,
          )
          const visitorDate = visitor.date_of_visit || visitor.start_date
          const datesMatch = visitorDate === groupVisitorDate

          return codesMatch && datesMatch
        })

        return !mainVisitorExists
      })

      standaloneGroupVisitors.forEach((visitor) => {
        processedData.push({
          ...visitor,
          // Dates are already formatted in Dashboard Presentation files
          start_date: visitor.start_date,
          end_date: visitor.end_date,
          // Set mm_bool to true when group visitors are present
          mm_bool: true,
          mm_details: visitor.mm_details || [],
        })
      })

      const updatedData = processedData.map((v) => ({
        ...v,
        email: normalizeEmail(v.email),
        // Dates are already formatted in Dashboard Presentation files, so don't format again here
        // This prevents double conversion (DD-MM-YYYY -> MM-DD-YYYY -> DD-MM-YYYY)
        start_date: v.start_date,
        end_date: v.end_date,
      }))
      setRowData(updatedData)
    } catch (err) {
      console.error('Error processing visitor data:', err)
      setError('Error loading visitor data. Please try again.')
      setRowData([])
    }
  }, [data, visitorType])

  const handleToggle = () => {
    setIsPDF(!isPDF)
  }

  // Function to toggle visitor expansion
  const toggleVisitorExpansion = (visitorId) => {
    setExpandedVisitors((prev) => {
      const currentState = prev[visitorId] || false
      const newState = {
        ...prev,
        [visitorId]: !currentState,
      }
      return newState
    })

    // Force grid refresh to update the UI
    setTimeout(() => {
      if (gridApiRef.current) {
        gridApiRef.current.refreshCells({ force: true })
        gridApiRef.current.redrawRows()
      }
    }, 100)
  }

  // Function to get expanded row data including group members
  const getExpandedRowData = () => {
    const expandedData = []

    rowData.forEach((visitor) => {
      // Add main visitor row
      expandedData.push(visitor)

      // If visitor is expanded and has group members, add group member rows
      if (
        expandedVisitors[visitor.visitor_id] &&
        visitor.hasGroupMembers &&
        visitor.groupMembers
      ) {
        visitor.groupMembers.forEach((member, index) => {
          // Create group member row with proper data mapping
          // Get email from member.grp_user_email or member.email (for group members)
          const groupMemberEmail =
            normalizeEmail(member.grp_user_email) ||
            normalizeEmail(member.email) ||
            ''
          const groupMemberRow = {
            ...member,
            visitor_id: `${visitor.visitor_id}_group_${index}`,
            isGroupMember: true,
            isMainVisitor: false,
            hasGroupMembers: false,
            parentVisitorId: visitor.visitor_id, // Add parent visitor ID
            main_visitor_email: visitor.email || '',
            main_visitor_name: visitor.fullName || '',
            visitor_type: 'group_member',
            // Ensure email column shows only valid email (no phone fallback)
            email: groupMemberEmail,
          }

          expandedData.push(groupMemberRow)
        })
      }
    })

    return expandedData
  }

  // Function to get ALL data including group members for PDF/CSV exports
  const getAllDataForExport = () => {
    const allData = []
    const processedGroupVisitorIds = new Set() // Track processed group visitors

    // First, add all main visitors and their group members from rowData
    rowData.forEach((visitor) => {
      // Add main visitor row
      allData.push(visitor)

      // If visitor has group members, add ALL group member rows (regardless of expansion state or check-in status)
      if (visitor.hasGroupMembers && visitor.grp_details) {
        visitor.grp_details.forEach((member, index) => {
          // Parse group member name into first and last name
          const fullName = member.grp_user_name || ''
          const nameParts = fullName.split(' ')
          const firstName = nameParts[0] || ''
          const lastName = nameParts.slice(1).join(' ') || ''

          const groupMemberData = {
            ...member,
            fullName: member.grp_user_name,
            grp_user_name: member.grp_user_name,
            // Map group member fields to form field names
            first_name: firstName,
            last_name: lastName,
            phNo: member.grp_user_phno || '',
            ph_ext: member.grp_user_phext || '+91',
            phNos:
              `${member.grp_user_phext || ''} ${member.grp_user_phno || ''}`.trim(),
            start_date: visitor.start_date,
            end_date: visitor.end_date,
            time_of_visit: visitor.time_of_visit,
            time_to_exit: visitor.time_to_exit,
            role_name: member.grp_user_role_name || member.role_name,
            email:
              normalizeEmail(member.grp_user_email) ||
              normalizeEmail(member.email) ||
              '',
            purpose_of_visit: visitor.purpose_of_visit,
            bookingTime: visitor.bookingTime,
            action: visitor.action,
            visitor_code: visitor.visitor_code,
            // Inherit vehicle/material data from parent visitor
            vm_bool: visitor.vm_bool,
            mm_bool: visitor.mm_bool,
            vm_details: visitor.vm_details,
            mm_details: visitor.mm_details,
            grp_book_bool: visitor.grp_book_bool,
            grp_details: visitor.grp_details,
            visitor_id:
              member.grp_user_unique_id ||
              member.grp_user_id ||
              member.visitor_id ||
              `group_${visitor.visitor_id}_${index}`,
            branch_id: visitor.branch_id,
            org_id: visitor.org_id,
            areas_list: visitor.areas_list,
            isGroupMember: true,
            parentVisitorId: visitor.visitor_id,
            memberIndex: index,
          }

          allData.push(groupMemberData)
          // Track this group visitor ID to avoid duplicates
          if (groupMemberData.visitor_id) {
            processedGroupVisitorIds.add(groupMemberData.visitor_id)
          }
        })
      }

      // Also check groupMembers property (alternative structure)
      if (visitor.hasGroupMembers && visitor.groupMembers) {
        visitor.groupMembers.forEach((member) => {
          // Skip if already processed
          if (
            member.visitor_id &&
            processedGroupVisitorIds.has(member.visitor_id)
          ) {
            return
          }

          const groupMemberData = {
            ...member,
            fullName:
              member.fullName || `${member.first_name} ${member.last_name}`,
            phNos: member.phNos || `${member.ph_ext}-${member.phNo}`,
            isGroupMember: true,
            parentVisitorId: visitor.visitor_id,
          }

          allData.push(groupMemberData)
          if (groupMemberData.visitor_id) {
            processedGroupVisitorIds.add(groupMemberData.visitor_id)
          }
        })
      }
    })

    // Also include any standalone group visitors from the original data that might not be in rowData
    if (data && Array.isArray(data)) {
      data.forEach((item) => {
        // If it's a group visitor that hasn't been processed yet, add it
        if (
          (item.visitor_type === 'group_visitor' ||
            item.visitor_type === 'group_member') &&
          !item.isMainVisitor
        ) {
          // Check if already processed
          const itemId =
            item.visitor_id || item.grp_user_unique_id || item.grp_user_id
          if (itemId && processedGroupVisitorIds.has(itemId)) {
            return // Skip if already included
          }

          // Add standalone group visitor
          const groupVisitorData = {
            ...item,
            fullName: `${item.first_name || ''} ${item.last_name || ''}`.trim(),
            phNos: `${item.ph_ext || ''}-${item.phNo || item.ph_no || ''}`,
            action: item.isVisited ? 'Arrived' : 'Arrive',
            time_extended: '',
            isGroupMember: true,
          }

          allData.push(groupVisitorData)
          if (groupVisitorData.visitor_id) {
            processedGroupVisitorIds.add(groupVisitorData.visitor_id)
          }
        }
      })
    }

    return allData
  }

  const { data: countrycodes, isCountryCodesLoading } = useQuery({
    queryFn: () => listOfCountriesExt(),
  })
  const updateFilteredArrivedVisitors = async () => {
    // Instead of calling API again, invalidate the query to refresh data
    // The dashboard component will refetch and update this component's data
    queryClient.invalidateQueries({
      queryKey: [
        'getAllVisitors',
        branch_id,
        format(data_of_visit, 'dd-MM-yyyy'),
      ],
    })
  }

  const mutate = useMutation({
    mutationFn: (values) => extendTimeDuringVisit(values),
    onMutate: () => setLoading(true),
    onSuccess: async (_, variables) => {
      updateRowData(variables.visitor_id, {
        time_to_exit: variables.extendedTime,
      })
      await updateFilteredArrivedVisitors()
      toast.success('Extended Visit Successful')
      setLoading(false)
      setOpenModal(false)

      // Refresh the entire dashboard page after successful extend visit
      setTimeout(() => {
        window.location.reload()
      }, 1000) // Small delay to show success message
    },
    onError: (err) => {
      setLoading(false)
      setError('Failed to extend visit time. Please try again.')
      toast.error('Failed to extend visit time. Please try again.')
      setOpenModal(false)
    },
  })

  const mutates = useMutation({
    mutationFn: (values) => updateVisitorData(values),
    onMutate: () => setLoading(true),
    onSuccess: async () => {
      await updateFilteredArrivedVisitors()

      toast.success('Update Phone number sucess')
      setLoading(false)
      setOpenModal(false)

      // Refresh the entire dashboard page after successful edit
      setTimeout(() => {
        window.location.reload()
      }, 1000) // Small delay to show success message
    },
    onError: (err) => {
      setLoading(false)
      setError('Failed to update visitor data. Please try again.')
      toast.error('Failed to update visitor data. Please try again.')
      setOpenModal(false)
    },
  })

  const handleConfirm = (values) => {
    const startTimeInMinutes = timeToMinutes(values.time_of_visit)
    const endTimeInMinutes = timeToMinutes(values.time_to_exit)
    const durationInMinutes = endTimeInMinutes - startTimeInMinutes
    const hours = Math.floor(durationInMinutes / 60)
    const minutes = durationInMinutes % 60

    // Use the branch_id from props if not available in values
    const branchId = values?.branch_id || branch_id

    // Validate required fields before making API call
    if (!branchId) {
      toast.error('Branch ID is required for extending visit')
      return
    }

    if (!values?.visitor_id) {
      toast.error('Visitor ID is required for extending visit')
      return
    }

    mutate.mutate({
      visitor_id: values.visitor_id,
      extendedTime: values?.time_to_exit || '',
      visit_duration: `${hours}:${minutes}`,
      branch_id: branchId,
      extendedDate: values?.end_date || '',
      entryTime: values?.time_of_visit || '',
      org_id: auth?.org_id || '',
    })
    setOpenModal(false)
  }

  const actionCellRenderer = (params) => {
    // Hide extend visit button for group visitors
    if (
      params.data.isGroupMember ||
      params.data.visitor_type === 'group_visitor'
    ) {
      return <div style={{ width: '100%', height: '100%' }}></div>
    }

    // For main visitors, use their data for extend visit functionality
    const visitorData = params.data

    return (
      <button
        className="bg-yellow-500 hover:bg-yellow-600 text-white text-xs font-medium py-1.5 px-3 rounded-md transition-colors"
        style={{
          cursor: 'pointer',
          margin: '2px auto',
          width: '100px',
          whiteSpace: 'nowrap',
          textAlign: 'center',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
        onClick={() => {
          setSelectedVisitor(visitorData)
          setOpenModal(true)
        }}
      >
        Extend Visit
      </button>
    )
  }

  const actionssCellRenderer = (params) => {
    // Hide Update Details button for group visitors
    if (
      params.data?.isGroupMember === true ||
      params.data?.visitor_type === 'group_member' ||
      params.data?.visitor_type === 'group_visitor'
    ) {
      return null
    }

    return (
      <button
        className="bg-yellow-500 hover:bg-yellow-600 text-white text-xs font-medium py-1.5 px-3 rounded-md transition-colors"
        style={{
          cursor: 'pointer',
          margin: '2px auto',
          width: '100px',
          whiteSpace: 'nowrap',
          textAlign: 'center',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
        onClick={() => {
          setSelectedVisitor(params.data)
          setEditModalOpen(true) // Open the edit modal
        }}
      >
        Update Details
      </button>
    )
  }

  const vehicleMaterialCellRenderer = (params) => {
    // For group members, use their main visitor's vehicle/material data
    const visitorData = params.data.isGroupMember
      ? {
          ...params.data,
          // Use main visitor's vehicle/material data
          vm_bool: params.data.vm_bool,
          mm_bool: params.data.mm_bool,
          vm_details: params.data.vm_details,
          mm_details: params.data.mm_details,
        }
      : params.data

    // Check if there's vehicle/material data available
    const hasVehicleData =
      visitorData.vm_bool &&
      visitorData.vm_details &&
      visitorData.vm_details.length > 0
    const hasMaterialData =
      visitorData.mm_bool &&
      visitorData.mm_details &&
      visitorData.mm_details.length > 0
    const hasData = hasVehicleData || hasMaterialData

    return (
      <button
        className={`${hasData ? 'bg-blue-500 hover:bg-blue-600' : 'bg-gray-500 cursor-not-allowed'} text-white text-xs font-medium py-1.5 px-3 rounded-md transition-colors`}
        style={{
          cursor: hasData ? 'pointer' : 'not-allowed',
          margin: '2px auto',
          width: '110px',
          whiteSpace: 'nowrap',
          textAlign: 'center',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          opacity: hasData ? 1 : 0.6,
        }}
        disabled={!hasData}
        onClick={() => {
          if (!hasData) return

          if (window.openVehicleMaterialModal) {
            window.openVehicleMaterialModal(visitorData)
          } else {
            console.error('❌ window.openVehicleMaterialModal not found!')
          }
        }}
      >
        Vehicle/Material
      </button>
    )
  }

  const groupBookingCellRenderer = (params) => {
    // Hide group details button for group visitors and group members
    if (
      params.data.isGroupMember ||
      params.data.visitor_type === 'group_visitor' ||
      params.data.visitor_type === 'group_member'
    ) {
      return <div style={{ width: '100%', height: '100%' }}></div>
    }

    // For main visitors and single group members, use their group booking data
    let visitorData = params.data

    // If no group booking data in current visitor, search for it in all visitors data
    if (
      !visitorData.grp_book_bool ||
      !visitorData.grp_details ||
      visitorData.grp_details.length === 0
    ) {
      let searchEmail = visitorData.email

      // For group visitors, search for their main visitor's group booking data
      if (
        visitorData.visitor_type === 'group_visitor' &&
        visitorData.main_visitor_email
      ) {
        searchEmail = visitorData.main_visitor_email
      }

      if (searchEmail && allVisitorsData) {
        // Search in all visitors data arrays
        const allVisitorsArrays = [
          allVisitorsData.visitors_List || [],
          allVisitorsData.arrivedVisitorsList || [],
          allVisitorsData.arrivedVisitorsOnlyTrue || [],
          allVisitorsData.noShowVisitorsOnlyFalse || [],
        ]

        for (const visitorsArray of allVisitorsArrays) {
          const foundVisitor = visitorsArray.find(
            (visitor) =>
              visitor.email === searchEmail &&
              visitor.grp_book_bool &&
              visitor.grp_details &&
              visitor.grp_details.length > 0,
          )

          if (foundVisitor) {
            // Update visitor data with found group booking details
            visitorData = {
              ...visitorData,
              grp_book_bool: foundVisitor.grp_book_bool,
              grp_details: foundVisitor.grp_details,
            }
            break
          }
        }
      }
    }

    // Check if there's group booking data available or if mm_bool is true (indicating group visitors)
    const hasGroupData =
      (visitorData.grp_book_bool &&
        visitorData.grp_details &&
        visitorData.grp_details.length > 0) ||
      visitorData.mm_bool === true ||
      visitorData.visitor_type === 'group_visitor' ||
      visitorData.isGroupMember === true

    return (
      <button
        className={`${hasGroupData ? 'bg-green-500 hover:bg-green-600' : 'bg-gray-500 cursor-not-allowed'} text-white text-xs font-medium py-1.5 px-3 rounded-md transition-colors`}
        style={{
          cursor: hasGroupData ? 'pointer' : 'not-allowed',
          margin: '2px auto',
          width: '110px',
          whiteSpace: 'nowrap',
          textAlign: 'center',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          opacity: hasGroupData ? 1 : 0.6,
        }}
        disabled={!hasGroupData}
        onClick={() => {
          if (!hasGroupData) return

          if (window.openGroupBookingModal) {
            window.openGroupBookingModal(visitorData)
          } else {
            console.error('❌ window.openGroupBookingModal not found!')
          }
        }}
      >
        Group Details
      </button>
    )
  }

  const expandCellRenderer = (params) => {
    const isGroupMember = params.data.isGroupMember
    const hasGroupMembers = params.data.hasGroupMembers
    const isExpanded = expandedVisitors[params.data.visitor_id] || false

    if (isGroupMember) {
      // Group member row - no arrow, just empty space
      return <div style={{ width: '100%', height: '100%' }}></div>
    }

    if (hasGroupMembers) {
      // Main visitor with group members - show expand/collapse arrow
      return (
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: '100%',
            height: '100%',
          }}
        >
          <button
            style={{
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              padding: '4px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              width: '24px',
              height: '24px',
              borderRadius: '4px',
              backgroundColor: isExpanded ? '#e3f2fd' : 'transparent',
              transition: 'all 0.2s ease',
            }}
            onClick={(e) => {
              e.stopPropagation()
              toggleVisitorExpansion(params.data.visitor_id)
            }}
          >
            {!isExpanded ? '▶' : '▼'}
          </button>
        </div>
      )
    }

    // Main visitor without group members - empty space
    return <div style={{ width: '100%', height: '100%' }}></div>
  }

  const nameCellRenderer = (params) => {
    const isGroupMember = params.data.isGroupMember
    const isGroupVisitor = params.data.visitor_type === 'group_visitor'

    // Only indent if this is actually a group member AND has a valid parent visitor
    const hasValidParent =
      params.data.parentVisitorId &&
      params.data.parentVisitorId !== params.data.visitor_id

    // Check if the parent visitor is expanded (only show children when parent is expanded)
    const parentVisitorId = params.data.parentVisitorId
    const isParentExpanded = parentVisitorId
      ? expandedVisitors[parentVisitorId]
      : false

    if (isGroupMember && hasValidParent && isParentExpanded) {
      // Group member row - show with indentation and main visitor full name in brackets
      const mainVisitorName =
        params.data.main_visitor_name || params.data.mainVisitorName || ''
      const mainVisitorFirstName =
        params.data.main_visitor_first_name ||
        params.data.mainVisitorFirstName ||
        ''
      const mainVisitorLastName =
        params.data.main_visitor_last_name ||
        params.data.mainVisitorLastName ||
        ''

      // Create full main visitor name (first name + last name)
      const mainVisitorFullName =
        mainVisitorFirstName && mainVisitorLastName
          ? `${mainVisitorFirstName} ${mainVisitorLastName}`.trim()
          : mainVisitorName || ''

      const displayName = mainVisitorFullName
        ? `${params.data.fullName} (${mainVisitorFullName})`
        : params.data.fullName

      return (
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            paddingLeft: '16px',
            backgroundColor: '#f8f9fa',
            padding: '8px 0 8px 16px',
            margin: '2px 0',
            textAlign: 'left',
            width: '100%',
          }}
        >
          <span
            style={{
              fontSize: '0.9rem',
              color: '#666',
              fontWeight: '500',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              textAlign: 'left',
              width: '100%',
            }}
          >
            👤{' '}
            <span style={{ color: '#333', textAlign: 'left' }}>
              {displayName}
            </span>
          </span>
        </div>
      )
    }

    if (isGroupVisitor && hasValidParent && isParentExpanded) {
      // Group visitor row - show with main visitor name in brackets
      const mainVisitorName = params.data.main_visitor_name || ''
      const displayName = mainVisitorName
        ? `${params.data.fullName} (${mainVisitorName})`
        : params.data.fullName

      return (
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            paddingLeft: '8px',
            textAlign: 'left',
            width: '100%',
          }}
        >
          <span style={{ fontWeight: '600', textAlign: 'left' }}>
            {displayName}
          </span>
        </div>
      )
    }

    // Hide group members when parent is not expanded
    if (
      (isGroupMember || isGroupVisitor) &&
      hasValidParent &&
      !isParentExpanded
    ) {
      return <div style={{ width: '100%', height: '100%' }}></div>
    }

    // Group visitor appearing individually (not as part of expanded group) - show main visitor name in brackets
    if (isGroupVisitor && !hasValidParent) {
      const mainVisitorName =
        params.data.main_visitor_name || params.data.mainVisitorName || ''
      const mainVisitorFirstName =
        params.data.main_visitor_first_name ||
        params.data.mainVisitorFirstName ||
        ''
      const mainVisitorLastName =
        params.data.main_visitor_last_name ||
        params.data.mainVisitorLastName ||
        ''

      // Create full main visitor name (first name + last name)
      const mainVisitorFullName =
        mainVisitorFirstName && mainVisitorLastName
          ? `${mainVisitorFirstName} ${mainVisitorLastName}`.trim()
          : mainVisitorName || ''

      const displayName = mainVisitorFullName
        ? `${params.data.fullName} (${mainVisitorFullName})`
        : params.data.fullName

      return (
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            paddingLeft: '8px',
            textAlign: 'left',
            width: '100%',
          }}
        >
          <span style={{ fontWeight: '600', textAlign: 'left' }}>
            {displayName}
          </span>
        </div>
      )
    }

    // Main visitor row or standalone visitor - just the name, no arrow, left-aligned
    // Use params.data.fullName directly to avoid showing group member names (valueGetter includes them for search only)
    return (
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          paddingLeft: '8px',
          textAlign: 'left',
          width: '100%',
        }}
      >
        <span style={{ fontWeight: '600', textAlign: 'left' }}>
          {params.data.fullName}
        </span>
      </div>
    )
  }

  const phoneCellRenderer = (params) => {
    const phoneNumber = params.data.ph_no || params.data.phone || ''
    const countryCode = params.data.ph_ext || ''

    // Check if phone number is empty, null, undefined, or masked
    const isPhoneValid =
      phoneNumber &&
      phoneNumber.trim() !== '' &&
      !phoneNumber.includes('XXXXXXXXXX')

    // Format the country code to ensure it has + prefix
    const formattedCountryCode = countryCode
      ? countryCode.startsWith('+')
        ? countryCode
        : `+${countryCode}`
      : ''

    // Combine country code and phone number, or show N/A if invalid
    const fullPhoneNumber = isPhoneValid
      ? formattedCountryCode && phoneNumber
        ? `${formattedCountryCode} ${phoneNumber}`
        : phoneNumber
      : 'N/A'

    return (
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          paddingLeft: '8px',
          textAlign: 'left',
          width: '100%',
        }}
      >
        <span style={{ fontWeight: '500', textAlign: 'left' }}>
          {fullPhoneNumber}
        </span>
      </div>
    )
  }

  // Date cell renderer - dates are already formatted in Dashboard Presentation files to DD-MM-YYYY
  // Just return the value as-is without any additional formatting
  const dateCellRenderer = (params) => {
    if (!params.value) return 'N/A'
    // Dates are already formatted in Dashboard Presentation files to DD-MM-YYYY
    // Return as-is without any additional formatting
    return params.value
  }

  // Date-time cell renderer for formatting dates with time to DD-MM-YYYY HH:mm:ss
  const dateTimeCellRenderer = (params) => {
    if (!params.value) return 'N/A'
    return formatDateTime(params.value)
  }

  const validationSchema = yup.object().shape({
    phNo: yup
      .string()
      .test(
        'phone-required-if-country-code',
        'Phone number is required when country code is provided',
        function (value) {
          const { ph_ext } = this.parent
          // If country code is provided, phone number must be provided
          if (ph_ext && ph_ext.trim() !== '') {
            return value && value.trim() !== ''
          }
          // If country code is not provided, phone number is optional
          return true
        },
      )
      .test('is-valid-phone', 'Enter a valid phone number', function (value) {
        // Only validate phone format if phone number is provided
        if (!value || value.trim() === '') {
          return true
        }
        const { ph_ext } = this.parent
        const countryCode = countrycodes.find((c) => c.code === ph_ext)
        if (!countryCode) return false
        const isValidLength = value.length >= 5 && value.length <= 10
        const isNumeric = /^[0-9]+$/.test(value)
        const doesNotStartWithZero = !value.startsWith('0')

        if (!doesNotStartWithZero) {
          return this.createError({
            message: 'Phone number cannot start with 0',
          })
        }

        return isValidLength && isNumeric && doesNotStartWithZero
      }),
    ph_ext: yup
      .string()
      .test(
        'country-code-empty-if-phone-empty',
        'Country code must be empty when phone number is empty',
        function (value) {
          const { phNo } = this.parent
          // If phone number is empty, country code must be empty
          if (!phNo || phNo.trim() === '') {
            return !value || value.trim() === ''
          }
          // If phone number is provided, country code must be provided
          return value && value.trim() !== ''
        },
      ),
    email: yup
      .string()
      .test(
        'phone-or-email-required',
        'Phone number or email is required',
        function (value) {
          const { phNo } = this.parent
          // At least one of phone number or email must be provided
          const hasPhone = phNo && phNo.trim() !== ''
          const hasEmail = value && value.trim() !== ''
          return hasPhone || hasEmail
        },
      ),
    area_of_permit: yup
      .array()
      .of(
        yup.object().shape({
          area_id: yup.string().required('Area ID is required'),
          area_name: yup.string().required('Area name is required'),
        }),
      )
      .min(1, 'At least one area must be selected')
      .required('Area of permit is required'),
  })
  const columnDefs = useMemo(
    () => [
      {
        headerName: '',
        field: 'expand',
        cellRenderer: expandCellRenderer,
        width: 40,
        minWidth: 40,
        resizable: false,
        sortable: false,
        filter: false,
        pinned: 'left',
      },
      {
        headerName: 'VISITOR NAME',
        headerTooltip: 'Visitor Name',
        field: 'fullName',
        cellRenderer: nameCellRenderer,
        tooltipField: 'fullName',
        width: 300,
        minWidth: 250,
        cellStyle: { textAlign: 'left', paddingLeft: '8px' },
        headerClass: 'ag-left-aligned-header',
        valueGetter: (params) => {
          // Return the actual text value for filtering
          if (params.data.isGroupMember) {
            const mainVisitorName =
              params.data.main_visitor_name || params.data.mainVisitorName || ''
            const mainVisitorFirstName =
              params.data.main_visitor_first_name ||
              params.data.mainVisitorFirstName ||
              ''
            const mainVisitorLastName =
              params.data.main_visitor_last_name ||
              params.data.mainVisitorLastName ||
              ''
            const mainVisitorFullName =
              mainVisitorFirstName && mainVisitorLastName
                ? `${mainVisitorFirstName} ${mainVisitorLastName}`.trim()
                : mainVisitorName || ''
            return mainVisitorFullName
              ? `${params.data.fullName} (${mainVisitorFullName})`
              : params.data.fullName
          }
          if (params.data.visitor_type === 'group_visitor') {
            const mainVisitorName = params.data.main_visitor_name || ''
            return mainVisitorName
              ? `${params.data.fullName} (${mainVisitorName})`
              : params.data.fullName
          }
          // For main visitors with group members (even when collapsed), include group member names in search
          if (params.data.hasGroupMembers && params.data.groupMembers) {
            const mainVisitorName = params.data.fullName || ''
            const groupMemberNames = params.data.groupMembers
              .map((member) => member.fullName || member.grp_user_name || '')
              .filter((name) => name.trim() !== '')
              .join(' ')
            // Combine main visitor name with all group member names for searchability
            return groupMemberNames
              ? `${mainVisitorName} ${groupMemberNames}`.trim()
              : mainVisitorName
          }
          return params.data.fullName
        },
      },
      {
        headerName: 'VISIT START DATE',
        headerTooltip: 'Visit Start Date',
        field: 'start_date',
        tooltipField: 'start_date',
        width: 180,
        minWidth: 160,
        cellStyle: { textAlign: 'left', paddingLeft: '8px' },
        headerClass: 'ag-left-aligned-header',
        cellRenderer: dateCellRenderer,
        valueGetter: (params) => {
          // Return the date for filtering
          return params.data.start_date || ''
        },
      },
      {
        headerName: 'VISIT END DATE',
        headerTooltip: 'Visit End Date',
        field: 'end_date',
        tooltipField: 'end_date',
        width: 180,
        minWidth: 160,
        cellStyle: { textAlign: 'left', paddingLeft: '8px' },
        headerClass: 'ag-left-aligned-header',
        cellRenderer: dateCellRenderer,
        valueGetter: (params) => {
          // Return the date for filtering
          return params.data.end_date || ''
        },
      },
      {
        headerName: 'VISIT START TIME',
        headerTooltip: 'Visit Start Time',
        field: 'time_of_visit',
        tooltipField: 'time_of_visit',
        width: 180,
        minWidth: 160,
        cellStyle: { textAlign: 'left', paddingLeft: '8px' },
        headerClass: 'ag-left-aligned-header',
        valueGetter: (params) => {
          // Return the time for filtering
          return params.data.time_of_visit || ''
        },
      },
      {
        headerName: 'VISIT END TIME',
        headerTooltip: 'Visit End Time',
        field: 'time_to_exit',
        tooltipField: 'time_to_exit',
        width: 180,
        minWidth: 160,
        cellStyle: { textAlign: 'left', paddingLeft: '8px' },
        headerClass: 'ag-left-aligned-header',
        valueGetter: (params) => {
          // Return the time for filtering
          return params.data.time_to_exit || ''
        },
      },
      {
        headerName: 'CATEGORY',
        headerTooltip: 'Category',
        field: 'role_name',
        tooltipField: 'role_name',
        width: 150,
        minWidth: 130,
        cellStyle: { textAlign: 'left', paddingLeft: '8px' },
        headerClass: 'ag-left-aligned-header',
        valueGetter: (params) => {
          // Return the role name for filtering
          return params.data.role_name || ''
        },
      },
      {
        headerName: 'PHONE NUMBER',
        headerTooltip: 'Phone Number',
        field: 'ph_no',
        cellRenderer: phoneCellRenderer,
        tooltipField: 'ph_no',
        width: 200,
        minWidth: 180,
        cellStyle: { textAlign: 'left', paddingLeft: '8px' },
        headerClass: 'ag-left-aligned-header',
        valueGetter: (params) => {
          // Return the phone number for filtering, handling both ph_no and phone fields
          const phoneNumber = params.data.ph_no || params.data.phone || ''
          const countryCode = params.data.ph_ext || ''
          const formattedCountryCode = countryCode
            ? countryCode.startsWith('+')
              ? countryCode
              : `+${countryCode}`
            : ''
          return formattedCountryCode && phoneNumber
            ? `${formattedCountryCode} ${phoneNumber}`
            : phoneNumber
        },
      },
      {
        headerName: 'EMAIL ADDRESS',
        headerTooltip: 'Email Address',
        field: 'email',
        headerClass: 'ag-left-aligned-header',
        cellStyle: { textAlign: 'left', paddingLeft: '8px' },
        tooltipField: 'email',
        width: 280,
        minWidth: 250,
        valueGetter: (params) => params.data.email || '',
        cellRenderer: (params) => {
          const email = params.data.email || ''
          // Check if email is valid (not empty, contains @, not masked, not placeholder)
          const isValidEmail =
            email &&
            email.trim() !== '' &&
            email.includes('@') &&
            !email.includes('XXXXXXXXXX') &&
            email !== 'no-email@example.com'

          return (
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                paddingLeft: '8px',
                textAlign: 'left',
                width: '100%',
              }}
            >
              <span style={{ fontWeight: '500', textAlign: 'left' }}>
                {isValidEmail ? email : 'N/A'}
              </span>
            </div>
          )
        },
      },
      {
        headerName: 'PURPOSE',
        headerTooltip: 'Purpose of Visit',
        field: 'purpose_of_visit',
        tooltipField: 'purpose_of_visit',
        width: 200,
        minWidth: 180,
        cellStyle: { textAlign: 'left', paddingLeft: '8px' },
        headerClass: 'ag-left-aligned-header',
        valueGetter: (params) => {
          // Return the purpose for filtering
          return params.data.purpose_of_visit || ''
        },
      },
      {
        headerName: 'BOOKING TIME',
        headerTooltip: 'Booking Time',
        field: 'bookingTime',
        tooltipValueGetter: (params) => {
          if (!params.value) return 'N/A'
          return formatDateTime(params.value)
        },
        width: 200,
        minWidth: 180,
        cellStyle: { textAlign: 'left', paddingLeft: '8px' },
        headerClass: 'ag-left-aligned-header',
        cellRenderer: dateTimeCellRenderer,
        valueGetter: (params) => {
          // Return the booking time for filtering
          return params.data.bookingTime || ''
        },
      },
      {
        headerName: 'STATUS',
        headerTooltip: 'Status',
        field: 'action',
        tooltipField: 'action',
        width: 140,
        minWidth: 120,
        cellStyle: { textAlign: 'left', paddingLeft: '8px' },
        headerClass: 'ag-left-aligned-header',
        valueGetter: (params) => {
          // Return the status for filtering
          return params.data.action || ''
        },
      },
      ...(auth.role == '3'
        ? [
            {
              headerName: 'Src Code',
              headerTooltip: 'Access Reference Code',
              field: 'visitor_code',
              tooltipField: 'visitor_code',
              width: 130,
              minWidth: 120,
              cellStyle: { textAlign: 'left', paddingLeft: '8px' },
              headerClass: 'ag-left-aligned-header',
              valueGetter: (params) => {
                // Return the visitor code for filtering
                return params.data.visitor_code || ''
              },
            },
          ]
        : []),
      {
        headerName: 'Vehicle/Material',
        headerTooltip: 'Vehicle/Material',
        cellRenderer: vehicleMaterialCellRenderer,
        width: 140,
        minWidth: 130,
        cellStyle: { textAlign: 'left', paddingLeft: '8px' },
        headerClass: 'ag-left-aligned-header',
        valueGetter: (params) => {
          // Return a string value for filtering
          if (params.data.vm_bool && params.data.mm_bool) {
            return 'Vehicle & Material'
          } else if (params.data.vm_bool) {
            return 'Vehicle'
          } else if (params.data.mm_bool) {
            return 'Material'
          }
          return 'None'
        },
      },
      {
        headerName: 'Group Details',
        headerTooltip: 'Group Details',
        cellRenderer: groupBookingCellRenderer,
        width: 140,
        minWidth: 130,
        valueGetter: (params) => {
          // Return a string value for filtering
          // Hide group details option only for group visitors that have a main visitor
          if (params.data.isGroupMember && params.data.main_visitor_email) {
            return 'N/A'
          }
          if (params.data.grp_book_bool || params.data.is_group_booking) {
            return 'Group Details'
          }
          return 'Individual'
        },
      },
      {
        headerName: 'Extend Visit',
        headerTooltip: 'Extend Visit',
        cellRenderer: actionCellRenderer,
        width: 120,
        minWidth: 110,
        valueGetter: (params) => {
          // Return a string value for filtering
          // Hide extend visit option for group visitors
          if (
            params.data.isGroupMember ||
            params.data.visitor_type === 'group_visitor'
          ) {
            return 'N/A'
          }
          return params.data.action === 'Arrived' ? 'Extend' : 'N/A'
        },
      },
      {
        headerName: 'Edit',
        headerTooltip: 'Edit',
        cellRenderer: actionssCellRenderer,
        width: 120,
        minWidth: 110,
        valueGetter: (params) => {
          // Return a string value for filtering
          return 'Edit'
        },
      }, // New actionss column
    ],
    [expandedVisitors, nameCellRenderer, expandCellRenderer],
  )
  const [editModalOpen, setEditModalOpen] = useState(false)

  const handleEditClose = () => {
    setEditModalOpen(false)
  }

  // Save changes for edit modal
  const handleEditConfirm = (values) => {
    const areaNames =
      values.area_of_permit?.map((area) => area.area_name).join(',') || ''

    // Use the branch_id from props if not available in values
    const branchId = values?.branch_id || branch_id

    // Validate required fields before making API call
    if (!branchId) {
      toast.error('Branch ID is required for updating visitor data')
      return
    }

    if (!values?.visitor_id) {
      toast.error('Visitor ID is required for updating visitor data')
      return
    }

    mutates.mutate({
      email: values?.email || '',
      ph_ext: values?.ph_ext || '',
      ph_no: values?.phNo || '',
      org_id: auth?.org_id || '',
      visitor_code: values?.visitor_code || '',
      visitor_id: values.visitor_id,
      branch_id: branchId,
      area_of_permit: areaNames, // Convert to comma-separated string
    })

    setEditModalOpen(false)
  }

  const defaultColDef = useMemo(
    () => ({
      filter: 'agTextColumnFilter',
      floatingFilter: true,
      cellClass: 'ag-cell-centered', // Apply to all columns by default
      headerClass: 'ag-header-cell-custom', // Custom header styling
      cellStyle: {
        padding: '12px 8px',
        fontSize: '0.875rem',
        borderBottom: '1px solid #e5e7eb',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        textAlign: 'center',
      },
      tooltipComponent: 'agTooltipComponent',
      tooltipValueGetter: (params) => params.value || 'No data available',
      filterParams: {
        filterOptions: ['contains', 'equals', 'startsWith', 'endsWith'],
        defaultOption: 'contains',
        suppressAndOrCondition: true,
      },
    }),
    [],
  )

  const customIcons = {
    sortAscending: '<i class="fa fa-sort-asc"></i>',
    sortDescending: '<i class="fa fa-sort-desc"></i>',
  }

  const onGridReady = (params) => {
    gridApiRef.current = params.api
  }

  const handleClose = () => {
    setOpenModal(false)
  }

  const onExport = () => {
    // Use getAllDataForExport to include ALL visitors (including collapsed group visitors)
    const allData = getAllDataForExport()

    // Define CSV columns in the same order as PDF: Name, Visitor Type, Category, Visit Start Date, Visit End Date, Visit Start Time, Visit End Time, Phone Number, Email, Purpose of Visit, Booking Time, Access Reference Code, Status
    const csvColumnOrder = [
      { header: 'Name', field: 'fullName' },
      { header: 'Visitor Type', field: 'visitorType' },
      { header: 'Category', field: 'role_name' },
      { header: 'Visit Start Date', field: 'start_date' },
      { header: 'Visit End Date', field: 'end_date' },
      { header: 'Visit Start Time', field: 'time_of_visit' },
      { header: 'Visit End Time', field: 'time_to_exit' },
      { header: 'Phone Number', field: 'phNos' },
      { header: 'Email', field: 'email' },
      { header: 'Purpose of Visit', field: 'purpose_of_visit' },
      { header: 'Booking Time', field: 'bookingTime' },
      { header: 'Access Reference Code', field: 'visitor_code' },
      { header: 'Status', field: 'action' },
    ]

    // Prepare CSV data
    const csvData = allData.map((row) => {
      const csvRow = {}

      csvColumnOrder.forEach((col) => {
        let value = row[col.field] || ''

        // Special handling for Visitor Type
        if (col.field === 'visitorType') {
          value = getVisitorTypeDisplay(
            row.visitor_type,
            row.isGroupMember,
            row.isMainVisitor,
          )
        }

        // Special handling for Phone Number
        if (col.field === 'phNos') {
          const phoneNumber = row.ph_no || row.phone || row.phNo || ''
          const countryCode = row.ph_ext || ''
          const formattedCountryCode = countryCode
            ? countryCode.startsWith('+')
              ? countryCode
              : `+${countryCode}`
            : ''
          const fullPhoneNumber =
            formattedCountryCode && phoneNumber
              ? `${formattedCountryCode} ${phoneNumber}`
              : phoneNumber
          value = fullPhoneNumber || 'N/A'
        }

        // Special handling for Email
        if (col.field === 'email') {
          value = value || 'N/A'
        }

        // Format date fields - keep start_date and end_date as-is from API, format bookingTime with date and time
        if (col.field === 'bookingTime') {
          value = formatDateTime(value) || ''
        }
        // start_date and end_date are kept as-is from API response (no formatting)

        csvRow[col.header] = value
      })

      return csvRow
    })

    // Convert to CSV format
    const csv = Papa.unparse(csvData)
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    saveAs(blob, 'Visitors Report.csv')
  }

  const onExportPDF = () => {
    if (!gridApiRef.current) {
      toast.error('Export failed: Grid API not initialized.')
      return
    }

    const doc = new jsPDF({
      orientation: 'landscape',
      unit: 'pt',
      format: [1200, 700], // Custom page size
    })

    // Add a teal background for the header
    doc.setFillColor(39, 174, 96) // Teal color
    doc.rect(0, 0, doc.internal.pageSize.width, 100, 'F') // Fill the top area with teal color

    // Add the "Visitors Report" heading in the middle
    doc.setFontSize(20)
    doc.setTextColor(255, 255, 255) // White text color
    const pageWidth = doc.internal.pageSize.width
    const textWidth = doc.getTextWidth('Visitors Report')
    const centerX = (pageWidth - textWidth) / 2
    doc.text(`${report_name}`, centerX, 40) // Centered title

    // Static data for branch name and date
    const Admin = `Admin: ${name || ''}`

    const branchName = `Branch Name : ${branch?.branch_name || ''}`
    const reportDate = `Date : ${formatDate(data_of_visit)}`

    // Add the branch name below the title
    doc.setFontSize(13)
    doc.setTextColor(255, 255, 255) // White text color
    doc.text(Admin, 40, 40)
    doc.text(branchName, 40, 60) // Branch name on the left

    // Add the date below the branch name
    doc.text(reportDate, 40, 80) // Report date on the left

    // Adjust the layout below the header
    doc.setTextColor(0) // Reset text color for table content

    // Define table columns
    const tableColumns = [
      { header: 'Name', dataKey: 'fullName' },
      { header: 'Visitor Type', dataKey: 'visitorType' },
      { header: 'Category', dataKey: 'role_name' },
      { header: 'Visit Start Date', dataKey: 'start_date' },
      { header: 'Visit End Date', dataKey: 'end_date' },
      { header: 'Visit Start Time', dataKey: 'time_of_visit' },
      { header: 'Visit End Time', dataKey: 'time_to_exit' },
      { header: 'Phone Number', dataKey: 'phNos' },
      { header: 'Email', dataKey: 'email' },
      { header: 'Purpose of Visit', dataKey: 'purpose_of_visit' },
      { header: 'Booking Time', dataKey: 'bookingTime' },
      { header: 'Access Reference Code', dataKey: 'visitor_code' },
      { header: 'Status', dataKey: 'action' },
    ]

    // Use getAllDataForExport to include ALL visitors (including collapsed group visitors)
    const allData = getAllDataForExport()
    const tableRows = allData.map((row) => {
      // Add visitorType to row data for PDF export
      const rowWithVisitorType = {
        ...row,
        visitorType: getVisitorTypeDisplay(
          row.visitor_type,
          row.isGroupMember,
          row.isMainVisitor,
        ),
      }

      return tableColumns.map((col) => {
        // Special handling for Phone Number
        if (col.dataKey === 'ph_no' || col.dataKey === 'phNos') {
          const phoneNumber = row.ph_no || row.phone || row.phNo || ''
          const countryCode = row.ph_ext || ''
          const formattedCountryCode = countryCode
            ? countryCode.startsWith('+')
              ? countryCode
              : `+${countryCode}`
            : ''
          const fullPhoneNumber =
            formattedCountryCode && phoneNumber
              ? `${formattedCountryCode} ${phoneNumber}`
              : phoneNumber
          return fullPhoneNumber || 'N/A'
        }
        // Special handling for Email
        if (col.dataKey === 'email') {
          return rowWithVisitorType[col.dataKey] || 'N/A'
        }
        // Special handling for Visitor Type
        if (col.dataKey === 'visitorType') {
          return rowWithVisitorType.visitorType || 'N/A'
        }
        // Format date fields - keep start_date and end_date as-is from API, format bookingTime with date and time
        if (col.dataKey === 'bookingTime') {
          return formatDateTime(rowWithVisitorType[col.dataKey]) || 'N/A'
        }
        // start_date and end_date are kept as-is from API response (no formatting)
        return rowWithVisitorType[col.dataKey] || 'N/A'
      })
    })

    // Add the table to the PDF
    doc.autoTable({
      startY: 120, // Start after the header
      head: [tableColumns.map((col) => col.header)],
      body: tableRows,
      styles: { fontSize: 9, cellPadding: 3 },
      columnStyles: {
        0: { cellWidth: 80 }, // Name
        1: { cellWidth: 70 }, // Visitor Type
        2: { cellWidth: 90 }, // Category
        3: { cellWidth: 90 }, // Visit Start Date
        4: { cellWidth: 80 }, // Visit End Date
        5: { cellWidth: 80 }, // Visit Start Time
        6: { cellWidth: 80 }, // Visit End Time
        7: { cellWidth: 100 }, // Phone Number
        8: { cellWidth: 100 }, // Email
        9: { cellWidth: 80 }, // Purpose of Visit
        10: { cellWidth: 100 }, // Booking Time
        11: { cellWidth: 100 }, // Access Reference Code
        12: { cellWidth: 60 }, // Status
      },
      headStyles: { fillColor: [39, 174, 96] }, // Teal color for table header
      horizontalPageBreak: true, // Automatically add page breaks
    })

    // Save the PDF
    doc.save('visitors_report_custom_styled.pdf')
  }

  const updateRowData = (visitorId, newData) => {
    setRowData((prevRowData) =>
      prevRowData.map((row) =>
        row.visitor_id === visitorId ? { ...row, ...newData } : row,
      ),
    )
  }

  // Removed downloadVehicleMaterialPDF function
  const removedFunction1 = () => {
    // Create PDF in landscape orientation
    const doc = new jsPDF('landscape', 'mm', 'a4')

    // Add green header background
    doc.setFillColor(39, 174, 96) // Green color matching the image
    doc.rect(0, 0, doc.internal.pageSize.width, 25, 'F') // Fill the top area with green

    // Add admin details on the left side of header (white text)
    doc.setFontSize(10)
    doc.setTextColor(255, 255, 255) // White text
    doc.text('Admin: Organization Admin', 10, 10)
    doc.text('Branch Name: All Branches', 10, 16)
    doc.text(`Date: ${format(new Date(), 'dd-MM-yyyy')}`, 10, 22)

    // Add report title on the right side of header (white text)
    doc.setFontSize(14)
    doc.setTextColor(255, 255, 255) // White text
    const pageWidth = doc.internal.pageSize.width
    const textWidth = doc.getTextWidth('Vehicle/Material Reports')
    const centerX = pageWidth - textWidth - 10 // Right align
    doc.text('Vehicle/Material Reports', centerX, 16)

    // Prepare table data - using visitor data with vehicle/material related fields (matching image)
    // Same fields as CSV for consistency
    const tableColumns = [
      'Visitor Name',
      'Vehicle Name',
      'Vehicle Type',
      'Driver License',
      'RC Number',
      'Insurance Provider',
      'Insurance Number',
      'Material Name',
      'Material Description',
    ]
    const exportData = getAllDataForExport()
    // Filter out group members - only show main visitors for Vehicle/Material reports
    const mainVisitorsOnly = exportData.filter((user) => !user.isGroupMember)
    const tableRows = mainVisitorsOnly.flatMap((user) => {
      // Get the correct name - show actual main visitor names, individual names for group members
      const displayName = user.isGroupMember
        ? user.grp_user_name || user.fullName || 'N/A'
        : user.fullName || user.first_name + ' ' + user.last_name || 'N/A'

      // Check if user has vehicle/material data
      const userRows = []
      const hasVehicleDetails = user.vm_details && user.vm_details.length > 0
      const hasMaterialDetails = user.mm_details && user.mm_details.length > 0

      if (hasVehicleDetails) {
        // Process each vehicle and its associated materials
        user.vm_details.forEach((vehicle) => {
          // Find materials associated with this specific vehicle
          const associatedMaterials = hasMaterialDetails
            ? user.mm_details.filter(
                (material) =>
                  material.material_vehicle_id === vehicle.vehicle_id,
              )
            : []

          if (associatedMaterials.length > 0) {
            // Vehicle has associated materials - create one row per material
            associatedMaterials.forEach((material) => {
              userRows.push([
                displayName,
                vehicle.vehicle_name || 'N/A',
                vehicle.vehicle_type || 'N/A',
                vehicle.driver_licence || 'N/A',
                vehicle.rc_no || 'N/A',
                vehicle.insurance_provider || 'N/A',
                vehicle.insurance_no || 'N/A',
                material.material_name || 'N/A',
                material.material_description || 'N/A',
              ])
            })
          } else {
            // Vehicle exists but no associated materials
            userRows.push([
              displayName,
              vehicle.vehicle_name || 'N/A',
              vehicle.vehicle_type || 'N/A',
              vehicle.driver_licence || 'N/A',
              vehicle.rc_no || 'N/A',
              vehicle.insurance_provider || 'N/A',
              vehicle.insurance_no || 'N/A',
              'N/A', // No material
              'N/A', // No material
            ])
          }
        })
      }

      // Handle materials that are not associated with any vehicle
      if (hasMaterialDetails) {
        const materialsHandledByVehicles = new Set()
        if (hasVehicleDetails) {
          user.vm_details.forEach((vehicle) => {
            const associatedMaterials = user.mm_details.filter(
              (material) => material.material_vehicle_id === vehicle.vehicle_id,
            )
            associatedMaterials.forEach((material) => {
              materialsHandledByVehicles.add(material.material_id)
            })
          })
        }

        // Add materials that are not associated with any vehicle
        user.mm_details.forEach((material) => {
          if (!materialsHandledByVehicles.has(material.material_id)) {
            userRows.push([
              displayName,
              'N/A', // No vehicle
              'N/A', // No vehicle
              'N/A', // No vehicle
              'N/A', // No vehicle
              'N/A', // No vehicle
              'N/A', // No vehicle
              material.material_name || 'N/A',
              material.material_description || 'N/A',
            ])
          }
        })
      }

      // If no vehicle or material data at all, add a single row with N/A for everything
      if (!hasVehicleDetails && !hasMaterialDetails) {
        userRows.push([
          displayName,
          'N/A',
          'N/A',
          'N/A',
          'N/A',
          'N/A',
          'N/A', // Vehicle fields
          'N/A',
          'N/A',
        ])
      }

      return userRows
    })

    // Add table with styling matching the image
    doc.autoTable({
      startY: 30, // Start after the green header
      head: [tableColumns],
      body: tableRows,
      styles: {
        fontSize: 8,
        cellPadding: 3,
        overflow: 'linebreak',
        halign: 'left',
        textColor: [0, 0, 0], // Black text for data rows
      },
      headStyles: {
        fillColor: [39, 174, 96], // Green header matching the image
        fontSize: 9,
        fontStyle: 'bold',
        textColor: [255, 255, 255], // White text for header
      },
      columnStyles: {
        // Increased column widths to utilize more landscape space (9 columns matching image)
        0: { cellWidth: 35 }, // Visitor Name
        1: { cellWidth: 30 }, // Vehicle Name
        2: { cellWidth: 25 }, // Vehicle Type
        3: { cellWidth: 30 }, // Driver License
        4: { cellWidth: 30 }, // RC Number
        5: { cellWidth: 30 }, // Insurance Provider
        6: { cellWidth: 30 }, // Insurance Number
        7: { cellWidth: 30 }, // Material Name
        8: { cellWidth: 40 }, // Material Description
      },
      horizontalPageBreak: true,
      margin: { left: 2, right: 2 },
    })

    doc.save('vehicle_material_report.pdf')
  }

  return (
    <div>
      <style>{`
        .ag-theme-material {
          --ag-header-background-color: #f8fafc !important;
          --ag-header-foreground-color: #374151 !important;
          --ag-border-color: #d1d5db !important;
          --ag-row-hover-color: #e2e8f0 !important;
          --ag-font-size: 0.875rem !important;
          --ag-header-height: 65px !important;
          --ag-row-height: 60px !important;
          --ag-cell-horizontal-border: 1px solid #e5e7eb !important;
          --ag-cell-vertical-border: none !important;
          --ag-row-border-color: #e5e7eb !important;
          --ag-header-cell-horizontal-border: 2px solid #d1d5db !important;
          --ag-header-cell-vertical-border: none !important;
          --ag-header-cell-border-right: none !important;
          --ag-header-cell-border: none !important;
        }
        .ag-header-cell-custom {
          font-weight: 700 !important;
          font-size: 0.9rem !important;
          color: #374151 !important;
          background-color: #f8fafc !important;
          border-bottom: 2px solid #d1d5db !important;
          border-right: none !important;
          text-transform: uppercase !important;
          letter-spacing: 0.3px !important;
          white-space: normal !important;
          word-wrap: break-word !important;
          line-height: 1.2 !important;
          text-align: center !important;
          padding: 12px 8px !important;
          overflow: visible !important;
          text-overflow: unset !important;
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
          height: 100% !important;
        }
        .ag-header-cell {
          border-right: none !important;
          border-left: none !important;
          border: none !important;
        }
        .ag-header-viewport .ag-header-cell {
          border-right: none !important;
          border-left: none !important;
          border: none !important;
        }
        .ag-header-center .ag-header-cell {
          border-right: none !important;
          border-left: none !important;
          border: none !important;
        }
        .ag-header-left .ag-header-cell {
          border-right: none !important;
          border-left: none !important;
          border: none !important;
        }
        .ag-header-right .ag-header-cell {
          border-right: none !important;
          border-left: none !important;
          border: none !important;
        }
        .ag-header-cell-custom {
          border-right: none !important;
          border-left: none !important;
        }
        .ag-header-cell-custom:first-child {
          border-right: none !important;
        }
        .ag-header-cell-custom:nth-child(2) {
          border-right: none !important;
        }
        .ag-header-cell-custom:nth-child(3) {
          border-right: none !important;
        }
        .ag-header-cell-custom:nth-child(4) {
          border-right: none !important;
        }
        .ag-header-cell-custom:nth-child(5) {
          border-right: none !important;
        }
        .ag-header-cell-custom:nth-child(6) {
          border-right: none !important;
        }
        .ag-header-cell-custom:nth-child(7) {
          border-right: none !important;
        }
        .ag-header-cell-custom:nth-child(8) {
          border-right: none !important;
        }
        .ag-header-cell-custom:nth-child(9) {
          border-right: none !important;
        }
        .ag-header-cell-custom:nth-child(10) {
          border-right: none !important;
        }
        .ag-header-cell-custom * {
          border-right: none !important;
        }
        .ag-header-cell-custom::after {
          border-right: none !important;
        }
        .ag-header-cell-custom::before {
          border-right: none !important;
        }
        .ag-cell-centered {
          display: flex;
          align-items: center;
          justify-content: center;
          text-align: center;
          padding: 12px 8px;
        }
        .ag-row {
          border-bottom: 1px solid #e5e7eb;
          transition: all 0.3s ease;
          background-color: #ffffff;
        }
        .ag-row:nth-child(even) {
          background-color: #f8fafc;
        }
        .ag-row:hover {
          background-color: #e2e8f0;
          transform: translateY(-1px);
          box-shadow: 0 4px 15px rgba(75, 85, 99, 0.15);
          border-radius: 8px;
        }
        .ag-body-viewport {
          background-color: #f8fafc;
        }
        .ag-cell {
          border-right: none !important;
          border-left: none !important;
          padding: 12px 8px;
          font-size: 0.875rem;
          line-height: 1.4;
        }
        .ag-cell:last-child {
          border-right: none !important;
        }
        .ag-body-viewport .ag-cell {
          border-right: none !important;
          border-left: none !important;
        }
        .ag-center-cols-viewport .ag-cell {
          border-right: none !important;
          border-left: none !important;
        }
        .ag-root-wrapper {
          border: none;
          box-shadow:
            0 4px 6px -1px rgba(0, 0, 0, 0.1),
            0 2px 4px -1px rgba(0, 0, 0, 0.06);
          border-radius: 12px;
          overflow: hidden;
        }
        .ag-theme-material {
          width: 100% !important;
          max-width: 100% !important;
          overflow-x: auto !important;
          overflow-y: hidden !important;
        }
        .ag-body-viewport {
          background-color: #f8fafc;
          overflow-x: auto !important;
          overflow-y: auto !important;
        }
        .ag-body-viewport .ag-row:nth-child(2n) {
          background-color: #f8fafc !important;
        }
        .ag-body-viewport .ag-row:nth-child(2n + 1) {
          background-color: #ffffff !important;
        }
        .ag-center-cols-viewport .ag-row:nth-child(even) {
          background-color: #f8fafc !important;
        }
        .ag-center-cols-viewport .ag-row:nth-child(odd) {
          background-color: #ffffff !important;
        }
        .ag-body-horizontal-scroll {
          overflow-x: auto !important;
        }
        .ag-center-cols-container {
          width: max-content !important;
        }
        .ag-center-cols-viewport {
          overflow-x: auto !important;
        }
        .ag-paging-panel {
          background-color: #f8fafc;
          border-top: 1px solid #e5e7eb;
        }
        .ag-header-row {
          margin-bottom: 0 !important;
          padding-bottom: 0 !important;
        }
        .ag-header-row-filter {
          margin-top: 0 !important;
          padding-top: 0 !important;
        }
        .ag-header {
          gap: 0 !important;
        }
      `}</style>
      <div className="flex items-center space-x-4 mb-4">
        {/* Toggle Button */}
        <button
          onClick={handleToggle}
          className="bg-gray-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-gray-600 transition-colors"
        >
          {isPDF ? (
            <>
              <FontAwesomeIcon icon={faToggleOn} className="mr-1.5 text-xs" />
              Switch to CSV
            </>
          ) : (
            <>
              <FontAwesomeIcon icon={faToggleOff} className="mr-1.5 text-xs" />
              Switch to PDF
            </>
          )}
        </button>

        {/* Conditional Buttons */}
        {isPDF ? (
          <>
            <button
              onClick={onExportPDF}
              className="bg-green-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-green-600 transition-colors"
            >
              Download PDF
              <FontAwesomeIcon icon={faDownload} className="ml-1.5 text-xs" />
            </button>
          </>
        ) : (
          <>
            <button
              onClick={onExport}
              className="bg-blue-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-blue-600 transition-colors"
            >
              Download CSV
              <FontAwesomeIcon icon={faDownload} className="ml-1.5 text-xs" />
            </button>
          </>
        )}
      </div>

      <br />
      {loading ? (
        <div className="flex items-center justify-center p-8">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto mb-2"></div>
            <p className="text-gray-600">Loading visitor data...</p>
          </div>
        </div>
      ) : error ? (
        <div className="flex items-center justify-center p-8">
          <div className="text-center">
            <div className="text-red-500 text-6xl mb-4">⚠️</div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">
              Error Loading Data
            </h3>
            <p className="text-gray-600 mb-4">{error}</p>
            <button
              onClick={() => window.location.reload()}
              className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md transition-colors"
            >
              Retry
            </button>
          </div>
        </div>
      ) : rowData.length === 0 ? (
        <div className="flex items-center justify-center p-8">
          <div className="text-center">
            <div className="text-gray-400 text-6xl mb-4">📋</div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">
              No Visitors Found
            </h3>
            <p className="text-gray-600">
              There are no visitors to display at this time.
            </p>
          </div>
        </div>
      ) : (
        <div style={{ width: '100%', overflow: 'hidden' }}>
          <div
            className="ag-theme-material"
            style={{
              height: 500,
              width: '100%',
              overflowX: 'auto',
              overflowY: 'hidden',
            }}
          >
            <AgGridReact
              rowData={getExpandedRowData()}
              columnDefs={columnDefs}
              defaultColDef={defaultColDef}
              icons={customIcons}
              pagination={true}
              paginationPageSize={20}
              rowHeight={60}
              onGridReady={onGridReady}
              suppressMovableColumns={true}
              suppressHorizontalScroll={false}
              alwaysShowHorizontalScroll={false}
              suppressColumnVirtualisation={true}
              getRowClass={(params) => {
                const isGroupMember = params.data.isGroupMember
                const hasValidParent =
                  params.data.parentVisitorId &&
                  params.data.parentVisitorId !== params.data.visitor_id
                const parentVisitorId = params.data.parentVisitorId
                const isParentExpanded = parentVisitorId
                  ? expandedVisitors[parentVisitorId]
                  : false

                if (isGroupMember && hasValidParent && isParentExpanded) {
                  return 'child-row'
                }
                return null
              }}
            />
          </div>
        </div>
      )}

      <Modal open={openModal} onClose={handleClose}>
        <Box sx={stylees.modal}>
          <Formik
            initialValues={{
              first_name: selectedVisitor?.first_name || '',
              last_name: selectedVisitor?.last_name || '',
              start_date: selectedVisitor?.start_date || '',
              end_date: selectedVisitor?.end_date || '',
              time_of_visit: selectedVisitor?.time_of_visit || '',
              time_to_exit: selectedVisitor?.time_to_exit || '',
              phNo: selectedVisitor?.ph_no || selectedVisitor?.phone || '',
              ph_ext: selectedVisitor?.ph_ext || '',
              email: selectedVisitor?.email || '',
              purpose_of_visit: selectedVisitor?.purpose_of_visit || '',
              bookingTime: selectedVisitor?.bookingTime || '',
              action: selectedVisitor?.action || '',
              visitor_id: selectedVisitor?.visitor_id || '',
              branch_id: selectedVisitor?.branch_id || branch_id,
            }}
            validationSchema={validationSchemas}
            onSubmit={handleConfirm}
          >
            {({ values, handleChange, setFieldValue }) => (
              <Form>
                <div className="grid grid-cols-2 gap-4">
                  <FormikTextField
                    label="First Name"
                    name="first_name"
                    value={values.first_name}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <FormikTextField
                    label="Last Name"
                    name="last_name"
                    value={values.last_name}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <TextField
                    label="Visit Start Date"
                    name="start_date"
                    value={values.start_date}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <FormikDatePicker
                    name="end_date"
                    label="Visit End Date *"
                    value={values.end_date}
                    variant="outlined"
                    fullWidth
                    onChange={handleChange}
                  />
                  <TextField
                    label="Visit Start Time"
                    name="time_of_visit"
                    value={values.time_of_visit}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <FormikTimePicker
                    name="time_to_exit"
                    label="Visit End Time *"
                  />
                  <TextField
                    label="Email"
                    name="email"
                    value={values.email}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <FormikSelect
                    name="ph_ext"
                    label="Country Code"
                    options={
                      isCountryCodesLoading
                        ? [{ value: '', label: 'Loading...' }]
                        : countrycodes.map((country) => ({
                            value: country.code,
                            label: `${country.country} (${country.code})`,
                          }))
                    }
                    value={values.ph_ext}
                    variant="outlined"
                    fullWidth
                    onChange={(e) => setFieldValue('ph_ext', e.target.value)}
                    disabled={true}
                  />
                  <FormikTextField
                    label="Phone Number"
                    name="phNo"
                    value={values.phNo}
                    variant="outlined"
                    fullWidth
                    onChange={(e) => setFieldValue('phNo', e.target.value)}
                    disabled={true}
                  />
                  <TextField
                    label="Purpose Of Visit"
                    name="purpose_of_visit"
                    value={values.purpose_of_visit}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <TextField
                    label="Booking Time"
                    name="bookingTime"
                    value={values.bookingTime}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <TextField
                    label="Status"
                    name="action"
                    value={values.action}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                </div>
                <div className="flex justify-center gap-4 mt-4">
                  <button
                    type="submit"
                    className="bg-primary text-white px-4 py-2 rounded"
                  >
                    Confirm
                  </button>
                  <button
                    type="button"
                    onClick={() => setOpenModal(false)}
                    className="bg-gray-300 px-4 py-2 rounded"
                  >
                    Cancel
                  </button>
                </div>
              </Form>
            )}
          </Formik>
        </Box>
      </Modal>

      <Modal open={editModalOpen} onClose={handleEditClose}>
        <Box sx={stylees.modal}>
          <Formik
            initialValues={{
              first_name: selectedVisitor?.first_name || '',
              last_name: selectedVisitor?.last_name || '',
              start_date: selectedVisitor?.start_date || '',
              end_date: selectedVisitor?.end_date || '',
              time_of_visit: selectedVisitor?.time_of_visit || '',
              time_to_exit: selectedVisitor?.time_to_exit || '',
              phNo: selectedVisitor?.ph_no || selectedVisitor?.phone || '',
              ph_ext:
                selectedVisitor?.ph_no || selectedVisitor?.phone
                  ? selectedVisitor?.ph_ext || ''
                  : '',
              email: selectedVisitor?.email || '',
              purpose_of_visit: selectedVisitor?.purpose_of_visit || '',
              bookingTime: selectedVisitor?.bookingTime || '',
              action: selectedVisitor?.action || '',
              visitor_code: selectedVisitor?.visitor_code || '',
              branch_id: selectedVisitor?.branch_id || branch_id,
              visitor_id: selectedVisitor?.visitor_id || '',
              area_of_permit:
                selectedVisitor?.areas_list
                  ?.filter((area) => area.isActive)
                  ?.map((area) => ({
                    area_id: area.area_id,
                    area_name: area.area_name,
                  })) || [],
            }}
            validationSchema={validationSchema}
            onSubmit={handleEditConfirm}
          >
            {({ values, setFieldValue, errors, touched }) => (
              <Form>
                <div className="grid grid-cols-2 gap-4">
                  <FormikTextField
                    label="First Name"
                    name="first_name"
                    value={values.first_name}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <FormikTextField
                    label="Last Name"
                    name="last_name"
                    value={values.last_name}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <TextField
                    label="Visit Start Date"
                    name="start_date"
                    value={values.start_date}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <TextField
                    label="Visit End Date"
                    name="end_date"
                    value={values.end_date}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <TextField
                    label="Visit Start Time"
                    name="time_of_visit"
                    value={values.time_of_visit}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <TextField
                    label="Visit End Time"
                    name="time_to_exit"
                    value={values.time_to_exit}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <FormikSelect
                    name="ph_ext"
                    label="Country Code *"
                    options={
                      isCountryCodesLoading
                        ? [{ value: '', label: 'Loading...' }]
                        : countrycodes.map((country) => ({
                            value: country.code,
                            label: `${country.country} (${country.code})`,
                          }))
                    }
                    onChange={(event) => {
                      const countryCodeValue = event.target.value
                      setFieldValue('ph_ext', countryCodeValue)
                      // If country code is cleared, clear phone number
                      if (!countryCodeValue || countryCodeValue.trim() === '') {
                        setFieldValue('phNo', '')
                      }
                    }}
                    value={values.ph_ext} // Ensure the correct Formik value is passed
                    disabled={isCountryCodesLoading}
                  />
                  <FormikTextField
                    label="Phone Number"
                    name="phNo"
                    value={values.phNo}
                    variant="outlined"
                    fullWidth
                    onChange={(e) => {
                      const phoneValue = e.target.value
                      setFieldValue('phNo', phoneValue)
                      // If phone number is empty, clear country code
                      if (!phoneValue || phoneValue.trim() === '') {
                        setFieldValue('ph_ext', '')
                      }
                    }}
                  />
                  <MultiSelectForm
                    name="area_of_permit"
                    label="Select Area *"
                    options={selectedVisitor?.areas_list.map((area) => ({
                      value: area.area_id,
                      label: area.area_name,
                    }))}
                    onChange={(selectedValues) => {
                      setFieldValue('area_of_permit', selectedValues)
                    }}
                    disabled={false}
                  />
                  <FormikTextField
                    label="Email"
                    name="email"
                    value={values.email}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <TextField
                    label="Purpose Of Visit"
                    name="purpose_of_visit"
                    value={values.purpose_of_visit}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                </div>
                <div className="flex justify-center gap-4 mt-4">
                  <button
                    type="submit"
                    className="bg-primary text-white px-4 py-2 rounded"
                  >
                    Update
                  </button>
                  <button
                    type="button"
                    onClick={handleEditClose}
                    className="bg-gray-300 px-4 py-2 rounded"
                  >
                    Cancel
                  </button>
                </div>
              </Form>
            )}
          </Formik>
        </Box>
      </Modal>
    </div>
  )
}

export default VisitorsTable
