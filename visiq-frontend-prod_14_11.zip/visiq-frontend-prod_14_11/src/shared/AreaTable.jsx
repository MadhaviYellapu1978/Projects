// import React, { useEffect, useState } from 'react';
// import AreaImage from '../assets/AreaImage.png';

// const AreaTable = ({ data }) => {
//   const [areaList, setAreaList] = useState([]);

//   // Sync prop data with local state
//   useEffect(() => {
//     if (data && data.length) {
//       setAreaList(data);
//     }
//   }, [data]);

//   const handleToggle = (index) => {
//     const updatedAreas = [...areaList];
//     updatedAreas[index].decat = !updatedAreas[index].decat;
//     setAreaList(updatedAreas);
//   };

//   return (
//     <div
//       style={{
//         display: 'flex',
//         gap: '20px',
//         padding: '20px',
//         backgroundColor: 'white',
//       }}
//       className="mt-5"
//     >
//       {/* Left Side: Area List */}
//       <div
//         style={{
//           flex: 1,
//           background: '#f5f8fc',
//           borderRadius: '8px',
//           padding: '20px',
//           boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
//           maxHeight: '470px',
//           overflowY: 'auto',
//         }}
//       >
//         <h3 className="mb-5 text-2xl font-semibold">Areas</h3>
//         <ul style={{ listStyleType: 'none', padding: 0, margin: 0 }}>
//           {areaList.map((item, index) => (
//             <li
//               key={item.area_id}
//               style={{
//                 padding: '10px 0',
//                 borderBottom: '1px solid #e0e0e0',
//                 fontSize: '16px',
//                 display: 'flex',
//                 justifyContent: 'space-between',
//                 alignItems: 'center',
//               }}
//             >
//               <span>
//                 {index + 1}. {item.area_name}
//               </span>
//               <label className="switch">
//                 <input
//                   type="checkbox"
//                   checked={item.decat}
//                   onChange={() => handleToggle(index)}
//                 />
//                 <span className="slider round"></span>
//               </label>
//             </li>
//           ))}
//         </ul>
//       </div>

//       {/* Right Side: Single Image */}
//       <div
//         style={{
//           flex: 2,
//           display: 'flex',
//           justifyContent: 'center',
//           alignItems: 'center',
//         }}
//       >
//         <img
//           src={AreaImage}
//           alt="Area Representation"
//           style={{
//             maxWidth: '100%',
//             height: 'auto',
//             borderRadius: '8px',
//             boxShadow: '0 1px 4px rgba(0, 0, 0, 0.2)',
//           }}
//         />
//       </div>

//       {/* Toggle CSS */}
//       <style>
//         {`
//           .switch {
//             position: relative;
//             display: inline-block;
//             width: 40px;
//             height: 22px;
//           }

//           .switch input {
//             opacity: 0;
//             width: 0;
//             height: 0;
//           }

//           .slider {
//             position: absolute;
//             cursor: pointer;
//             top: 0;
//             left: 0;
//             right: 0;
//             bottom: 0;
//             background-color: #ccc;
//             transition: 0.4s;
//             border-radius: 34px;
//           }

//           .slider:before {
//             position: absolute;
//             content: "";
//             height: 16px;
//             width: 16px;
//             left: 3px;
//             bottom: 3px;
//             background-color: white;
//             transition: 0.4s;
//             border-radius: 50%;
//           }

//           input:checked + .slider {
//             background-color: #4caf50;
//           }

//           input:checked + .slider:before {
//             transform: translateX(18px);
//           }
//         `}
//       </style>
//     </div>
//   );
// };

// export default AreaTable;
import React, { useEffect, useState } from 'react'
import { useMutation } from '@tanstack/react-query'
import { areaDecatEnable } from '../services/adminService'

const AreaTable = ({ data, onAddArea }) => {
  const [areaList, setAreaList] = useState([])
  const [loadingToggles, setLoadingToggles] = useState({})

  useEffect(() => {
    if (Array.isArray(data)) {
      setAreaList(data)
    } else {
      setAreaList([])
    }
  }, [data])

  const mutation = useMutation({
    mutationFn: (payload) => areaDecatEnable(payload),
    onMutate: (variables) => {
      setLoadingToggles((prev) => ({
        ...prev,
        [variables.area_id]: true,
      }))
    },
    onSuccess: (data, variables) => {
      setLoadingToggles((prev) => ({
        ...prev,
        [variables.area_id]: false,
      }))
    },
    onError: (error, variables) => {
      const updatedAreas = [...areaList]
      const index = updatedAreas.findIndex(
        (item) => item.area_id === variables.area_id,
      )
      if (index !== -1) {
        updatedAreas[index].decat = !variables.decat
        setAreaList(updatedAreas)
      }
      setLoadingToggles((prev) => ({
        ...prev,
        [variables.area_id]: false,
      }))
      console.error('Mutation failed:', error)
    },
  })

  const handleToggle = (index) => {
    const updatedAreas = [...areaList]
    const updatedArea = updatedAreas[index]
    const newDecatValue = !updatedArea.decat

    updatedArea.decat = newDecatValue
    setAreaList(updatedAreas)

    mutation.mutate({
      area_id: updatedArea.area_id,
      branch_id: updatedArea?.branch_id,
      decat: newDecatValue,
    })
  }

  return (
    <div className="ml-4 mt-2 max-w-5xl">
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Areas</h3>
          {onAddArea && (
            <button className="btn bg-[#0F1D40] text-white" onClick={onAddArea}>
              + Add Area
            </button>
          )}
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="bg-[#F5F8FC] text-sm text-gray-600">
                <th className="text-left p-2 rounded-l-lg">Area Name</th>
                <th className="text-right p-2 pr-8 rounded-r-lg">Status</th>
              </tr>
            </thead>
            <tbody className="text-sm">
              {areaList.map((item, index) => (
                <tr key={item.area_id} className="border-b last:border-b-0">
                  <td className="p-2">{item.area_name}</td>
                  <td className="p-2 text-right">
                    <div className="flex items-center gap-2 justify-end">
                      <label className="switch">
                        <input
                          type="checkbox"
                          checked={item.decat}
                          onChange={() => handleToggle(index)}
                          disabled={loadingToggles[item.area_id]}
                        />
                        <span className="slider round"></span>
                      </label>
                      <div className="flex items-center gap-1">
                        {loadingToggles[item.area_id] && (
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-500"></div>
                        )}
                        <span
                          className={
                            item.decat ? 'text-green-600' : 'text-red-500'
                          }
                        >
                          {loadingToggles[item.area_id]
                            ? 'Updating...'
                            : item.decat
                              ? 'Active'
                              : 'Inactive'}
                        </span>
                      </div>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <style>
        {`
          .switch {
            position: relative;
            display: inline-block;
            width: 40px;
            height: 22px;
          }
          .switch input {
            opacity: 0;
            width: 0;
            height: 0;
          }
          .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: 0.4s;
            border-radius: 34px;
          }
          .slider:before {
            position: absolute;
            content: '';
            height: 16px;
            width: 16px;
            left: 3px;
            bottom: 3px;
            background-color: white;
            transition: 0.4s;
            border-radius: 50%;
          }
          input:checked + .slider {
            background-color: #4caf50;
          }
          input:checked + .slider:before {
            transform: translateX(18px);
          }
        `}
      </style>
    </div>
  )
}

export default AreaTable
