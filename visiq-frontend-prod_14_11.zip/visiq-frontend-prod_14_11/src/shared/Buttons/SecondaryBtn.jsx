import React from 'react'

const SecondaryBtn = ({ type, text, handleClick }) => {
  return (
    <button
      type={type}
      className="btn border-2 border-primary py-2 text-center text-primary rounded-md px-6"
      onClick={handleClick}
    >
      {text}
    </button>
  )
}

export default SecondaryBtn
