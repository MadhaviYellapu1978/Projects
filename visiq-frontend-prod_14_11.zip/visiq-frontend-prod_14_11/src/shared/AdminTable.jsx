// 'use strict'
// import React, { useMemo, useState, useEffect, useRef, useCallback } from 'react'
// import { AgGridReact } from 'ag-grid-react'
// import 'ag-grid-community/styles/ag-grid.css'
// import 'ag-grid-community/styles/ag-theme-material.css'

// const AdminTable = ({ data }) => {
//   const [rowData, setRowData] = useState([])
//   const gridApiRef = useRef(null)
//   const columnApiRef = useRef(null)

//   useEffect(() => {
//     // Update the action field based on isVisited value
//     const updatedData = data.map((item) => ({
//       ...item,
//       action: item.isVisited ? 'Arrived' : 'Yet To Arrive',
//     }))
//     setRowData(updatedData)
//   }, [data])

//   const columnDefs = useMemo(
//     () => [
//       {
//         headerName: 'First Name',
//         field: 'first_name',
//         headerClass: 'header-bold',
//         cellClass: 'ag-cell-centered',
//       },
//       {
//         headerName: 'Last Name',
//         field: 'last_name',
//         headerClass: 'header-bold',
//         cellClass: 'ag-cell-centered',
//       },
//       {
//         headerName: 'User Name',
//         field: 'username',
//         headerClass: 'header-bold',
//         cellClass: 'ag-cell-centered',
//       },
//       {
//         headerName: 'Email',
//         field: 'email',
//         headerClass: 'header-bold',
//         cellClass: 'ag-cell-centered',
//       },
//       {
//         headerName: 'Phone Number',
//         field: 'phone',
//         headerClass: 'header-bold',
//         cellClass: 'ag-cell-centered',
//       },
//     ],
//     [],
//   )

//   const defaultColDef = useMemo(
//     () => ({
//       filter: 'agTextColumnFilter',
//       floatingFilter: true,
//       cellClass: 'ag-cell-centered', // Apply to all columns by default
//       resizable: true, // Make columns resizable
//     }),
//     [],
//   )

//   const customIcons = {
//     sortAscending: '<i class="fa fa-sort-asc"></i>',
//     sortDescending: '<i class="fa fa-sort-desc"></i>',
//     // Add more custom icons here if needed
//   }

//   const onGridReady = useCallback((params) => {
//     gridApiRef.current = params.api
//     columnApiRef.current = params.columnApi
//     // Auto size columns to fit content
//     params.api.sizeColumnsToFit()
//     window.addEventListener('resize', () => {
//       params.api.sizeColumnsToFit()
//     })
//   }, [])

//   return (
//     <div>
//       <br />
//       <div className="mt-5 p-6">
//         <div
//           className="ag-theme-material"
//           style={{ height: 500, width: '100%' }}
//         >
//           <AgGridReact
//             rowData={rowData}
//             columnDefs={columnDefs}
//             defaultColDef={defaultColDef}
//             icons={customIcons}
//             pagination={true}
//             paginationPageSize={10}
//             onGridReady={onGridReady}
//             suppressMovableColumns={true}
//             domLayout="autoHeight"
//           />
//         </div>
//       </div>
//     </div>
//   )
// }

// export default AdminTable

'use strict'
import React, { useMemo, useState, useEffect, useRef, useCallback } from 'react'
import { AgGridReact } from 'ag-grid-react'
import 'ag-grid-community/styles/ag-grid.css'
import 'ag-grid-community/styles/ag-theme-material.css'
import NoDataImage from '../assets/NoDataPic.png'
const AdminTable = ({ data, isLoading = false }) => {
  const [rowData, setRowData] = useState([])
  const gridApiRef = useRef(null)
  const columnApiRef = useRef(null)

  useEffect(() => {
    if (data && Array.isArray(data)) {
      // Update the action field based on isVisited value
      const updatedData = data.map((item) => ({
        ...item,
        action: item.isVisited ? 'Arrived' : 'Yet To Arrive',
      }))
      setRowData(updatedData)
    } else {
      setRowData([])
    }
  }, [data])

  const columnDefs = useMemo(
    () => [
      {
        headerName: 'First Name',
        field: 'first_name',
        headerClass: 'header-bold',
        cellClass: 'ag-cell-centered',
      },
      {
        headerName: 'Last Name',
        field: 'last_name',
        headerClass: 'header-bold',
        cellClass: 'ag-cell-centered',
      },
      {
        headerName: 'User Name',
        field: 'username',
        headerClass: 'header-bold',
        cellClass: 'ag-cell-centered',
      },
      {
        headerName: 'Email',
        field: 'email',
        headerClass: 'header-bold',
        cellClass: 'ag-cell-centered',
      },
      {
        headerName: 'Phone Number',
        field: 'phone',
        headerClass: 'header-bold',
        cellClass: 'ag-cell-centered',
      },
    ],
    [],
  )

  const defaultColDef = useMemo(
    () => ({
      filter: 'agTextColumnFilter',
      floatingFilter: true,
      cellClass: 'ag-cell-centered', // Apply to all columns by default
      resizable: true, // Make columns resizable
    }),
    [],
  )

  const customIcons = {
    sortAscending: '<i class="fa fa-sort-asc"></i>',
    sortDescending: '<i class="fa fa-sort-desc"></i>',
    // Add more custom icons here if needed
  }

  const onGridReady = useCallback((params) => {
    gridApiRef.current = params.api
    columnApiRef.current = params.columnApi
    // Auto size columns to fit content
    params.api.sizeColumnsToFit()
    window.addEventListener('resize', () => {
      params.api.sizeColumnsToFit()
    })
  }, [])

  return (
    <div>
      <div className=" ">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
            <p className="mt-4 text-gray-600">Loading data...</p>
          </div>
        ) : rowData.length === 0 ? (
          <div className="flex flex-col items-center">
            <img
              src={NoDataImage}
              alt="No data available illustration"
              className="w-82 h-70 object-contain"
              style={{
                maxWidth: '45%',
                maxHeight: '45%',
                objectFit: 'fit',
              }}
            />
          </div>
        ) : (
          <div
            className="ag-theme-material"
            style={{ height: 500, width: '100%' }}
          >
            <AgGridReact
              rowData={rowData}
              columnDefs={columnDefs}
              defaultColDef={defaultColDef}
              icons={customIcons}
              pagination={true}
              paginationPageSize={20}
              onGridReady={onGridReady}
              suppressMovableColumns={true}
              domLayout="autoHeight"
            />
          </div>
        )}
      </div>
    </div>
  )
}

export default AdminTable
