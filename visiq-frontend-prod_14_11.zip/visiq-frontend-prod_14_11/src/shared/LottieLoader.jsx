// import React from "react";
// import Lottie from "lottie-react";

// const LottieLoader = ({ data }) => {
//   return (
//     <div className="flex justify-center items-center h-full w-full ">
//       <Lottie animationData={data} alt="loading" style={{ height: "30vh" }} />
//     </div>
//   );
// };

// export default LottieLoader;

import React from 'react'
import Lottie from 'lottie-react'

const LottieLoader = ({ data, height = '30vh' }) => {
  return (
    <div className="fixed inset-0 flex justify-center items-center">
      <Lottie animationData={data} alt="loading" style={{ height: height }} />
    </div>
  )
}

export default LottieLoader

// import React from 'react';
// import Lottie from 'lottie-react';
// import facialRecognitionData from '../assets/facial-recognition.json'; // Adjust path if necessary

// const LottieLoader = () => {
//   return (
//     <div className="fixed inset-0 flex justify-center items-center bg-white">
//       <Lottie animationData={facialRecognitionData} alt="Facial Recognition Loading" style={{ height: '30vh' }} />
//     </div>
//   );
// };

// export default LottieLoader
