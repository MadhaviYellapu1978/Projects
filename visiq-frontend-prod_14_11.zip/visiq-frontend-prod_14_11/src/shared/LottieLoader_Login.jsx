// import React from "react";
// import Lottie from "lottie-react";

// const LottieLoader = ({ data }) => {
//   return (
//     <div className="flex justify-center items-center h-full w-full ">
//       <Lottie animationData={data} alt="loading" style={{ height: "30vh" }} />
//     </div>
//   );
// };

// export default LottieLoader;

import React from 'react'
import Lottie from 'lottie-react'

const LottieLoader = ({ data }) => {
  return (
    <div className="ml-20">
      <Lottie animationData={data} alt="loading" style={{ height: '30vh' }} />
    </div>
  )
}

export default LottieLoader
