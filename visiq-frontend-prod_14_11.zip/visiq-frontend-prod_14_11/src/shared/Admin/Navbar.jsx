import Logo from '../Logo'
import { logout } from '../../assets'
import Drawer from './Drawer'
import { useNavigate } from 'react-router-dom'
import React, { useContext } from 'react'
import { AuthContext } from '../../context/AuthContext'
import Pick from '../../assets/profile.png'

// Function to map role IDs to role names
const getRoleName = (role, org_name) => {
  switch (role) {
    case '1':
      return <>Super Admin</>
    case '2':
      return (
        <>
          <strong>{org_name}</strong> <br /> Organization Admin
        </>
      )
    case '3':
      return (
        <>
          <strong>{org_name}</strong> <br /> Branch Admin
        </>
      )
    case '4':
      return (
        <>
          <strong>{org_name}</strong> <br /> Security Admin
        </>
      )
    default:
      return <>User</> // Default role name if role is not recognized
  }
}

const Navbar = () => {
  const [open, setOpen] = React.useState(false)
  const navigate = useNavigate()
  const auth = useContext(AuthContext)

  return (
    <>
      <nav className="navbar bg-base-100 drop-shadow sticky top-0 z-50">
        <div className="flex-none">
          <button
            className="btn btn-square btn-ghost"
            onClick={() => setOpen(!open)}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              className="inline-block w-5 h-5 stroke-current"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M4 6h16M4 12h16M4 18h16"
              ></path>
            </svg>
          </button>
        </div>
        <div className="flex-1 flex items-center">
          <a className="text-xl">
            <Logo />
          </a>
        </div>
        <div className="flex-none flex items-center gap-4">
          <div className="flex items-center gap-2">
            <img
              src={Pick}
              alt="avatar"
              className="h-12 w-12 rounded-full border-2 border-gray-300 shadow-lg"
              style={{ objectFit: 'cover' }}
            />
            <span
              style={{ marginLeft: '10px' }}
              className="text-sm font-medium"
            >
              {getRoleName(auth.role, auth.org_name)}
            </span>
          </div>
          <button
            className="btn btn-ghost"
            onClick={() => {
              auth.logout()
              navigate('/auth/login')
            }}
          >
            <img src={logout} alt="logout" className="h-4" />
          </button>
        </div>
      </nav>
      {open && <Drawer open={open} setOpen={setOpen} />}
    </>
  )
}

export default Navbar

// import Logo from '../Logo'
// import { logout } from '../../assets'
// import Drawer from './Drawer'
// import { useNavigate } from 'react-router-dom'
// import React, { useContext, useState } from 'react'
// import { AuthContext } from '../../context/AuthContext'
// import Pick from '../../assets/profile.png'

// // Function to map role IDs to role names
// const getRoleName = (role, org_name) => {
//   switch (role) {
//     case '1':
//       return <>Super Admin</>
//     case '2':
//       return (
//         <>
//           <strong>{org_name}</strong> <br /> Organization Admin
//         </>
//       )
//     case '3':
//       return (
//         <>
//           <strong>{org_name}</strong> <br /> Branch Admin
//         </>
//       )
//     case '4':
//       return (
//         <>
//           <strong>{org_name}</strong> <br /> Security Admin
//         </>
//       )
//     default:
//       return <>User</> // Default role name if role is not recognized
//   }
// }

// const Navbar = () => {
//   const [open, setOpen] = React.useState(false)
//   const [showLogoutModal, setShowLogoutModal] = useState(false)
//   const navigate = useNavigate()
//   const auth = useContext(AuthContext)

//   const handleLogout = () => {
//     localStorage.clear()
//     navigate('/auth/login')
//   }

//   return (
//     <>
//       <nav className="navbar bg-base-100 drop-shadow">
//         <div className="flex-none">
//           <button
//             className="btn btn-square btn-ghost"
//             onClick={() => setOpen(!open)}
//           >
//             <svg
//               xmlns="http://www.w3.org/2000/svg"
//               fill="none"
//               viewBox="0 0 24 24"
//               className="inline-block w-5 h-5 stroke-current"
//             >
//               <path
//                 strokeLinecap="round"
//                 strokeLinejoin="round"
//                 strokeWidth="2"
//                 d="M4 6h16M4 12h16M4 18h16"
//               ></path>
//             </svg>
//           </button>
//         </div>
//         <div className="flex-1 flex items-center">
//           <a className="text-xl">
//             <Logo />
//           </a>
//         </div>
//         <div className="flex-none flex items-center gap-4">
//           <div className="flex items-center gap-2">
//             <img
//               src={Pick}
//               alt="avatar"
//               className="h-12 w-12 rounded-full border-2 border-gray-300 shadow-lg"
//               style={{ objectFit: 'cover' }}
//             />
//             <span
//               style={{ marginLeft: '10px' }}
//               className="text-sm font-medium"
//             >
//               {getRoleName(auth.role, auth.org_name)}
//             </span>
//           </div>
//           <button
//             className="btn btn-ghost"
//             onClick={() => setShowLogoutModal(true)}
//           >
//             <img src={logout} alt="logout" className="h-4" />
//           </button>
//         </div>
//       </nav>

//       {/* Logout Confirmation Modal */}
//       {showLogoutModal && (
//         <div className="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50 z-50">
//           <div className="bg-white p-6 rounded-lg shadow-lg">
//             <h3 className="text-lg font-medium mb-4">Are you sure you want to logout?</h3>
//             <div className="flex justify-end gap-4">
//               <button
//                 className="btn bg-teal-300 "
//                 onClick={handleLogout}
//               >
//                 Yes
//               </button>
//               <button
//                 className="btn bg-teal-300"
//                 onClick={() => setShowLogoutModal(false)}
//               >
//                 No
//               </button>
//             </div>
//           </div>
//         </div>
//       )}

//       {open && <Drawer open={open} setOpen={setOpen} />}
//     </>
//   )
// }

// export default Navbar
