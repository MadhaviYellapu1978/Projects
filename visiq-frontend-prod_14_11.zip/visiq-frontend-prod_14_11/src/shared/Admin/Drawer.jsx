// // import React, { useContext } from 'react'
// // import { useNavigate } from 'react-router-dom'
// // import { Drawer, IconButton, List, ListItem, ListItemText } from '@mui/material'
// // import CloseIcon from '@mui/icons-material/Close'
// // import { AuthContext } from '../../context/AuthContext'

// // const DrawerComponent = ({ open, setOpen }) => {
// //   const auth = useContext(AuthContext)
// //   const navigate = useNavigate()

// //   const closeDrawer = () => setOpen(false)

// //   const handlePasswordChangeClick = () => {
// //     closeDrawer()
// //     if (auth.role === '2') {
// //       navigate('/admin/change-password')
// //     } else if (auth.role === '3') {
// //       navigate('/branchAdmin/change-password')
// //     } else if (auth.role === '4') {
// //       navigate('/securityLevelAdmin/change-password')
// //     }
// //   }

// //   const handleToHomeChangeClick = () => {
// //     closeDrawer()
// //     if (auth.role === '2') {
// //       navigate('/admin/dashboard')
// //     } else if (auth.role === '3') {
// //       navigate('/branchAdmin/dashboard')
// //     } else if (auth.role === '4') {
// //       navigate('/securityLevelAdmin/dashboard')
// //     }
// //   }

// //   const handleDashBoardChangeClick = () => {
// //     closeDrawer()
// //     if (auth.role === '2') {
// //       navigate('/admin/dashboard-graphs')
// //     } else if (auth.role === '3') {
// //       navigate('/branchAdmin/dashboard-graphs')
// //     }
// //   }
// //   return (
// //     <Drawer
// //       anchor="left"
// //       open={open}
// //       onClose={closeDrawer}
// //       PaperProps={{
// //         sx: {
// //           width: 240, // Width of the drawer
// //           display: 'flex',
// //           flexDirection: 'column',
// //         },
// //       }}
// //     >
// //       {/* Close button inside the drawer */}
// //       <div className="drawer-header">
// //         <IconButton
// //           onClick={closeDrawer}
// //           sx={{ alignSelf: 'flex-end', margin: 1 }}
// //         >
// //           <CloseIcon />
// //         </IconButton>
// //       </div>

// //       <List>
// //         <ListItem button onClick={handleToHomeChangeClick}>
// //           <ListItemText primary="Home" />
// //         </ListItem>
// //         <ListItem button onClick={handlePasswordChangeClick}>
// //           <ListItemText primary="Change Password" />
// //         </ListItem>
// //         {auth.role !== '4' && (
// //           <ListItem button onClick={handleDashBoardChangeClick}>
// //             <ListItemText primary="Dashboard" />
// //           </ListItem>
// //         )}
// //         <ListItem
// //           button
// //           onClick={() => {
// //             /* Handle logout */
// //           }}
// //         ></ListItem>
// //       </List>
// //     </Drawer>
// //   )

// // }

// // export default DrawerComponent

// import React, { useContext } from 'react';
// import { useNavigate } from 'react-router-dom';
// import { Drawer, IconButton, List, ListItem, ListItemText, ListItemIcon, Divider, Typography } from '@mui/material';
// import HomeIcon from '@mui/icons-material/Home';
// import LockIcon from '@mui/icons-material/Lock';
//
// import ExitToAppIcon from '@mui/icons-material/ExitToApp';
// import CloseIcon from '@mui/icons-material/Close';
// import { AuthContext } from '../../context/AuthContext';
// import './DrawerComponent.css'; // Import custom CSS

// const DrawerComponent = ({ open, setOpen }) => {
//   const auth = useContext(AuthContext);
//   const navigate = useNavigate();

//   const closeDrawer = () => setOpen(false);

//   const handlePasswordChangeClick = () => {
//     closeDrawer();
//     if (auth.role === '2') {
//       navigate('/admin/change-password');
//     } else if (auth.role === '3') {
//       navigate('/branchAdmin/change-password');
//     } else if (auth.role === '4') {
//       navigate('/securityLevelAdmin/change-password');
//     }
//   };

//   const handleToHomeChangeClick = () => {
//     closeDrawer();
//     if (auth.role === '2') {
//       navigate('/admin/dashboard');
//     } else if (auth.role === '3') {
//       navigate('/branchAdmin/dashboard');
//     } else if (auth.role === '4') {
//       navigate('/securityLevelAdmin/dashboard');
//     }
//   };

//   const handleDashBoardChangeClick = () => {
//     closeDrawer();
//     if (auth.role === '2') {
//       navigate('/admin/dashboard-graphs');
//     } else if (auth.role === '3') {
//       navigate('/branchAdmin/dashboard-graphs');
//     }
//   };

//   const handleLogout = () => {
//     localStorage.clear()
//     navigate('/auth/login')
//     closeDrawer();
//   };

//   return (
//     <Drawer
//       anchor="left"
//       open={open}
//       onClose={closeDrawer}
//       PaperProps={{
//         sx: {
//           width: 280, // Width of the drawer
//           display: 'flex',
//           flexDirection: 'column',
//           backgroundColor: '#f0f0f0', // Light background color
//         },
//       }}
//     >
//       {/* Drawer Header */}
//       <div className="drawer-header">
//         <Typography variant="h6" className="drawer-title">Menu</Typography>
//         <IconButton
//           onClick={closeDrawer}
//           className="drawer-close-button"
//         >
//           <CloseIcon />
//         </IconButton>
//       </div>
//       <Divider />

//       {/* Drawer List */}
//       <List>
//         <ListItem button onClick={handleToHomeChangeClick}>
//           <ListItemIcon className="list-icon">
//             <HomeIcon />
//           </ListItemIcon>
//           <ListItemText primary="Home" />
//         </ListItem>
//         <ListItem button onClick={handlePasswordChangeClick}>
//           <ListItemIcon className="list-icon">
//             <LockIcon />
//           </ListItemIcon>
//           <ListItemText primary="Change Password" />
//         </ListItem>
//         {auth.role !== '4' && (
//           <ListItem button onClick={handleDashBoardChangeClick}>
//             <ListItemIcon className="list-icon">
//               <DashboardIcon />
//             </ListItemIcon>
//             <ListItemText primary="Dashboard" />
//           </ListItem>
//         )}
//         <ListItem button onClick={handleLogout}>
//           <ListItemIcon className="list-icon">
//             <ExitToAppIcon />
//           </ListItemIcon>
//           <ListItemText primary="Logout" />
//         </ListItem>
//       </List>
//     </Drawer>
//   );
// };

// export default DrawerComponent;

// import React, { useContext } from 'react';
// import { useNavigate } from 'react-router-dom';
// import { Drawer, IconButton, List, ListItem, ListItemText, ListItemIcon, Divider, Typography } from '@mui/material';
// import HomeIcon from '@mui/icons-material/Home';
// import LockIcon from '@mui/icons-material/Lock';
// import DashboardIcon from '@mui/icons-material/Dashboard';
// import ExitToAppIcon from '@mui/icons-material/ExitToApp';
// import CloseIcon from '@mui/icons-material/Close';
// import { AuthContext } from '../../context/AuthContext';
// import './DrawerComponent.css'; // Import custom CSS

// const DrawerComponent = ({ open, setOpen }) => {
//   const auth = useContext(AuthContext);
//   const navigate = useNavigate();

//   const closeDrawer = () => setOpen(false);

//   const handlePasswordChangeClick = () => {
//     closeDrawer();
//     if (auth.role === '2') {
//       navigate('/admin/change-password');
//     } else if (auth.role === '3') {
//       navigate('/branchAdmin/change-password');
//     } else if (auth.role === '4') {
//       navigate('/securityLevelAdmin/change-password');
//     }
//   };

//   const handleToHomeChangeClick = () => {
//     closeDrawer();
//     if (auth.role === '2') {
//       navigate('/admin/dashboard');
//     } else if (auth.role === '3') {
//       navigate('/branchAdmin/dashboard');
//     } else if (auth.role === '4') {
//       navigate('/securityLevelAdmin/dashboard');
//     }
//   };

//   const handleDashBoardChangeClick = () => {
//     closeDrawer();
//     if (auth.role === '2') {
//       navigate('/admin/dashboard-graphs');
//     } else if (auth.role === '3') {
//       navigate('/branchAdmin/dashboard-graphs');
//     }
//   };

//   const handleLogout = () => {
//     localStorage.clear()
//     navigate('/auth/login')
//     closeDrawer();
//   };

//   return (
//     <Drawer
//       anchor="left"
//       open={open}
//       onClose={closeDrawer}
//       PaperProps={{
//         sx: {
//           width: 280, // Width of the drawer
//           display: 'flex',
//           flexDirection: 'column',
//           backgroundColor: '#ffffff', // White background color
//           color: '#333333', // Dark text color
//         },
//       }}
//     >
//       {/* Drawer Header */}
//       <div className="drawer-header">
//         <Typography variant="h6" className="drawer-title">Menu</Typography>
//         <IconButton
//           onClick={closeDrawer}
//           className="drawer-close-button"
//         >
//           <CloseIcon />
//         </IconButton>
//       </div>
//       <Divider />

//       {/* Drawer List */}
//       <List>
//         <ListItem button onClick={handleToHomeChangeClick}>
//           <ListItemIcon className="list-icon">
//             <HomeIcon />
//           </ListItemIcon>
//           <ListItemText primary="Home" />
//         </ListItem>
//         <ListItem button onClick={handlePasswordChangeClick}>
//           <ListItemIcon className="list-icon">
//             <LockIcon />
//           </ListItemIcon>
//           <ListItemText primary="Change Password" />
//         </ListItem>
//         {auth.role !== '4' && (
//           <ListItem button onClick={handleDashBoardChangeClick}>
//             <ListItemIcon className="list-icon">
//               <DashboardIcon />
//             </ListItemIcon>
//             <ListItemText primary="Dashboard" />
//           </ListItem>
//         )}
//         <ListItem button onClick={handleLogout}>
//           <ListItemIcon className="list-icon">
//             <ExitToAppIcon />
//           </ListItemIcon>
//           <ListItemText primary="Logout" />
//         </ListItem>
//       </List>
//     </Drawer>
//   );
// };

// export default DrawerComponent;

import React, { useContext } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Drawer,
  IconButton,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Divider,
  Typography,
} from '@mui/material'
import HomeIcon from '@mui/icons-material/Home'
import LockIcon from '@mui/icons-material/Lock'
import DashboardIcon from '@mui/icons-material/Dashboard'
import ExitToAppIcon from '@mui/icons-material/ExitToApp'
import CloseIcon from '@mui/icons-material/Close'
import { AuthContext } from '../../context/AuthContext'
import CloudUploadIcon from '@mui/icons-material/CloudUpload'
import './DrawerComponent.css' // Import custom CSS
import SupervisorAccountIcon from '@mui/icons-material/SupervisorAccount'

import reports_icon from '../../assets/Visitor_Reports_main.svg'
import ManageAccountsIcon from '@mui/icons-material/ManageAccounts'
import BlockIcon from '@mui/icons-material/Block'
import DirectionsCarIcon from '@mui/icons-material/DirectionsCar'
import GroupIcon from '@mui/icons-material/Group'
const DrawerComponent = ({ open, setOpen }) => {
  const auth = useContext(AuthContext)
  const navigate = useNavigate()

  const closeDrawer = () => setOpen(false)

  const handlePasswordChangeClick = () => {
    closeDrawer()
    if (auth.role === '2') {
      navigate('/admin/change-password')
    } else if (auth.role === '3') {
      navigate('/branchAdmin/change-password')
    } else if (auth.role === '4') {
      navigate('/securityLevelAdmin/change-password')
    }
  }

  const handleBlacklistManagement = () => {
    closeDrawer()
    if (auth.role === '2') {
      navigate('/admin/blacklist-management')
    } else if (auth.role === '3') {
      navigate('/branchAdmin/blacklist-management')
    } else if (auth.role === '4') {
      navigate('/securityLevelAdmin/blacklist-management')
    }
  }

  const handleToHomeChangeClick = () => {
    closeDrawer()
    if (auth.role === '2') {
      navigate('/admin/dashboard')
    } else if (auth.role === '3') {
      navigate('/branchAdmin/dashboard')
    } else if (auth.role === '4') {
      navigate('/securityLevelAdmin/dashboard')
    }
  }

  const handlevisitorReports = () => {
    closeDrawer()
    if (auth.role === '2') {
      navigate('/admin/visitorReports')
    } else if (auth.role === '3') {
      navigate('/branchAdmin/visitorReports')
    } else if (auth.role === '4') {
      navigate('/securityLevelAdmin/visitorReports')
    }
  }
  const handleLogout = () => {
    auth.logout()
    // Note: auth.logout() already handles localStorage clearing while preserving vehicle movement states
    // No need to call localStorage.clear() again
    closeDrawer()
  }
  // const handleDownloadClick = () => {
  //   closeDrawer()
  //   navigate('/admin/download')
  // }
  // const handlePolicesDownloadClick = () => {
  //   closeDrawer()
  //   navigate('/admin/polices')
  // }
  const handlePolicesDownloadClickPolicesNda = () => {
    closeDrawer()
    if (auth.role === '2') {
      navigate('/admin/UploadPolicesAndNda')
    } else if (auth.role === '3') {
      navigate('/branchAdmin/UploadPolicesAndNda')
    } else if (auth.role === '4') {
      navigate('/securityLevelAdmin/UploadPolicesAndNda')
    }
  }
  const handleAllAdmins = () => {
    closeDrawer()
    if (auth.role === '2') {
      navigate('/admin/all-admins')
    } else if (auth.role === '3') {
      navigate('/branchAdmin/all-admins')
    } else if (auth.role === '4') {
      navigate('/securityLevelAdmin/all-admins')
    }
  }

  const handleDashboardClick = () => {
    closeDrawer()
    if (auth.role === '2') {
      navigate('/admin/dashboard-graphs')
    } else if (auth.role === '3') {
      navigate('/branchAdmin/dashboard-graphs')
    } else if (auth.role === '4') {
      navigate('/securityLevelAdmin/dashboard-graphs')
    }
  }

  const handleVehicleMovement = () => {
    closeDrawer()
    if (auth.role === '2') {
      navigate('/admin/vehicle-movement')
    } else if (auth.role === '3') {
      navigate('/branchAdmin/vehicle-movement')
    } else if (auth.role === '4') {
      navigate('/securityLevelAdmin/vehicle-movement')
    }
  }

  const handleVehicleMaterialGroupBooking = () => {
    closeDrawer()
    if (auth.role === '2') {
      navigate('/admin/vehicle-material-group-booking')
    } else if (auth.role === '3') {
      navigate('/branchAdmin/vehicle-material-group-booking')
    } else if (auth.role === '4') {
      navigate('/securityLevelAdmin/vehicle-material-group-booking')
    }
  }
  return (
    <Drawer
      anchor="left"
      open={open}
      onClose={closeDrawer}
      PaperProps={{
        sx: {
          width: 280,
          display: 'flex',
          flexDirection: 'column',
          backgroundColor: '#ffffff',
          color: '#333333',
        },
      }}
    >
      {/* Drawer Header */}
      <div className="drawer-header">
        <Typography variant="h6" className="drawer-title">
          Menu
        </Typography>
        <IconButton onClick={closeDrawer} className="drawer-close-button">
          <CloseIcon />
        </IconButton>
      </div>
      <Divider />

      {/* Drawer List */}
      <List>
        <ListItem button onClick={handleToHomeChangeClick}>
          <ListItemIcon className="list-icon">
            <HomeIcon />
          </ListItemIcon>
          <ListItemText primary="Home" />
        </ListItem>
        <ListItem button onClick={handlePasswordChangeClick}>
          <ListItemIcon className="list-icon">
            <LockIcon />
          </ListItemIcon>
          <ListItemText primary="Change Password" />
        </ListItem>
        <ListItem button onClick={handleDashboardClick}>
          <ListItemIcon className="list-icon">
            <DashboardIcon />
          </ListItemIcon>
          <ListItemText primary="Dashboard" />
        </ListItem>

        {/* {auth.role == '2' && (
          <ListItem button onClick={handleDownloadClick}>
            <ListItemIcon className="list-icon">
              <CloudUploadIcon />
            </ListItemIcon>
            <ListItemText primary="Upload NDA" />
          </ListItem>
        )} */}
        {/* {auth.role == '2' && (
          <ListItem button onClick={handlePolicesDownloadClick}>
            <ListItemIcon className="list-icon">
              <CloudUploadIcon />
            </ListItemIcon>
            <ListItemText primary="Upload Policies" />
          </ListItem>
        )} */}
        {(auth.role == '2' || auth.role == '3' || auth.role == '4') && (
          <ListItem button onClick={handlePolicesDownloadClickPolicesNda}>
            <ListItemIcon className="list-icon">
              <CloudUploadIcon />
            </ListItemIcon>
            <ListItemText primary="Upload NDA / Policies" />
          </ListItem>
        )}
        {(auth.role == '2' || auth.role == '3' || auth.role == '4') && (
          <ListItem button onClick={handleAllAdmins}>
            <ListItemIcon className="list-icon">
              <SupervisorAccountIcon />
            </ListItemIcon>
            <ListItemText primary="All Admins" />
          </ListItem>
        )}

        {auth.role !== '5' && (
          <ListItem button onClick={handlevisitorReports}>
            <ListItemIcon className="list-icon">
              {/* <CategoryIcon /> */}
              <ManageAccountsIcon />
              {/* <img style={{ width: '22px' }} src={reports_icon} /> */}
            </ListItemIcon>
            <ListItemText primary="Visitor Reports" />
          </ListItem>
        )}

        {/* Areas/Vehicle Movement - Above Blacklist Management */}
        {(auth.role === '2' || auth.role === '3' || auth.role === '4') && (
          <ListItem button onClick={handleVehicleMovement}>
            <ListItemIcon className="list-icon">
              <DirectionsCarIcon />
            </ListItemIcon>
            <ListItemText primary="Areas-Vehicle Movement" />
          </ListItem>
        )}

        {/* Blacklist Management - Only for Organization Admin (role '2') */}
        {auth.role === '2' && (
          <ListItem button onClick={handleBlacklistManagement}>
            <ListItemIcon className="list-icon">
              <BlockIcon />
            </ListItemIcon>
            <ListItemText primary="Blacklist Management" />
          </ListItem>
        )}

        {/* Vehicle/Material/Group Booking - Below Blacklist Management */}
        {auth.role !== '5' && (
          <ListItem button onClick={handleVehicleMaterialGroupBooking}>
            <ListItemIcon className="list-icon">
              <GroupIcon />
            </ListItemIcon>
            <ListItemText primary="Vehicle/Group Booking" />
          </ListItem>
        )}
        <ListItem button onClick={handleLogout}>
          <ListItemIcon className="list-icon">
            <ExitToAppIcon />
          </ListItemIcon>
          <ListItemText primary="Logout" />
        </ListItem>
      </List>
    </Drawer>
  )
}

export default DrawerComponent
