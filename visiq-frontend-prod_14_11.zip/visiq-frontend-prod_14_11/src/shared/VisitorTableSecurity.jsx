'use strict'
import React, { useMemo, useState, useRef, useContext, useEffect } from 'react'
import { AgGridReact } from '@ag-grid-community/react'
import '@ag-grid-community/styles/ag-grid.css'
import '@ag-grid-community/styles/ag-theme-material.css'
import { ModuleRegistry } from '@ag-grid-community/core'
import { ClientSideRowModelModule } from '@ag-grid-community/client-side-row-model'
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query'
import toast from 'react-hot-toast'
import Modal from '@mui/material/Modal'
import {
  changeVisitorStatus,
  extendTimeDuringVisit,
  getAllVisitors,
  listOfCountriesExt,
  updateVisitorData,
} from '../services/adminService'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faDownload, faEdit } from '@fortawesome/free-solid-svg-icons'
import TextField from '@mui/material/TextField'
import { Formik, Form, Field, ErrorMessage } from 'formik'
import FormikDatePicker from '../lib/Formik/FormikDatePicker'
import FormikTimePicker from '../lib/Formik/FormikTimePicker'
import * as yup from 'yup'
import * as Yup from 'yup'
import { AuthContext } from '../context/AuthContext'
import { formatDate, formatDateTime } from '../utils/dateFormat'
import { Box } from '@mui/material'
import { styles, stylees } from '../constants/styes.js'
import FormikTextField from '../lib/Formik/FormikTextfield'
import FormikSelect from '../lib/Formik/FormikSelect'
import jsPDF from 'jspdf'
import MultiSelectForm from '../lib/Formik/MultiSelectForm.jsx'

// Register modules with the grid
ModuleRegistry.registerModules([ClientSideRowModelModule])

const timeToMinutes = (timeStr) => {
  const [hours, minutes] = timeStr.split(':').map(Number)
  return hours * 60 + minutes
}

// Validation Schema using Yup with custom time validation

const VisitorsTable = ({
  data = [],
  dataOfVisit,
  fetchVisitors,
  isArrived = false,
  orgId,
  branch_id,
  data_of_visit,
  visitorType,
  name,
  report_name,
  branch,
}) => {
  const queryClient = useQueryClient()
  const auth = useContext(AuthContext)
  // Preprocess data to add status and action field
  // const processedData = data.map((visitor) => ({
  //   ...visitor,
  //   fullName: `${visitor.first_name} ${visitor.last_name}`, // Compute full name
  //   status: visitor.isVisited ? 'Arrived' : 'Yet To Arrived',
  //   action: visitor.isVisited ? '--' : 'Arrive',
  // }))
  const [loading, setLoading] = useState(false)
  const [rowData, setRowData] = useState([])
  const [openModal, setOpenModal] = useState(false)
  const [selectedVisitor, setSelectedVisitor] = useState(null)
  const dialogRef = useRef(null)
  const dialogRefs = useRef(null)
  const gridApiRef = useRef(null)
  useEffect(() => {
    if (data && data.length > 0) {
      const updatedData = data.map((item) => {
        const fullName = `${item.first_name} ${item.last_name}`
        
        // If this is a group visitor appearing individually, show main visitor name in brackets
        let displayName = fullName
        if (item.visitor_type === 'group_visitor' && !item.isGroupMember) {
          const mainVisitorName = item.main_visitor_name || item.mainVisitorName || ''
          const mainVisitorFirstName = item.main_visitor_first_name || item.mainVisitorFirstName || ''
          const mainVisitorLastName = item.main_visitor_last_name || item.mainVisitorLastName || ''
          
          // Create full main visitor name (first name + last name)
          const mainVisitorFullName =
            mainVisitorFirstName && mainVisitorLastName
              ? `${mainVisitorFirstName} ${mainVisitorLastName}`.trim()
              : mainVisitorName || ''
          
          if (mainVisitorFullName) {
            displayName = `${fullName} (${mainVisitorFullName})`
          }
        }
        
        // Set mm_bool to true when group visitors are present
        const isGroupVisitor =
          item.visitor_type === 'group_visitor' ||
          item.isGroupMember === true ||
          (item.grp_book_bool && item.grp_details && item.grp_details.length > 0)

        return {
        ...item,
          fullName: displayName, // Use displayName which includes main visitor name in brackets for group visitors
        phNos: `${item.ph_ext}-${item.phNo}`, // Compute phone number with extension
        action: item.isVisited ? 'Arrived' : 'Arrive',
        time_extended: '',
          // Set mm_bool to true when group visitors are present
          mm_bool: isGroupVisitor ? true : item.mm_bool,
          mm_details: isGroupVisitor ? (item.mm_details || []) : item.mm_details,
        }
      })
      setRowData(updatedData)
    }
  }, [data])
  const { data: countrycodes, isCountryCodesLoading } = useQuery({
    queryFn: () => listOfCountriesExt(),
  })
  // Custom cell renderer for Action column

  const actionCellRenderers = (params) => {
    const buttonStyle = {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer',
      transition: 'background-color 0.3s',
      padding: '0.5rem 1rem',
      margin: '5px auto',
      width: '150px',
      height: 'auto',
    }
    const handleButtonClicks = () => {
      setSelectedVisitor(params.data)
      setOpenModal(true)
    }

    return (
      <button
        className="btn btn-warning"
        style={{
          ...buttonStyle,
          width: '170px',
          whiteSpace: 'nowrap',
          textAlign: 'center',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
        onClick={handleButtonClicks}
      >
        Extend Visit
      </button>
    )
  }

  const updateFilteredArrivedVisitorss = async () => {
    // Instead of calling API again, invalidate the query to refresh data
    // The dashboard component will refetch and update this component's data
    queryClient.invalidateQueries({
      queryKey: [
        'getAllVisitors',
        branch_id,
        format(data_of_visit, 'dd-MM-yyyy'),
      ],
    })
  }

  const mutatess = useMutation({
    mutationFn: (values) => updateVisitorData(values),
    onMutate: () => setLoading(true),
    onSuccess: async () => {
      await updateFilteredArrivedVisitorss()

      toast.success('Update Phone number sucess')
      setLoading(false)
      setOpenModal(false)

      // Refresh the entire dashboard page after successful edit
      setTimeout(() => {
        window.location.reload()
      }, 1000) // Small delay to show success message
    },
    onError: (err) => {
      setLoading(false)
      toast.error(err)
      setOpenModal(false)
    },
  })

  const handleConfirms = (values) => {
    try {
      const startTimeInMinutes = timeToMinutes(values.time_of_visit)
      const endTimeInMinutes = timeToMinutes(values.time_to_exit)
      const durationInMinutes = endTimeInMinutes - startTimeInMinutes
      const hours = Math.floor(durationInMinutes / 60)
      const minutes = durationInMinutes % 60

      // Use the branch_id from props if not available in values
      const branchId = values?.branch_id || branch_id

      // Validate required fields before making API call
      if (!branchId) {
        toast.error('Branch ID is required for extending visit')
        return
      }

      if (!values?.visitor_id) {
        toast.error('Visitor ID is required for extending visit')
        return
      }

      mutates.mutate({
        visitor_id: values.visitor_id,
        extendedTime: values?.time_to_exit || '',
        visit_duration: `${hours}:${minutes}`,
        branch_id: branchId,
        extendedDate: values?.end_date || '',
        entryTime: values?.time_of_visit || '',
        org_id: auth?.org_id || '',
      })
      setOpenModal(false)
    } catch (err) {
      // Error handled
    }
  }

  const actionssCellRenderer = (params) => {
    // Hide Update Details button for group visitors
    if (
      params.data?.isGroupMember === true ||
      params.data?.visitor_type === 'group_member' ||
      params.data?.visitor_type === 'group_visitor'
    ) {
      return null
    }

    return (
      <button
        className="btn btn-warning"
        style={{
          cursor: 'pointer',
          padding: '0.5rem 1rem',
          margin: '5px auto',
          width: '170px',
          whiteSpace: 'nowrap',
          textAlign: 'center',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
        onClick={() => {
          setSelectedVisitor(params.data)
          setEditModalOpen(true) // Open the edit modal
        }}
      >
        Update Details
      </button>
    )
  }

  const validationSchemas = Yup.object().shape({
    time_to_exit: Yup.string()
      .test(
        'is-greater',
        'Visit End Time must be greater than Visit Start Time',
        function (value) {
          const { time_of_visit } = this.parent
          // Compare the time strings as minutes from midnight
          return timeToMinutes(value) > timeToMinutes(time_of_visit)
        },
      )
      .test(
        'valid-time-range',
        'Time must be within a valid range (minutes: 0-59)',
        function (value) {
          const timeParts = value.split(':')
          const minutes = parseInt(timeParts[1], 10)
          return minutes >= 0 && minutes < 60
        },
      )
      .required('Visit End Time is required'),
  })

  const validationSchema = yup.object().shape({
    phNo: yup
      .string()
      .test(
        'phone-required-if-country-code',
        'Phone number is required when country code is provided',
        function (value) {
          const { ph_ext } = this.parent
          // If country code is provided, phone number must be provided
          if (ph_ext && ph_ext.trim() !== '') {
            return value && value.trim() !== ''
          }
          // If country code is not provided, phone number is optional
          return true
        },
      )
      .test('is-valid-phone', 'Enter a valid phone number', function (value) {
        // Only validate phone format if phone number is provided
        if (!value || value.trim() === '') {
          return true
        }
        const { ph_ext } = this.parent
        const countryCode = countrycodes.find((c) => c.code === ph_ext)
        if (!countryCode) return false
        const isValidLength = value.length >= 5 && value.length <= 10
        const isNumeric = /^[0-9]+$/.test(value)
        const doesNotStartWithZero = !value.startsWith('0')

        if (!doesNotStartWithZero) {
          return this.createError({
            message: 'Phone number cannot start with 0',
          })
        }

        return isValidLength && isNumeric && doesNotStartWithZero
      }),
    ph_ext: yup
      .string()
      .test(
        'country-code-empty-if-phone-empty',
        'Country code must be empty when phone number is empty',
        function (value) {
          const { phNo } = this.parent
          // If phone number is empty, country code must be empty
          if (!phNo || phNo.trim() === '') {
            return !value || value.trim() === ''
          }
          // If phone number is provided, country code must be provided
          return value && value.trim() !== ''
        },
      ),
    email: yup
      .string()
      .test(
        'phone-or-email-required',
        'Phone number or email is required',
        function (value) {
          const { phNo } = this.parent
          // At least one of phone number or email must be provided
          const hasPhone = phNo && phNo.trim() !== ''
          const hasEmail = value && value.trim() !== ''
          return hasPhone || hasEmail
        },
      ),
  })

  // Date cell renderer for formatting dates to DD-MM-YYYY
  const dateCellRenderer = (params) => {
    if (!params.value) return 'N/A'
    return formatDate(params.value)
  }

  // Date-time cell renderer for formatting dates with time to DD-MM-YYYY HH:mm:ss
  const dateTimeCellRenderer = (params) => {
    if (!params.value) return 'N/A'
    return formatDateTime(params.value)
  }

  const columnDefs = useMemo(
    () => [
      {
        headerName: 'Name',
        field: 'fullName',
        headerClass: 'header-bold',
        cellClass: 'ag-cell-centered',
        tooltipField: 'first_name',
      },
      {
        headerName: 'Email',
        field: 'email',
        headerClass: 'header-bold',
        cellClass: 'ag-cell-centered',
        tooltipField: 'email',
      },
      {
        headerName: 'Category',
        field: 'role_name',
        tooltipField: 'role_name',
      },
      {
        headerName: 'Phone Number',
        field: 'phNos',
        tooltipField: 'phNos',
      },
      {
        headerName: 'Visit Start Date',
        field: 'start_date',
        headerClass: 'header-bold',
        cellClass: 'ag-cell-centered',
        tooltipField: 'start_date',
        cellRenderer: dateCellRenderer,
      },
      {
        headerName: 'Visit End Date',
        field: 'end_date',
        headerClass: 'header-bold',
        cellClass: 'ag-cell-centered',
        tooltipField: 'end_date',
        cellRenderer: dateCellRenderer,
      },
      {
        headerName: 'Visit Start Time',
        field: 'time_of_visit',
        headerClass: 'header-bold',
        cellClass: 'ag-cell-centered',
        tooltipField: 'time_of_visit',
      },
      {
        headerName: 'Visit End Time',
        field: 'time_to_exit',
        headerClass: 'header-bold',
        cellClass: 'ag-cell-centered',
        tooltipField: 'time_to_exit',
      },
      {
        headerName: 'Purpose Of Visit',
        field: 'purpose_of_visit',
        headerClass: 'header-bold',
        cellClass: 'ag-cell-centered',
        tooltipField: 'purpose_of_visit',
      },
      {
        headerName: 'Booking Time',
        field: 'bookingTime',
        headerClass: 'header-bold',
        cellClass: 'ag-cell-centered',
        tooltipValueGetter: (params) => {
          if (!params.value) return 'N/A'
          return formatDateTime(params.value)
        },
        cellRenderer: dateTimeCellRenderer,
      },
      { headerName: 'Edit', cellRenderer: actionssCellRenderer }, // New actionss column
      {
        headerName: 'Extend Visit',
        field: 'action',
        cellRenderer: actionCellRenderers,
        cellStyle: { padding: '0px' },
        suppressCellFlash: true,
        headerClass: 'header-bold',
        cellClass: 'ag-cell-centered',
        suppressCsvExport: true, // This prevents "Extended Time" from being exported
      },
    ],
    [isArrived],
  )

  const [editModalOpen, setEditModalOpen] = useState(false)

  const handleEditClose = () => {
    setEditModalOpen(false)
  }

  // Save changes for edit modal
  const handleEditConfirm = (values) => {
    const areaNames =
      values.area_of_permit?.map((area) => area.area_name).join(',') || ''
    mutatess.mutate({
      email: values?.email || '',
      ph_ext: values?.ph_ext || '',
      ph_no: values?.phNo || '',
      org_id: auth?.org_id || '',
      visitor_code: values?.visitor_code || '',
      visitor_id: values?.visitor_id || '',
      branch_id: values?.branch_id || branch_id,
      area_of_permit: areaNames, // Convert to comma-separated string
    })
    setEditModalOpen(false)
  }

  const defaultColDef = useMemo(
    () => ({
      filter: 'agTextColumnFilter',
      floatingFilter: true,
      cellClass: 'ag-cell-centered', // Apply to all columns by default
    }),
    [],
  )

  const customIcons = {
    sortAscending: '<i class="fa fa-sort-asc"></i>',
    sortDescending: '<i class="fa fa-sort-desc"></i>',
  }

  const handleClose = () => {
    if (dialogRef.current) {
      dialogRef.current.close()
    }
  }

  const handleCloses = () => {
    setOpenModal(false)
  }
  const updateFilteredArrivedVisitors = async () => {
    setRowData([])
    const updatedVisitors = await getAllVisitors({
      org_id: auth.org_id || orgId,
      branch_id,
      role: '',
      data_of_visit: format(data_of_visit, 'dd-MM-yyyy'),
    })
    // Filter arrived visitors based on the new data
    const arrivedVisitors = updatedVisitors.visitors_List.filter(
      (visitor) =>
        visitor.action === 'Arrive' &&
        visitor.date_of_visit === format(data_of_visit, 'dd-MM-yyyy'),
    )
    setRowData(arrivedVisitors)
  }
  const mutates = useMutation({
    mutationFn: (values) => extendTimeDuringVisit(values),
    mutationKey: 'extendTimeDuringVisit',
    onMutate: () => setLoading(true),
    onSuccess: async () => {
      await updateFilteredArrivedVisitors()
      toast.success('Extended Visit Successful')
      setLoading(false)
      setOpenModal(false)

      // Refresh the entire dashboard page after successful extend visit
      setTimeout(() => {
        window.location.reload()
      }, 1000) // Small delay to show success message
    },
    onError: (err) => {
      setLoading(false)
      toast.error(err)
      setOpenModal(false)
    },
  })

  const mutate = useMutation({
    mutationFn: (values) => changeVisitorStatus(values),
    mutationKey: 'ChangeVisitorStatus',
    onSuccess: async (data) => {
      // Invalidate the specific query key used by dashboard components
      await queryClient.invalidateQueries({
        queryKey: [
          'getAllVisitors',
          branch_id,
          format(new Date(), 'dd-MM-yyyy'),
        ],
      })
      toast.success('Visitor Status Changed Successfully')

      setRowData((prevRowData) =>
        prevRowData.map((visitor) =>
          visitor.visitor_id === selectedVisitor.visitor_id
            ? { ...visitor, status: 'Arrived', action: '--' }
            : visitor,
        ),
      )
    },
    onError: (err) => {
      toast.dismiss()
      toast.error('Please select today date')
    },
  })
  const onGridReady = (params) => {
    gridApiRef.current = params.api
  }
  //   const onExport = () => {
  //     console.log("hello welcomee..")
  //     if (!gridApiRef.current) {
  //       toast.error('Export failed: Grid API not initialized.')
  //       return
  //     }
  //     // Define the export parameters
  //     const exportParams = {
  //       fileName: 'visitors_report.csv',
  //       columnKeys: columnDefs
  //         .filter((col) => col.headerName !== 'Extend Visit') // Exclude "Extend Visit"
  //         .map((col) => col.field), // Get the field names for the remaining columns
  //       processCellCallback: (params) => {
  //         if (params.column.getColId() === 'phoneExtension') {
  //           // Ensure the phone extension is treated as a string
  //           return String(params.value) // Convert the value to a string
  //         }
  //         return params.value
  //       },
  //     }
  // console.log(exportParams,"exportParams")
  //     // Export the data as CSV
  //     gridApiRef.current.exportDataAsCsv(exportParams)
  //   }

  // Helper function to get ALL data for export (including group visitors from original data)
  const getAllDataForExport = () => {
    // Use the original data prop which contains all visitors from API response
    // This ensures we get ALL visitors including group visitors that might be filtered out
    if (!data || data.length === 0) {
      return rowData // Fallback to rowData if data is empty
    }

    // Process all visitors from the original data response
    const allData = data.map((item) => {
      // Format each visitor similar to how rowData is formatted
      return {
        ...item,
        fullName: `${item.first_name || ''} ${item.last_name || ''}`.trim(),
        phNos: `${item.ph_ext || ''}-${item.phNo || item.ph_no || ''}`,
        action: item.isVisited ? 'Arrived' : 'Arrive',
        time_extended: '',
      }
    })

    return allData
  }

  const onExport = () => {
    // Use getAllDataForExport to include ALL visitors (including collapsed group visitors)
    const allData = getAllDataForExport()

    // Define CSV columns in the same order as PDF: Name, Category, Visit Start Date, Visit End Date, Visit Start Time, Visit End Time, Phone Number, Email, Purpose of Visit, Booking Time, Status
    const csvColumnOrder = [
      { header: 'Name', field: 'fullName' },
      { header: 'Category', field: 'role_name' },
      { header: 'Visit Start Date', field: 'start_date' },
      { header: 'Visit End Date', field: 'end_date' },
      { header: 'Visit Start Time', field: 'time_of_visit' },
      { header: 'Visit End Time', field: 'time_to_exit' },
      { header: 'Phone Number', field: 'phNos' },
      { header: 'Email', field: 'email' },
      { header: 'Purpose of Visit', field: 'purpose_of_visit' },
      { header: 'Booking Time', field: 'bookingTime' },
      { header: 'Status', field: 'action' },
    ]

    // Prepare CSV data
    const csvData = allData.map((row) => {
      const csvRow = {}
      
      csvColumnOrder.forEach((col) => {
        let value = row[col.field] || ''

        // Special handling for Phone Number
        if (col.field === 'phNos') {
          const phoneNumber = row.ph_no || row.phone || row.phNo || ''
          const countryCode = row.ph_ext || ''
          const formattedCountryCode = countryCode
            ? countryCode.startsWith('+')
              ? countryCode
              : `+${countryCode}`
            : ''
          const fullPhoneNumber =
            formattedCountryCode && phoneNumber
              ? `${formattedCountryCode} ${phoneNumber}`
              : phoneNumber
          value = fullPhoneNumber || 'N/A'
        }

        // Special handling for Email
        if (col.field === 'email') {
          value = value || 'N/A'
        }

        // Format date fields
        if (col.field === 'start_date' || col.field === 'end_date' || col.field === 'bookingTime') {
          value = formatDate(value) || ''
        }
        
        csvRow[col.header] = value
      })
      return csvRow
    })

    // Convert to CSV format manually
    const headers = csvColumnOrder.map((col) => col.header).join(',')
    const rows = csvData.map((row) =>
      csvColumnOrder
        .map((col) => {
          const value = row[col.header] || ''
          // Escape commas and quotes in CSV
          return `"${String(value).replace(/"/g, '""')}"`
        })
        .join(','),
    )
    const csvContent = [headers, ...rows].join('\n')

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })
    const link = document.createElement('a')
    link.href = URL.createObjectURL(blob)
    link.download = 'Visitors Report.csv'
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const onExportPDF = () => {
    if (!gridApiRef.current) {
      toast.error('Export failed: Grid API not initialized.')
      return
    }

    const doc = new jsPDF({
      orientation: 'landscape',
      unit: 'pt',
      format: [1200, 700], // Custom page size
    })

    // Add a teal background for the header
    doc.setFillColor(39, 174, 96) // Teal color
    doc.rect(0, 0, doc.internal.pageSize.width, 100, 'F') // Fill the top area with teal color

    // Add the "Visitors Report" heading in the middle
    doc.setFontSize(20)
    doc.setTextColor(255, 255, 255) // White text color
    const pageWidth = doc.internal.pageSize.width
    const textWidth = doc.getTextWidth('Visitors Report')
    const centerX = (pageWidth - textWidth) / 2
    doc.text(`${report_name}`, centerX, 40) // Centered title

    // Static data for branch name and date
    const Admin = `Admin: ${name || ''}`

    const branchName = `Branch Name : ${branch?.branch_name || ''}`
    const reportDate = `Date : ${formatDate(data_of_visit)}`

    // Add the branch name below the title
    doc.setFontSize(13)
    doc.setTextColor(255, 255, 255) // White text color
    doc.text(Admin, 40, 40)
    doc.text(branchName, 40, 60) // Branch name on the left

    // Add the date below the branch name
    doc.text(reportDate, 40, 80) // Report date on the left

    // Adjust the layout below the header
    doc.setTextColor(0) // Reset text color for table content

    // Define table columns
    const tableColumns = [
      { header: 'Name', dataKey: 'fullName' },
      { header: 'Category', dataKey: 'role_name' },
      { header: 'Visit Start Date', dataKey: 'start_date' },
      { header: 'Visit End Date', dataKey: 'end_date' },
      { header: 'Visit Start Time', dataKey: 'time_of_visit' },
      { header: 'Visit End Time', dataKey: 'time_to_exit' },
      { header: 'Phone Number', dataKey: 'phNos' },
      { header: 'Email', dataKey: 'email' },
      { header: 'Purpose of Visit', dataKey: 'purpose_of_visit' },
      { header: 'Booking Time', dataKey: 'bookingTime' },
      { header: 'Status', dataKey: 'action' },
    ]

    // Use getAllDataForExport to include ALL visitors (including collapsed group visitors)
    const allData = getAllDataForExport()
    const tableRows = allData.map((row) => {
      return tableColumns.map((col) => {
        // Special handling for Phone Number
        if (col.dataKey === 'phNos') {
          const phoneNumber = row.ph_no || row.phone || row.phNo || ''
          const countryCode = row.ph_ext || ''
          const formattedCountryCode = countryCode
            ? countryCode.startsWith('+')
              ? countryCode
              : `+${countryCode}`
            : ''
          const fullPhoneNumber =
            formattedCountryCode && phoneNumber
              ? `${formattedCountryCode} ${phoneNumber}`
              : phoneNumber
          return fullPhoneNumber || 'N/A'
        }
        // Format date fields
        if (col.dataKey === 'start_date' || col.dataKey === 'end_date' || col.dataKey === 'bookingTime') {
          return formatDate(row[col.dataKey]) || 'N/A'
        }
        return row[col.dataKey] || 'N/A'
      })
    })

    // Add the table to the PDF
    doc.autoTable({
      startY: 120, // Start after the header
      head: [tableColumns.map((col) => col.header)],
      body: tableRows,
      styles: { fontSize: 9, cellPadding: 3 },
      columnStyles: {
        0: { cellWidth: 80 }, // Adjust column widths as needed
        1: { cellWidth: 100 },
        2: { cellWidth: 100 },
        3: { cellWidth: 80 },
        4: { cellWidth: 80 },
        5: { cellWidth: 100 },
        6: { cellWidth: 120 },
        7: { cellWidth: 100 },
        8: { cellWidth: 80 },
      },
      headStyles: { fillColor: [39, 174, 96] }, // Teal color for table header
      horizontalPageBreak: true, // Automatically add page breaks
    })

    // Save the PDF
    doc.save('visitors_report_custom_styled.pdf')
  }
  const handleConfirm = () => {
    const date = new Date(dataOfVisit)
    const year = date.getFullYear()
    const month = String(date.getMonth() + 1).padStart(2, '0') // Months are zero-based
    const day = String(date.getDate()).padStart(2, '0')

    const formattedDate = `${year}-${month}-${day}`

    if (selectedVisitor) {
      const values = {
        branch_id: selectedVisitor?.branch_id,
        org_id: selectedVisitor?.org_id,
        visitor_code: selectedVisitor?.visitor_code,
        action: 'Arrived',
        selectedDate: formattedDate,
      }
      mutate.mutate(values)
    }

    // Directly update rowData to reflect the 'Arrived' status and disable button
    setRowData((prevRowData) =>
      prevRowData.map((visitor) =>
        visitor.visitor_id === selectedVisitor.visitor_id
          ? { ...visitor, status: 'Arrived', action: '--' }
          : visitor,
      ),
    )

    handleClose() // Close the popup after confirming
  }

  return (
    <div>
      {/* <div className="ag-theme-material" style={{ height: 500, width: '100%' }}>
        <AgGridReact
          rowData={rowData}
          columnDefs={columnDefs}
          defaultColDef={defaultColDef}
          icons={customIcons}
          pagination={true}
          paginationPageSize={10}
          rowHeight={60} // Increase row height to accommodate larger button
        />
      </div> */}
      <div className="flex gap-4">
        <button
          onClick={onExport}
          className="bg-blue-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-blue-600 transition-colors"
        >
          Download CSV
          <FontAwesomeIcon icon={faDownload} className="ml-1.5 text-xs" />
        </button>

        <button
          onClick={onExportPDF}
          className="bg-green-500 text-white text-sm font-medium py-1.5 px-3 rounded-md flex items-center hover:bg-green-600 transition-colors"
        >
          Download PDF
          <FontAwesomeIcon icon={faDownload} className="ml-1.5 text-xs" />
        </button>
      </div>
      <br />
      {loading ? (
        <div>
          <h1>Loading.......</h1>
        </div>
      ) : (
        <div
          className="ag-theme-material"
          style={{ height: 500, width: '100%' }}
        >
          <AgGridReact
            rowData={rowData}
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            icons={customIcons}
            pagination={true}
            paginationPageSize={20}
            rowHeight={60}
            suppressMovableColumns={true} // Disable dragging of headers
            onGridReady={onGridReady}
          />
        </div>
      )}
      <dialog id="my_modal_1" className="modal" ref={dialogRef}>
        <div
          className="modal-box"
          style={{ width: '50%', maxWidth: '600px', textAlign: 'center' }}
        >
          <div style={{ marginBottom: '20px' }}>
            <strong>
              {' '}
              Are you sure you want to mark this visitor as Arrived?{' '}
            </strong>
          </div>
          <form method="dialog">
            <button
              className="btn btn-sm btn-circle btn-ghost absolute right-2 top-2"
              id="my_modal_1_btn"
              onClick={handleClose}
              type="button"
            >
              ✕
            </button>
          </form>
          <div
            style={{ display: 'flex', justifyContent: 'center', gap: '10px' }}
          >
            <button
              className="btn btn-success"
              onClick={handleConfirm}
              type="button"
            >
              Confirm
            </button>
          </div>
        </div>
      </dialog>
      <Modal open={openModal} onClose={handleCloses}>
        <Box sx={styles.modal}>
          <Formik
            initialValues={{
              first_name: selectedVisitor?.first_name || '',
              last_name: selectedVisitor?.last_name || '',
              start_date: selectedVisitor?.start_date || '',
              end_date: selectedVisitor?.end_date || '',
              time_of_visit: selectedVisitor?.time_of_visit || '',
              time_to_exit: selectedVisitor?.time_to_exit || '',
              email: selectedVisitor?.email || '',
              purpose_of_visit: selectedVisitor?.purpose_of_visit || '',
              bookingTime: selectedVisitor?.bookingTime || '',
              action: selectedVisitor?.action || '',
              visitor_id: selectedVisitor?.visitor_id || '',
              branch_id: selectedVisitor?.branch_id || branch_id,
            }}
            validationSchema={validationSchemas}
            onSubmit={handleConfirms}
            enableReinitialize
          >
            {({ values, handleChange }) => (
              <Form>
                <div className="grid grid-cols-2 gap-4">
                  <FormikTextField
                    label="First Name"
                    name="first_name"
                    value={values.first_name}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <FormikTextField
                    label="Last Name"
                    name="last_name"
                    value={values.last_name}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <TextField
                    label="Visit Start Date"
                    name="start_date"
                    value={values.start_date}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <FormikDatePicker
                    name="end_date"
                    label="Visit End Date *"
                    value={values.end_date}
                    variant="outlined"
                    fullWidth
                    onChange={handleChange}
                  />
                  <TextField
                    label="Visit Start Time"
                    name="time_of_visit"
                    value={values.time_of_visit}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <FormikTimePicker
                    name="time_to_exit"
                    label="Visit End Time *"
                  />
                  <TextField
                    label="Email"
                    name="email"
                    value={values.email}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <TextField
                    label="Purpose Of Visit"
                    name="purpose_of_visit"
                    value={values.purpose_of_visit}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <TextField
                    label="Booking Time"
                    name="bookingTime"
                    value={values.bookingTime}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <TextField
                    label="Status"
                    name="action"
                    value={values.action}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                </div>

                <div className="flex justify-center gap-4 mt-4">
                  <button
                    type="submit"
                    className="rounded px-5 py-2.5 bg-primary text-white"
                  >
                    Confirm
                  </button>
                  <button
                    className="bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded"
                    onClick={handleCloses}
                    type="button"
                  >
                    Cancel
                  </button>
                </div>
              </Form>
            )}
          </Formik>

          <form method="dialog">
            <button
              className="absolute top-2 right-2 text-gray-400 hover:text-gray-600"
              onClick={handleCloses}
              type="button"
            >
              ✕
            </button>
          </form>
        </Box>
      </Modal>
      <Modal open={editModalOpen} onClose={handleEditClose}>
        <Box sx={stylees.modal}>
          <Formik
            initialValues={{
              first_name: selectedVisitor?.first_name || '',
              last_name: selectedVisitor?.last_name || '',
              start_date: selectedVisitor?.start_date || '',
              end_date: selectedVisitor?.end_date || '',
              time_of_visit: selectedVisitor?.time_of_visit || '',
              time_to_exit: selectedVisitor?.time_to_exit || '',
              phNo: selectedVisitor?.phNo || '',
              ph_ext: selectedVisitor?.phNo ? selectedVisitor?.ph_ext || '' : '',
              email: selectedVisitor?.email || '',
              purpose_of_visit: selectedVisitor?.purpose_of_visit || '',
              bookingTime: selectedVisitor?.bookingTime || '',
              action: selectedVisitor?.action || '',
              visitor_code: selectedVisitor?.visitor_code || '',
              branch_id: selectedVisitor?.branch_id || branch_id,
              visitor_id: selectedVisitor?.visitor_id || '',
              area_of_permit:
                selectedVisitor?.areas_list
                  ?.filter((area) => area.isActive)
                  ?.map((area) => ({
                    area_id: area.area_id,
                    area_name: area.area_name,
                  })) || [],
            }}
            validationSchema={validationSchema}
            onSubmit={handleEditConfirm}
          >
            {({ values, setFieldValue, errors, touched }) => (
              <Form>
                <div className="grid grid-cols-2 gap-4">
                  <FormikTextField
                    label="First Name"
                    name="first_name"
                    value={values.first_name}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <FormikTextField
                    label="Last Name"
                    name="last_name"
                    value={values.last_name}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <TextField
                    label="Visit Start Date"
                    name="start_date"
                    value={values.start_date}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <TextField
                    label="Visit End Date"
                    name="end_date"
                    value={values.end_date}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <TextField
                    label="Visit Start Time"
                    name="time_of_visit"
                    value={values.time_of_visit}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <TextField
                    label="Visit End Time"
                    name="time_to_exit"
                    value={values.time_to_exit}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <FormikSelect
                    name="ph_ext"
                    label="Country Code"
                    options={
                      isCountryCodesLoading
                        ? [{ value: '', label: 'Loading...' }]
                        : countrycodes.map((country) => ({
                            value: country.code,
                            label: `${country.country} (${country.code})`,
                          }))
                    }
                    onChange={(event) => {
                      const countryCodeValue = event.target.value
                      setFieldValue('ph_ext', countryCodeValue)
                      // If country code is cleared, clear phone number
                      if (!countryCodeValue || countryCodeValue.trim() === '') {
                        setFieldValue('phNo', '')
                      }
                    }}
                    value={values.ph_ext} // Ensure the correct Formik value is passed
                    disabled={true}
                  />
                  <FormikTextField
                    label="Phone Number"
                    name="phNo"
                    value={values.phNo}
                    variant="outlined"
                    fullWidth
                    onChange={(e) => {
                      const phoneValue = e.target.value
                      setFieldValue('phNo', phoneValue)
                      // If phone number is empty, clear country code
                      if (!phoneValue || phoneValue.trim() === '') {
                        setFieldValue('ph_ext', '')
                      }
                    }}
                    disabled={true}
                  />
                  <MultiSelectForm
                    name="area_of_permit"
                    label="Select Area *"
                    options={selectedVisitor?.areas_list.map((area) => ({
                      value: area.area_id,
                      label: area.area_name,
                    }))}
                    onChange={(selectedValues) => {
                      setFieldValue('area_of_permit', selectedValues)
                    }}
                    disabled={false}
                  />
                  <FormikTextField
                    label="Email"
                    name="email"
                    value={values.email}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                  <TextField
                    label="Purpose Of Visit"
                    name="purpose_of_visit"
                    value={values.purpose_of_visit}
                    variant="outlined"
                    fullWidth
                    disabled
                  />
                </div>
                <div className="flex justify-center gap-4 mt-4">
                  <button
                    type="submit"
                    className="bg-primary text-white px-4 py-2 rounded"
                  >
                    Update
                  </button>
                  <button
                    type="button"
                    onClick={handleEditClose}
                    className="bg-gray-300 px-4 py-2 rounded"
                  >
                    Cancel
                  </button>
                </div>
              </Form>
            )}
          </Formik>
        </Box>
      </Modal>
    </div>
  )
}

export default VisitorsTable
