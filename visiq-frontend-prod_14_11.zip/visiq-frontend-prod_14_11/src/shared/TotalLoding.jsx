import React from 'react'
import Lottie from 'lottie-react'

const LottieLoader = ({ data, height = '30vh' }) => {
  return (
    <div className="fixed inset-0 flex justify-center items-center">
      <Lottie
        animationData={data}
        alt="loading"
        style={{ height: height, marginTop: '18vh' }}
      />
    </div>
  )
}

export default LottieLoader
