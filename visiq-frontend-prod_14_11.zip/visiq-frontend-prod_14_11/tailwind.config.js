/* eslint-disable prettier/prettier */
// /** @type {import('tailwindcss').Config} */
// export default {
//   content: [
//     "./index.html",
//     "./src/**/*.{js,ts,jsx,tsx}",
//   ],
//   theme: {
//     extend: {
//       backgroundImage: {
//         "login-left": "url('./assets/login-left-face-rek.svg')",
//         "card-bg": "url('./assets/cardbg.svg')"
//       },
//       colors: {
//         primary: "#051737",
//         secondary: "#76E5F0",
//         secondary100: "#DFF9FC",
//       }
//     },
//   },
//   plugins: [require("daisyui")],
//   daisyui: {
//     themes: ["light"],
//   },
// }
// tailwind.config.js
// export default {
//   content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
//   theme: {
//     extend: {
//       backgroundImage: {
//         'login-left': "url('./assets/login-left-face-rek.svg')",
//         'card-bg': "url('./assets/cardbg.svg')",
//       },
//       colors: {
//         primary: '#051737',
//         secondary: '#76E5F0',
//         secondary100: '#DFF9FC',
//         headerBg: '#f8fafc', // Example custom color for header background
//         headerText: '#374151', // Example custom color for header text
//       },
//     },
//   },
//   plugins: [require('daisyui')],
//   daisyui: {
//     themes: ['light'],
//   },
// }

// tailwind.config.js
export default {
  darkMode: 'class', // Enable class-based dark mode
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      backgroundImage: {
        'login-left': "url('./assets/login-left-face-rek.svg')",
        'card-bg': "url('./assets/cardbg.svg')",
      },
      colors: {
        primary: '#051737',
        secondary: '#76E5F0',
        secondary100: '#DFF9FC',
        headerBg: '#f8fafc', // Example custom color for header background
        headerText: '#374151', // Example custom color for header text
        darkBg: '#1a202c', // Example dark mode background color
        darkText: '#cbd5e0', // Example dark mode text color
      },
      animation: {
        marquee: 'marquee 20s linear infinite',
      },
      keyframes: {
        marquee: {
          '0%': { transform: 'translateX(100%)' },
          '100%': { transform: 'translateX(-100%)' },
        },
      },
    },
  },
  plugins: [require('daisyui')],
  daisyui: {
    themes: ['light'], // Enable light and dark themes in DaisyUI
  },
}
