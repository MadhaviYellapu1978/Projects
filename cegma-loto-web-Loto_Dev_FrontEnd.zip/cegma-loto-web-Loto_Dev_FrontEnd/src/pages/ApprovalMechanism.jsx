import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useLocation } from "react-router-dom";
import Navbar from "../components/Navbar";
import { approvalMechanism } from "../assets";
import { apiCall, isValidToken, decryptAesBase64, encryptAesBase64 } from "../utils";
import { methods, userEndPoints, workflowEndPoints } from "../constants";
import { setUser, setToken } from "../features/auth/authSlice";

const ApprovalMechanism = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const user = useSelector((state) => state.authSlice.user);

  // Get token from URL parameters first, then fallback to localStorage
  const searchParams = new URLSearchParams(window.location.search);
  const tokenFromUrl = searchParams.get("token");
  const tokenFromStorage = localStorage.getItem("token");
  const token = tokenFromUrl || tokenFromStorage || "";

  // Ensure token is in URL - update URL if token exists but not in URL
  useEffect(() => {
    if (token && !tokenFromUrl) {
      // Token exists in localStorage but not in URL, update URL
      const newSearchParams = new URLSearchParams(window.location.search);
      newSearchParams.set("token", token);
      navigate(
        {
          pathname: location.pathname,
          search: newSearchParams.toString(),
        },
        { replace: true }
      );
    }
  }, [token, tokenFromUrl, navigate, location.pathname]);

  // State for roles and actions from API
  const [roles, setRoles] = useState([]);
  const [rolesData, setRolesData] = useState([]);
  const [isLoadingRoles, setIsLoadingRoles] = useState(false);
  const [rolesError, setRolesError] = useState(null);
  const [workflowActions, setWorkflowActions] = useState([]);
  const [workflowActionsData, setWorkflowActionsData] = useState([]);
  const [isLoadingActions, setIsLoadingActions] = useState(false);
  const [actionsError, setActionsError] = useState(null);

  const [selectedRole, setSelectedRole] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedActions, setSelectedActions] = useState([]);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [expandedRoles, setExpandedRoles] = useState(new Set());
  const [roleWorkflows, setRoleWorkflows] = useState([]);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  // Fetch main actions using getMainActions endpoint
  useEffect(() => {
    const fetchActions = async () => {
      setIsLoadingActions(true);
      setActionsError(null);
      try {
        const token = localStorage.getItem("token");

        // Call getMainActions API with type query parameter
        // type should be "Approval" or "Action" - using "Approval" for approval mechanism
        const url = `${workflowEndPoints.orgGetMainActions}?type=Approval`;

        // First get the encrypted data
        const encryptedRes = await apiCall(url, methods.get, null, token);

        console.log("Encrypted response:", encryptedRes);

        if (!encryptedRes?.data) {
          throw new Error("No encrypted data received");
        }

        // Decrypt the data locally using SubtleCrypto helper
        let decryptedRes;
        try {
          decryptedRes = await decryptAesBase64(encryptedRes.data);
        } catch (e) {
          console.error("Local decryption failed:", e);
          throw new Error("Failed to decrypt data locally");
        }

        console.log("Decrypted string:", decryptedRes);

        // Parse the decrypted JSON response (handle array/object/string)
        let actions = [];
        if (Array.isArray(decryptedRes)) {
          actions = decryptedRes;
        } else if (decryptedRes && Array.isArray(decryptedRes.data)) {
          actions = decryptedRes.data;
        } else if (typeof decryptedRes === "string") {
          try {
            const parsed = JSON.parse(decryptedRes);
            actions = Array.isArray(parsed)
              ? parsed
              : Array.isArray(parsed.data)
              ? parsed.data
              : [];
          } catch (e) {
            console.error("Failed to parse decrypted response string:", e);
            throw new Error("Invalid decrypted data format");
          }
        } else if (decryptedRes && typeof decryptedRes === "object") {
          const maybeArray =
            decryptedRes.body ||
            decryptedRes.result ||
            decryptedRes.payload ||
            decryptedRes.data;
          if (Array.isArray(maybeArray)) actions = maybeArray;
        } else {
          throw new Error("Invalid decrypted data format");
        }

        console.log("Actions array:", actions);

        // Store full actions data for ID/enum lookup
        setWorkflowActionsData(actions.filter(Boolean));

        // Extract the action field from each item
        const actionsList = actions.filter(Boolean).map((item) => {
          console.log("Processing action item:", item);
          return item.action;
        });

        console.log("Final actionsList:", actionsList);

        // Filter out any undefined/null values and ensure we have actions
        const validActions = actionsList.filter(Boolean);
        if (validActions.length === 0) {
          console.warn("No valid actions found in response");
          setActionsError("No actions available");
        } else {
          setWorkflowActions(validActions);
        }
      } catch (err) {
        console.error("Failed to fetch workflow actions:", err);
        setActionsError(err.message || "Failed to load actions");
      } finally {
        setIsLoadingActions(false);
      }
    };

    fetchActions();
  }, []);

  // Fetch roles and departments using getRolesAndDept endpoint
  useEffect(() => {
    const fetchRolesAndDept = async () => {
      if (!user?.org?.org_id) {
        console.log("Waiting for user org_id...");
        return;
      }

      setIsLoadingRoles(true);
      setRolesError(null);
      try {
        const token = localStorage.getItem("token");
        console.log(
          "📝 Fetching roles and departments using getRolesAndDept endpoint"
        );
        console.log("   Endpoint:", workflowEndPoints.getRolesAndDept);
        console.log("   Method: GET");
        console.log("   Org ID:", user.org.org_id);

        // Call the getRolesAndDept endpoint with GET
        // apiCall handles encryption/decryption automatically
        const response = await apiCall(
          workflowEndPoints.getRolesAndDept,
          methods.get,
          null,
          token
        );

        console.log("✅ Roles and Departments API response:", response);

        // Handle different response formats
        let rolesData = [];
        if (Array.isArray(response)) {
          rolesData = response;
        } else if (response && Array.isArray(response.data)) {
          rolesData = response.data;
        } else if (response && Array.isArray(response.roles)) {
          rolesData = response.roles;
        } else if (response && typeof response === "object") {
          // Try to extract roles from various possible fields
          const maybeArray =
            response.body ||
            response.result ||
            response.payload ||
            response.data ||
            response.roles;
          if (Array.isArray(maybeArray)) {
            rolesData = maybeArray;
          }
        }

        // If response contains encrypted data field, decrypt it
        if (response?.data && typeof response.data === "string") {
          try {
            const decryptedRes = await decryptAesBase64(response.data);
            console.log("Decrypted roles string:", decryptedRes);

            let parsedData;
            if (typeof decryptedRes === "string") {
              parsedData = JSON.parse(decryptedRes);
            } else {
              parsedData = decryptedRes;
            }

            if (Array.isArray(parsedData)) {
              rolesData = parsedData;
            } else if (parsedData && Array.isArray(parsedData.data)) {
              rolesData = parsedData.data;
            } else if (parsedData && Array.isArray(parsedData.roles)) {
              rolesData = parsedData.roles;
            }
          } catch (e) {
            console.error("Failed to decrypt roles data:", e);
          }
        }

        console.log("Processed roles data:", rolesData);

        // Store full roles data for role_id lookup
        setRolesData(rolesData);

        // Process roles with aliases for dropdown display
        // If a role has alias_names, show "Role Name - Alias Name" for each alias
        // If no aliases, show just "Role Name"
        const orgId = user?.org?.org_id || user?.org_id || "";
        const roleNamesWithAliases = [];

        rolesData.forEach((role) => {
          const roleName =
              role.role_name ||
              role.roleName ||
              role.name ||
              role.role ||
              role.label ||
            role.title;

          if (!roleName) return;

          // Check if role has alias_names array
          const aliasNames = role.alias_names || [];

          // Filter aliases by current org_id if available
          const orgAliases = orgId
            ? aliasNames.filter(
                (alias) =>
                  alias.org_id === orgId ||
                  alias.orgId === orgId ||
                  !alias.org_id // Include aliases without org_id filter
              )
            : aliasNames;

          if (orgAliases && orgAliases.length > 0) {
            // Create entries for each alias: "Role Name - Alias Name"
            orgAliases.forEach((alias) => {
              const aliasName =
                alias.alias_name || alias.aliasName || alias.name || "";
              if (aliasName) {
                roleNamesWithAliases.push(`${roleName} - ${aliasName}`);
              } else {
                // If alias name is empty, still add the role name
                roleNamesWithAliases.push(roleName);
              }
            });
          } else {
            // No aliases, just add the role name
            roleNamesWithAliases.push(roleName);
          }
        });

        // Remove duplicates
        const uniqueRoleNames = [...new Set(roleNamesWithAliases)];

        if (uniqueRoleNames.length === 0) {
          console.warn("No valid roles found in response");
          setRolesError("No roles available");
        } else {
          setRoles(uniqueRoleNames);
          // Set default selected role if none is selected or if current selection is not in the list
          if (!selectedRole || !uniqueRoleNames.includes(selectedRole)) {
            setSelectedRole(uniqueRoleNames[0]);
          }
        }
      } catch (err) {
        console.error("Failed to fetch roles and departments:", err);
        setRolesError(err.message || "Failed to load roles");
        setRoles([]);
        setRolesData([]);
      } finally {
        setIsLoadingRoles(false);
      }
    };

    fetchRolesAndDept();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.org?.org_id]);

  // Fetch assigned actions for ALL roles when page opens
  useEffect(() => {
    const fetchAssignedActionsForAllRoles = async () => {
      if (!user?.org?.org_id) {
        return;
      }

      if (!rolesData || rolesData.length === 0) {
        return;
      }

      try {
        const token = localStorage.getItem("token");
        const orgId = user.org.org_id;
        const roleWorkflowsMap = new Map(); // Use Map to group by base role name

        // Fetch assigned actions for each role
        for (const roleData of rolesData) {
          const roleId =
            roleData?.role_id ||
            roleData?.roleId ||
            roleData?.id;

          if (!roleId) continue;

          const roleName =
            roleData?.role_name ||
            roleData?.roleName ||
            roleData?.name ||
            roleData?.role ||
            roleData?.label ||
            roleData?.title;

          if (!roleName) continue;

          // Get alias names for this role
          const aliasNames = roleData.alias_names || [];
          const orgAliases = orgId
            ? aliasNames.filter(
                (alias) =>
                  alias.org_id === orgId ||
                  alias.orgId === orgId ||
                  !alias.org_id
              )
            : aliasNames;

          // If role has aliases, fetch for each alias; otherwise fetch once for the role
          const rolesToFetch = orgAliases.length > 0
            ? orgAliases.map((alias) => ({
                roleId,
                displayName: `${roleName} - ${alias.alias_name || alias.aliasName || alias.name || ""}`,
              }))
            : [{ roleId, displayName: roleName }];

          // Fetch actions for each alias separately to show them as separate cards
          for (const roleInfo of rolesToFetch) {
            try {
              const baseUrl = workflowEndPoints.getAssignedActionsByOrgId;
              const url = `${baseUrl}?org_id=${encodeURIComponent(
                orgId
              )}&role_id=${encodeURIComponent(String(roleInfo.roleId))}`;

              const response = await apiCall(url, methods.get, null, token);

              if (response?.status >= 400) {
                continue;
              }

              // Decrypt the response
              let decryptedResponse;
              if (response?.data && typeof response.data === "string") {
                try {
                  const { decrypt } = await import("../crypto");
                  decryptedResponse = decrypt(response.data);
                  if (typeof decryptedResponse === "string") {
                    try {
                      decryptedResponse = JSON.parse(decryptedResponse);
                    } catch (e) {}
                  }
                } catch (e) {
                  try {
                    decryptedResponse = await decryptAesBase64(response.data);
                    if (typeof decryptedResponse === "string") {
                      try {
                        decryptedResponse = JSON.parse(decryptedResponse);
                      } catch (parseErr) {}
                    }
                  } catch (decryptErr) {
                    continue;
                  }
                }
              } else if (
                response?.data &&
                typeof response.data === "object" &&
                response.data?.data
              ) {
                const encryptedData = response.data.data;
                if (typeof encryptedData === "string") {
                  try {
                    const { decrypt } = await import("../crypto");
                    decryptedResponse = decrypt(encryptedData);
                    if (typeof decryptedResponse === "string") {
                      try {
                        decryptedResponse = JSON.parse(decryptedResponse);
                      } catch (e) {}
                    }
                  } catch (e) {
                    try {
                      decryptedResponse = await decryptAesBase64(encryptedData);
                      if (typeof decryptedResponse === "string") {
                        try {
                          decryptedResponse = JSON.parse(decryptedResponse);
                        } catch (parseErr) {}
                      }
                    } catch (decryptErr) {
                      continue;
                    }
                  }
                } else {
                  decryptedResponse = response.data;
                }
              } else {
                decryptedResponse = response;
              }

              // Check if the decrypted response contains "No assigned actions found"
              if (
                decryptedResponse?.error === "No assigned actions found" ||
                decryptedResponse?.message === "No assigned actions found" ||
                (typeof decryptedResponse === "string" &&
                  decryptedResponse
                    .toLowerCase()
                    .includes("no assigned actions found"))
              ) {
                continue;
              }

              // Extract actions from the response
              let actionsArray = [];
              if (Array.isArray(decryptedResponse)) {
                actionsArray = decryptedResponse;
              } else if (decryptedResponse?.data && Array.isArray(decryptedResponse.data)) {
                actionsArray = decryptedResponse.data;
              } else if (decryptedResponse?.actions && Array.isArray(decryptedResponse.actions)) {
                actionsArray = decryptedResponse.actions;
              }

              // Map action IDs/enums to action names from workflowActionsData
              const actionNames = actionsArray
                .map((actionItem) => {
                  const actionId =
                    typeof actionItem === "string"
                      ? actionItem
                      : actionItem?.action_id ||
                        actionItem?.actionId ||
                        actionItem?.id ||
                        actionItem?.enum ||
                        actionItem?.action;

                  if (!actionId) return null;

                  const actionData = workflowActionsData.find(
                    (item) =>
                      item.action_id === actionId ||
                      item.actionId === actionId ||
                      item.id === actionId ||
                      item.enum === actionId ||
                      item.action === actionId
                  );

                  return actionData?.action || actionId;
                })
                .filter(Boolean);

              // Add/update this role with alias in the map (showing alias name)
              if (actionNames.length > 0) {
                roleWorkflowsMap.set(roleInfo.displayName, {
                  role: roleInfo.displayName,
                  actions: actionNames,
                });
              }
            } catch (error) {
              // Continue with next role
              continue;
            }
          }
        }

        // Convert Map to Array and update roleWorkflows state
        const allRoleWorkflows = Array.from(roleWorkflowsMap.values());
        setRoleWorkflows(allRoleWorkflows);

        // Also fetch actions for the selected role (or first role) to update selectedActions
        // First, try to get actions from roleWorkflowsMap if they're already fetched
        let roleId = null;
        let roleDisplayName = null;
        let actionsFromMap = null;
        
        // Determine which role to fetch actions for
        const roleToUse = selectedRole || (roles.length > 0 ? roles[0] : null);
        
        // First, check if we already have actions for this role in roleWorkflowsMap
        if (roleToUse && roleWorkflowsMap.has(roleToUse)) {
          const roleWorkflow = roleWorkflowsMap.get(roleToUse);
          if (roleWorkflow && roleWorkflow.actions && roleWorkflow.actions.length > 0) {
            actionsFromMap = roleWorkflow.actions;
          }
        }
        
        // If not found in map, fetch from API
        if (roleToUse && rolesData.length > 0) {
          const baseRoleName = roleToUse.includes(" - ")
            ? roleToUse.split(" - ")[0].trim()
            : roleToUse;

          const selectedRoleData = rolesData.find((role) => {
            const roleName =
              role.role_name ||
              role.roleName ||
              role.name ||
              role.role ||
              role.label ||
              role.title;
            return roleName === baseRoleName;
          });

          if (selectedRoleData) {
            roleId =
              selectedRoleData?.role_id ||
              selectedRoleData?.roleId ||
              selectedRoleData?.id ||
              null;
            roleDisplayName = roleToUse;
          }
        }

        // Fallback to first role if still no roleId found
        if (!roleId && rolesData.length > 0) {
          const firstRole = rolesData[0];
          roleId =
            firstRole?.role_id ||
            firstRole?.roleId ||
            firstRole?.id ||
            null;

          const roleName =
            firstRole?.role_name ||
            firstRole?.roleName ||
            firstRole?.name ||
            firstRole?.role ||
            firstRole?.label ||
            firstRole?.title;
          roleDisplayName = roleName || (roles.length > 0 ? roles[0] : null);
        }

        // If we already have actions from the map, use them; otherwise fetch from API
        if (actionsFromMap && actionsFromMap.length > 0) {
          setSelectedActions(actionsFromMap);
        } else if (roleId) {
          // Fetch actions for selected/first role to update selectedActions
          const baseUrl = workflowEndPoints.getAssignedActionsByOrgId;
          const url = `${baseUrl}?org_id=${encodeURIComponent(
            orgId
          )}&role_id=${encodeURIComponent(String(roleId))}`;

          const response = await apiCall(url, methods.get, null, token);

          // Handle error responses
          if (response?.status >= 400) {
            const errorData = response.data;
            const errorMessage =
              errorData?.error ||
              errorData?.message ||
              errorData?.details ||
              JSON.stringify(errorData) ||
              "Failed to fetch assigned actions";

            // Handle "No assigned actions found" as a valid empty response
            if (
              errorMessage === "No assigned actions found" ||
              errorMessage?.toLowerCase().includes("no assigned actions found")
            ) {
              setSelectedActions([]);
            } else {
              // For other errors, set empty array
              setSelectedActions([]);
            }
          } else if (response?.status < 400) {
            let decryptedResponse;
            if (response?.data && typeof response.data === "string") {
              try {
                const { decrypt } = await import("../crypto");
                decryptedResponse = decrypt(response.data);
                if (typeof decryptedResponse === "string") {
                  try {
                    decryptedResponse = JSON.parse(decryptedResponse);
                  } catch (e) {}
                }
              } catch (e) {
                try {
                  decryptedResponse = await decryptAesBase64(response.data);
                  if (typeof decryptedResponse === "string") {
                    try {
                      decryptedResponse = JSON.parse(decryptedResponse);
                    } catch (parseErr) {}
                  }
                } catch (decryptErr) {
                  decryptedResponse = response;
                }
              }
            } else if (
              response?.data &&
              typeof response.data === "object" &&
              response.data?.data
            ) {
              const encryptedData = response.data.data;
              if (typeof encryptedData === "string") {
                try {
                  const { decrypt } = await import("../crypto");
                  decryptedResponse = decrypt(encryptedData);
                  if (typeof decryptedResponse === "string") {
                    try {
                      decryptedResponse = JSON.parse(decryptedResponse);
                    } catch (e) {}
                  }
                } catch (e) {
                  try {
                    decryptedResponse = await decryptAesBase64(encryptedData);
                    if (typeof decryptedResponse === "string") {
                      try {
                        decryptedResponse = JSON.parse(decryptedResponse);
                      } catch (parseErr) {}
                    }
                  } catch (decryptErr) {
                    decryptedResponse = response.data;
                  }
                }
              } else {
                decryptedResponse = response.data;
              }
            } else {
              decryptedResponse = response;
            }

            // Handle "No assigned actions found" as empty result
            if (
              decryptedResponse?.error === "No assigned actions found" ||
              decryptedResponse?.message === "No assigned actions found" ||
              (typeof decryptedResponse === "string" &&
                decryptedResponse
                  .toLowerCase()
                  .includes("no assigned actions found"))
            ) {
              setSelectedActions([]);
            } else if (
              !decryptedResponse?.error &&
              decryptedResponse?.message !== "No assigned actions found"
            ) {
              let actionsArray = [];
              if (Array.isArray(decryptedResponse)) {
                actionsArray = decryptedResponse;
              } else if (decryptedResponse?.data && Array.isArray(decryptedResponse.data)) {
                actionsArray = decryptedResponse.data;
              } else if (decryptedResponse?.actions && Array.isArray(decryptedResponse.actions)) {
                actionsArray = decryptedResponse.actions;
              }

              // Map action IDs/enums to action names from workflowActionsData
              // Use the same mapping logic as Role Assigned WorkFlow section
              const actionNames = actionsArray
                .map((actionItem) => {
                  const actionId =
                    typeof actionItem === "string"
                      ? actionItem
                      : actionItem?.action_id ||
                        actionItem?.actionId ||
                        actionItem?.id ||
                        actionItem?.enum ||
                        actionItem?.action;

                  if (!actionId) return null;

                  // Try to find the action in workflowActionsData (same logic as Role Assigned WorkFlow)
                  const actionData = workflowActionsData.find(
                    (item) =>
                      item.action_id === actionId ||
                      item.actionId === actionId ||
                      item.id === actionId ||
                      item.enum === actionId ||
                      item.action === actionId
                  );

                  // Return action name if found, otherwise return the actionId as-is
                  // This handles cases where actions might be from "Action" type, not just "Approval" type
                  return actionData?.action || actionId;
                })
                .filter(Boolean);

              // Update selectedActions state with the mapped action names
              setSelectedActions(actionNames);
            } else {
              // If response has error but not "No assigned actions found", set empty array
              setSelectedActions([]);
            }
          } else {
            // If response doesn't have expected structure, set empty array
            setSelectedActions([]);
          }
        } else {
          // If no roleId found, set empty array
          setSelectedActions([]);
        }
      } catch (error) {
        // Error fetching assigned actions - set empty array
        console.error("Error fetching assigned actions for selected role:", error);
        setSelectedActions([]);
      }
    };

    // Call when rolesData, workflowActionsData, selectedRole, or roles is available/changes
    if (rolesData.length > 0 && workflowActionsData.length > 0) {
      fetchAssignedActionsForAllRoles();
    }
    // eslint-disable-next-line
  }, [user?.org?.org_id, rolesData, workflowActionsData, selectedRole, roles, refreshTrigger]);

  // Verify token on component mount
  useEffect(() => {
    const verifyTokenOnMount = async () => {
      // Check if token is valid before making API calls
      if (isValidToken(token)) {
        try {
          const data = await apiCall(userEndPoints.verifyToken, methods.post, {
            token: token,
          });

          if (data && data.valid) {
            // Fetch user data after token verification
            try {
              const userData = await apiCall(
                `${userEndPoints.getUser}${data.userId}`,
                methods.get
              );
              dispatch(setUser(userData));
              dispatch(setToken(token));
              console.log("Token verified successfully");
            } catch (error) {
              console.error("Failed to fetch user data:", error);
            }
          } else {
            console.warn("Token verification failed - invalid token");
          }
        } catch (error) {
          console.error("Token verification failed:", error);
        }
      } else {
        console.warn("No valid token found");
      }
    };

    verifyTokenOnMount();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);


  const handleActionToggle = (action) => {
    if (selectedActions.includes(action)) {
      setSelectedActions(selectedActions.filter((item) => item !== action));
    } else {
      setSelectedActions([...selectedActions, action]);
    }
  };

  // Load selected actions when role changes
  const handleRoleChange = async (newRole) => {
    setSelectedRole(newRole);
    
    // Fetch assigned actions for the new role
    if (!user?.org?.org_id || !rolesData || rolesData.length === 0) {
      return;
    }

    try {
      const token = localStorage.getItem("token");
      const orgId = user.org.org_id;

      // Extract role name from newRole (handle "Role Name - Alias Name" format)
      const baseRoleName = newRole.includes(" - ")
        ? newRole.split(" - ")[0].trim()
        : newRole;

      const selectedRoleData = rolesData.find((role) => {
        const roleName =
          role.role_name ||
          role.roleName ||
          role.name ||
          role.role ||
          role.label ||
          role.title;
        return roleName === baseRoleName;
      });

      const roleId =
        selectedRoleData?.role_id ||
        selectedRoleData?.roleId ||
        selectedRoleData?.id;

      if (!roleId) {
        setSelectedActions([]);
        return;
      }

      // Call the API with GET method
      const baseUrl = workflowEndPoints.getAssignedActionsByOrgId;
      const url = `${baseUrl}?org_id=${encodeURIComponent(
        orgId
      )}&role_id=${encodeURIComponent(String(roleId))}`;

      const response = await apiCall(url, methods.get, null, token);

      // Check if apiCall returned an error response (status >= 400)
      if (response?.status >= 400) {
        const errorData = response.data;
        const errorMessage =
          errorData?.error ||
          errorData?.message ||
          errorData?.details ||
          JSON.stringify(errorData) ||
          "Failed to fetch assigned actions";

        // Handle "No assigned actions found" as a valid empty response
        if (
          errorMessage === "No assigned actions found" ||
          errorMessage?.toLowerCase().includes("no assigned actions found")
        ) {
          setSelectedActions([]);
          return;
        }

        setSelectedActions([]);
        return;
      }

      // Decrypt the response data
      let decryptedResponse;

      if (response?.data && typeof response.data === "string") {
        try {
          const { decrypt } = await import("../crypto");
          decryptedResponse = decrypt(response.data);
          if (typeof decryptedResponse === "string") {
            try {
              decryptedResponse = JSON.parse(decryptedResponse);
            } catch (e) {
              // Failed to parse
            }
          }
        } catch (e) {
          try {
            decryptedResponse = await decryptAesBase64(response.data);
            if (typeof decryptedResponse === "string") {
              try {
                decryptedResponse = JSON.parse(decryptedResponse);
              } catch (parseErr) {
                // Failed to parse
              }
            }
          } catch (decryptErr) {
            decryptedResponse = response;
          }
        }
      } else if (
        response?.data &&
        typeof response.data === "object" &&
        response.data?.data
      ) {
        const encryptedData = response.data.data;
        if (typeof encryptedData === "string") {
          try {
            const { decrypt } = await import("../crypto");
            decryptedResponse = decrypt(encryptedData);
            if (typeof decryptedResponse === "string") {
              try {
                decryptedResponse = JSON.parse(decryptedResponse);
              } catch (e) {
                // Failed to parse
              }
            }
          } catch (e) {
            try {
              decryptedResponse = await decryptAesBase64(encryptedData);
              if (typeof decryptedResponse === "string") {
                try {
                  decryptedResponse = JSON.parse(decryptedResponse);
                } catch (parseErr) {
                  // Failed to parse
                }
              }
            } catch (decryptErr) {
              decryptedResponse = response;
            }
          }
        } else {
          decryptedResponse = response.data;
        }
      } else {
        decryptedResponse = response;
      }

      // Check if the decrypted response contains "No assigned actions found"
      if (
        decryptedResponse?.error === "No assigned actions found" ||
        decryptedResponse?.message === "No assigned actions found" ||
        (typeof decryptedResponse === "string" &&
          decryptedResponse
            .toLowerCase()
            .includes("no assigned actions found"))
      ) {
        setSelectedActions([]);
        return;
      }

      // Extract actions from the response
      let actionsArray = [];
      if (Array.isArray(decryptedResponse)) {
        actionsArray = decryptedResponse;
      } else if (decryptedResponse?.data && Array.isArray(decryptedResponse.data)) {
        actionsArray = decryptedResponse.data;
      } else if (decryptedResponse?.actions && Array.isArray(decryptedResponse.actions)) {
        actionsArray = decryptedResponse.actions;
      }

      // Map action IDs/enums to action names from workflowActionsData
      const actionNames = actionsArray
        .map((actionItem) => {
          const actionId =
            typeof actionItem === "string"
              ? actionItem
              : actionItem?.action_id ||
                actionItem?.actionId ||
                actionItem?.id ||
                actionItem?.enum ||
                actionItem?.action;

          if (!actionId) return null;

          const actionData = workflowActionsData.find(
            (item) =>
              item.action_id === actionId ||
              item.actionId === actionId ||
              item.id === actionId ||
              item.enum === actionId ||
              item.action === actionId
          );

          return actionData?.action || actionId;
        })
        .filter(Boolean);

      // Update selectedActions state
      setSelectedActions(actionNames);

      // Update roleWorkflows state to show this role in "Role Assigned WorkFlow" section
      if (newRole && actionNames.length > 0) {
        setRoleWorkflows((prevWorkflows) => {
          const existingIndex = prevWorkflows.findIndex(
      (workflow) => workflow.role === newRole
    );

          const roleWorkflow = {
            role: newRole,
            actions: actionNames,
          };

          if (existingIndex !== -1) {
            // Update existing role workflow
            const updated = [...prevWorkflows];
            updated[existingIndex] = roleWorkflow;
            return updated;
          } else {
            // Add new role workflow
            return [...prevWorkflows, roleWorkflow];
          }
        });
      } else if (newRole && actionNames.length === 0) {
        // Remove role workflow if no actions found
        setRoleWorkflows((prevWorkflows) =>
          prevWorkflows.filter((workflow) => workflow.role !== newRole)
        );
      }
    } catch (error) {
      // Error fetching assigned actions - leave selectedActions empty
      setSelectedActions([]);
    }
  };

  // Toggle expanded state for a role
  const toggleRoleExpansion = (roleName) => {
    const newExpandedRoles = new Set(expandedRoles);
    if (newExpandedRoles.has(roleName)) {
      newExpandedRoles.delete(roleName);
    } else {
      newExpandedRoles.add(roleName);
    }
    setExpandedRoles(newExpandedRoles);
  };

  const handleSaveWorkflow = async () => {
    // Validate inputs
    if (!selectedRole) {
      alert("Please select a role");
      return;
    }

    if (selectedActions.length === 0) {
      alert("Please select at least one action");
      return;
    }

    if (!user?.org?.org_id) {
      alert("Organization ID is required");
      return;
    }

    // Extract role name from selectedRole (handle "Role Name - Alias Name" format)
    const baseRoleName = selectedRole.includes(" - ")
      ? selectedRole.split(" - ")[0].trim()
      : selectedRole;

    // Find the role data from rolesData
    const selectedRoleData = rolesData.find((role) => {
      const roleName =
        role.role_name ||
        role.roleName ||
        role.name ||
        role.role ||
        role.label ||
        role.title;
      return roleName === baseRoleName;
    });

    if (!selectedRoleData) {
      alert("Role data not found");
      return;
    }

    // Get role_id from selectedRoleData
    const roleId =
      selectedRoleData?.role_id ||
      selectedRoleData?.roleId ||
      selectedRoleData?.id;

    if (!roleId) {
      alert("Role ID is required");
      return;
    }

    // Get role_name from selectedRoleData
    const roleName =
      selectedRoleData?.role_name ||
      selectedRoleData?.roleName ||
      selectedRoleData?.name ||
      selectedRoleData?.role ||
      baseRoleName ||
      "";

    setIsSaving(true);
    setSaveSuccess(false);

    try {
      const token = localStorage.getItem("token");
      const orgId = user.org.org_id;

      // First, fetch existing actions for this role (includes Workflow Management actions)
      let existingActionIds = new Set();
      try {
        const baseUrl = workflowEndPoints.getAssignedActionsByOrgId;
        const url = `${baseUrl}?org_id=${encodeURIComponent(
          orgId
        )}&role_id=${encodeURIComponent(String(roleId))}`;

        const existingResponse = await apiCall(url, methods.get, null, token);

        if (existingResponse?.status < 400) {
          let decryptedExistingResponse;
          if (existingResponse?.data && typeof existingResponse.data === "string") {
            try {
              const { decrypt } = await import("../crypto");
              decryptedExistingResponse = decrypt(existingResponse.data);
              if (typeof decryptedExistingResponse === "string") {
                try {
                  decryptedExistingResponse = JSON.parse(decryptedExistingResponse);
                } catch (e) {}
              }
            } catch (e) {
              try {
                decryptedExistingResponse = await decryptAesBase64(existingResponse.data);
                if (typeof decryptedExistingResponse === "string") {
                  try {
                    decryptedExistingResponse = JSON.parse(decryptedExistingResponse);
                  } catch (parseErr) {}
                }
              } catch (decryptErr) {
                decryptedExistingResponse = existingResponse;
              }
            }
          } else if (
            existingResponse?.data &&
            typeof existingResponse.data === "object" &&
            existingResponse.data?.data
          ) {
            const encryptedData = existingResponse.data.data;
            if (typeof encryptedData === "string") {
              try {
                const { decrypt } = await import("../crypto");
                decryptedExistingResponse = decrypt(encryptedData);
                if (typeof decryptedExistingResponse === "string") {
                  try {
                    decryptedExistingResponse = JSON.parse(decryptedExistingResponse);
                  } catch (e) {}
                }
              } catch (e) {
                try {
                  decryptedExistingResponse = await decryptAesBase64(encryptedData);
                  if (typeof decryptedExistingResponse === "string") {
                    try {
                      decryptedExistingResponse = JSON.parse(decryptedExistingResponse);
                    } catch (parseErr) {}
                  }
                } catch (decryptErr) {
                  decryptedExistingResponse = existingResponse.data;
                }
              }
    } else {
              decryptedExistingResponse = existingResponse.data;
            }
          } else {
            decryptedExistingResponse = existingResponse;
          }

          if (
            !decryptedExistingResponse?.error &&
            decryptedExistingResponse?.message !== "No assigned actions found"
          ) {
            let existingActionsArray = [];
            if (Array.isArray(decryptedExistingResponse)) {
              existingActionsArray = decryptedExistingResponse;
            } else if (decryptedExistingResponse?.data && Array.isArray(decryptedExistingResponse.data)) {
              existingActionsArray = decryptedExistingResponse.data;
            } else if (decryptedExistingResponse?.actions && Array.isArray(decryptedExistingResponse.actions)) {
              existingActionsArray = decryptedExistingResponse.actions;
            }

            // Extract existing action IDs
            existingActionsArray.forEach((actionItem) => {
              const actionId =
                typeof actionItem === "string"
                  ? actionItem
                  : actionItem?.action_id ||
                    actionItem?.actionId ||
                    actionItem?.id ||
                    actionItem?.enum ||
                    actionItem?.action;
              if (actionId) {
                existingActionIds.add(String(actionId));
              }
            });
          }
        }
      } catch (fetchError) {
        // If fetching existing actions fails, continue with only new actions
        console.warn("Failed to fetch existing actions, proceeding with new actions only:", fetchError);
    }

      // Map selected Approval actions (action names) to their IDs/enums from workflowActionsData
      const newApprovalActionIds = selectedActions
        .map((actionName) => {
          // Find the action object in workflowActionsData that matches the action name
          const actionData = workflowActionsData.find(
            (item) => item.action === actionName
          );
          // Return the action ID/enum, or fallback to action name if ID not found
          return (
            actionData?.action_id ||
            actionData?.actionId ||
            actionData?.id ||
            actionData?.enum ||
            actionData?.action ||
            actionName
          );
        })
        .filter(Boolean)
        .map((action) => String(action));

      // Merge existing actions with new Approval actions (Set automatically handles duplicates)
      const mergedActionIds = new Set([...existingActionIds, ...newApprovalActionIds]);

      // Prepare the payload with all required fields (merged actions)
      const payload = {
        org_id: String(user.org.org_id || ""),
        role_id: Number(roleId),
        role_name: String(roleName || ""),
        zone_id: String(user?.org?.zone_id || user?.zone_id || ""),
        site_id: String(user?.org?.site_id || user?.site_id || ""),
        department: String(
          user?.org?.department || user?.department || ""
        ),
        actions: Array.from(mergedActionIds), // Array of action IDs/enums as strings (merged)
      };

      // Encrypt the payload
      const encryptedPayload = await encryptAesBase64(payload);

      // Verify encryption format (should be base64 string)
      if (typeof encryptedPayload !== "string") {
        throw new Error(
          "Encryption failed: Expected string but got " +
            typeof encryptedPayload
        );
      }

      // Create the request payload with data field containing encrypted string
      const encryptedRequestPayload = {
        data: encryptedPayload.trim(),
      };

      // Call the API
      const response = await apiCall(
        workflowEndPoints.assignActionsRolesByRoleIdOrgId,
        methods.post,
        encryptedRequestPayload,
        token
      );

      // Check if apiCall returned an error response (status >= 400)
      if (response?.status >= 400) {
        const errorData = response.data;
        let errorMessage =
          errorData?.error ||
          errorData?.message ||
          errorData?.details ||
          JSON.stringify(errorData) ||
          "Failed to assign actions";

        // Try to decrypt error message if it's encrypted
        if (typeof errorData === "string") {
          try {
            const decryptedError = await decryptAesBase64(errorData);
            try {
              const parsedError = JSON.parse(decryptedError);
              errorMessage =
                parsedError?.error ||
                parsedError?.message ||
                parsedError?.details ||
                errorMessage;
            } catch (e) {
              // If parsing fails, use decrypted string as is
              errorMessage = decryptedError;
            }
          } catch (e) {
            // If decryption fails, use original error message
          }
        }

        throw new Error(errorMessage);
      }

      // Decrypt the response if it has encrypted data field
      let finalResponse;
      if (response?.data && typeof response.data === "string") {
        try {
          const decryptedRes = await decryptAesBase64(response.data);
          if (typeof decryptedRes === "string") {
            try {
              finalResponse = JSON.parse(decryptedRes);
            } catch (e) {
              throw new Error("Invalid decrypted data format");
            }
          } else if (decryptedRes && typeof decryptedRes === "object") {
            finalResponse = decryptedRes;
          } else {
            throw new Error("Invalid decrypted data format");
          }
        } catch (e) {
          // If decryption fails, maybe response.data is already plain JSON
          if (typeof response.data === "object") {
            finalResponse = response.data;
          } else {
            throw new Error("Failed to decrypt data locally");
          }
        }
      } else {
        finalResponse = response;
      }

      // Check if response indicates success
      if (finalResponse?.error || finalResponse?.success === false) {
        throw new Error(
          finalResponse.error ||
            finalResponse.message ||
            "Failed to assign actions"
        );
      }

      // After successful save, immediately fetch all assigned actions to refresh the role workflows
      try {
        const orgId = user.org.org_id;
        const roleWorkflowsMap = new Map(); // Use Map to group by base role name

        // Fetch assigned actions for each role
        for (const roleData of rolesData) {
          const roleId =
            roleData?.role_id ||
            roleData?.roleId ||
            roleData?.id;

          if (!roleId) continue;

          const roleName =
            roleData?.role_name ||
            roleData?.roleName ||
            roleData?.name ||
            roleData?.role ||
            roleData?.label ||
            roleData?.title;

          if (!roleName) continue;

          // Get alias names for this role
          const aliasNames = roleData.alias_names || [];
          const orgAliases = orgId
            ? aliasNames.filter(
                (alias) =>
                  alias.org_id === orgId ||
                  alias.orgId === orgId ||
                  !alias.org_id
              )
            : aliasNames;

          // If role has aliases, fetch for each alias; otherwise fetch once for the role
          const rolesToFetch = orgAliases.length > 0
            ? orgAliases.map((alias) => ({
                roleId,
                displayName: `${roleName} - ${alias.alias_name || alias.aliasName || alias.name || ""}`,
              }))
            : [{ roleId, displayName: roleName }];

          // Fetch actions for each alias separately to show them as separate cards with alias names
          for (const roleInfo of rolesToFetch) {
            try {
              const baseUrl = workflowEndPoints.getAssignedActionsByOrgId;
              const url = `${baseUrl}?org_id=${encodeURIComponent(
                orgId
              )}&role_id=${encodeURIComponent(String(roleInfo.roleId))}`;

              const refreshResponse = await apiCall(url, methods.get, null, token);

              if (refreshResponse?.status >= 400) {
                continue;
              }

              // Decrypt the response
              let decryptedResponse;
              if (refreshResponse?.data && typeof refreshResponse.data === "string") {
                try {
                  const { decrypt } = await import("../crypto");
                  decryptedResponse = decrypt(refreshResponse.data);
                  if (typeof decryptedResponse === "string") {
                    try {
                      decryptedResponse = JSON.parse(decryptedResponse);
                    } catch (e) {}
                  }
                } catch (e) {
                  try {
                    decryptedResponse = await decryptAesBase64(refreshResponse.data);
                    if (typeof decryptedResponse === "string") {
                      try {
                        decryptedResponse = JSON.parse(decryptedResponse);
                      } catch (parseErr) {}
                    }
                  } catch (decryptErr) {
                    continue;
                  }
                }
              } else if (
                refreshResponse?.data &&
                typeof refreshResponse.data === "object" &&
                refreshResponse.data?.data
              ) {
                const encryptedData = refreshResponse.data.data;
                if (typeof encryptedData === "string") {
                  try {
                    const { decrypt } = await import("../crypto");
                    decryptedResponse = decrypt(encryptedData);
                    if (typeof decryptedResponse === "string") {
                      try {
                        decryptedResponse = JSON.parse(decryptedResponse);
                      } catch (e) {}
                    }
                  } catch (e) {
                    try {
                      decryptedResponse = await decryptAesBase64(encryptedData);
                      if (typeof decryptedResponse === "string") {
                        try {
                          decryptedResponse = JSON.parse(decryptedResponse);
                        } catch (parseErr) {}
                      }
                    } catch (decryptErr) {
                      continue;
                    }
                  }
                } else {
                  decryptedResponse = refreshResponse.data;
                }
              } else {
                decryptedResponse = refreshResponse;
              }

              // Check if the decrypted response contains "No assigned actions found"
              if (
                decryptedResponse?.error === "No assigned actions found" ||
                decryptedResponse?.message === "No assigned actions found" ||
                (typeof decryptedResponse === "string" &&
                  decryptedResponse
                    .toLowerCase()
                    .includes("no assigned actions found"))
              ) {
                continue;
              }

              // Extract actions from the response
              let actionsArray = [];
              if (Array.isArray(decryptedResponse)) {
                actionsArray = decryptedResponse;
              } else if (decryptedResponse?.data && Array.isArray(decryptedResponse.data)) {
                actionsArray = decryptedResponse.data;
              } else if (decryptedResponse?.actions && Array.isArray(decryptedResponse.actions)) {
                actionsArray = decryptedResponse.actions;
              }

              // Map action IDs/enums to action names from workflowActionsData
              const actionNames = actionsArray
                .map((actionItem) => {
                  const actionId =
                    typeof actionItem === "string"
                      ? actionItem
                      : actionItem?.action_id ||
                        actionItem?.actionId ||
                        actionItem?.id ||
                        actionItem?.enum ||
                        actionItem?.action;

                  if (!actionId) return null;

                  const actionData = workflowActionsData.find(
                    (item) =>
                      item.action_id === actionId ||
                      item.actionId === actionId ||
                      item.id === actionId ||
                      item.enum === actionId ||
                      item.action === actionId
                  );

                  return actionData?.action || actionId;
                })
                .filter(Boolean);

              // Add/update this role with alias in the map (showing alias name)
              if (actionNames.length > 0) {
                roleWorkflowsMap.set(roleInfo.displayName, {
                  role: roleInfo.displayName,
                  actions: actionNames,
                });
              }
            } catch (error) {
              // Continue with next role
              continue;
            }
          }
        }

        // Convert Map to Array and update roleWorkflows state
        const allRoleWorkflows = Array.from(roleWorkflowsMap.values());
        setRoleWorkflows(allRoleWorkflows);
      } catch (refreshError) {
        // If refresh fails, still show success but log the error
        console.error("Error refreshing role workflows:", refreshError);
      }

      // Show success indicator
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 2000);
    } catch (error) {
      console.error("Error saving workflow:", error);
      alert(error.message || "Failed to save workflow");
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteRole = async (roleToDelete) => {
    if (
      !window.confirm(
        `Are you sure you want to delete the ${roleToDelete} role workflow?`
      )
    ) {
      return;
    }

    try {
      const token = localStorage.getItem("token");
      const orgId = user?.org?.org_id || user?.org_id || "";

      if (!orgId) {
        alert("Organization ID not found. Please ensure you are logged in.");
        return;
      }

      // Extract base role name (remove alias if present, e.g., "Initiator - PAAAA" -> "Initiator")
      const baseRoleName = roleToDelete.includes(" - ")
        ? roleToDelete.split(" - ")[0].trim()
        : roleToDelete;

      // Find role_id from rolesData
      const roleData = rolesData.find((role) => {
        const roleName =
          role?.role_name ||
          role?.roleName ||
          role?.name ||
          role?.role ||
          role?.label ||
          role?.title;
        return roleName === baseRoleName;
      });

      if (!roleData) {
        alert(`Role data not found for ${roleToDelete}`);
        return;
      }

      const roleId =
        roleData?.role_id || roleData?.roleId || roleData?.id || null;

      if (!roleId) {
        alert(`Role ID not found for ${roleToDelete}`);
        return;
      }

      // Get role_name from roleData
      const roleName =
        roleData?.role_name ||
        roleData?.roleName ||
        roleData?.name ||
        roleData?.role ||
        baseRoleName ||
        "";

      // First, fetch all current assigned actions for this role
      const baseUrl = workflowEndPoints.getAssignedActionsByOrgId;
      const fetchUrl = `${baseUrl}?org_id=${encodeURIComponent(orgId)}&role_id=${encodeURIComponent(String(roleId))}`;
      const fetchResponse = await apiCall(fetchUrl, methods.get, null, token);

      if (fetchResponse?.status >= 400) {
        const errorData = fetchResponse.data;
        const errorMessage =
          errorData?.error ||
          errorData?.message ||
          errorData?.details ||
          JSON.stringify(errorData) ||
          "Failed to fetch assigned actions";
        alert(`Failed to fetch assigned actions: ${errorMessage}`);
        return;
      }

      // Decrypt the response
      let decryptedResponse;
      if (fetchResponse?.data && typeof fetchResponse.data === "string") {
        try {
          const { decrypt } = await import("../crypto");
          decryptedResponse = decrypt(fetchResponse.data);
          if (typeof decryptedResponse === "string") {
            try {
              decryptedResponse = JSON.parse(decryptedResponse);
            } catch (e) {}
          }
        } catch (e) {
          try {
            decryptedResponse = await decryptAesBase64(fetchResponse.data);
            if (typeof decryptedResponse === "string") {
              try {
                decryptedResponse = JSON.parse(decryptedResponse);
              } catch (parseErr) {}
            }
          } catch (decryptErr) {
            decryptedResponse = fetchResponse;
          }
        }
      } else if (
        fetchResponse?.data &&
        typeof fetchResponse.data === "object" &&
        fetchResponse.data?.data
      ) {
        const encryptedData = fetchResponse.data.data;
        if (typeof encryptedData === "string") {
          try {
            const { decrypt } = await import("../crypto");
            decryptedResponse = decrypt(encryptedData);
            if (typeof decryptedResponse === "string") {
              try {
                decryptedResponse = JSON.parse(decryptedResponse);
              } catch (e) {}
            }
          } catch (e) {
            try {
              decryptedResponse = await decryptAesBase64(encryptedData);
              if (typeof decryptedResponse === "string") {
                try {
                  decryptedResponse = JSON.parse(decryptedResponse);
                } catch (parseErr) {}
              }
            } catch (decryptErr) {
              decryptedResponse = fetchResponse.data;
            }
          }
        } else {
          decryptedResponse = fetchResponse.data;
        }
      } else {
        decryptedResponse = fetchResponse;
      }

      // Extract all current actions
      let allActionsArray = [];
      if (Array.isArray(decryptedResponse)) {
        allActionsArray = decryptedResponse;
      } else if (decryptedResponse?.data && Array.isArray(decryptedResponse.data)) {
        allActionsArray = decryptedResponse.data;
      } else if (decryptedResponse?.actions && Array.isArray(decryptedResponse.actions)) {
        allActionsArray = decryptedResponse.actions;
      }

      // Filter out only "Approval" type actions (those that exist in workflowActionsData)
      // Keep only actions that are NOT in workflowActionsData (i.e., Action type actions)
      const actionsToKeep = allActionsArray.filter((actionItem) => {
        const actionId =
          typeof actionItem === "string"
            ? actionItem
            : actionItem?.action_id ||
              actionItem?.actionId ||
              actionItem?.id ||
              actionItem?.enum ||
              actionItem?.action;

        if (!actionId) return false;

        // Check if this action exists in workflowActionsData (Approval type)
        const isApprovalType = workflowActionsData.some(
          (item) =>
            item.action_id === actionId ||
            item.actionId === actionId ||
            item.id === actionId ||
            item.enum === actionId ||
            item.action === actionId
        );

        // Keep only if it's NOT an Approval type (i.e., it's Action type or other)
        return !isApprovalType;
      });

      // If there are no actions left to keep, we can optionally delete all actions
      // But for now, we'll save the filtered list (which may be empty)
      const actionsToSave = actionsToKeep.map((actionItem) => {
        const actionId =
          typeof actionItem === "string"
            ? actionItem
            : actionItem?.action_id ||
              actionItem?.actionId ||
              actionItem?.id ||
              actionItem?.enum ||
              actionItem?.action;
        return String(actionId || actionItem);
      });

      // Prepare payload with remaining actions (only Action type actions)
      const payload = {
        org_id: String(orgId || ""),
        role_id: Number(roleId),
        role_name: String(roleName || ""),
        zone_id: String(user?.org?.zone_id || user?.zone_id || ""),
        site_id: String(user?.org?.site_id || user?.site_id || ""),
        department: String(
          user?.org?.department || user?.department || ""
        ),
        actions: actionsToSave, // Only Action type actions (or empty array)
      };

      // Encrypt and save the updated actions list
      const encryptedPayload = await encryptAesBase64(payload);

      if (typeof encryptedPayload !== "string") {
        throw new Error(
          "Encryption failed: Expected string but got " + typeof encryptedPayload
        );
      }

      const encryptedRequestPayload = {
        data: encryptedPayload.trim(),
      };

      const saveResponse = await apiCall(
        workflowEndPoints.assignActionsRolesByRoleIdOrgId,
        methods.post,
        encryptedRequestPayload,
        token
      );

      if (saveResponse?.status >= 400) {
        const errorData = saveResponse.data;
        const errorMessage =
          errorData?.error ||
          errorData?.message ||
          errorData?.details ||
          JSON.stringify(errorData) ||
          "Failed to delete approval actions";
        alert(`Failed to delete approval actions: ${errorMessage}`);
        return;
      }

      // Remove the role from roleWorkflows temporarily for better UX
      const updatedRoleWorkflows = roleWorkflows.filter(
        (workflow) => workflow.role !== roleToDelete
      );
      setRoleWorkflows(updatedRoleWorkflows);

      // Trigger refresh by updating refreshTrigger to cause useEffect to re-run
      setRefreshTrigger((prev) => prev + 1);

      alert(`${roleToDelete} role workflow has been deleted successfully`);
    } catch (err) {
      let errorMessage = "Unknown error";
      if (err.response?.data) {
        const errorData = err.response.data;
        if (typeof errorData === "object" && errorData !== null) {
          errorMessage =
            errorData.error ||
            errorData.message ||
            errorData.details ||
            JSON.stringify(errorData);
        } else if (typeof errorData === "string" && errorData.trim() !== "") {
          errorMessage = errorData;
        } else {
          errorMessage = String(errorData);
        }
      } else {
        errorMessage = err.message || "Unknown error";
      }

      alert(`Failed to delete role workflow: ${errorMessage}`);
    }
  };

  const filteredActions = workflowActions.filter((action) =>
    action.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar token={token} />

      {/* Header */}
      <div className="bg-white px-6 py-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => window.history.back()}
            className="text-gray-600 hover:text-gray-800 transition-colors"
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
              <path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z" />
            </svg>
          </button>
          <h1 className="text-2xl font-bold text-gray-800">
            Approval Mechanism
          </h1>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-6 pt-2 pb-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-2">
          {/* Column 1: Role Selection */}
          <div className="bg-white rounded-lg p-6 shadow-sm">
            <h2 className="text-lg font-semibold text-gray-800 mb-2">
              Role Selection
            </h2>
            <p className="text-sm text-gray-600 mb-4">
              Select your role to view relevant workflow actions
            </p>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Role <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                {isLoadingRoles ? (
                  <div className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50 flex items-center">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary mr-2"></div>
                    <span className="text-sm text-gray-500">
                    Loading roles...
                    </span>
                  </div>
                ) : rolesError ? (
                  <div className="w-full px-3 py-2 border border-red-300 rounded-md bg-red-50 text-red-600 text-sm">
                    {rolesError}
                  </div>
                ) : (
                  <select
                    value={selectedRole}
                    onChange={(e) => handleRoleChange(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                  >
                    {roles.length > 0 ? (
                      roles.map((role) => (
                        <option key={role} value={role}>
                        {role}
                      </option>
                      ))
                    ) : (
                      <option value="">No roles available</option>
                    )}
                  </select>
                )}
                {!isLoadingRoles && !rolesError && (
                <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                  <svg
                    className="w-4 h-4 text-gray-400"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M19 9l-7 7-7-7"
                    />
                  </svg>
                </div>
                )}
              </div>
            </div>

            <p className="text-sm text-gray-600 mb-4">
              Selected actions to the Role
            </p>

            {/* Selected Actions */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 h-80 overflow-y-auto">
              {selectedActions.length > 0 ? (
                <div className="space-y-2">
                  {selectedActions.map((action, index) => (
                    <div
                      key={index}
                      className="flex items-center text-blue-800"
                    >
                      <div className="w-2 h-2 bg-blue-600 rounded-full mr-3"></div>
                      <span className="text-sm">{action}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col justify-center items-center h-full">
                  <img
                    src={approvalMechanism}
                    alt="No approvals found"
                    className="w-8 h-8 mx-auto mb-4"
                  />
                  <p className="text-gray-600 font-medium">
                    No Approval/Role found
                  </p>
                </div>
              )}
            </div>

            <div className="flex justify-end mt-6">
              <button
                onClick={handleSaveWorkflow}
                disabled={isSaving}
                className={`py-2.5 px-8 rounded-full transition-colors font-semibold text-base ${
                  saveSuccess
                    ? "bg-green-500 text-white"
                    : isSaving
                    ? "bg-gray-400 text-white cursor-not-allowed"
                    : "bg-primary text-white hover:bg-primary-dark"
                }`}
              >
                {isSaving ? "Saving..." : saveSuccess ? "✓ Saved!" : "Save"}
              </button>
            </div>
          </div>

          {/* Column 2: LOTO Approval Checklist */}
          <div className="bg-white rounded-lg p-6 shadow-sm">
            <h2 className="text-lg font-semibold text-gray-800 mb-6">
              LOTO Approval Checklist
            </h2>

            {/* Action Checklist */}
            <div className="bg-white border border-gray-300 rounded-lg p-4 h-[28rem] flex flex-col">
              {/* Search Bar */}
              <div className="relative mb-4 flex-shrink-0">
                <input
                  type="text"
                  placeholder="Search..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full px-3 py-2 pl-10 rounded-md focus:outline-none bg-blue-50"
                />
                <div className="absolute inset-y-0 left-0 flex items-center pl-3">
                  <svg
                    className="w-4 h-4 text-gray-400"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                    />
                  </svg>
                </div>
              </div>

              {/* Action Checklist - Scrollable Area */}
              <div className="flex-1 overflow-y-auto">
                {isLoadingActions ? (
                  <div className="flex flex-col justify-center items-center h-full">
                    <p className="text-gray-600 font-medium">
                      Loading actions...
                    </p>
                  </div>
                ) : actionsError ? (
                  <div className="flex flex-col justify-center items-center h-full">
                    <p className="text-red-600 font-medium">{actionsError}</p>
                  </div>
                ) : filteredActions.length > 0 ? (
                  <div className="space-y-3">
                    {filteredActions.map((action, index) => (
                      <div key={index} className="flex items-center">
                        <input
                          type="checkbox"
                          id={`action-${index}`}
                          checked={selectedActions.includes(action)}
                          onChange={() => handleActionToggle(action)}
                          className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                        />
                        <label
                          htmlFor={`action-${index}`}
                          className="ml-3 text-sm text-gray-700 cursor-pointer"
                        >
                          {action}
                        </label>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-col justify-center items-center h-full">
                    <img
                      src={approvalMechanism}
                      alt="No approvals found"
                      className="w-8 h-8 mx-auto mb-4"
                    />
                    <p className="text-gray-600 font-medium">
                      No Approval/Role found
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Column 3: Role Assigned WorkFlow */}
          <div className="bg-white rounded-lg p-6 shadow-sm">
            <h2 className="text-lg font-semibold text-gray-800 mb-6">
              Role Assigned WorkFlow
            </h2>

            {/* Role Cards */}
            <div className="space-y-4">
              {roleWorkflows.map((roleWorkflow, index) => (
                <div
                  key={`${roleWorkflow.role}-${index}`}
                  className="bg-gray-50 border border-gray-200 rounded-lg p-4"
                >
                  <div className="flex justify-between items-center mb-3">
                    <h3 className="font-semibold text-gray-800">
                      {roleWorkflow.role}
                    </h3>
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleDeleteRole(roleWorkflow.role)}
                        className="text-gray-400 hover:text-red-500"
                        title="Delete role workflow"
                      >
                        <svg
                          className="w-4 h-4"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                          />
                        </svg>
                      </button>
                    </div>
                  </div>

                  <div className="space-y-2 mb-3">
                    {(() => {
                      const isExpanded = expandedRoles.has(roleWorkflow.role);
                      const actionsToShow = isExpanded
                        ? roleWorkflow.actions
                        : roleWorkflow.actions.slice(0, 3);
                      const hasMoreActions = roleWorkflow.actions.length > 3;

                      return (
                        <>
                          {actionsToShow.map((action, actionIndex) => (
                            <div
                              key={actionIndex}
                              className="flex items-center text-blue-800"
                            >
                              <div className="w-2 h-2 bg-blue-600 rounded-full mr-3"></div>
                              <span className="text-sm">{action}</span>
                            </div>
                          ))}
                          {hasMoreActions && (
                            <div className="flex justify-end mt-2">
                              <button
                                onClick={() =>
                                  toggleRoleExpansion(roleWorkflow.role)
                                }
                                className="text-blue-600 hover:text-blue-800 text-sm font-medium flex items-center"
                              >
                                {isExpanded ? (
                                  <>
                                    <svg
                                      className="w-4 h-4 mr-1"
                                      fill="none"
                                      stroke="currentColor"
                                      viewBox="0 0 24 24"
                                    >
                                      <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth={2}
                                        d="M5 15l7-7 7 7"
                                      />
                                    </svg>
                                    View Less
                                  </>
                                ) : (
                                  <>
                                    <svg
                                      className="w-4 h-4 mr-1"
                                      fill="none"
                                      stroke="currentColor"
                                      viewBox="0 0 24 24"
                                    >
                                      <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth={2}
                                        d="M19 9l-7 7-7-7"
                                      />
                                    </svg>
                                    View More ({roleWorkflow.actions.length - 3}{" "}
                                    more)
                                  </>
                                )}
                              </button>
                            </div>
                          )}
                        </>
                      );
                    })()}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ApprovalMechanism;
