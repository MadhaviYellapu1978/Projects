/* eslint-disable */
import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Navbar from "../components/Navbar";
import { apiCall } from "../utils";
import { methods, workOrderEndPoints } from "../constants";
import {
  Card,
  Grid,
  Typography,
  Button,
  // Accordion,
  // AccordionSummary,
  // AccordionDetails,
  Dialog,
  DialogContent,
} from "@mui/material";
// import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import { useSelector } from "react-redux";
import EditCustodian from "./EditCustodian"; // Import the EditCustodian component
import RequestforIssuer from "./RequestforIssuer";
import { useLocation } from "react-router-dom";
import RequestForIsolators from "./RequestForIsolators";
import WorkOrderLogs from "./WorkOrderLogs";
import toast from "react-hot-toast";
// import Avatar from "@mui/material/Avatar";
// import Chip from "@mui/material/Chip";
import InitiatorDialog from "./InitiatorDialog";
import { CustomActions } from "./track_act_to_cust_act";
import "./WorkOrderDetail.css";
import HandlePrint from "./HandlePrint";
import IsolationImages from "./workOrderDetails/IsolationImages";

const formatDate = (date) => {
  const formattedDate = new Date(date);

  const hours = formattedDate.getHours();
  const minutes = formattedDate.getMinutes();

  return minutes > 0 ? `${hours} hour(s) ${minutes} mins` : `${hours} hour(s)`;
};

const WorkorderDetail = (refetch) => {
  const location = useLocation();
  const { rowData } = location.state || {};
  const searchParams = new URLSearchParams(window.location.search);
  const tokenValue = searchParams.get("token");
  const { workorderId } = useParams();
  const [workOrderDetails, setWorkOrderDetails] = useState(null);
  const [selectedImage, setSelectedImage] = useState(null);
  // const [custodian_status, setCustodian_status] = useState(null)
  const [issuer_list, setIssuer_list] = useState([]);
  const [custodian_status, setCustodian_status] = useState(null);
  const [isolator_list, setIsolator_list] = useState([]);
  const [requestIssuerOpen, setRequestIssuerOpen] = useState(false);
  const [requestIsolatorOpen, setRequestIsolatorOpen] = useState(false);
  const [workOrderData, setWorkOrderData] = useState(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false); // Dialog visibility
  const [dialogOpen, setDialogOpen] = useState(false);
  const [notifications, setNotifications] = useState([]); // Define state for notifications

  const user = useSelector((state) => state.authSlice.user);

  const [editOpen, setEditOpen] = useState(false); // State to control the EditCustodian dialog
  const [editData, setEditData] = useState(null); // State to pass data to the EditCustodian component
  const [error, setError] = useState("");

  const [isEditVisible, setIsEditVisible] = useState(true); // State to control Edit button visibility
  const [isEditOpen, setIsEditOpen] = useState(false); // State to control the dialog

  const navigate = useNavigate();

  const handleAssignTechnicianClick = () => setDialogOpen(true);
  const handleCloseDialog = () => setDialogOpen(false);

  const handleEditButtonClick = () => {
    setIsEditOpen(true);
  };

  const handleDialogClose = () => {
    setIsEditOpen(false);
  };

  const handleUpdateSuccess = () => {
    setIsEditVisible(false); // Hide the Edit button on successful update
  };

  const fetchData = async () => {
    try {
      // Decode the Work Order ID
      const decodedId = atob(workorderId);

      // Fetch Work Order Details
      const workOrderResponse = await apiCall(
        `${workOrderEndPoints.getWorkOrderById}?WorkOrderId=${decodedId}&emp_id=${user.emp_id}`,
        methods.get,
        null,
        tokenValue
      );
      setWorkOrderDetails(workOrderResponse);
      setWorkOrderData(workOrderResponse);

      // Fetch Notifications
      const notificationPayload = {
        user_id: user?.emp_id || "", // Replace with the correct user ID if available
        orgId: user?.org?.org_id || "",
        siteId: workOrderResponse?.getWorkOrderDetails?.siteId || "",
        zoneId: workOrderResponse?.getWorkOrderDetails?.zoneId || "",
      };

      const notificationResponse = await apiCall(
        `${workOrderEndPoints.getNotificationsByOrgId}`,
        methods.post,
        notificationPayload,
        tokenValue
      );
      console.log("Fetched Notifications:", notificationResponse);
      setNotifications(notificationResponse || { notifications: [] });
    } catch (error) {
      console.error("Error fetching notifications:", error);
      setNotifications({ notifications: [] });
    }
  };

  useEffect(() => {
    fetchData();
  }, [workorderId, user]);

  useEffect(() => {
    if (workorderId) fetchData();
  }, [workorderId, tokenValue, user.emp_id]);

  useEffect(() => {
    if (workOrderDetails?.getWorkOrderDetails?.custodian_details) {
      const custodian =
        workOrderDetails.getWorkOrderDetails.custodian_details.find(
          (data) => data.custodian_name === "custodian user"
        );
      if (custodian) {
        setCustodian_status(custodian.custodian_status);
      }
    }
  }, [workOrderDetails]);

  console.log("getWorkOrderDetailsssss", workOrderDetails);

  const handleCompleteWOInitiatorClick = async () => {
    try {
      // Define the request object to mark the work order as completed
      const requestObject = {
        workOrderId: workOrderDetails.getWorkOrderDetails.workOrderId,
        workOrder_status: "Completed", // Set status to Completed
      };

      // Make the API call to update the work order
      const response = await apiCall(
        workOrderEndPoints.updateCustodiansWO, // API endpoint for updating work order status
        methods.put, // PUT method for updating
        requestObject
      );

      // Handle the response
      if (response) {
        toast.success("Work order completed successfully!");
        setTimeout(() => {
          window.location.href = `/loto/dashboard?token=${tokenValue}`;
          fetchData();
          // onClose();
        }, 2000); // 3 seconds delay

        // Add further actions here, like showing a success message or refreshing data
      } else {
        console.error("Error completing work order:", response);
      }
    } catch (error) {
      console.error("Error in API call:", error);
      // Handle the error (e.g., show an error message)
    }
  };

  const handleAcceptInitiatorClick = async () => {
    try {
      // Extract technician details from the response (for demonstration, it's assumed that getWorkOrderDetails is available in the context)
      const { technician_details } = getWorkOrderDetails; // Assuming getWorkOrderDetails is already available in the context

      // If there are technician details, use the first technician's details (you can modify this logic if needed)
      const technician = technician_details[0] || {};

      // Define the request object with technician details
      const requestObject = {
        workOrderId: workOrderDetails.getWorkOrderDetails.workOrderId, // Use the appropriate workOrderId variable
        initiator_id: user?.emp_id || "", // Include technician's id if available
        initiator_name: technician.technician_name || "vamsi viswa", // Use technician's name or fallback to default
        initiator_status: "InitStartDeIso", // Status can be adjusted based on your logic
        initiator_rejected_reason: technician.technician_rejected_reason || "", // Include rejection reason if available
        isHold: technician.isHold || false, // If technician hold status is available, include it
        requestBy: "", // Optionally include requestor name here
      };

      // Make the API call using axios (apiCall method is assumed to be predefined in your project)
      const response = await apiCall(
        `${workOrderEndPoints.updateCustodiansWO}`,
        methods.put,
        requestObject
      );

      // Handle the response
      if (response) {
        toast.success("Work order accepted successfully!");
        setTimeout(() => {
          window.location.href = `/loto/dashboard?token=${tokenValue}`;
          fetchData();
          // onClose();
        }, 2000);
        // You can add further actions here (like showing a success message)
      } else {
        console.error("Error in API response:", response);
      }
    } catch (error) {
      console.error("Error in API call:", error);
      // Handle the error (show error message, etc.)
    }
  };

  useEffect(() => {
    const fetchCustodiansList = async () => {
      try {
        const response = await apiCall(
          workOrderEndPoints.getCustodians,
          methods.post,
          {
            org_id: user?.org.org_id,
            zone_id: workOrderDetails?.getWorkOrderDetails.zoneId,
            site_id: workOrderDetails?.getWorkOrderDetails.siteId,
            workOrderId: workOrderDetails?.getWorkOrderDetails.workOrderId,
          }
        );
        setIssuer_list(response.issuers);
        setIsolator_list(response.isolators);
        console.log(isolator_list, "isolator_listttttt");
      } catch (err) {
        setError("Failed to fetch custodians");
        console.error("Error creating work order:", error.message || error);
      }
    };
    if (workOrderDetails) fetchCustodiansList();
  }, [workOrderDetails, user?.org?.org_id, error]);

  if (!workOrderDetails) {
    return <div>Loading...</div>;
  }
  const { getWorkOrderDetails, workOrdertrackingDetails } = workOrderDetails;
  const handleImageClick = (imageUrl) => setSelectedImage(imageUrl);
  const handleClose = () => setSelectedImage(null);

  const handleRequestIssuerClick = () => {
    setRequestIssuerOpen(true); // Open dialog
  };

  const handleRequestIssuerClose = () => {
    setRequestIssuerOpen(false); // Close dialog
  };

  const handleRequestIsolatorClick = () => {
    setRequestIsolatorOpen(true); // Open dialog
  };

  const handleRequestIsolatorClose = () => {
    setRequestIsolatorOpen(false); // Close dialog
  };

  const handleEditClick = (data) => {
    const machinesWithIsolationPoints = data.machines.map((machine) => ({
      workorderId: workorderId,
      machineName: machine.machineName,
      isolationPoints: machine.isolationPoints.map((point) => ({
        isolationName: point.isolationName,
        isolationImgPath: point.isolationImgPath,
        deIsolationImgPath: point.deIsolationImgPath,
      })),
    }));

    setEditData({ ...data, machines: machinesWithIsolationPoints }); // Include machines and isolation points
    setEditOpen(true); // Open the dialog
  };
  const handleCloseEditDialog = () => {
    setEditOpen(false); // Close the dialog
    setEditData(null); // Clear the edit data
  };

  const handleUpdate = (updatedData) => {
    setEditOpen(false);
    setEditData(null);
    fetchData();
  };

  const handleCustodianAcceptClick = () => {
    setIsDialogOpen(true);
  };

  const handleIsoIssuerVerificationClick = async () => {
    // setButtonText("Processing...");
    const workOrderId = workOrderDetails?.getWorkOrderDetails.workOrderId; // Replace with actual key for workOrderId
    const issuerDetails =
      workOrderData?.getWorkOrderDetails?.issuer_details?.[0];

    // Prepare the payload for the API
    const payload = {
      workOrderId,
      issuer_details: [
        {
          issuer_id: issuerDetails.issuer_id || "",
          issuer_name: issuerDetails.issuer_name || "",
          issuer_status: "IsoVerificationAccepted",
          issuer_rejected_reason: "",
          requestBy: "",
          isHold: false,
          isRejected: false,
        },
      ],
    };

    try {
      // Make the API call
      const res = await apiCall(
        `${workOrderEndPoints.updateCustodiansWO}`,
        methods.put,
        payload
      );

      if (res) {
        // Update button text on success
        toast.success("Isolation Verified");
        setTimeout(() => {
          window.location.href = `/loto/dashboard?token=${tokenValue}`;
          fetchData();
        }, 2000);
      }
    } catch (error) {
      console.error("Error verifying isolation:", error);
      // Update button text on error
    }
  };

  const handleDeIsoIssuerVerificationClick = async () => {
    // setButtonText("Processing...");
    const workOrderId = workOrderData?.getWorkOrderDetails?.workOrderId; // Replace with actual key for workOrderId
    const issuerDetails =
      workOrderData?.getWorkOrderDetails?.issuer_details?.[0];

    // Prepare the payload for the API
    const payload = {
      workOrderId,
      issuer_details: [
        {
          issuer_id: issuerDetails.issuer_id || "",
          issuer_name: issuerDetails.issuer_name || "",
          issuer_status: "DeIsoVerificationAccepted",
          issuer_rejected_reason: "",
          requestBy: "",
          isHold: false,
          isRejected: false,
        },
      ],
    };

    try {
      // Make the API call
      const res = await apiCall(
        `${workOrderEndPoints.updateCustodiansWO}`,
        methods.put,
        payload
      );

      if (res) {
        // Update button text on success

        // setButtonText("De-Isolation Verified");
        toast.success("De-Isolation Verified");
        setTimeout(() => {
          window.location.href = `/loto/dashboard?token=${tokenValue}`;
          fetchData();
        }, 2000);
      } else {
        // Handle failure response
        // setButtonText("Failed. Retry?");
      }
    } catch (error) {
      console.error("Error verifying isolation:", error);
      // Update button text on error
      // setButtonText("Failed. Retry?");
    }
  };

  const HandleCustodianAccept = async () => {
    try {
      // const workOrderId = workorderId;
      const workOrderId = workOrderData?.getWorkOrderDetails?.workOrderId;
      const CustodianId =
        workOrderData?.getWorkOrderDetails?.custodian_details?.[0]
          ?.custodian_id;
      const payload = {
        workOrderId: workOrderId,
        custodian_details: [
          {
            custodian_id: CustodianId || "",
            custodian_status: "Accepted", // Accepted or Rejected
            custodian_rejected_reason: "", // Empty for acceptance
          },
        ],
      };

      // API call
      const res = await apiCall(
        `${workOrderEndPoints.updateCustodiansWO}`,
        methods.put,
        payload
      );

      if (res) {
        toast.success("Custodian accepted successfully!");
        setTimeout(() => {
          window.location.href = `/loto/dashboard?token=${tokenValue}`;
          fetchData();
        }, 2000);
      } else {
        toast.error("Something went wrong!");
      }
    } catch (error) {
      console.error("Error accepting custodian:", error);
      toast.error("Failed to accept custodian.");
    }
  };

  const HandleIssuerAccept = async () => {
    try {
      // Extract necessary details from workOrderData
      const workOrderId = workOrderData?.getWorkOrderDetails?.workOrderId;
      const issuerDetails =
        workOrderData?.getWorkOrderDetails?.issuer_details?.[0];

      if (!workOrderId || !issuerDetails?.issuer_id) {
        toast.error("Missing required data: workOrderId or issuer details.");
        return;
      }

      // Construct the payload
      const payload = {
        workOrderId: workOrderId,
        issuer_details: [
          {
            issuer_id: issuerDetails.issuer_id, // Match from workOrderData
            issuer_name: issuerDetails.issuer_name, // Match from workOrderData
            issuer_status: "Accepted", // Updated status
            issuer_rejected_reason: "", // Empty for acceptance
            requestBy: "", // Match from workOrderData
            isHold: false, // Default value
            isRejected: false, // Default value
          },
        ],
      };

      // API call
      const res = await apiCall(
        `${workOrderEndPoints.updateCustodiansWO}`,
        methods.put,
        payload
      );

      if (res) {
        // navigate(`/loto/dashboard?token=${tokenValue}`);
        toast.success("Issuer accepted successfully!");
        // onClose();

        setTimeout(() => {
          window.location.href = `/loto/dashboard?token=${tokenValue}`;
          fetchData();
        }, 2000); // 3 seconds delay

        // window.location.href = `/loto/dashboard?token=${tokenValue}`;

        // fetchData(); // Refresh the work order data
      } else {
        toast.error("Something went wrong!");
      }
    } catch (error) {
      console.error("Error accepting issuer:", error);
      toast.error("Failed to accept issuer.");
    }
  };

  const getStatusStyle = (status) => {
    switch (status) {
      case "Accepted":
        return {
          borderColor: "#A4D3A2", // Light Green Border
          backgroundColor: "#DFF6DD", // Light Green Background
        };
      case "InProgress":
        return {
          borderColor: "#FFC107", // Amber Border
          backgroundColor: "#FFE9A5", // Light Amber Background
        };
      case "Pending":
        return {
          borderColor: "#FFCC00", // Yellow Border
          backgroundColor: "#FFF5CC", // Light Yellow Background
        };
      case "Completed":
        return {
          borderColor: "#A4D3A2", // Light Green Border
          backgroundColor: "#DFF6DD", // Light Green Background
        };
      case "Completed_deiso":
        return {
          borderColor: "#A4D3A2", // Light Green Border
          backgroundColor: "#DFF6DD", // Light Green Background
        };
      case "Completed_iso":
        return {
          borderColor: "#A4D3A2", // Light Green Border
          backgroundColor: "#DFF6DD", // Light Green Background
        };
      default:
        return {
          borderColor: "#000", // Default Border
          backgroundColor: "transparent", // Default Background
        };
    }
  };

  //   const handlePrint = () => {
  //   // Open the print dialog
  //   window.print();
  // };

  // const handlePrint = () => {
  //   const printElement = document.getElementById("printableWorkOrder");
  //   if (!printElement) {
  //     console.error("Printable content not found");
  //     return;
  //   }

  //   const content = printElement.innerHTML;

  //   // Backup original body content
  //   const originalContent = document.body.innerHTML;

  //   // Replace body content with the printable content
  //   document.body.innerHTML = content;

  //   // Trigger the print dialog
  //   window.print();

  //   // Restore original content
  //   document.body.innerHTML = originalContent;

  //   // Reload the page to restore React state
  //   window.location.reload();
  // };

  const trackingDetails = workOrderDetails.workOrdertrackingDetails || [];

  function formatDuration(minutes) {
    const hours = Math.floor(minutes / 60); // Convert total minutes to hours
    const remainingMinutes = minutes % 60; // Get the remainder of minutes after converting to hours
    // Constructing the output string conditionally based on hours and minutes
    return `${hours > 0 ? `${hours} hour(s) ` : ""}${remainingMinutes} min`;
  }

  // Example usage
  const timeToComplete = 250; // 250 minutes
  console.log(formatDuration(timeToComplete)); // Outputs: "4 hour(s) and 10 min"

  return (
    <div>
      <Navbar token={tokenValue} />
      <div className="px-4 sm:px-10">
        <div className="flex items-center mb-2">
          {" "}
          {/* Use flex to align items horizontally */}
          <Button
            onClick={() => navigate(-1)}
            startIcon={<ArrowBackIcon style={{ color: "black" }} />}
            sx={{ mt: 2, mb: 2 }}
          >
            Back
          </Button>
          <div className="flex items-center ml-4">
            {" "}
            {/* Add margin-left to separate */}
            <Typography variant="h6">Work Order Name:</Typography>
            <Typography variant="h6" sx={{ marginLeft: "5px" }}>
              {getWorkOrderDetails?.workOrderName}
            </Typography>
          </div>
        </div>

        <Grid container spacing={3}>
          {/* Work Order Details */}
          <Grid item xs={12} md={6} id="printableWorkOrder">
            <Card sx={{ maxHeight: "120vh", p: 3, overflowY: "scroll" }}>
              <Grid container spacing={4} sx={{ mt: 2 }}>
                {/* Left Column */}

                <Grid container alignItems="center">
                  <div className="flex items-center ml-6 mr-6 gap-4">
                    <Typography variant="h6" sx={{ fontWeight: 600 }}>
                      Work Order Details
                    </Typography>

                    {/* Edit Button */}
                    {rowData.your_role === "Custodian" &&
                      rowData.track_action === "Pending Custodian" &&
                      isEditVisible && (
                        <button
                          className="bg-primary py-2 px-5 rounded-full text-white font-semibold"
                          onClick={() => handleEditClick(getWorkOrderDetails)}
                        >
                          Edit
                        </button>
                      )}

                    {/* Accept Button for Custodian */}
                    {rowData.your_role === "Custodian" &&
                      rowData.track_action === "Pending Custodian" && (
                        <button
                          className="bg-primary py-2 px-5 rounded-full text-white font-semibold"
                          onClick={handleCustodianAcceptClick}
                        >
                          Accept
                        </button>
                      )}

                    {/* Accept Button for Issuer */}
                    {rowData.your_role === "Issuer" &&
                      rowData.track_action === "Pending Issuer" && (
                        <button
                          className="bg-primary py-2 px-5 rounded-full text-white font-semibold"
                          onClick={HandleIssuerAccept}
                        >
                          Accept
                        </button>
                      )}
                  </div>

                  {/* Edit Custodian Dialog */}
                  {isEditVisible && (
                    <EditCustodian
                      open={editOpen}
                      onClose={handleCloseEditDialog}
                      data={editData}
                      workOrderDetails={getWorkOrderDetails}
                      onUpdate={handleUpdate}
                      fetchData={fetchData}
                    />
                  )}

                  {/* Conditionally Render Track Action */}
                  {!(
                    rowData.your_role === "Custodian" &&
                    rowData.track_action === "Custodian Accepted"
                  ) &&
                    !(
                      rowData.your_role === "Issuer" &&
                      rowData.track_action === "All Issuers Accepted"
                    ) && (
                      <div className="mt-2 ml-4">
                        {rowData.track_action && (
                          <div className="pl- bg-gray-100 text-gray-800 border border-gray-300 rounded-lg p-4">
                            <strong>Track Action:</strong>{" "}
                            {CustomActions[
                              trackingDetails?.[trackingDetails.length - 1]
                                ?.status_name
                            ] ||
                              trackingDetails?.[trackingDetails.length - 1]
                                ?.status_name ||
                              rowData.track_action ||
                              "N/A"}
                          </div>
                        )}
                      </div>
                    )}

                  {/* Request Buttons for Issuer and Isolator */}
                  {rowData.your_role === "Custodian" &&
                    rowData.track_action === "Custodian Accepted" && (
                      <Grid item xs={6} textAlign="right">
                        <div className="flex gap-2 justify-end ml-1">
                          <button
                            className="min-w-[160px] px-6 py-2 rounded-full text-white bg-primary font-semibold shadow-md hover:bg-primary-dark transition-all duration-300 flex items-center justify-center gap-2 whitespace-nowrap"
                            onClick={handleRequestIssuerClick}
                          >
                            Assign Issuer
                          </button>
                        </div>
                      </Grid>
                    )}

                  {rowData.your_role === "Issuer" &&
                    rowData.track_action === "All Issuers Accepted" && (
                      <Grid item xs={6} textAlign="right">
                        <div className="flex gap-2 justify-end ml-1">
                          <button
                            style={{ width: "140px" }}
                            className="min-w-[160px] px-6 py-2 rounded-full text-white bg-primary font-semibold shadow-md hover:bg-primary-dark transition-all duration-300 flex items-center justify-center gap-2 whitespace-nowrap"
                            onClick={handleRequestIsolatorClick}
                          >
                            Assign Isolator
                          </button>
                        </div>
                      </Grid>
                    )}

                  {rowData?.your_role === "Issuer" &&
                    rowData?.track_action === "Completed Isolation" &&
                    notifications?.notifications?.some(
                      (notification) =>
                        notification.workOrderId === rowData?.workOrderId &&
                        notification.action === "await_Issuer_verify_iso"
                    ) && (
                      <Grid item xs={6} textAlign="right">
                        <div className="flex gap-2 justify-end ml-1 mt-2">
                          <button
                            style={{ width: "140px" }}
                            className="min-w-[160px] px-6 py-2 rounded-full text-white bg-primary font-semibold shadow-md hover:bg-primary-dark transition-all duration-300 flex items-center justify-center gap-2 whitespace-nowrap"
                            onClick={handleIsoIssuerVerificationClick}
                          >
                            Verify Isolation
                          </button>
                        </div>
                      </Grid>
                    )}

                  {rowData.your_role === "Initiator" &&
                    rowData.track_action === "Completed Isolation" &&
                    notifications?.notifications?.some(
                      (notification) =>
                        notification.workOrderId === rowData?.workOrderId &&
                        notification.action === "await_technicians_added"
                    ) && (
                      <Grid item xs={6} textAlign="right">
                        <div className="flex gap-2 justify-end ml-1 mt-2">
                          <button
                            style={{ width: "160px" }}
                            className="min-w-[180px] px-7 py-2 rounded-full text-white bg-primary font-semibold  hover:bg-primary-dark transition-all duration-300 flex items-center justify-center gap-2 whitespace-nowrap"
                            onClick={handleAssignTechnicianClick}
                          >
                            Assign Technician
                          </button>
                        </div>
                      </Grid>
                    )}

                  {rowData.your_role === "Initiator" &&
                    // rowData.track_action === "Completed De-Isolation" &&
                    notifications?.notifications?.some(
                      (notification) =>
                        notification.workOrderId === rowData?.workOrderId &&
                        notification.action === "completed_workOrder"
                    ) &&
                    workOrderDetails.getWorkOrderDetails.workOrder_status !==
                      "Completed" && (
                      <Grid item xs={6} textAlign="right">
                        <div className="flex gap-2 justify-end ml-1 mt-2">
                          <button
                            style={{ width: "160px" }}
                            className="min-w-[180px] px-7 py-2 rounded-full text-white bg-primary font-semibold shadow-md hover:bg-primary-dark transition-all duration-300 flex items-center justify-center gap-2 whitespace-nowrap"
                            onClick={handleCompleteWOInitiatorClick}
                          >
                            Complete Work order
                          </button>
                        </div>
                      </Grid>
                    )}

                  {CustomActions[
                    trackingDetails?.[trackingDetails.length - 1]?.status_name
                  ] === "Work order Completed" && (
                    <Grid item xs={6} textAlign="right">
                      <div className="flex gap-2 justify-end ml-1 mt-2">
                        <h1
                          style={{ width: "160px" }}
                          className="min-w-[180px] px-7 py-2 rounded-full text-black bg-green-300 font-semibold shadow-md hover:bg-primary-dark transition-all duration-300 flex items-center justify-center gap-2 whitespace-nowrap"
                        >
                          Work order completed
                        </h1>
                      </div>
                    </Grid>
                  )}

                  {rowData.your_role === "Initiator" &&
                    rowData.track_action === "Completed Work" && (
                      <Grid item xs={6} textAlign="right">
                        <div className="flex gap-2 justify-end ml-1 mt-2">
                          <button
                            style={{ width: "140px" }}
                            className="min-w-[160px] px-6 py-2 rounded-full text-white bg-primary font-semibold shadow-md hover:bg-primary-dark transition-all duration-300 flex items-center justify-center gap-2 whitespace-nowrap"
                            onClick={handleAcceptInitiatorClick}
                          >
                            Accept
                          </button>
                        </div>
                      </Grid>
                    )}
                  {rowData?.your_role === "Issuer" &&
                    rowData?.track_action === "Completed De-Isolation" &&
                    notifications?.notifications?.some(
                      (notification) =>
                        notification.workOrderId === rowData?.workOrderId &&
                        notification.action === "await_issuer_verify_deiso"
                    ) && (
                      <Grid item xs={6} textAlign="right">
                        <div className="flex gap-2 justify-end ml-1 mt-2">
                          <button
                            style={{ width: "140px" }}
                            className="min-w-[160px] px-6 py-2 rounded-full text-white bg-primary font-semibold shadow-md hover:bg-primary-dark transition-all duration-300 flex items-center justify-center gap-2 whitespace-nowrap"
                            onClick={handleDeIsoIssuerVerificationClick}
                          >
                            Verify De-Isolation
                          </button>
                        </div>
                      </Grid>
                    )}
                </Grid>

                <Dialog
                  open={isDialogOpen}
                  onClose={() => setIsDialogOpen(false)}
                  maxWidth="sm" // Set the maximum width of the dialog
                  fullWidth // Makes the dialog take the full available width
                >
                  <DialogContent
                    sx={{
                      padding: "24px", // Add more padding for more space inside the dialog
                      textAlign: "center", // Optionally center the content
                    }}
                  >
                    <Typography variant="h6" sx={{ marginBottom: "20px" }}>
                      Do you want to accept without editing the work order?
                    </Typography>
                    <button
                      onClick={() => {
                        setIsDialogOpen(false); // Close dialog
                        HandleCustodianAccept(); // Trigger API call
                      }}
                      className="bg-primary py-2 px-7 rounded-full text-white font-semibold"
                      sx={{ marginRight: "10px" }} // Add some margin between the buttons
                    >
                      Yes
                    </button>
                    <button
                      onClick={() => setIsDialogOpen(false)}
                      className="border-2 border-primary py-2 px-7 rounded-full text-primary font-semibold "
                      style={{ marginLeft: "10px" }}
                    >
                      No
                    </button>
                  </DialogContent>
                </Dialog>

                <Grid item xs={12} sm={6} style={{ paddingTop: "0px" }}>
                  {[
                    {
                      label: "Task Name",
                      value: getWorkOrderDetails.workOrderName,
                    },
                    {
                      label: "Description",
                      value: getWorkOrderDetails.description,
                    },

                    {
                      label: "Time to Complete",
                      value: formatDate(getWorkOrderDetails.timeToComplete),
                    },
                    {
                      label: "Equipment",
                      value: getWorkOrderDetails.equipmentId,
                    },
                    { label: "Zone", value: getWorkOrderDetails.zoneName },
                  ].map(({ label, value }) => (
                    <Typography key={label} sx={{ mt: 2 }}>
                      <strong>{label}:</strong>
                      <br />
                      {value || "N/A"}
                    </Typography>
                  ))}
                </Grid>

                {/* Right Column */}
                <Grid item xs={12} sm={6} style={{ paddingTop: "0px" }}>
                  {[
                    {
                      label: "Workorder Id",
                      value: getWorkOrderDetails.workOrderId,
                    },
                    {
                      label: "Risk Level",
                      value: getWorkOrderDetails.risk_level,
                    },
                    { label: "Site", value: getWorkOrderDetails.siteName },
                    {
                      label: "Worktype",
                      value: getWorkOrderDetails.workOrder_type,
                    },
                    {
                      label: "Date and Time",
                      value: getWorkOrderDetails.createdAt,
                    },
                  ].map(({ label, value }) => (
                    <Typography key={label} sx={{ mt: 2, mb: 2 }}>
                      <strong>{label}:</strong>
                      <br />
                      {value || "N/A"}
                    </Typography>
                  ))}
                </Grid>
              </Grid>

              {/* Print Work Orders Button */}
              {rowData.your_role === "Initiator" && (
                // <button
                //   className="bg-primary py-2 px-6 rounded-full text-white font-semibold"
                //   onClick={handlePrint}
                // >
                //   Print Work Orders
                // </button>
                <HandlePrint workOrderDetails={workOrderDetails} />
              )}

              {/* <HandlePrint /> */}

              {/* Machines and Isolation Points */}
              <IsolationImages
                getWorkOrderDetails={getWorkOrderDetails}
                handleImageClick={handleImageClick}
              />

              <Grid
                className=" p-10 "
                sx={{ padding: "10px", backgroundColor: "#F9FAFB" }}
              >
                {/* <div>
                <h2>
                  <b>Initiator</b>
                </h2>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    marginBottom: "10px",
                  }}
                >
                  <h2 style={{ marginRight: "20px" }}>Initiator Name:</h2>
                  <h2
                    style={{
                      marginRight: "100px",

                      border: "2px solid #ccc", // Static border color
                      backgroundColor: "#f9f9f9", // Light gray background
                      padding: "5px 10px",
                      borderRadius: "10px",
                      display: "inline-block",
                    }}
                  >
                    {workOrderData?.getWorkOrderDetails?.initiator_name ||
                      "No Name Available"}
                  </h2>
                </div>
              </div> */}

                <div
                  style={{
                    // maxHeight: "500px",
                    // paddingRight: "10px",
                    border: "2px solid #ccc",
                    borderRadius: "10px",
                    padding: "10px",
                    backgroundColor: "#f9f9f9",
                  }}
                >
                  <div>
                    <h2>
                      <b>Initiator</b>
                    </h2>
                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        marginBottom: "10px",
                      }}
                    >
                      <h2 style={{ marginRight: "20px" }}>Initiator Name:</h2>
                      <h2
                        style={{
                          marginRight: "100px",
                          border: "2px solid #ccc", // Static border color
                          backgroundColor: "#e6f7ff", // Light gray background
                          padding: "5px 10px",
                          borderRadius: "10px",
                          display: "inline-block",
                        }}
                      >
                        {workOrderData?.getWorkOrderDetails?.initiator_name ||
                          "No Name Available"}
                      </h2>
                    </div>

                    {/* Equipment Name */}
                    {/* <div
  style={{
    marginBottom: "10px",
  }}
>
  <h2 style={{ marginBottom: "10px" }}>Equipment Name(s):</h2>
  <div
    style={{
      border: "2px solid #ccc",
      backgroundColor: "#f9f9f9",
      padding: "10px",
      borderRadius: "10px",
      display: "inline-block",
      maxWidth: "100%", // Ensures responsiveness
      overflowX: "auto", // Adds scroll if the names overflow
    }}
  >
    {workOrderData?.getWorkOrderDetails?.machines?.length > 0 ? (
      workOrderData.getWorkOrderDetails.machines.map((machine, index) => (
        <h2
          key={index}
          style={{
            marginBottom: "5px",
            padding: "5px 10px",
            backgroundColor: "#e6f7ff", // Optional background for each name
            borderRadius: "5px",
            display: "inline-block",
          }}
        >
          {machine.machineName || "Unnamed Equipment"}
        </h2>
      ))
    ) : (
      <h2>No Equipment Available</h2>
    )}
  </div>
</div> */}

                    {/* Isolation Point Name */}
                    <div>
                      <h2 style={{ marginBottom: "10px" }}>
                        Equipment and Isolation Points:
                      </h2>
                      <div
                        style={{
                          border: "2px solid #ccc",
                          backgroundColor: "#f9f9f9",
                          padding: "10px",
                          borderRadius: "10px",
                          maxWidth: "100%", // Ensures responsiveness
                          overflowX: "auto", // Adds horizontal scroll if needed
                        }}
                      >
                        {workOrderData?.getWorkOrderDetails?.machines?.length >
                        0 ? (
                          workOrderData.getWorkOrderDetails.machines.map(
                            (machine, machineIndex) => (
                              <div
                                key={machineIndex}
                                style={{
                                  display: "flex",
                                  alignItems: "center",
                                  justifyContent: "space-between",
                                  marginBottom: "10px",
                                }}
                              >
                                {/* Equipment Name */}
                                <h3
                                  style={{
                                    fontWeight: "bold",
                                    marginRight: "280px",
                                    flex: "1", // Allow space for alignment
                                  }}
                                >
                                  {machine.machineName || "Unnamed Equipment"}
                                </h3>

                                {/* Isolation Points */}
                                <div
                                  style={{
                                    display: "flex",
                                    flexWrap: "wrap", // Ensures responsive layout
                                    gap: "10px",
                                    flex: "2", // Wider space for isolation points
                                  }}
                                >
                                  {machine.isolationPoints?.length > 0 ? (
                                    // Filter unique isolation points based on isolationId
                                    Array.from(
                                      new Map(
                                        machine.isolationPoints.map(point => [
                                          point.isolationId,
                                          point
                                        ])
                                      ).values()
                                    ).map((point) => (
                                      <span
                                        key={point.isolationId}
                                        style={{
                                          padding: "5px 10px",
                                          backgroundColor: "#e6f7ff",
                                          borderRadius: "5px",
                                          border: "1px solid #ccc",
                                        }}
                                      >
                                        {point.isolationName ||
                                          "Unnamed Isolation Point"}
                                      </span>
                                    ))
                                  ) : (
                                    <span>No Isolation Points Available</span>
                                  )}
                                </div>
                              </div>
                            )
                          )
                        ) : (
                          <h2>No Machines Available</h2>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Custodian Section */}
                  <div>
                    <h2>
                      <b>Custodian</b>
                    </h2>
                    {workOrderData?.getWorkOrderDetails?.custodian_details?.map(
                      (custodianDetail, index) => (
                        <div
                          key={index}
                          style={{
                            display: "flex",
                            alignItems: "center",
                            marginBottom: "10px",
                            justifyContent: "space-between",
                          }}
                        >
                          <h2>
                            {custodianDetail?.custodian_name ||
                              "No Name Available"}
                          </h2>
                          <h2
                            style={{
                              marginRight: "100px",
                              border: `2px solid ${
                                getStatusStyle(
                                  custodianDetail?.custodian_status
                                ).borderColor
                              }`,
                              backgroundColor: getStatusStyle(
                                custodianDetail?.custodian_status
                              ).backgroundColor,
                              padding: "5px 10px",
                              borderRadius: "10px",
                              display: "inline-block",
                            }}
                          >
                            {custodianDetail?.custodian_status ||
                              "No Status Available"}
                          </h2>
                        </div>
                      )
                    )}
                  </div>

                  {/* Issuer Section */}
                  <div>
                    <h2>
                      <b>Issuer</b>
                    </h2>
                    {workOrderData?.getWorkOrderDetails?.issuer_details?.map(
                      (issuerDetails, index) => (
                        <div
                          key={index}
                          style={{
                            display: "flex",
                            alignItems: "center",
                            marginBottom: "10px",
                            justifyContent: "space-between",
                          }}
                        >
                          <h2>
                            {issuerDetails?.issuer_name || "No Name Available"}
                          </h2>
                          <h2
                            style={{
                              marginRight: "100px",
                              border: `2px solid ${
                                getStatusStyle(issuerDetails?.issuer_status)
                                  .borderColor
                              }`,
                              backgroundColor: getStatusStyle(
                                issuerDetails?.issuer_status
                              ).backgroundColor,
                              padding: "5px 10px",
                              borderRadius: "10px",
                              display: "inline-block",
                            }}
                          >
                            {issuerDetails?.issuer_status ||
                              "No Status Available"}
                          </h2>
                        </div>
                      )
                    )}
                  </div>

                  {/* Isolator Section */}
                  <div>
                    <h2>
                      <b>Isolator</b>
                    </h2>
                    {workOrderData?.getWorkOrderDetails?.machines?.map(machine => {
                      // Get unique isolation points for this machine
                      const uniqueIsolationPoints = Array.from(
                        new Map(
                          (machine?.isolationPoints || []).map(point => [
                            point.isolationId,
                            point
                          ])
                        ).values()
                      );
                      
                      return uniqueIsolationPoints.map(isolatorDetails => (
                        <div
                          key={isolatorDetails.isolationId}
                          style={{
                            display: "flex",
                            alignItems: "center",
                            marginBottom: "10px",
                            justifyContent: "space-between",
                          }}
                        >
                          <h2 style={{ marginRight: "20px" }}>
                            {isolatorDetails?.isolatorName ||
                              "No Name Available"}
                          </h2>
                          <h2
                            style={{
                              marginRight: "100px",
                              border: `2px solid ${
                                getStatusStyle(
                                  isolatorDetails?.isolatorStatus
                                ).borderColor
                              }`,
                              backgroundColor: getStatusStyle(
                                isolatorDetails?.isolatorStatus
                              ).backgroundColor,
                              padding: "5px 10px",
                              borderRadius: "10px",
                              display: "inline-block",
                            }}
                          >
                            {isolatorDetails?.isolatorStatus ||
                              "No Status Available"}
                          </h2>
                        </div>
                      ));
                    })}
                  </div>

                  <div>
                    <h2>
                      <b>Technician</b>
                    </h2>
                    {workOrderData?.getWorkOrderDetails?.technician_details?.map(
                      (technicianDetails, index) => (
                        <div
                          key={index}
                          style={{
                            display: "flex",
                            alignItems: "center",
                            marginBottom: "10px",
                            justifyContent: "space-between",
                          }}
                        >
                          <h2>
                            {technicianDetails?.technician_name ||
                              "No Name Available"}
                          </h2>
                          <h2
                            style={{
                              marginRight: "100px",
                              border: `2px solid ${
                                getStatusStyle(
                                  technicianDetails?.technician_status
                                ).borderColor
                              }`,
                              backgroundColor: getStatusStyle(
                                technicianDetails?.technician_status
                              ).backgroundColor,
                              padding: "5px 10px",
                              borderRadius: "10px",
                              display: "inline-block",
                            }}
                          >
                            {technicianDetails?.technician_status ||
                              "No Status Available"}
                          </h2>
                        </div>
                      )
                    )}
                  </div>
                </div>
              </Grid>
            </Card>
          </Grid>

          <WorkOrderLogs workOrdertrackingDetails={workOrdertrackingDetails} />
        </Grid>

        {/* Image Modal */}
        <Dialog open={Boolean(selectedImage)} onClose={handleClose}>
          <DialogContent>
            <img src={selectedImage} alt="Selected" style={{ width: "100%" }} />
          </DialogContent>
        </Dialog>

        <InitiatorDialog
          open={dialogOpen}
          onClose={handleCloseDialog}
          workOrderDetails={workOrderDetails}
          zoneId={workOrderDetails?.getWorkOrderDetails.zoneId}
          siteId={workOrderDetails?.getWorkOrderDetails.siteId}
          workOrderId={workOrderData?.getWorkOrderDetails?.workOrderId}
        />

        <Dialog
          open={requestIssuerOpen}
          onClose={handleRequestIssuerClose}
          // maxWidth="large"
          fullWidth
          width="large"
        >
          <DialogContent>
            <RequestforIssuer
              issuer_list={issuer_list}
              workOrderDetails={workOrderData}
              onClose={handleRequestIssuerClose}
              refetch={refetch}
            />
          </DialogContent>
        </Dialog>

        <Dialog
          open={requestIsolatorOpen} // Controls the visibility of the dialog
          onClose={handleRequestIsolatorClose} // Close dialog when triggered
          width="large"
          fullWidth
        >
          <DialogContent>
            <RequestForIsolators
              onClose={handleRequestIsolatorClose}
              workOrderDetails={workOrderDetails} // Pass work order details
              isolator_list={isolator_list} // Pass the isolator list
              refetch={refetch}
            />
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default WorkorderDetail;
