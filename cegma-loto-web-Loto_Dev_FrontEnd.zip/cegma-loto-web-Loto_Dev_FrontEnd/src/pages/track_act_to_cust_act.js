export const CustomActions = {
  "Awaiting for custodian custodian user Acceptance":
    "Awaiting for Custodian Acceptance",
  "Custodian custodian user accepted the work permit": "Request for Issuer",
  "Issuers has accepted the work permit": "Request for Isolators",
  "Isolation process started": "Isolation in progress",
  "Awaiting for Isolation Verification By Issuer":
    "Awaiting for Issuer to verify Isolation",
  "Isolation process successfully verified":
    "Awaiting Initiator to assign Technicians",
  "All Technicians completed the workOrder":
    "Awaiting for Initiator Acceptance",
  "Awaiting for De-Isolation verification by Issuer":
    "Awaiting for Issuer to verify De-Isolation",
  "De-Isolation process successfully verified":
    "Awaiting Initiator to complete workorder",
  "Custodian custodian user has updated the work permit.":
    "Waiting for Custodian Acceptance",
  "Work permit is completed": "Work order Completed",
};
