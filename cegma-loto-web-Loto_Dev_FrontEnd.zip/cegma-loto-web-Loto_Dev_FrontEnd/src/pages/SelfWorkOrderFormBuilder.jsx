import React from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import { workflowArch } from "../assets";

const SelfWorkOrderFormBuilder = () => {
  const navigate = useNavigate();

  // Get token from URL parameters
  const searchParams = new URLSearchParams(window.location.search);
  const tokenFromUrl = searchParams.get("token");
  const tokenFromStorage = localStorage.getItem("token");
  const token = tokenFromUrl || tokenFromStorage || "";

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar token={token} />

      {/* Header */}
      <div className="bg-gray-100 px-6 py-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate(-1)}
            className="text-black hover:text-gray-600 transition-colors"
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
              <path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z" />
            </svg>
          </button>
          <h1 className="text-xl font-semibold text-black">
            Self Work order formbuilder
          </h1>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex items-center justify-center min-h-[calc(100vh-200px)] bg-white">
        <div className="text-center">
          {/* Circular Icon */}
          <div className="flex justify-center mb-6">
            <div
              className="w-24 h-24 rounded-full flex items-center justify-center"
              style={{ 
                backgroundColor: "#E3E8F0",
                boxShadow: "0 2px 8px rgba(0, 0, 0, 0.1)"
              }}
            >
              <img
                src={workflowArch}
                alt="Workflow"
                width="48"
                height="48"
                style={{ 
                  filter: "brightness(0) saturate(100%) opacity(0.6)",
                }}
              />
            </div>
          </div>

          {/* Text Message */}
          <p className="text-lg font-medium text-gray-800">
            Please Contact Admin
          </p>
        </div>
      </div>
    </div>
  );
};

export default SelfWorkOrderFormBuilder;

