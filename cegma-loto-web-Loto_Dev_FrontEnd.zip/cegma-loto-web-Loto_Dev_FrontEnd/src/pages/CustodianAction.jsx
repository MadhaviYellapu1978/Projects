import React, { useState } from "react";
import { Grid } from "@mui/material";
import { toast } from "react-hot-toast";
import { apiCall } from "../utils";
import { workOrderEndPoints, methods } from "../constants";

const CustodianAction = ({ rowData, setRowData }) => {
  // Handler for accepting the custodian
  const HandleCustodianAccept = async () => {
    try {
      const workOrderId = rowData.workOrderId; // Replace with actual key for workOrderId
      const custodianId = rowData.custodian_id; // Replace with actual key for custodian_id

      const payload = {
        workOrderId: workOrderId,
        custodian_details: [
          {
            custodian_id: custodianId,
            custodian_status: "Accepted", // Accepted or Rejected
            custodian_rejected_reason: "", // Empty for acceptance
          },
        ],
      };

      // API call
      const res = await apiCall(
        `${workOrderEndPoints.updateCustodiansWO}`,
        methods.put,
        payload
      );

      if (res && res.status === 200) {
        // Update track_action or other state based on API response
        setRowData((prev) => ({
          ...prev,
          track_action: "Pending Custodian", // Adjust based on your app's logic
        }));

        // Show success message
        toast.success("Custodian accepted successfully!");
      } else {
        toast.error("Something went wrong!");
      }
    } catch (error) {
      console.error("Error accepting custodian:", error);
      toast.error("Failed to accept custodian.");
    }
  };

  return (
    <>
    
    </>
  );
};

export default CustodianAction;
