import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import { Modal, Box } from "@mui/material";
import { Close } from "@mui/icons-material";

const WorkOrderFormBuilder = () => {
  const navigate = useNavigate();
  const [openModal, setOpenModal] = useState(true);
  const [selectedType, setSelectedType] = useState(null);

  // Get token from URL parameters
  const searchParams = new URLSearchParams(window.location.search);
  const tokenFromUrl = searchParams.get("token");
  const tokenFromStorage = localStorage.getItem("token");
  const token = tokenFromUrl || tokenFromStorage || "";

  const handleClose = () => {
    setOpenModal(false);
    // Navigate back or to a default page
    navigate(-1);
  };

  const handleTypeSelect = (type) => {
    setSelectedType(type);
  };

  const handleSubmit = () => {
    if (selectedType) {
      setOpenModal(false);
      // Navigate to different pages based on the selected type
      if (selectedType === "Self") {
        navigate(`/loto/selfWorkOrderFormBuilder?token=${token}`);
      } else if (selectedType === "LOTO") {
        navigate(`/loto/lotoWorkOrderFormBuilder?token=${token}`);
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar token={token} />

      {/* Header */}
      <div className="bg-white px-6 py-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate(-1)}
            className="text-gray-600 hover:text-gray-800 transition-colors"
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
              <path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z" />
            </svg>
          </button>
          <h1 className="text-2xl font-bold text-gray-800">
            Create new LOTO Work order Form builder
          </h1>
        </div>
      </div>

      {/* Modal */}
      <Modal
        open={openModal}
        onClose={handleClose}
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Box
          sx={{
            position: "relative",
            width: "90%",
            maxWidth: "600px",
            bgcolor: "#F5F5F5",
            borderRadius: "8px",
            boxShadow: 24,
            p: 0,
            outline: "none",
            overflow: "hidden",
          }}
        >
          {/* Close Button */}
          <button
            onClick={handleClose}
            className="absolute top-4 right-4 z-10 text-gray-400 hover:text-gray-600 transition-colors"
            style={{ backgroundColor: "transparent" }}
          >
            <Close />
          </button>

          {/* Content Container */}
          <div className="p-6">
            {/* Title */}
            <h2 className="text-xl font-bold text-black mb-3 pr-8">
              Select Work Order Form Builder
            </h2>

            {/* Horizontal Line Separator */}
            <hr className="border-gray-300 mb-4" style={{ borderColor: "#D1D5DB" }} />

            {/* Instruction Text */}
            <p className="text-sm text-gray-500 mb-6">
              Select which type process you use for LOTO process
            </p>

            {/* Type Selection Buttons */}
            <div className="flex gap-4 mb-8">
              <button
                onClick={() => handleTypeSelect("LOTO")}
                className="flex-1 py-4 px-6 transition-all"
                style={{
                  borderRadius: "4px",
                  backgroundColor: "#E3E8F0",
                  border: selectedType === "LOTO" ? "2px solid #93C5FD" : "none",
                }}
              >
                <span className="text-lg font-semibold text-black">
                  LOTO
                </span>
              </button>
              <button
                onClick={() => handleTypeSelect("Self")}
                className="flex-1 py-4 px-6 transition-all"
                style={{
                  borderRadius: "4px",
                  backgroundColor: "#E3E8F0",
                  border: selectedType === "Self" ? "2px solid #93C5FD" : "none",
                }}
              >
                <span className="text-lg font-semibold text-black">
                  Self
                </span>
              </button>
            </div>

            {/* Action Buttons */}
            <div className="flex justify-end gap-3">
              <button
                onClick={handleClose}
                className="px-6 py-2 border-2 border-blue-500 bg-white text-blue-500 rounded-full font-semibold hover:bg-blue-50 transition-colors"
                style={{ borderColor: "#3B82F6" }}
              >
                Cancel
              </button>
              <button
                onClick={handleSubmit}
                disabled={!selectedType}
                className="px-6 py-2 rounded-full font-semibold text-white transition-colors"
                style={{
                  backgroundColor: selectedType ? "#1E40AF" : "#9CA3AF",
                  cursor: selectedType ? "pointer" : "not-allowed",
                }}
              >
                Submit
              </button>
            </div>
          </div>
        </Box>
      </Modal>
    </div>
  );
};

export default WorkOrderFormBuilder;

