/* eslint-disable */
import React, { useEffect, useState } from "react";
import Navbar from "../components/Navbar";
import { assetManagement, noneFound } from "../assets";
import AddAssets from "../components/AddAssets/AddAssets";
import { apiCall } from "../utils";
import { methods, userEndPoints } from "../constants";
import { setEquipment } from "../features/auth/equipmentSlice";
import { useDispatch, useSelector } from "react-redux";
import EquipmentCard from "../components/Equipment/EquipmentCard";
import {
  FormControl,
  Grid,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Tooltip,
} from "@mui/material";
import AttachQr from "../components/AttachQr/AttachQr";
import DownloadQr from "../components/DownloadQr/DownloadQr";

const Home = () => {
  const user = useSelector((state) => state.authSlice.user);
  const [zones, setZones] = useState([]);
  const [sites, setSites] = useState([]);
  const fetchData = () => {
    const body = {
      orgId: user.org.org_id,
      siteId: selectedSite,
      zoneId: selectedZone,
    };
    apiCall(userEndPoints.getAssetsByZoneAndSite, methods.post, body).then(
      (data) => {
        dispatch(setEquipment(data));
      }
    );
  };

  const [selectedZone, setSelectedZone] = useState(null);
  const [search, setSearch] = useState("");
  const [selectedSite, setSelectedSite] = useState(null);
  const equipment = useSelector((state) => state.equipmentSlice.equipment);
  const dispatch = useDispatch();

  useEffect(() => {
    if (Object.keys(user).length > 0) {
      apiCall(
        `${userEndPoints.getAllZonesByOrg}/${user.org?.org_id}/getAllZones`,
        methods.get
      ).then((data) => {
        setZones(data);
        setSelectedZone(data[0]?.zone_id);
        if (data.length > 0) {
          apiCall(
            `${userEndPoints.getAllSitesByZone}/${data[0]?.zone_id}/getAllSites`,
            methods.get,
            null
          ).then((data) => {
            setSites(data);
            setSelectedSite(data[0]?.site_id);
          });
        }
      });
    }
  }, [user]);

  useEffect(() => {
    if (selectedZone && selectedSite) {
      fetchData();
    }
  }, [selectedSite, selectedZone]);

  const searchParams = new URLSearchParams(window.location.search);
  const tokenValue = searchParams.get("token");

  return (
    <div>
      <Navbar token={tokenValue} />

      <div className="py-5 px-5 ">
        <div className="bg-white w-full min-h-56 h-full rounded-lg shadow-md py-5 px-12">
          <div className="border-b-2 flex flex-wrap justify-between py-2">
            <div className="flex gap-4 items-center h-12">
              <img
                src={assetManagement}
                alt="Asset Management"
                className="h-9"
              />
              <p className="text-primary font-semibold text-lg">
                Asset Management
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <AttachQr />
              <AddAssets fetchData={fetchData} />
              <DownloadQr />
            </div>
          </div>
          <div className="flex gap-3 md:gap-0 flex-col md:flex-row justify-between items-center mt-5  md:mt-5">
            <div className="flex flex-col gap-3 md:flex-row md:gap-4">
              {selectedZone && (
                <FormControl sx={{ width: 200 }}>
                  <InputLabel id="zone-select-label">Select Zones</InputLabel>
                  <Select
                    labelId="zone-select-label"
                    id="zone-select"
                    value={selectedZone}
                    label="Select Zones"
                    onChange={(e) => {
                      setSelectedZone(e.target.value);
                      apiCall(
                        `${userEndPoints.getAllSitesByZone}/${e.target.value}/getAllSites`,
                        methods.get,
                        null
                      ).then((data) => {
                        setSites(data);
                        setSelectedSite(data[0].site_id);
                      });
                    }}
                  >
                    {zones.map((zone, index) => {
                      return (
                        <MenuItem
                          value={zone.zone_id}
                          key={index}
                          className="w-full"
                        >
                          <Tooltip
                            title={zone.zone_name}
                            placement="bottom-end"
                          >
                            <span>{zone.zone_name}</span>
                          </Tooltip>
                        </MenuItem>
                      );
                    })}
                  </Select>
                </FormControl>
              )}
              {sites.length > 0 && (
                <FormControl sx={{ width: 200 }}>
                  <InputLabel id="site-select-label">Select Sites</InputLabel>
                  <Select
                    labelId="site-select-label"
                    id="site-select"
                    value={selectedSite}
                    label="Select Sites"
                    onChange={(e) => {
                      setSelectedSite(e.target.value);
                    }}
                  >
                    {sites.map((site, index) => {
                      return (
                        <MenuItem value={site.site_id} key={index}>
                          <Tooltip
                            title={site.site_name}
                            placement="bottom-end"
                          >
                            <span>{site.site_name}</span>
                          </Tooltip>
                        </MenuItem>
                      );
                    })}
                  </Select>
                </FormControl>
              )}
            </div>
            <TextField
              placeholder="Please Enter Asset Name"
              variant="outlined"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
              }}
              className="mt-3 md:mt-0"
            />
          </div>
          {equipment?.length === 0 ? (
            <div className="py-12 flex flex-col gap-5 justify-center items-center w-full">
              <img src={noneFound} alt="Not Found" />
              <p>No Asset data found</p>
              <AddAssets fetchData={fetchData} />
            </div>
          ) : (
            <Grid container spacing={5} className="mt-2">
              {Object.keys(equipment).length > 0 ? (
                equipment
                  .filter((each) =>
                    each.equipmentName
                      ?.toLowerCase()
                      .includes(search?.toLowerCase())
                  )
                  ?.map((each, key) => {
                    return (
                      <Grid item xs={12} mt={8} md={6} lg={4} key={key}>
                        <EquipmentCard
                          data={each}
                          fetchData={fetchData}
                          selectedZone={
                            zones.find((zone) => zone.zone_id === selectedZone)
                              ?.zone_name
                          }
                          selectedSite={
                            sites.find((site) => site.site_id === selectedSite)
                              ?.site_name
                          }
                        />
                      </Grid>
                    );
                  })
              ) : (
                <></>
              )}
            </Grid>
          )}
        </div>
      </div>
    </div>
  );
};

export default Home;
