/* eslint-disable */
import React, { useState } from "react";
import { Autocomplete, TextField, Button } from "@mui/material";
import { apiCall } from "../utils";
import { methods, workOrderEndPoints } from "../constants";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom"; // Import useNavigate
import toast from "react-hot-toast";

const RequestforIssuer = ({
  fetchData,
  onClose,
  issuer_list,
  workOrderDetails,
}) => {
  console.log({ workOrderDetails });
  const [selectedIssuer, setSelectedIssuer] = useState(null); // Single selection for issuer
  const [loading, setLoading] = useState(false);
  const searchParams = new URLSearchParams(window.location.search);
  const tokenValue = searchParams.get("token");

  const user = useSelector((state) => state.authSlice.user);
  const navigate = useNavigate(); // Initialize useNavigate

  // Handle Issuer selection change
  const handleIssuerChange = (event, value) => {
    setSelectedIssuer(value); // Update single selection
  };

  // Handle form submission
  const handleSubmit = async () => {
    setLoading(true);

    try {
      if (!selectedIssuer) {
        console.error("No issuer selected");
        setLoading(false);
        return;
      }
      console.log(selectedIssuer, "Issuer selected");

      // Construct the request payload
      const issuerDetails = [
        {
          issuer_id: selectedIssuer.emp_id || "", // Map emp_id to issuer_id
          issuer_name: `${selectedIssuer.first_name || ""} ${
            selectedIssuer.last_name || ""
          }`.trim(), // Combine first_name and last_name
          issuer_status: "Pending", // Set default status as "Accepted"
          issuer_rejected_reason: "", // Set default rejected reason as an empty string
          issuer_device_id: selectedIssuer.device_id,
          requestBy: "", // Set requestBy as an empty string
          isHold: false, // Set default isHold to false
          isRejected: false, // Set default isRejected to false
        },
      ];

      const payload = {
        workOrderId: workOrderDetails?.getWorkOrderDetails?.workOrderId || "",
        issuer_details: Array.isArray(issuerDetails)
          ? issuerDetails
          : [issuerDetails],
      };
      console.log("Request Payload:", payload);

      // API call to update issuer details
      const res = await apiCall(
        `${workOrderEndPoints.updateCustodiansWO}`,
        methods.put,
        payload
      );
      console.log("API Response:", res.data);

      // navigate(`/loto/dashboard?token=${tokenValue}`);
      onClose(); // Close dialog after submission
      toast.success("Issuer assigned successfully!");

      setTimeout(() => {
        window.location.href = `/loto/dashboard?token=${tokenValue}`;
        // fetchData();

        // onClose();
      }, 2000); // 3 seconds delay
      // window.location.href = `/loto/dashboard?token=${tokenValue}`;

      // fetchData(); // Refresh
    } catch (error) {
      console.error("Error updating custodians:", error);
    } finally {
      setLoading(false);
    }
  };

  // Custom filtering for Autocomplete (prefix matching)
  const filterIssuers = (options, state) => {
    const searchText = state.inputValue.trim().toLowerCase(); // Convert to lowercase and trim
    if (!searchText) return options;

    return options.filter((option) => {
      const fullName = `${option.first_name} ${option.last_name}`.toLowerCase();
      return fullName.startsWith(searchText); // Matches the start of the full name
    });
  };

  return (
    <div>
      <h2 className="mb-3">Select Issuer</h2>

      <Autocomplete
        value={selectedIssuer}
        onChange={handleIssuerChange}
        options={issuer_list || []}
        getOptionLabel={(option) => `${option.first_name} ${option.last_name}`}
        isOptionEqualToValue={(option, value) =>
          option.emp_id === value?.emp_id
        }
        renderInput={(params) => (
          <TextField {...params} label="Search Issuer" variant="outlined" />
        )}
        filterOptions={filterIssuers} // Custom filter for accurate search
        disableClearable // Disable clearing the selection
        noOptionsText="No issuers found" // Custom message when no options are available
      />
      <div
        style={{ display: "flex", justifyContent: "flex-end", width: "100%" }}
      >
        <button
          className="min-w-[100px] px-6 py-2 mt-5 rounded-full text-white bg-primary font-semibold shadow-md hover:bg-primary-dark transition-all duration-300 flex items-center justify-center gap-2 whitespace-nowrap"
          variant="contained"
          // sx={{ mt: 3 }}
          disabled={!selectedIssuer || loading}
          onClick={handleSubmit}
        >
          {loading ? "Submitting..." : "Submit"}
        </button>
      </div>
    </div>
  );
};

export default RequestforIssuer;
