/* eslint-disable */
import React, { useEffect, useState, useCallback, useMemo } from "react";
import Navbar from "../components/Navbar";
// import { plusIcon } from "../assets";
import { Link } from "react-router-dom";
import Cards from "../components/Dashboard/Cards";
import CardIcon from "../assets/CardIcon.svg";
import TimeIcon from "../assets/TimeIcon.svg";
import CompletedIcon from "../assets/CompletedIcon.svg";
import ScheduleIcon from "../assets/ScheduleIcon.svg";
import RejectedIcon from "../assets/RejectedIcon.svg";
import inprogressIcon from "../assets/inprogressIcon.svg";
import WorkOrderTable from "../components/Dashboard/WorkOrderTable";
import Search from "../components/Dashboard/Search";
import {
  dashboardEndPoints,
  methods,
  userEndPoints,
  workOrderEndPoints,
} from "../constants";
import { apiCall } from "../utils";
import { useDispatch, useSelector } from "react-redux";
import Lottie from "lottie-react";
import Loading from "../assets/Loading.json";
// import Map from "../components/Dashboard/Map";
// import Analytics from "../components/Dashboard/Analatycs";
import lockAnimation from "../assets/lockAnimation.json";
import debounce from "lodash/debounce";
import { useQuery } from "@tanstack/react-query";
// import FilterListIcon from "@mui/icons-material/FilterList";
import {
  Box,
  // FormControl,
  // InputLabel,
  // MenuItem,
  // Select,
  // TextField,
  // Tooltip,
} from "@mui/material";
// import TuneIcon from "@mui/icons-material/Tune";
// import WorkOrderCard from "../components/Dashboard/WorkOrderCard";
// import { CheckCircle, Cancel } from "@mui/icons-material";
// import OpenPopOver from "../components/Dashboard/OpenPopOver";
import CreateWorkOrder from "../components/Dashboard/CreateWorkOrder";
import { setEquipment } from "../features/auth/equipmentSlice";

const Dashboard = () => {
  const status = [
    "MyTasks",
    "Pending",
    "Accepted",
    "InProgress",
    "Completed",
    "Rejected",
  ];
  const searchParams = new URLSearchParams(window.location.search);
  const tokenValue = searchParams.get("token");
  const [filterStatus, setFilterStatus] = useState("All");
  const [selectedCardIndex, setSelectedCardIndex] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [page, setPage] = useState(1);
  const [isMapView, setIsMapView] = useState(false); // State to manage view toggle
  // const [totalPages, setTotalPages] = useState(0);

  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isSubDropdownOpen, setIsSubDropdownOpen] = useState(false);
  const [notifications, setNotifications] = useState([]); // Define state for notifications

  // const toggleDropdown = () => setIsDropdownOpen(!isDropdownOpen);
  // const toggleSubDropdown = () => setIsSubDropdownOpen(!isSubDropdownOpen);

  const breadcrumbs = [
    { label: "Home", path: "/" },
    { label: "Dashboard", path: "/dashboard" },
  ];
  const user = useSelector((state) => state.authSlice.user);
  // eslint-disable-next-line
  const [zones, setZones] = useState([]);
  // eslint-disable-next-line
  const [sites, setSites] = useState([]);
  const fetchData = () => {
    const body = {
      orgId: user.org.org_id,
      siteId: selectedSite,
      zoneId: selectedZone,
    };
    apiCall(userEndPoints.getAssetsByZoneAndSite, methods.post, body).then(
      (data) => {
        dispatch(setEquipment(data));
      }
    );
  };

  const [selectedZone, setSelectedZone] = useState(null);
  const [search, setSearch] = useState("");
  const [selectedSite, setSelectedSite] = useState(null);
  // eslint-disable-next-line
  const equipment = useSelector((state) => state.equipmentSlice.equipment);
  const dispatch = useDispatch();

  useEffect(() => {
    if (Object.keys(user).length > 0) {
      apiCall(
        `${userEndPoints.getAllZonesByOrg}/${user.org?.org_id}/getAllZones`,
        methods.get
      ).then((data) => {
        setZones(data);
        setSelectedZone(data[0]?.zone_id);
        if (data.length > 0) {
          apiCall(
            `${userEndPoints.getAllSitesByZone}/${data[0]?.zone_id}/getAllSites`,
            methods.get,
            null
          ).then((data) => {
            setSites(data);
            setSelectedSite(data[0]?.site_id);
          });
        }
      });
    }
  }, [user]);

  useEffect(() => {
    if (selectedZone && selectedSite) {
      fetchData();
    }
  }, [selectedSite, selectedZone]);

  const fetchWorkOrders = useCallback(
    async ({ queryKey }) => {
      // eslint-disable-next-line
      const [_, filterStatus, page] = queryKey;
      const response = await apiCall(
        `${dashboardEndPoints.getAllWorkOrders}?orgId=${user.org.org_id}`,
        methods.post,
        {
          emp_id: user.emp_id,
          faceAuth: false,
          page: page,
          limit: 10,
          filterStatus: filterStatus,
        }
      );
      return response;
    },
    [user]
  );

  const fetchDataNotify = async () => {
    // Fetch Notifications
    try {
      const notificationPayload = {
        user_id: user?.emp_id || "", // Replace with the correct user ID if available
        orgId: user?.org?.org_id || "",
        siteId: selectedSite || "",
        zoneId: selectedZone || "",
      };

      const notificationResponse = await apiCall(
        `${workOrderEndPoints.getNotificationsByOrgId}`,
        methods.post,
        notificationPayload,
        tokenValue
      );
      console.log(
        "Fetched Notificationsssssssssssssssss:",
        notificationResponse
      );
      setNotifications(notificationResponse);
      console.log(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      setNotifications({ notifications: [] });
    }
  };

  useEffect(() => {
    fetchDataNotify();
  }, [user, selectedZone, selectedSite]);
  // eslint-disable-next-line
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ["workOrders", filterStatus, page],
    queryFn: fetchWorkOrders,
    keepPreviousData: true,
  });

  // if (isError) return <p>Error: {error.message}</p>;

  const cards = [
    {
      title: "My-Task",
      description: data?.mytasks || 0,
      image: CardIcon,
    },
    {
      title: "Pending",
      description: data?.pending || 0,
      image: TimeIcon,
    },
    {
      title: "Scheduled",
      description: data?.scheduled || 0,
      image: ScheduleIcon,
    },
    {
      title: "In-progress",
      description: data?.inprogress || 0,
      image: inprogressIcon,
    },
    {
      title: "Completed",
      description: data?.completed || 0,
      image: CompletedIcon,
    },
    {
      title: "Rejected",
      description: data?.rejected || 0,
      image: RejectedIcon,
    },
  ];

  // Debounced search handler
  const handleSearch = useCallback(
    debounce((query) => {
      setSearchQuery(query);
    }, 300),
    []
  );

  // Filter data based on search query
  const filteredData = useMemo(() => {
    if (!data || !data.WorkOrder_Details) return [];
    return data.WorkOrder_Details.filter((item) => {
      const searchLower = searchQuery.toLowerCase();
      return (
        (item.workOrderName &&
          item.workOrderName.toLowerCase().includes(searchLower)) ||
        (item.equipmentId &&
          item.equipmentId.toLowerCase().includes(searchLower)) ||
        (item.workOrder_status &&
          item.workOrder_status.toLowerCase().includes(searchLower)) ||
        (item.createdAt &&
          item.createdAt.toLowerCase().includes(searchLower)) ||
        (item.workOrderId &&
          item.workOrderId.toLowerCase().includes(searchLower)) ||
        (item.your_role && item.your_role.toLowerCase().includes(searchLower))
      );
    });
  }, [searchQuery, data]);

  // Handle map view toggle
  const toggleMapView = (checked) => {
    setIsMapView(checked);
  };
  const workOrders = [
    {
      workPermitId: "WP001",
      equipment: "Machine A",
      status: "Pending",
      role: "Initiator",
    },
    {
      workPermitId: "WP002",
      equipment: "Machine B",
      status: "Approved",
      role: "Custodian",
    },
    {
      workPermitId: "WP003",
      equipment: "Machine C",
      status: "Rejected",
      role: "Approver",
    },
    // Add more work orders as needed
  ];

  const [filters, setFilters] = useState({
    initiator: false,
    custodian: false,
    approver: false,
  });

  // Function to handle filter change
  const handleFilterChange = (filterName) => {
    setFilters((prevFilters) => ({
      ...prevFilters,
      [filterName]: !prevFilters[filterName],
    }));
  };

  // Filter work orders based on selected roles
  const filteredDataMap = workOrders.filter((workOrder) => {
    if (filters.initiator && workOrder.role === "Initiator") return true;
    if (filters.custodian && workOrder.role === "Custodian") return true;
    if (filters.approver && workOrder.role === "Approver") return true;
    return !filters.initiator && !filters.custodian && !filters.approver;
  });

  return (
    <>
      <Navbar token={tokenValue} />
      <div className="flex flex-col md:flex-row justify-between items-center py-5 px-4 md:px-8 lg:px-12">
        <div className="mb-4 md:mb-0">
          <h3 className="font-bold text-lg md:text-xl">Dashboard</h3>
          <nav aria-label="Breadcrumb" className="mt-2">
            <ol className="flex flex-wrap space-x-2 list-none text-gray-500">
              {breadcrumbs.map((crumb, index) => (
                <li key={index} className="flex items-center">
                  {index !== breadcrumbs.length - 1 ? (
                    <Link
                      to={crumb.path}
                      className="hover:text-gray-700 text-sm md:text-base"
                    >
                      {crumb.label}
                    </Link>
                  ) : (
                    <span className="font-bold text-gray-900 text-sm md:text-base">
                      {crumb.label}
                    </span>
                  )}
                  {index < breadcrumbs.length - 1 && (
                    <span className="mx-2 text-gray-300 text-lg">›</span>
                  )}
                </li>
              ))}
            </ol>
          </nav>
        </div>
        <CreateWorkOrder refetch={refetch} />
      </div>

      <div className="px-12">
        <Cards
          cards={cards}
          setFilterStatus={setFilterStatus}
          status={status}
          selectedCardIndex={selectedCardIndex}
          setSelectedCardIndex={setSelectedCardIndex}
        />
        <div>
          <Search onSearch={handleSearch} toggleMapView={toggleMapView} />

          <div className="flex gap-3 md:gap-0 flex-col md:flex-row justify-between items-center mt-5  md:mt-5">
            {/* <div className="flex flex-col gap-3 md:flex-row md:gap-4">
              {selectedZone && (
                <FormControl sx={{ width: 200 }}>
                  <InputLabel id="zone-select-label">Select Zones</InputLabel>
                  <Select
                    labelId="zone-select-label"
                    id="zone-select"
                    value={selectedZone}
                    label="Select Zones"
                    onChange={(e) => {
                      setSelectedZone(e.target.value);
                      apiCall(
                        `${userEndPoints.getAllSitesByZone}/${e.target.value}/getAllSites`,
                        methods.get,
                        null
                      ).then((data) => {
                        setSites(data);
                        setSelectedSite(data[0].site_id);
                      });
                    }}
                  >
                    {zones.map((zone, index) => {
                      return (
                        <MenuItem
                          value={zone.zone_id}
                          key={index}
                          className="w-full"
                        >
                          <Tooltip
                            title={zone.zone_name}
                            placement="bottom-end"
                          >
                            <span>{zone.zone_name}</span>
                          </Tooltip>
                        </MenuItem>
                      );
                    })}
                  </Select>
                </FormControl>
              )}
              {sites.length > 0 && (
                <FormControl sx={{ width: 200 }}>
                  <InputLabel id="site-select-label">Select Sites</InputLabel>
                  <Select
                    labelId="site-select-label"
                    id="site-select"
                    value={selectedSite}
                    label="Select Sites"
                    onChange={(e) => {
                      setSelectedSite(e.target.value);
                    }}
                  >
                    {sites.map((site, index) => {
                      return (
                        <MenuItem value={site.site_id} key={index}>
                          <Tooltip
                            title={site.site_name}
                            placement="bottom-end"
                          >
                            <span>{site.site_name}</span>
                          </Tooltip>
                        </MenuItem>
                      );
                    })}
                  </Select>
                </FormControl>
              )}
            </div> */}
          </div>

          <div className="mt-3 relative" style={{ minHeight: "60vh" }}>
            {isLoading ? (
              <div className="flex justify-center items-center w-full h-full absolute top-0 left-0">
                <div className="relative w-60 h-60">
                  <Lottie
                    animationData={Loading}
                    loop={true}
                    className="absolute w-full h-full top-0 left-0 pointer-events-none"
                  />
                  <div className="w-20 h-20 flex items-center justify-center content-center ml-20 mt-20">
                    <Lottie
                      animationData={lockAnimation}
                      loop={true}
                      className="w-full h-full"
                    />
                  </div>
                </div>
              </div>
            ) : (
              <>
                {isMapView ? (
                  // <Map />
                  <Box
                    sx={{
                      display: "flex",
                      flexDirection: { xs: "column", md: "row" },
                      width: "100%",
                      height: "100%",
                      // gap: 1,
                    }}
                  >
                    {/* <Box
                      sx={{
                        width: "35%",
                        md: { width: "33.33%" },
                        height: "100%",
                        overflowY: "auto",
                        backgroundColor: "grey.100",
                        borderRadius: 1,
                        padding: 2,
                        boxShadow: 1,
                        maxHeight: "76vh",
                        overflowX: "hidden",

                        // zIndex: 200,
                        scrollbarWidth: "thin", // For Firefox

                        scrollbarColor: "rgba(100, 100, 100, 0.4) transparent", // For Firefox
                        "&::-webkit-scrollbar": {
                          width: "4px", // For WebKit browsers
                        },
                        "&::-webkit-scrollbar-thumb": {
                          backgroundColor: "rgba(100, 100, 100, 0.4)",
                          borderRadius: "4px",
                        },
                        "&::-webkit-scrollbar-thumb:hover": {
                          backgroundColor: "rgba(100, 100, 100, 0.6)",
                        },
                        "&::-webkit-scrollbar-track": {
                          background: "transparent",
                        },
                      }}
                    >
                      <div className="flex items-center mb-4 justify-between">
                        <h3 className="text-lg font-semibold">Work Orders</h3>
                        <OpenPopOver />
                        
                        
                      </div>

                      {filteredData.length === 0 ? (
                        <p className="text-gray-500">
                          No work orders found for the selected filters.
                        </p>
                      ) : (
                        filteredData.map((workOrder, index) => (
                          <WorkOrderCard key={index} workOrder={workOrder} />
                        ))
                      )}
                    </Box> */}

                    {/* Right column for the map */}
                    <Box
                      sx={{
                        width: "100%",
                        height: "100%",
                        mt: { md: 0, xs: 6 },
                      }}
                      className="relative z-10"
                    >
                      {/* <Map /> */}
                    </Box>
                  </Box>
                ) : (
                  <>
                    <WorkOrderTable
                      apiData={filteredData}
                      setPage={setPage}
                      totalPages={data?.totalPages || 0}
                      page={page}
                      notifications={notifications} // Pass notifications as a prop
                    />
                    {/* <Analytics /> */}
                  </>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default Dashboard;
