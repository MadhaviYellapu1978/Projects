import React, { useState } from 'react'
import {
  Card,
  Grid,
  Typography,
  Button,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Dialog,
  DialogContent,
} from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";


const IsolationImage = (machine) => {
  const handleImageClick = (imageUrl) => setSelectedImage(imageUrl);
    const [selectedImage, setSelectedImage] = useState(null);
  

  return (
    <>
    <AccordionDetails>
  {machine.isolationPoints.map((point) => (
    <Accordion key={point.isolationId} sx={{ mt: 1 }}>
      <AccordionSummary expandIcon={<ExpandMoreIcon />}>
        <div className="flex items-center" style={{ gap: "50vh" }}>
          <h1>
            <b>Isolation Point</b>
          </h1>
          <Typography>{point.isolationName}</Typography>
        </div>
      </AccordionSummary>
      <AccordionDetails>
        <Grid container spacing={2}>
          {/* Pre-Isolation Images */}
          <Grid item xs={12} sm={6}>
            <Typography>
              <strong>Pre-Isolation Images</strong>
            </Typography>
            {point.preIsoImgPaths && point.preIsoImgPaths.length > 0 ? (
              point.preIsoImgPaths.map((imgPath, index) => (
                <img
                  key={index}
                  src={imgPath}
                  alt={`Pre-Isolation ${index + 1}`}
                  style={{
                    width: "100%",
                    cursor: "pointer",
                    marginTop: 10,
                  }}
                  onClick={() => handleImageClick(imgPath)}
                />
              ))
            ) : (
              <Typography>No pre-isolation images found</Typography>
            )}
          </Grid>

          {/* Post-Isolation Images */}
          <Grid item xs={12} sm={6}>
            <Typography>
              <strong>Post-Isolation Images</strong>
            </Typography>
            {point.postIsoImgPaths && point.postIsoImgPaths.length > 0 ? (
              point.postIsoImgPaths.map((imgPath, index) => (
                <img
                  key={index}
                  src={imgPath}
                  alt={`Post-Isolation ${index + 1}`}
                  style={{
                    width: "100%",
                    cursor: "pointer",
                    marginTop: 10,
                  }}
                  onClick={() => handleImageClick(imgPath)}
                />
              ))
            ) : (
              <Typography>No post-isolation images found</Typography>
            )}
          </Grid>

          {/* Pre-De-isolation Images */}
          <Grid item xs={12} sm={6}>
            <Typography>
              <strong>Pre-De-isolation Images</strong>
            </Typography>
            {point.preDeIsoImgPaths && point.preDeIsoImgPaths.length > 0 ? (
              point.preDeIsoImgPaths.map((imgPath, index) => (
                <img
                  key={index}
                  src={imgPath}
                  alt={`Pre-De-isolation ${index + 1}`}
                  style={{
                    width: "100%",
                    cursor: "pointer",
                    marginTop: 10,
                  }}
                  onClick={() => handleImageClick(imgPath)}
                />
              ))
            ) : (
              <Typography>No pre-de-isolation images found</Typography>
            )}
          </Grid>

          {/* Post-De-isolation Images */}
          <Grid item xs={12} sm={6}>
            <Typography>
              <strong>Post-De-isolation Images</strong>
            </Typography>
            {point.postDeIsoImgPaths && point.postDeIsoImgPaths.length > 0 ? (
              point.postDeIsoImgPaths.map((imgPath, index) => (
                <img
                  key={index}
                  src={imgPath}
                  alt={`Post-De-isolation ${index + 1}`}
                  style={{
                    width: "100%",
                    cursor: "pointer",
                    marginTop: 10,
                  }}
                  onClick={() => handleImageClick(imgPath)}
                />
              ))
            ) : (
              <Typography>No post-de-isolation images found</Typography>
            )}
          </Grid>

          {/* Isolation Image */}
          <Grid item xs={12} sm={6}>
            <Typography>
              <strong>Isolation Image</strong>
            </Typography>
            {point.isolationImgPath ? (
              <img
                src={point.isolationImgPath}
                alt="Isolation"
                style={{
                  width: "100%",
                  cursor: "pointer",
                  marginTop: 10,
                }}
                onClick={() => handleImageClick(point.isolationImgPath)}
              />
            ) : (
              <Typography>No isolation image found</Typography>
            )}
          </Grid>

          {/* De-isolation Image */}
          <Grid item xs={12} sm={6}>
            <Typography>
              <strong>De-isolation Image</strong>
            </Typography>
            {point.deisolationImgPath ? (
              <img
                src={point.deisolationImgPath}
                alt="De-isolation"
                style={{
                  width: "100%",
                  cursor: "pointer",
                  marginTop: 10,
                }}
                onClick={() => handleImageClick(point.deisolationImgPath)}
              />
            ) : (
              <Typography>No de-isolation image found</Typography>
            )}
          </Grid>
        </Grid>
      </AccordionDetails>
    </Accordion>
  ))}
</AccordionDetails>

    
    </>
  )
}

export default IsolationImage