/* eslint-disable */
import React, { useEffect, useState } from "react";
import Navbar from "../components/Navbar";
import { moreIcon, padlockIcon, padlockImg } from "../assets";
import { apiCall } from "../utils";
import { equipmentEndPoints, methods } from "../constants";
import { useSelector } from "react-redux";
import PadlockCard from "../components/Padlock/PadlockCard";
import Loading from "../assets/Loading.json";
import Lottie from "lottie-react";
import AddPadlock from "../components/Padlock/AddPadlock";

const PadlockManagement = () => {
  const [loading, setLoading] = useState(false);
  const [padlock, setPadlock] = React.useState([]);
  const user = useSelector((state) => state.authSlice.user);

  // const fetchData = () => {
  //   setLoading(true);
  //   // apiCall(equipmentEndPoints.getAllPadlocks, methods.post, { // For Dev
  //   apiCall(
  //     equipmentEndPoints.getAllPadlocks,
  //     methods.get,
  //     { orgId: user.org.org_id }
  //   ).then((data) => {
  //     setPadlock(data.allPadlockDetails);
  //     setLoading(false);
  //   });
  // };

  // useEffect(() => {
  //   if (Object.keys(user).length > 0) fetchData();
  // }, [user]);

  const searchParams = new URLSearchParams(window.location.search);
  const tokenValue = searchParams.get("token");

  if (loading)
    return (
      <div className="flex justify-center items-center w-screen h-screen">
        <div className="max-w-40">
          <Lottie animationData={Loading} loop={true} />
        </div>
      </div>
    );

  return (
    <div>
      <Navbar token={tokenValue} />
      <div className="py-5 px-12">
        <div className="bg-white w-full min-h-56 h-full rounded-lg shadow-md py-5 px-12">
          <div className="border-b-2 flex justify-between py-2">
            <div className="flex gap-4 items-center h-12">
              <img
                src={padlockIcon}
                alt="Asset Management"
                className="h-9 w-6"
              />
              <p className="text-primary font-semibold text-lg">
                Smart Padlock(LOTO)
              </p>
            </div>
            <div>
              <AddPadlock /> {/* Button moved to the right */}
            </div>
          </div>
          {/* <div>
            <h3 className="text-xl my-5 text-primary">Attached Devices</h3>
          </div> */}
          <div className="grid lg:grid-cols-3 grid-cols-1">
            {padlock.map((lock) => {
              if (lock.isAssigned) return <PadlockCard key={lock.id} lock={lock} />;
              return null; // Add a return to avoid warning
            })}
          </div>
          {/* <div>
            <h3 className="text-xl my-5 text-primary">Detached Devices</h3>
          </div> */}
          <div className="grid lg:grid-cols-3 grid-cols-1">
            {padlock.map((lock) => {
              if (!lock.isAssigned) return <PadlockCard key={lock.id} lock={lock} />;
              return null; // Add a return to avoid warning
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PadlockManagement;
