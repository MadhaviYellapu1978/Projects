/* eslint-disable */
import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  Button,
  TextField,
  Checkbox,
  ListItemText,
  FormControl,
  Autocomplete
} from '@mui/material';
import { useSelector } from 'react-redux';
import toast from 'react-hot-toast';
import { apiCall } from '../utils';
import { methods, workOrderEndPoints } from '../constants';

const InitiatorDialog = ({ open, onClose, zoneId, siteId, workOrderId, isHold, workOrderDetails }) => {
  const [dropdownData, setDropdownData] = useState([]);
  const [selectedValues, setSelectedValues] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const user = useSelector((state) => state.authSlice.user);
  const searchParams = new URLSearchParams(window.location.search);
  const tokenValue = searchParams.get("token");

  const fetchDropdownData = async () => {
    const payload = {
      org_id: user?.org.org_id,
      zone_id: zoneId,
      site_id: siteId,
      workOrderId,
    };

    try {
      const res = await apiCall(
        `${workOrderEndPoints.getCustodians}`,
        methods.post,
        payload
      );
      if (res && Array.isArray(res.technicians)) {
        const mappedData = res.technicians.map((item) => ({
          id: item.emp_id,
          name: `${item.first_name || "Unknown"} ${item.last_name || "Unknown"}`,
        }));
        setDropdownData(mappedData);
      } else {
        setDropdownData([]);
      }
    } catch (error) {
      setDropdownData([]);
    }
  };

  useEffect(() => {
    if (open) {
      fetchDropdownData();
    }
  }, [open]);

  const handleDialogClose = () => {
    setSelectedValues([]);
    setSearchQuery("");
    setDropdownData([]);
    onClose();
  };

  const handleSubmit = async () => {
    const technicianDetails = selectedValues.map((selected) => ({
      technician_id: selected.id,
      technician_name: selected.name,
      technician_status: "Pending",
      technician_rejected_reason: "",
      technician_device_id: "",
      isHold: false,
      isRejected: false,
      technicianHoldedReason: "",
    }));

    const payload = {
      workOrderId,
      technician_details: technicianDetails,
    };

    try {
      const res = await apiCall(
        `${workOrderEndPoints.updateCustodiansWO}`,
        methods.put,
        payload
      );

      if (res) {
        toast.success("Technician(s) updated successfully!");
        setTimeout(() => {
          window.location.href = `/loto/dashboard?token=${tokenValue}`;
        }, 2000);
      }
    } catch (error) {
      console.error("Error during API call:", error);
    }

    handleDialogClose();
  };

  return (
    <Dialog open={open} onClose={handleDialogClose} fullWidth>
      <DialogTitle>Request for Technician</DialogTitle>
      <DialogContent>
        <FormControl fullWidth sx={{ mt: 2 }}>
          <Autocomplete
            multiple
            options={dropdownData}
            value={selectedValues}
            onChange={(event, newValue) => {
              setSelectedValues(newValue);
            }}
            getOptionLabel={(option) => option.name}
            filterSelectedOptions
            renderInput={(params) => (
              <TextField
                {...params}
                variant="outlined"
                label="Select Technician"
              />
            )}
            renderOption={(props, option, { selected }) => (
              <li {...props}>
                <Checkbox
                  icon={<span />}
                  checkedIcon={<span />}
                  style={{ marginRight: 8 }}
                  checked={selected}
                />
                {option.name}
              </li>
            )}
          />
        </FormControl>

        <div className="mt-4 flex justify-end">
          <button
            variant="outlined"
            onClick={handleDialogClose}
            className="border-2 border-primary py-2 px-5 rounded-full text-primary font-semibold "
          >
            Cancel
          </button>
          <button
            variant="contained"
            color="primary"
            onClick={handleSubmit}
            className="bg-primary py-2 px-5 rounded-full text-sm font-semibold text-white hover:bg-primary-dark ml-2"
            disabled={selectedValues.length === 0}
          >
            Submit
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default InitiatorDialog;
