import {
  Card,
  Grid,
  Step,
  StepLabel,
  Stepper,
  Typography,
  Box,
} from "@mui/material";
import React from "react";
import { jsPDF } from "jspdf";

const WorkOrderLogs = ({ workOrdertrackingDetails }) => {

  // Handle the PDF download
  const handleDownloadPDF = () => {
    const pdf = new jsPDF();
    let yOffset = 10; // Start position for text

    // Add a title for the PDF
    pdf.setFont("helvetica", "bold");
    pdf.setFontSize(16);
    pdf.text("Work Order Logs", 14, yOffset);
    yOffset += 10;

    // Set the font for the logs
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(12);

    // Iterate through the workOrdertrackingDetails to add each log
    workOrdertrackingDetails.forEach((log, index) => {
      // Add log status and timestamp
      pdf.text(`${log.status_name} - ${log.timeStamp}`, 14, yOffset);
      yOffset += 10;

      // Add a line break for clarity
      if (yOffset > 270) {
        pdf.addPage(); // Add a new page if content exceeds page length
        yOffset = 10; // Reset yOffset for the new page
      }
    });

    // Save the generated PDF
    pdf.save("work_order_logs.pdf");
  };

  return (
    <Grid item xs={12} md={6}>
      <Card sx={{ maxHeight: "84vh", overflowY: "scroll", p: 5 }}>
        {/* Heading and Button Row */}
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            mb: 2,
          }}
        >
          <Typography variant="h6">Work Order Logs</Typography>
          <button
            className="bg-primary flex gap-3 py-2 px-5 rounded-full text-white font-semibold"
            onClick={handleDownloadPDF}
          >
            Download PDF
          </button>
        </Box>

        {/* Logs Display */}
        <Stepper orientation="vertical">
          {workOrdertrackingDetails.map((log, index) => (
            <Step key={index} completed={log.isCompleted}>
              <StepLabel>
                <Typography variant="body2">{log.status_name}</Typography>
                <Typography variant="caption">{log.timeStamp}</Typography>
              </StepLabel>
            </Step>
          ))}
        </Stepper>
      </Card>
    </Grid>
  );
};

export default WorkOrderLogs;
