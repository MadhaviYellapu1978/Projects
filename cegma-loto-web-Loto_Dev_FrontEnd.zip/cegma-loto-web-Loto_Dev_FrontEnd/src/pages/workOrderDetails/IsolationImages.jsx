import React from "react";
import { Grid, Typography } from "@mui/material";

const IsolationImages = ({ getWorkOrderDetails, handleImageClick }) => {
  // Get unique machines by machineId
  const uniqueMachines = Array.from(
    new Map(getWorkOrderDetails.machines.map(machine => [machine.machineId, machine])).values()
  );

  return (
    <>
      {uniqueMachines.map((machine) => {
        // Get unique isolation points for this machine
        const uniqueIsolationPoints = Array.from(
          new Map(
            (machine.isolationPoints || []).map(point => [point.isolationId, point])
          ).values()
        );

        return (
          <div key={machine.machineId} style={{ marginBottom: "20px" }}>
            <Typography
              variant="h6"
              sx={{ fontWeight: "bold", marginBottom: "10px" }}
            >
              Machine: {machine.machineName}
            </Typography>

            {uniqueIsolationPoints.length > 0 ? (
              uniqueIsolationPoints.map((point) => (
                <div
                  key={point.isolationId}
                  style={{ marginLeft: "20px", marginBottom: "15px" }}
                >
                  <Typography variant="subtitle1" sx={{ fontWeight: "bold" }}>
                    Isolation Point: {point.isolationName}
                  </Typography>

                  <Grid container spacing={2} alignItems="stretch">
                    <Grid item xs={12} sm={6}>
                      <Grid
                        container
                        spacing={2}
                        alignItems="stretch"
                        direction={"column"}
                      >
                        {/* Pre-Isolation Image */}
                        {point.preIsoImgPaths?.length > 0 ? (
                          // Get unique pre-isolation images
                          [...new Set(point.preIsoImgPaths)].map((imgPath, index) => (
                            <Grid item xs={12} sm={6} key={imgPath + "-" + index}>
                              <Typography>
                                <strong>MCB/Fuse (Off)</strong>
                              </Typography>
                              <img
                                src={imgPath}
                                alt={`Pre-Isolation ${index + 1}`}
                                style={{
                                  width: "100%",
                                  cursor: "pointer",
                                  marginTop: 10,
                                }}
                                onClick={() => handleImageClick(imgPath)}
                              />
                            </Grid>
                          ))
                        ) : (
                          <Typography>No pre-isolation images found</Typography>
                        )}

                        {/* Isolation Image */}
                        <Grid item xs={12} sm={6}>
                          <Typography>
                            <strong>Isolation Image</strong>
                          </Typography>
                          {point.isolationImgPath ? (
                            <img
                              src={point.isolationImgPath}
                              alt="Isolation"
                              style={{
                                width: "100%",
                                cursor: "pointer",
                                marginTop: 10,
                              }}
                              onClick={() =>
                                handleImageClick(point.isolationImgPath)
                              }
                            />
                          ) : (
                            <Typography>No isolation image found</Typography>
                          )}
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <Grid
                        container
                        spacing={2}
                        alignItems="stretch"
                        direction={"column"}
                      >
                        {/* De-Isolation Image */}
                        <Grid item xs={12} sm={6}>
                          <Typography>
                            <strong>De-Isolation Image</strong>
                          </Typography>
                          {point.deisolationImgPath ? (
                            <img
                              src={point.deisolationImgPath}
                              alt="De-isolation"
                              style={{
                                width: "100%",
                                cursor: "pointer",
                                marginTop: 10,
                              }}
                              onClick={() =>
                                handleImageClick(point.deisolationImgPath)
                              }
                            />
                          ) : (
                            <Typography>No de-isolation image found</Typography>
                          )}
                        </Grid>

                        {/* Post-De-Isolation Images */}
                        {point.postDeIsoImgPaths?.length > 0 ? (
                          // Get unique post-de-isolation images
                          [...new Set(point.postDeIsoImgPaths)].map((imgPath, index) => (
                            <Grid item xs={12} sm={6} key={imgPath + "-" + index}>
                              <Typography>
                                <strong>MCB/Fuse (On)</strong>
                              </Typography>
                              <img
                                src={imgPath}
                                alt={`Post-De-isolation ${index + 1}`}
                                style={{
                                  width: "100%",
                                  cursor: "pointer",
                                  marginTop: 10,
                                }}
                                onClick={() => handleImageClick(imgPath)}
                              />
                            </Grid>
                          ))
                        ) : (
                          <Typography>
                            No post-de-isolation images found
                          </Typography>
                        )}
                      </Grid>
                    </Grid>
                  </Grid>
                </div>
              ))
            ) : (
              <Typography sx={{ marginLeft: "20px" }}>
                No Isolation Points Available
              </Typography>
            )}
          </div>
        );
      })}
    </>
  );
};

export default IsolationImages;
