/* eslint-disable */
import React, { useEffect, useState, useCallback, useMemo } from "react";
import Navbar from "../components/Navbar";
import { useSelector } from "react-redux";
import { Box, Grid, TextField } from "@mui/material";
import { apiCall, isValidToken } from "../utils";
import {
  equipmentEndPoints,
  methods,
  userEndPoints,
  workflowEndPoints,
} from "../constants";
import UserCard from "../components/Equipment/UserCard";
import CameraModal from "../components/UserManagement/CameraModal";
import { KeyboardArrowDown, KeyboardArrowUp } from "@mui/icons-material";
import Loading from "../assets/Loading.json";
import Lottie from "lottie-react";
import lockIcon from "../assets/lockIcon.svg";
import { encrypt, decrypt } from "../crypto.js";




const UserManagement = () => {
  const [loading, setLoading] = useState(false);
  const [userData, setUserData] = useState([]);
  const [filterUserData, setFilterUserData] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [roles, setRoles] = useState([]);
  const [showLotoUsers, setShowLotoUsers] = useState(true);
  const [showContractUsers, setShowContractUsers] = useState(true);

  const user = useSelector((state) => state.authSlice.user);

  // Memoize token extraction from URL
  const tokenValue = useMemo(() => {
    const searchParams = new URLSearchParams(window.location.search);
    return searchParams.get("token");
  }, []);

  // Memoize fetchData function to prevent unnecessary re-creations
  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      // Get token from URL or localStorage
      const tokenFromStorage = localStorage.getItem("token");
      const token = tokenValue || tokenFromStorage;

      // Encrypt the orgId payload - backend expects org_id (snake_case)
      const payload = { org_id: user.org.org_id };
      console.log("payload:", payload);
      // Use encrypt from crypto.js (synchronous function)
      const encryptedPayload = encrypt(payload);
      console.log("Encrypted payload:", encryptedPayload);

      // Verify encryption format (should be base64 string)
      if (typeof encryptedPayload !== "string") {
        throw new Error(
          "Encryption failed: Expected string but got " +
            typeof encryptedPayload
        );
      }

      // Create the request payload with data field containing encrypted string
      // Backend expects: {data: "encryptedString"}
      const requestPayload = {
        data: encryptedPayload, // Trim any whitespace
      };

      // Send encrypted payload wrapped in { data: encryptedPayload }
      let response;
      try {
        response = await apiCall(
          workflowEndPoints.getUsers,
          methods.post,
          requestPayload,
          token
        );

        // Check if apiCall returned an error response (status >= 400)
        if (response?.status >= 400) {
          const errorData = response.data;
          const errorMessage =
            errorData?.error ||
            errorData?.message ||
            errorData?.details ||
            JSON.stringify(errorData) ||
            "Failed to fetch users";

          throw new Error(errorMessage);
        }
        console.log("response:", response);

        // Decrypt the response data
        const decryptedResponse = decrypt(response.data);
        console.log("decryptedResponse:", decryptedResponse);

        // Extract users array from decrypted response
        // Response structure: { users: [...] }
        const users = Array.isArray(decryptedResponse?.users)
          ? decryptedResponse.users
          : Array.isArray(decryptedResponse?.allLotoUsers)
          ? decryptedResponse.allLotoUsers
          : Array.isArray(decryptedResponse)
          ? decryptedResponse
          : [];

        setUserData(users);
        setFilterUserData(users);
        setLoading(false);
      } catch (apiError) {
        // Handle axios errors (400, 500, etc.)
        if (apiError?.response?.data) {
          const errorData = apiError.response.data;
          const errorMessage =
            errorData?.error ||
            errorData?.message ||
            errorData?.details ||
            JSON.stringify(errorData) ||
            `API Error: ${apiError.response.status}`;

          throw new Error(errorMessage);
        }

        throw apiError;
      }
    } catch (error) {
      setUserData([]);
      setFilterUserData([]);
      setLoading(false);
    }
  }, [user, tokenValue]);

  // Memoize filterData function
  const filterData = useCallback(
    (searchInput) => {
      const searchLowerCase = searchInput.toLowerCase();
      const filteredData = userData.filter(
        (user) => user.first_name.toLowerCase().indexOf(searchLowerCase) !== -1
      );
      setFilterUserData(filteredData);
    },
    [userData]
  );

  // Memoize toggle handlers
  const toggleLotoUsers = useCallback(() => {
    setShowLotoUsers((prev) => !prev);
  }, []);

  const toggleContractUsers = useCallback(() => {
    setShowContractUsers((prev) => !prev);
  }, []);

  // Helper function to generate unique keys for users
  const getUserKey = useCallback((user, index, prefix = "") => {
    // Use emp_id if available and not 0, otherwise use index
    // Combine with prefix and index to ensure uniqueness
    const baseId =
      user.emp_id && user.emp_id !== 0 ? user.emp_id : `idx-${index}`;
    return `${prefix}${baseId}-${index}`;
  }, []);

  // Memoize filtered user arrays
  const lotoUsers = useMemo(
    () => filterUserData.filter((user) => user.isContractedUser),
    [filterUserData]
  );

  const contractUsers = useMemo(
    () => filterUserData.filter((user) => !user.isContractedUser),
    [filterUserData]
  );

  // Fetch user data when user changes
  useEffect(() => {
    if (Object.keys(user).length > 0) fetchData();
  }, [user, fetchData]);

  // Fetch departments and roles on mount
  useEffect(() => {
    // Fetch departments
    apiCall(equipmentEndPoints.getDepts, methods.get)
      .then((data) => {
        // Ensure data is an array
        const deptData = Array.isArray(data) ? data : [];
        setDepartments(deptData);
      })
      .catch((error) => {
        // Set fallback data for departments
       toast.error("Failed to fetch departments");
      });

    // Fetch roles
    apiCall(equipmentEndPoints.getRoles, methods.get)
      .then((data) => {
        // Ensure data is an array
        const roleData = Array.isArray(data) ? data : [];
        setRoles(roleData);
      })
      .catch((error) => {
        // Set fallback data based on the API response you provided
        toast.error("Failed to fetch roles");
      });
  }, []);

  // Token validation - redirect if no valid token
  if (!isValidToken(tokenValue)) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-white p-8 rounded-lg shadow-md text-center max-w-md">
          <div className="mb-4">
            <img
              src={lockIcon}
              alt="Authentication Required"
              className="w-16 h-16 mx-auto mb-4"
            />
          </div>
          <h2 className="text-xl font-semibold text-gray-800 mb-4">
            Authentication Required
          </h2>
          <p className="text-gray-600 mb-4">
            You need a valid authentication token to access this page.
          </p>
          <p className="text-sm text-gray-500 mb-6">
            Please ensure you have a valid token in the URL parameters.
          </p>
          <button
            onClick={() => (window.location.href = "/")}
            className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 rounded-lg transition-colors"
          >
            Go to Home
          </button>
        </div>
      </div>
    );
  }

  if (loading)
    return (
      <div className="flex justify-center items-center w-full h-full absolute top-0 left-0">
        <div className="relative w-40 h-40">
          <img src={lockIcon} alt="Lock" className="absolute inset-0 m-auto" />
          <Lottie
            animationData={Loading}
            loop={true}
            className="absolute w-full h-full top-0 left-0 pointer-events-none"
          />
        </div>
      </div>
    );

  return (
    <div>
      <Navbar token={tokenValue} />

      <div className="py-5 px-5 ">
        <div className="bg-white w-full min-h-56 h-full rounded-lg shadow-md py-5 md:px-12 px-5 ">
          <div className="flex justify-between items-center py-3 flex-wrap ">
            <div className="flex-grow mb-5">
              <p className="text-primary text-xl font-semibold">
                LOTO User Management
              </p>
              <p className="text-sm text-gray-500 mt-1">
                Departments: {departments.length} | Roles: {roles.length} |
                Users: {userData.length}
              </p>
            </div>

            <div className="flex gap-5 md:gap-0 flex-wrap items-center w-full md:w-auto mb-4 md:mb-0">
              <CameraModal fetchData={fetchData} />
              {/* Conditionally render the search input based on screen size */}
              <Box className="w-full md:w-auto md:ml-2 md:order-1 sm:order-2 mb-2 rounded-xl">
                <TextField
                  variant="outlined"
                  // label="Search user"
                  placeholder="Search user"
                  onChange={(e) => {
                    filterData(e.target.value);
                  }}
                  fullWidth
                  sx={{
                    "& .MuiOutlinedInput-root": {
                      borderRadius: "60px",
                      width: "165px",
                      height: "55px",
                      marginTop: "5px",
                    },
                    "& .MuiOutlinedInput-notchedOutline": {
                      borderRadius: "60px",
                      width: "168px",
                      height: "52px",
                      marginTop: "5px",
                    },
                  }}
                />
              </Box>
            </div>
          </div>

          <hr />
          <div className="mt-4">
            <div className="flex justify-between items-center">
              <h3 className="text-xl text-primary">LOTO Users</h3>
              <button onClick={toggleLotoUsers}>
                {showLotoUsers ? <KeyboardArrowUp /> : <KeyboardArrowDown />}
              </button>
            </div>
            {showLotoUsers && (
              <Grid container spacing={2}>
                {contractUsers.map((user, index) => (
                  <UserCard
                    key={getUserKey(user, index, "contract-")}
                    user={user}
                    departments={departments}
                    roles={roles}
                    fetchData={fetchData}
                  />
                ))}
              </Grid>
            )}
          </div>

          <hr className="mt-10" />
          <div className="mt-4">
            <div className="flex justify-between items-center">
              <h3 className="text-xl text-primary">Contractors</h3>
              <button onClick={toggleContractUsers}>
                {showContractUsers ? (
                  <KeyboardArrowUp />
                ) : (
                  <KeyboardArrowDown />
                )}
              </button>
            </div>
            {showContractUsers && (
              <Grid container spacing={2}>
                {lotoUsers.map((user, index) => (
                  <UserCard
                    key={getUserKey(user, index, "loto-")}
                    user={user}
                    departments={departments}
                    roles={roles}
                    fetchData={fetchData}
                  />
                ))}
              </Grid>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserManagement;
