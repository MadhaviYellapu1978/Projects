import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import Navbar from "../components/Navbar";
import { workorderIcon } from "../assets";
import { apiCall, decryptAesBase64 } from "../utils";
import { encrypt, decrypt } from "../crypto";
import { workflowEndPoints, methods } from "../constants";
import toast from "react-hot-toast";

const LOTOWorkOrderFormBuilder = () => {
  const navigate = useNavigate();
  const user = useSelector((state) => state.authSlice.user);
  const [operationType, setOperationType] = useState("Maintenance");
  const [workType, setWorkType] = useState("Cold Work");
  const [canvasFields, setCanvasFields] = useState([]);
  const [draggedField, setDraggedField] = useState(null);
  const [selectedSidebarField, setSelectedSidebarField] = useState(null);
  const [selectedCanvasField, setSelectedCanvasField] = useState(null);
  const [draggedCanvasField, setDraggedCanvasField] = useState(null);
  const [isSaving, setIsSaving] = useState(false);
  const [fieldDefinitions, setFieldDefinitions] = useState([]);
  const [isLoadingFields, setIsLoadingFields] = useState(true);
  const [fieldsError, setFieldsError] = useState(null);

  // Custom drag handle icon (2x3 grid of dots)
  const DragHandle = () => (
    <svg
      width="16"
      height="20"
      viewBox="0 0 16 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="cursor-move"
    >
      <circle cx="4" cy="4" r="1.5" fill="#6B7280" />
      <circle cx="12" cy="4" r="1.5" fill="#6B7280" />
      <circle cx="4" cy="10" r="1.5" fill="#6B7280" />
      <circle cx="12" cy="10" r="1.5" fill="#6B7280" />
      <circle cx="4" cy="16" r="1.5" fill="#6B7280" />
      <circle cx="12" cy="16" r="1.5" fill="#6B7280" />
    </svg>
  );

  // Fetch fields from API on component mount
  useEffect(() => {
    const fetchFields = async () => {
      setIsLoadingFields(true);
      setFieldsError(null);
      try {
        const token = localStorage.getItem("token") || "";
        const response = await apiCall(
          workflowEndPoints.getMainFields,
          methods.get,
          null,
          token
        );

        if (response?.status >= 400) {
          const errorData = response.data;
          const errorMessage =
            errorData?.error ||
            errorData?.message ||
            errorData?.details ||
            JSON.stringify(errorData) ||
            "Failed to fetch form fields";
          throw new Error(errorMessage);
        }

        // Decrypt the response data (API returns encrypted base64 payload)
        let decryptedData = null;
        if (response?.data && typeof response.data === "string") {
          try {
            decryptedData = await decryptAesBase64(response.data);
            if (typeof decryptedData === "string") {
              try {
                decryptedData = JSON.parse(decryptedData);
              } catch (e) {
                // If parsing fails, use decrypted string as is
                console.warn("Failed to parse decrypted response:", e);
              }
            }
          } catch (e) {
            // If decryption fails, maybe response.data is already plain JSON
            if (typeof response.data === "object") {
              decryptedData = response.data;
            } else {
              throw new Error("Failed to decrypt response data");
            }
          }
        } else if (response?.data && typeof response.data === "object") {
          // If response.data is already an object, check if it has encrypted data field
          if (response.data.data && typeof response.data.data === "string") {
            try {
              decryptedData = await decryptAesBase64(response.data.data);
              if (typeof decryptedData === "string") {
                try {
                  decryptedData = JSON.parse(decryptedData);
                } catch (e) {
                  console.warn("Failed to parse decrypted response:", e);
                }
              }
            } catch (e) {
              decryptedData = response.data;
            }
          } else {
            decryptedData = response.data;
          }
        } else {
          decryptedData = response;
        }

        // Parse response - handle different response structures
        console.log("Decrypted data:", decryptedData);
        let fieldsData = [];
        if (Array.isArray(decryptedData)) {
          fieldsData = decryptedData;
        } else if (decryptedData?.fields && Array.isArray(decryptedData.fields)) {
          fieldsData = decryptedData.fields;
        } else if (decryptedData?.data && Array.isArray(decryptedData.data)) {
          fieldsData = decryptedData.data;
        } else if (decryptedData?.fieldList && Array.isArray(decryptedData.fieldList)) {
          fieldsData = decryptedData.fieldList;
        }
        
        console.log("Extracted fieldsData:", fieldsData);
        
        if (fieldsData.length === 0) {
          console.warn("No fields found in response. Decrypted data structure:", decryptedData);
        }

        // Transform API fields to component format
        const transformedFields = fieldsData.map((field, index) => {
          // Map API field structure to component format
          const fieldName = field.fieldName || field.name || field.label || field.title || "";
          const fieldType = field.fieldType || field.type || "text";
          
          // Generate unique ID
          const fieldId = field.id || field._id || `field-${index}`;

          // Handle different field types
          if (fieldType === "select" || fieldType === "radio" || field.options || field.optionValues) {
            return {
              id: fieldId,
              type: "radio",
              label: fieldName,
              options: field.options || field.optionValues || field.values || [],
            };
          } else {
            return {
              id: fieldId,
              type: "text",
              label: fieldName,
              placeholder: fieldName || field.placeholder || "",
            };
          }
        });

        console.log("Transformed fields:", transformedFields);
        setFieldDefinitions(transformedFields);
      } catch (error) {
        console.error("Error fetching form fields:", error);
        setFieldsError(error.message || "Failed to load form fields");
        toast.error(error.message || "Failed to load form fields");
      } finally {
        setIsLoadingFields(false);
      }
    };

    fetchFields();
  }, []);

  // Drag handlers
  const handleDragStart = (e, fieldId) => {
    setDraggedField(fieldId);
    e.dataTransfer.effectAllowed = "move";
    e.dataTransfer.setData("text/html", fieldId);
  };

  const handleDragEnd = () => {
    setDraggedField(null);
    // Reset canvas background color
    const canvasElement = document.querySelector('[data-canvas-area]');
    if (canvasElement) {
      canvasElement.style.backgroundColor = "white";
    }
  };

  // Drop handlers
  const handleDragOver = (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    const fieldId = e.dataTransfer.getData("text/html");
    if (fieldId) {
      const fieldDef = fieldDefinitions.find((f) => f.id === fieldId);
      if (fieldDef) {
        const newField = {
          ...fieldDef,
          canvasId: `canvas-${Date.now()}-${Math.random()}`,
        };
        setCanvasFields((prevFields) => [...prevFields, newField]);
        // Scroll to bottom after state update to show the new field
        setTimeout(() => {
          const canvasContainer = e.currentTarget;
          if (canvasContainer) {
            canvasContainer.scrollTop = canvasContainer.scrollHeight;
          }
        }, 100);
      }
    }
    setDraggedField(null);
  };

  // Delete field handler
  const handleDeleteField = (canvasId, e) => {
    e.stopPropagation();
    setCanvasFields(canvasFields.filter((field) => field.canvasId !== canvasId));
    setSelectedCanvasField(null);
  };

  // Copy field handler
  const handleCopyField = (canvasId, e) => {
    e.stopPropagation();
    const fieldToCopy = canvasFields.find((field) => field.canvasId === canvasId);
    if (fieldToCopy) {
      const copiedField = {
        ...fieldToCopy,
        canvasId: `canvas-${Date.now()}-${Math.random()}`,
      };
      const index = canvasFields.findIndex((field) => field.canvasId === canvasId);
      const newFields = [...canvasFields];
      newFields.splice(index + 1, 0, copiedField);
      setCanvasFields(newFields);
    }
  };

  // Move field handler (copy to canvas from sidebar)
  const handleMoveField = (fieldId, e) => {
    e.stopPropagation();
    const fieldDef = fieldDefinitions.find((f) => f.id === fieldId);
    if (fieldDef) {
      const newField = {
        ...fieldDef,
        canvasId: `canvas-${Date.now()}-${Math.random()}`,
      };
      setCanvasFields([...canvasFields, newField]);
    }
    setSelectedSidebarField(null);
  };

  // Canvas field drag handlers for reordering
  const handleCanvasDragStart = (e, canvasId) => {
    // Don't start drag if clicking on interactive elements
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'LABEL' || e.target.closest('button')) {
      e.preventDefault();
      return;
    }
    setDraggedCanvasField(canvasId);
    e.dataTransfer.effectAllowed = "move";
    e.dataTransfer.setData("text/html", canvasId);
    e.stopPropagation();
  };

  const handleCanvasDragEnd = () => {
    setDraggedCanvasField(null);
  };

  const handleCanvasDragOver = (e, targetCanvasId) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
    e.stopPropagation();
  };

  const handleCanvasDrop = (e, targetCanvasId) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!draggedCanvasField || draggedCanvasField === targetCanvasId) {
      setDraggedCanvasField(null);
      return;
    }

    const draggedIndex = canvasFields.findIndex((f) => f.canvasId === draggedCanvasField);
    const targetIndex = canvasFields.findIndex((f) => f.canvasId === targetCanvasId);

    if (draggedIndex === -1 || targetIndex === -1) {
      setDraggedCanvasField(null);
      return;
    }

    const newFields = [...canvasFields];
    const [removed] = newFields.splice(draggedIndex, 1);
    newFields.splice(targetIndex, 0, removed);

    setCanvasFields(newFields);
    setDraggedCanvasField(null);
  };

  // Save handler
  const handleSave = async () => {
    if (canvasFields.length === 0) {
      toast.error("Please add at least one field to save");
      return;
    }

    setIsSaving(true);
    try {
      // Get token from URL or localStorage
      const searchParams = new URLSearchParams(window.location.search);
      const tokenFromUrl = searchParams.get("token");
      const tokenFromStorage = localStorage.getItem("token");
      const token = tokenFromUrl || tokenFromStorage;

      // Get orgId from user
      const orgId = user?.org?.org_id || user?.org_id || "";
      if (!orgId) {
        toast.error("Organization ID not found!");
        setIsSaving(false);
        return;
      }

      // Transform canvasFields to the required payload format
      const fields = canvasFields.map((field) => {
        return {
          fieldName: field.label || field.placeholder || "",
          fieldType: field.type === "text" ? "text" : field.type === "radio" ? "select" : field.type,
          required: false, // Default to false, can be made configurable later
        };
      });

      // Create payload
      const payload = {
        orgId: orgId,
        fields: fields,
      };

      console.log("Payload before encryption:", payload);

      // Encrypt the payload using encrypt from crypto.js
      const encryptedPayload = encrypt(payload);
      console.log("Encrypted payload:", encryptedPayload);

      // Verify encryption format (should be base64 string)
      if (typeof encryptedPayload !== "string") {
        throw new Error(
          "Encryption failed: Expected string but got " + typeof encryptedPayload
        );
      }

      // Create the request payload with data field containing encrypted string
      const requestPayload = {
        data: encryptedPayload,
      };

      // Call the API
      const response = await apiCall(
        workflowEndPoints.assignFieldsForWorkOrder,
        methods.post,
        requestPayload,
        token
      );

      console.log("API response:", response);

      // Check if apiCall returned an error response (status >= 400)
      if (response?.status >= 400) {
        const errorData = response.data;
        const errorMessage =
          errorData?.error ||
          errorData?.message ||
          errorData?.details ||
          JSON.stringify(errorData) ||
          "Failed to save form fields";

        throw new Error(errorMessage);
      }

      // Decrypt the response data
      let decryptedResponse;
      if (response?.data && typeof response.data === "string") {
        decryptedResponse = decrypt(response.data);
        console.log("Decrypted response:", decryptedResponse);

        // Parse if it's a JSON string
        if (typeof decryptedResponse === "string") {
          try {
            decryptedResponse = JSON.parse(decryptedResponse);
          } catch (e) {
            // If parsing fails, use the string as is
            console.warn("Failed to parse decrypted response:", e);
          }
        }
      } else {
        decryptedResponse = response;
      }

      console.log("Final decrypted response:", decryptedResponse);

      // Show success message
      toast.success("Form fields saved successfully!");
      
      // Optionally navigate back or reset form
      // navigate(-1);
    } catch (error) {
      console.error("Error saving form fields:", error);
      toast.error(error.message || "Failed to save form fields");
    } finally {
      setIsSaving(false);
    }
  };

  // Render field component for canvas
  const renderCanvasField = (field, index) => {
    const isSelected = selectedCanvasField === field.canvasId;
    const isDragging = draggedCanvasField === field.canvasId;
    return (
      <div
        key={field.canvasId}
        draggable
        onDragStart={(e) => handleCanvasDragStart(e, field.canvasId)}
        onDragEnd={handleCanvasDragEnd}
        onDragOver={(e) => handleCanvasDragOver(e, field.canvasId)}
        onDrop={(e) => handleCanvasDrop(e, field.canvasId)}
        onClick={(e) => {
          e.stopPropagation();
          setSelectedCanvasField(field.canvasId);
          setSelectedSidebarField(null);
        }}
        className={`mb-4 rounded-lg border-2 bg-white cursor-move ${
          isDragging ? "opacity-50" : ""
        }`}
        style={{ borderColor: isSelected ? "#3B82F6" : "#6B7280" }}
      >
        {/* Header with icons */}
        {isSelected && (
          <div className="flex items-center justify-end gap-3 px-3 py-2 border-b border-gray-300">
            {/* Delete Icon */}
            <button
              onClick={(e) => handleDeleteField(field.canvasId, e)}
              className="text-gray-600 hover:text-red-600 transition-colors cursor-pointer"
              title="Delete"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M3 6H5H21M8 6V4C8 3.46957 8.21071 2.96086 8.58579 2.58579C8.96086 2.21071 9.46957 2 10 2H14C14.5304 2 15.0391 2.21071 15.4142 2.58579C15.7893 2.96086 16 3.46957 16 4V6M19 6V20C19 20.5304 18.7893 21.0391 18.4142 21.4142C18.0391 21.7893 17.5304 22 17 22H7C6.46957 22 5.96086 21.7893 5.58579 21.4142C5.21071 21.0391 5 20.5304 5 20V6H19Z"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </button>

            {/* Copy Icon */}
            <button
              onClick={(e) => handleCopyField(field.canvasId, e)}
              className="text-gray-600 hover:text-blue-600 transition-colors cursor-pointer"
              title="Copy"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M8 8V5C8 4.46957 8.21071 3.96086 8.58579 3.58579C8.96086 3.21071 9.46957 3 10 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V14C21 14.5304 20.7893 15.0391 20.4142 15.4142C20.0391 15.7893 19.5304 16 19 16H16M8 8H5C4.46957 8 3.96086 8.21071 3.58579 8.58579C3.21071 8.96086 3 9.46957 3 10V19C3 19.5304 3.21071 20.0391 3.58579 20.4142C3.96086 20.7893 4.46957 21 5 21H14C14.5304 21 15.0391 20.7893 15.4142 20.4142C15.7893 20.0391 16 19.5304 16 19V16M8 8H16V16"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </button>

            {/* Move Icon */}
            <div
              className="text-gray-600 hover:text-green-600 transition-colors cursor-move"
              title="Drag field to reorder"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M5 9L2 12L5 15M9 5L12 2L15 5M15 19L12 22L9 19M19 9L22 12L19 15M12 2V22M2 12H22"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>
          </div>
        )}

        {/* Field Content */}
        <div className="p-4" onDragStart={(e) => e.stopPropagation()}>
          {field.type === "text" ? (
            <input
              type="text"
              placeholder={field.placeholder}
              className="w-full px-3 py-2 rounded text-sm text-gray-500 placeholder:text-gray-500 border-none focus:outline-none bg-white"
              onDragStart={(e) => e.preventDefault()}
            />
          ) : field.type === "radio" ? (
            <>
              <label className="block text-sm font-medium mb-2" style={{ color: "#374151" }}>
                {field.label}
              </label>
              <div className="flex gap-4">
                {field.options.map((option) => (
                  <label key={option} className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name={field.canvasId}
                      value={option}
                      className="w-4 h-4"
                      style={{ accentColor: "#6B7280" }}
                      onDragStart={(e) => e.preventDefault()}
                    />
                    <span className="text-sm" style={{ color: "#374151" }}>
                      {option}
                    </span>
                  </label>
                ))}
              </div>
            </>
          ) : null}
        </div>
      </div>
    );
  };

  // Get token from URL parameters
  const searchParams = new URLSearchParams(window.location.search);
  const tokenFromUrl = searchParams.get("token");
  const tokenFromStorage = localStorage.getItem("token");
  const token = tokenFromUrl || tokenFromStorage || "";

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar token={token} />

      {/* Header */}
      <div className="bg-white px-6 py-4 border-b">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate(-1)}
              className="text-gray-600 hover:text-gray-800 transition-colors"
            >
              <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                <path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z" />
              </svg>
            </button>
            <h1 className="text-xl font-semibold text-gray-800">
              Create LOTO Work Order Form Builder
            </h1>
          </div>
          <button
            onClick={handleSave}
            disabled={canvasFields.length === 0 || isSaving}
            className="px-6 py-2 rounded-full font-semibold text-white transition-colors"
            style={{
              backgroundColor: canvasFields.length > 0 && !isSaving ? "#1E40AF" : "#9CA3AF",
              cursor: canvasFields.length > 0 && !isSaving ? "pointer" : "not-allowed",
            }}
          >
            {isSaving ? "Saving..." : "Save"}
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex" style={{ height: "calc(100vh - 140px)", padding: "16px", gap: "16px", backgroundColor: "#F9FAFB" }}>
        {/* Left Sidebar - LOTO Form Fields */}
        <div
          className="w-80 bg-white rounded-lg"
          style={{ boxShadow: "0 1px 3px rgba(0,0,0,0.1)", display: "flex", flexDirection: "column", height: "100%" }}
          onClick={(e) => {
            // Only deselect if clicking directly on the sidebar container
            if (e.target === e.currentTarget || e.target.closest('h2')) {
              setSelectedSidebarField(null);
              setSelectedCanvasField(null);
            }
          }}
        >
          <div className="p-4 flex-shrink-0">
            <h2 className="text-lg font-semibold text-gray-800">
              LOTO Form Fields
            </h2>
          </div>
          <div className="flex-1 overflow-y-auto p-4 pt-0">
            {isLoadingFields ? (
              <div className="flex items-center justify-center py-8">
                <p className="text-gray-600">Loading fields...</p>
              </div>
            ) : fieldsError ? (
              <div className="flex items-center justify-center py-8">
                <p className="text-red-600">{fieldsError}</p>
              </div>
            ) : fieldDefinitions.length === 0 ? (
              <div className="flex items-center justify-center py-8">
                <p className="text-gray-600">No fields available</p>
              </div>
            ) : (
              <div className="space-y-3">
                {fieldDefinitions.map((field) => {
                const isSelected = selectedSidebarField === field.id;
                return (
                  <div
                    key={field.id}
                    draggable
                    onDragStart={(e) => handleDragStart(e, field.id)}
                    onDragEnd={handleDragEnd}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedSidebarField(field.id);
                      setSelectedCanvasField(null);
                    }}
                    className={`flex gap-2 p-2.5 cursor-move rounded ${
                      field.type === "radio" ? "items-start" : "items-center"
                    } ${draggedField === field.id ? "opacity-50" : ""} ${
                      isSelected ? "bg-blue-50 border-2 border-blue-300" : ""
                    }`}
                  >
                    {field.type === "text" ? (
                      <>
                        <input
                          type="text"
                          placeholder={field.placeholder}
                          className="flex-1 px-3 py-2 rounded text-sm text-gray-500 placeholder:text-gray-500 border-none focus:outline-none"
                          style={{ backgroundColor: "#E5E7EB" }}
                          readOnly
                        />
                        {isSelected ? <DragHandle /> : null}
                      </>
                    ) : (
                      <>
                        <div className="flex-1">
                          <label className="block text-sm font-medium mb-2" style={{ color: "#374151" }}>
                            {field.label}
                          </label>
                          <div className="flex gap-4">
                            {field.options.map((option) => (
                              <label key={option} className="flex items-center gap-2 cursor-pointer">
                                <input
                                  type="radio"
                                  name={`sidebar-${field.id}`}
                                  value={option}
                                  className="w-4 h-4"
                                  style={{ accentColor: "#6B7280" }}
                                  readOnly
                                />
                                <span className="text-sm" style={{ color: "#374151" }}>
                                  {option}
                                </span>
                              </label>
                            ))}
                          </div>
                        </div>
                        <div className="pt-0.5">
                          {isSelected ? <DragHandle /> : null}
                        </div>
                      </>
                    )}
                  </div>
                );
              })}
              </div>
            )}
          </div>
        </div>

        {/* Right Content Area - Form Building Canvas */}
        <div
          className="flex-1 bg-white rounded-lg"
          style={{ boxShadow: "0 1px 3px rgba(0,0,0,0.1)", display: "flex", flexDirection: "column" }}
        >
          <div
            data-canvas-area
            className="flex-1 overflow-y-auto transition-colors duration-200"
            style={{ 
              padding: "32px", 
              paddingBottom: "200px",
              minHeight: "100%"
            }}
            onDragOver={(e) => {
              // Only handle drag over if it's from sidebar (not canvas field reordering)
              if (!draggedCanvasField && draggedField) {
                handleDragOver(e);
                // Add visual feedback when dragging over canvas
                const target = e.currentTarget;
                if (target.style.backgroundColor !== "#F0F9FF") {
                  target.style.backgroundColor = "#F0F9FF";
                }
              }
            }}
            onDragLeave={(e) => {
              // Only reset if leaving the canvas area (not just moving to child element)
              if (!draggedCanvasField && draggedField) {
                const rect = e.currentTarget.getBoundingClientRect();
                const x = e.clientX;
                const y = e.clientY;
                // Check if we're actually leaving the canvas area
                if (x < rect.left || x > rect.right || y < rect.top || y > rect.bottom) {
                  e.currentTarget.style.backgroundColor = "white";
                }
              }
            }}
            onDrop={(e) => {
              // Only handle drop if it's from sidebar (not canvas field reordering)
              if (!draggedCanvasField) {
                handleDrop(e);
                e.currentTarget.style.backgroundColor = "white";
              }
            }}
            onClick={() => {
              setSelectedCanvasField(null);
              setSelectedSidebarField(null);
            }}
          >
            {canvasFields.length === 0 ? (
              <div className="flex items-center justify-center" style={{ minHeight: "400px" }}>
                <div className="text-center">
                  {/* Circular Icon */}
                  <div className="flex justify-center mb-4">
                    <div
                      className="w-20 h-20 rounded-full flex items-center justify-center"
                      style={{ backgroundColor: "#E0F2F7" }}
                    >
                      <img
                        src={workorderIcon}
                        alt="Work Order"
                        width="40"
                        height="40"
                      />
                    </div>
                  </div>

                  {/* Text Message */}
                  <p className="text-lg font-medium text-black">
                    No Form Field Selected
                  </p>
                </div>
              </div>
            ) : (
              <div className="max-w-2xl mx-auto" style={{ minHeight: "100%" }}>
                {canvasFields.map((field, index) => renderCanvasField(field, index))}
                {/* Extra space at bottom for easier dropping */}
                <div style={{ height: "150px", minHeight: "150px" }}></div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default LOTOWorkOrderFormBuilder;

