//give me the code for pending tasks that are pending or rejected when these roles are not accepted by the request based on the work order table and work order details


