/* eslint-disable */
import React, { useState, useEffect } from "react";
import {
  Button,
  TextField,
  Checkbox,
  ListItemText,
  Box,
  Typography,
  Paper,
  IconButton,
} from "@mui/material";
import Autocomplete from "@mui/material/Autocomplete";
import { Delete as DeleteIcon } from "@mui/icons-material";
import { apiCall } from "../utils";
import { methods, workOrderEndPoints } from "../constants";
import toast from "react-hot-toast";

const RequestForIsolators = ({
  fetchData,
  onClose,
  workOrderDetails,
  isolator_list,
}) => {
  const [isolationPoints, setIsolationPoints] = useState([]);
  const [selectedPoints, setSelectedPoints] = useState([]);
  const [selectedIsolators, setSelectedIsolators] = useState([]);
  const [isolatorMapping, setIsolatorMapping] = useState([]);
  const [loading, setLoading] = useState(false);
  const searchParams = new URLSearchParams(window.location.search);
  const tokenValue = searchParams.get("token");

  useEffect(() => {
    const data = workOrderDetails?.getWorkOrderDetails?.machines || [];
    const isolationPointList = data.flatMap((machine) =>
      machine.isolationPoints?.map((point) => ({
        ...point,
        isolationName: point.isolationName || "Unnamed Point",
      }))
    );
    setIsolationPoints(isolationPointList || []);
  }, [workOrderDetails]);

  const handleAddMapping = () => {
    if (selectedPoints.length === 0 || selectedIsolators.length === 0) return;

    const newMappings = selectedPoints.map((point) => ({
      isolationPoint: point,
      isolators: selectedIsolators,
    }));
    setIsolatorMapping([...isolatorMapping, ...newMappings]);
    setSelectedPoints([]);
    setSelectedIsolators([]);
  };

  const handleRemoveMapping = (indexToRemove) => {
    const updatedMappings = isolatorMapping.filter(
      (_, index) => index !== indexToRemove
    );
    setIsolatorMapping(updatedMappings);
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      const machines = workOrderDetails?.getWorkOrderDetails?.machines || [];
      const mappedMachines = machines.flatMap((machine) => {
        const machineMappings = isolatorMapping.filter((mapping) =>
          machine.isolationPoints.some(
            (point) => point.isolationId === mapping.isolationPoint.isolationId
          )
        );

        return machineMappings.flatMap((mapping) => {
          const { isolationPoint, isolators } = mapping;

          return isolators.map((isolator) => ({
            machineName: machine.machineName || "",
            isolationpointName: isolationPoint.isolationName || "",
            isolatorName: `${isolator.first_name || ""} ${
              isolator.last_name || ""
            }`.trim(),
            isolatorId: isolator.emp_id || "",
            isolatorDeviceId: isolator.isolatorDeviceId || "",
            isolatorStatus: "Pending",
            isolationId: isolationPoint.isolationId || "",
          }));
        });
      });

      const payload = {
        workOrderId: workOrderDetails?.getWorkOrderDetails?.workOrderId || "",
        newMachines: mappedMachines,
      };

      await apiCall(
        `${workOrderEndPoints.updateCustodiansWO}`,
        methods.put,
        payload
      );

      onClose();
      toast.success("Isolators assigned successfully!");
      setTimeout(() => {
        window.location.href = `/loto/dashboard?token=${tokenValue}`;
        // fetchData();

        // onClose();
      }, 2000); // 3 seconds delay

      // window.location.href = `/loto/dashboard?token=${tokenValue}`;

      // fetchData();
    } catch (error) {
      console.error("Error submitting isolators:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h2>Select Isolation Points & Isolators</h2>

      {/* Isolation Points Selection */}
      <Autocomplete
        multiple
        value={selectedPoints}
        onChange={(event, newValue) => setSelectedPoints(newValue)}
        options={isolationPoints.filter(
          (point) =>
            !isolatorMapping.some(
              (mapping) =>
                mapping.isolationPoint.isolationId === point.isolationId
            )
        )}
        getOptionLabel={(option) => option.isolationName || "Unnamed Point"}
        isOptionEqualToValue={(option, value) =>
          option.isolationId === value?.isolationId
        }
        renderOption={(props, option, { selected }) => (
          <li {...props}>
            <Checkbox checked={selected} />
            <ListItemText primary={option.isolationName || "Unnamed Point"} />
          </li>
        )}
        renderInput={(params) => (
          <TextField
            {...params}
            label="Select Isolation Points"
            variant="outlined"
          />
        )}
        noOptionsText="No points available"
        sx={{ mt: 2 }}
      />

      {/* Isolators Selection */}
      {selectedPoints.length > 0 && (
        <Autocomplete
          multiple
          disableCloseOnSelect
          value={selectedIsolators}
          onChange={(event, newValue) => setSelectedIsolators(newValue)}
          options={isolator_list || []}
          getOptionLabel={(option) =>
            `${option.first_name || ""} ${option.last_name || ""}`.trim()
          }
          isOptionEqualToValue={(option, value) =>
            option.emp_id === value?.emp_id
          }
          renderOption={(props, option, { selected }) => (
            <li {...props}>
              <Checkbox checked={selected} />
              <ListItemText
                primary={`${option.first_name || ""} ${
                  option.last_name || ""
                }`.trim()}
              />
            </li>
          )}
          renderInput={(params) => (
            <TextField
              {...params}
              label="Select Isolators"
              variant="outlined"
            />
          )}
          noOptionsText="No isolators found"
          sx={{ mt: 2 }}
        />
      )}

      {selectedPoints.length > 0 && selectedIsolators.length > 0 && (
        <button
          variant="contained"
          className="bg-primary py-2 px-7 rounded-full text-white font-semibold mt-5"
          onClick={handleAddMapping}
        >
          Add
        </button>
      )}

      {/* Mappings Display */}
      <Box sx={{ mt: 3 }}>
        {isolatorMapping.map((mapping, index) => (
          <Paper
            key={index}
            sx={{
              p: 2,
              mb: 2,
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <Box>
              <Typography variant="h6">
                Isolation Point: {mapping.isolationPoint.isolationName}
              </Typography>
              <Typography variant="body1">
                Isolators:{" "}
                {mapping.isolators
                  .map(
                    (isolator) => `${isolator.first_name} ${isolator.last_name}`
                  )
                  .join(", ")}
              </Typography>
            </Box>
            <IconButton
              color="error"
              onClick={() => handleRemoveMapping(index)}
            >
              <DeleteIcon />
            </IconButton>
          </Paper>
        ))}
      </Box>

      {/* <button
  variant="contained"
  onClick={handleSubmit}
  disabled={loading || isolatorMapping.length === 0}
  className="bg-primary py-2 px-7 rounded-full text-white font-semibold mt-5"
>
  {loading ? "Submitting..." : "Submit"}
</button> */}
      {isolatorMapping.length === isolationPoints.length && (
        <button
          variant="contained"
          onClick={handleSubmit}
          disabled={loading || isolatorMapping.length === 0}
          className="bg-primary py-2 px-7 rounded-full text-white font-semibold mt-5"
        >
          {loading ? "Submitting..." : "Submit"}
        </button>
      )}
    </div>
  );
};

export default RequestForIsolators;
