import * as XLSX from "xlsx";
import { saveAs } from "file-saver";

const HandlePrint = ({ workOrderDetails }) => {
  const handle = () => {
    // Assume workOrderDetails.getWorkOrderDetails returns the JSON object as provided.
    const workOrder = workOrderDetails.getWorkOrderDetails;

    // Extract names from nested arrays, or fallback to "N/A" if the arrays are not present.
    const custodianNames = workOrder.custodian_details
      ? workOrder.custodian_details
          .map((item) => item.custodian_name)
          .join(", ")
      : "N/A";
    const issuerNames = workOrder.issuer_details
      ? workOrder.issuer_details.map((item) => item.issuer_name).join(", ")
      : "N/A";
    const technicianNames = workOrder.technician_details
      ? workOrder.technician_details
          .map((item) => item.technician_name)
          .join(", ")
      : "N/A";
    const machineNames = workOrder.machines
      ? workOrder.machines.map((item) => item.machineName).join(", ")
      : "N/A";

    // Create a new workbook
    const wb = XLSX.utils.book_new();

    // Create data in a column-wise format. The first row is the header.
    const workOrderData = [
      [
        // "Your Role",
        // "Track Action",
        "Work Order ID",
        // "WOID",
        "Description",
        "Created At",
        "Updated At",
        "Work Order Name",
        "Equipment ID",
        "Work Order Status",
        "Work Order Type",
        "Operation Type",
        // "ERP",
        "Risk Level",
        "Time To Complete",
        // "Org ID",
        "Zone Name",
        "Site Name",
        // "Initiator ID",
        "Initiator Name",
        // "Initiator Device ID",
        "Custodian Names",
        "Issuer Names",
        "Technician Names",
        "Machine Names",
      ],
      [
        // workOrder.your_role || "N/A",
        // workOrder.track_action || "N/A",
        workOrder.workOrderId || "N/A",
        // workOrder.WOID || "N/A",
        workOrder.description || "N/A",
        workOrder.createdAt || "N/A",
        workOrder.updatedAt || "N/A",
        workOrder.workOrderName || "N/A",
        workOrder.equipmentId || "N/A",
        workOrder.workOrder_status || "N/A",
        workOrder.workOrder_type || "N/A",
        workOrder.wo_operation_type || "N/A",
        // workOrder.erp || "N/A",
        workOrder.risk_level || "N/A",
        workOrder.timeToComplete || "N/A",
        // workOrder.orgId || "N/A",
        workOrder.zoneName || "N/A",
        workOrder.siteName || "N/A",
        // workOrder.initiator_id || "N/A",
        workOrder.initiator_name || "N/A",
        // workOrder.initiator_device_id || "N/A",
        custodianNames,
        issuerNames,
        technicianNames,
        machineNames,
      ],
    ];

    // Create a worksheet from the data array
    const ws = XLSX.utils.aoa_to_sheet(workOrderData);

    // Append the worksheet to the workbook
    XLSX.utils.book_append_sheet(wb, ws, "Work Order Details");

    // Generate an Excel file and trigger its download
    const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    const data = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    saveAs(data, "WorkOrderDetails.xlsx");
  };

  return (
    <button
      className="bg-primary py-2 px-6 rounded-full text-white font-semibold"
      onClick={handle}
    >
      Download Work Orders
    </button>
  );
};

export default HandlePrint;
