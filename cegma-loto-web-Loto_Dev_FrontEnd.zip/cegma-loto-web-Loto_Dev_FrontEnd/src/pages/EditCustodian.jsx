/* eslint-disable */
import React, { useEffect, useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Box,
} from "@mui/material";
import { Autocomplete } from "@mui/material";
import Checkbox from "@mui/material/Checkbox";
import { useSelector } from "react-redux";
import { apiCall } from "../utils";
import { methods, userEndPoints, workOrderEndPoints } from "../constants";

const EditCustodian = ({ open, onClose, data, onUpdate, workOrderDetails }) => {
  const [machineList, setMachineList] = useState([]);
  const [selectedMachines, setSelectedMachines] = useState([]);
  const [isolationPoints, setIsolationPoints] = useState([]);
  const [selectedIsolationPoints, setSelectedIsolationPoints] = useState([]);
  const [loading, setLoading] = useState(false);
  // eslint-disable-next-line
  const [error, setError] = useState("");

  const user = useSelector((state) => state.authSlice.user);

  const fetchMachines = async () => {
    if (data?.zoneId && data?.siteId) {
      setLoading(true);
      try {
        const body = {
          orgId: user?.org?.org_id,
          zoneId: data.zoneId,
          siteId: data.siteId,
        };
        const response = await apiCall(
          userEndPoints.getAssetsByZoneAndSite,
          methods.post,
          body
        );

        // Filter the response based on equipmentName
        const filteredResponse = response.filter(
          (each) => each.equipmentName === workOrderDetails.equipmentId
        );

        // Now, flatten the filtered response and map it to extract necessary data
        const machines = filteredResponse
          .flatMap((asset) => asset.machines || [])
          .map((machine) => ({
            machineId: machine.machineId,
            machineName: machine.machineName || `Machine ${machine.machineId}`,
            isolationPoints: machine.isolationPoints || [],
          }));

        setMachineList(machines || []);
      } catch (err) {
        setError("Failed to fetch machines.");
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
  };

  // Fetch isolation points based on selected machines
  const fetchIsolationPoints = () => {
    if (selectedMachines.length > 0) {
      const points = machineList
        .filter((machine) => selectedMachines.includes(machine.machineId))
        .flatMap((machine) => machine.isolationPoints || []);
      setIsolationPoints(points);
    } else {
      setIsolationPoints([]);
    }
  };

  useEffect(() => {
    fetchMachines();
  }, [data?.zoneId, data?.siteId]);

  useEffect(() => {
    fetchIsolationPoints();
  }, [selectedMachines, machineList]);

  const handleSubmit = async () => {
    setLoading(true);
    try {
      const workOrderId = data?.workOrderId;
      const empId = user?.emp_id;

      if (!workOrderId) {
        console.error("WorkOrderId is undefined");
        setLoading(false);
        return;
      }

      const payload = {
        workOrderId,
        replacedMachines: selectedMachines,
        replacedIsolationPoints: selectedIsolationPoints,
      };

      const res = await apiCall(
        `${workOrderEndPoints.updateCustodiansWO}?WorkOrderId=${workOrderId}&emp_id=${empId}`,
        methods.put,
        payload
      );

      if (res) {
        if (onUpdate) {
          await onUpdate();
        }
      }
      onClose();
    } catch (error) {
      console.error("Error updating custodian:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    setSelectedMachines([]);
    setSelectedIsolationPoints([]);
    setIsolationPoints([]);
    onClose();
    onUpdate();
  };

  return (
    <Dialog open={open} onClose={handleCancel} fullWidth>
      <DialogTitle>Edit Custodian</DialogTitle>
      <DialogContent>
        <Box sx={{ mb: 2, mt: 1 }}>
          <Autocomplete
            multiple
            options={machineList}
            getOptionLabel={(machine) => machine.machineName || "Unknown"}
            value={machineList.filter((machine) =>
              selectedMachines.includes(machine.machineId)
            )}
            onChange={(event, value) => {
              const selectedIds = value.map((machine) => machine.machineId);
              setSelectedMachines(selectedIds);
              setSelectedIsolationPoints([]); // Clear isolation points when machines change
            }}
            renderOption={(props, option, state) => (
              <li {...props}>
                <Checkbox
                  checked={selectedMachines.includes(option.machineId)}
                  sx={{ marginRight: 2 }}
                />
                {option.machineName || "Unknown"}
              </li>
            )}
            renderInput={(params) => (
              <TextField
                {...params}
                label="Machines"
                placeholder="Select Machines"
              />
            )}
          />
        </Box>

        <Autocomplete
          multiple
          options={isolationPoints}
          getOptionLabel={(point) => point.isolationName}
          value={selectedIsolationPoints.map((id) =>
            isolationPoints.find((point) => point.isolationId === id)
          )}
          onChange={(event, value) => {
            setSelectedIsolationPoints(value.map((point) => point.isolationId));
          }}
          renderOption={(props, option, state) => (
            <li {...props}>
              <Checkbox
                checked={selectedIsolationPoints.includes(option.isolationId)}
                sx={{ marginRight: 2 }}
              />
              {option.isolationName}
            </li>
          )}
          renderInput={(params) => (
            <TextField
              {...params}
              label="Isolation Points"
              placeholder="Select Isolation Points"
              disabled={isolationPoints.length === 0}
            />
          )}
        />
      </DialogContent>
      <DialogActions>
        <button
          onClick={handleCancel}
          className="border-2 border-primary flex gap-3 py-2 px-6 mr-2 mb-2 rounded-full text-primary font-semibold"
        >
          Cancel
        </button>
        <button
          onClick={handleSubmit}
          className={`bg-primary flex gap-3 py-2 px-5 mr-4 mb-2 rounded-full text-white font-semibold ${
            loading ? "opacity-50 cursor-not-allowed" : ""
          }`}
          disabled={loading}
        >
          {loading ? "Updating..." : "Update"}
        </button>
      </DialogActions>
    </Dialog>
  );
};

export default EditCustodian;
