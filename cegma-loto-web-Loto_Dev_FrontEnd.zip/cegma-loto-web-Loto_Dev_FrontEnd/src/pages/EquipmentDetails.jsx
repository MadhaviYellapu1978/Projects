/* eslint-disable */
import React from "react";
import { Navigate, useLocation } from "react-router-dom";
import Navbar from "../components/Navbar";
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Button,
  Card,
  Grid,
  Typography,
} from "@mui/material";
import { GridExpandMoreIcon } from "@mui/x-data-grid";
import { useNavigate } from "react-router-dom";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import DownloadIcon from "@mui/icons-material/Download"; // Import download icon

const imageStyles = {
  width: "20vh",
  height: "20vh",
  marginTop: 10,
  cursor: "pointer",
};

const EquipmentDetails = () => {
  const location = useLocation();
  const { state } = location;
  const data = state?.state;
  console.log(state, "state");
  console.log(location, "location");

  const searchParams = new URLSearchParams(window.location.search);
  const tokenValue = searchParams.get("token");
  const navigate = useNavigate();

  if (!state) {
    return <Navigate to={`/loto/roleManagement/?token=${tokenValue}`} />;
  }

  // Function to handle QR image download
  const handleDownload = (url, filename) => {
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div>
      <Navbar token={tokenValue} />
      <div>
        <Typography className="px-10">
          <Button
            onClick={() => navigate(-1)}
            startIcon={
              <ArrowBackIcon
                style={{ height: 30, width: 30, color: "black" }}
              />
            }
            sx={{ mt: 2, mb: 2, mr: 1 }}
          ></Button>
          <strong>Equipment Details: </strong>
        </Typography>
        <Card
          sx={{
            maxHeight: "80vh",
            overflowY: "scroll",
            p: 5,
            maxWidth: "100%",
          }}
        >
          <Grid container spacing={3}>
            <Grid item xs={12} sm={6}  >
              <Typography style={{ marginTop: 2 }} >
                <strong>Equipment ID:</strong>
                <br />
                {data.equipmentId}
              </Typography>
              <Typography style={{ marginTop: 2 }}>
                <strong>Equipment Name:</strong>
                <br />
                {data.equipmentName}
              </Typography>
              <Typography style={{ marginTop: 2 }}>
                <strong>Latitude:</strong>
                <br />
                {data.latitude}
              </Typography>
              <Typography style={{ marginTop: 2 }}>
                <strong>Location:</strong>
                <br />
                {data.location}
              </Typography>
              <Typography style={{ marginTop: 2 }}>
                <strong>Longitude:</strong>
                <br />
                {data.longitude}
              </Typography>
              <Typography style={{ marginTop: 2 }}>
                <strong>Last Tested Date:</strong>
                <br />
                {data.lastTestedDate}
              </Typography>
            </Grid>
            <Grid item xs={12} sm={3}   >
              <Typography style={{ marginTop: 2 }}>
                <strong>Equipment Image:</strong>
                <br />
                {data.equipmentImgPath ? (
                  <img
                    src={data.equipmentImgPath}
                    alt="Equipment"
                    style={imageStyles}
                  />
                ) : (
                  <Typography>No image found</Typography>
                )}
              </Typography>
            </Grid>
            <Grid item xs={12} sm={3}>
              <Typography style={{ marginTop: 2 }}>
                <strong>QR Image:</strong>
                <br />
                {data.qr_image ? (
                  <img
                    src={data.qr_image}
                    alt="QR Code"
                    style={imageStyles}
                  />
                ) : (
                  <Typography>No image found</Typography>
                )}
              </Typography>
            </Grid>
          </Grid>
        </Card>
      </div>

      <div className="mt-10">
        <Typography className="px-10">
          <strong>Machines & Isolation Points Details: </strong>
        </Typography>
        <Card
          sx={{
            maxHeight: "80vh",
            overflowY: "scroll",
            p: 5,
            maxWidth: "100%",
            marginTop: "10px"
          }}
        >
          {data.machines &&
            data.machines.length > 0 &&
            data.machines.map((machine, index) => (
              <Accordion key={index}>
                <AccordionSummary
                  expandIcon={<GridExpandMoreIcon />}
                  aria-controls={`panel${index}-content`}
                  id={`panel${index}-header`}
                >
                  <Grid container spacing={2}>
                    <Grid item xs={12} sm={6} >
                      <Typography>
                        <strong>Machine Details:</strong>
                        <br />
                        Machine Name: {machine.machineName}
                        <br />
                        Machine Latitude: {machine.machine_lat}
                        <br />
                        Machine Longitude: {machine.machine_long}
                        <br />
                        Machine ID: {machine.machineId}
                      </Typography>
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <Grid container spacing={2}>
                        <Grid item xs={12} sm={6}>
                          <Typography>
                            <strong>Machine Image:</strong>
                            <br />
                            {machine.machine_image ? (
                              <img
                                src={machine.machine_image}
                                alt="Machine"
                                style={imageStyles}
                              />
                            ) : (
                              <Typography>No image found</Typography>
                            )}
                          </Typography>
                        </Grid>
                        <Grid item xs={12} sm={6}>
                          <Typography>
                            <strong>QR Image:</strong>
                            <br />
                            {machine.machine_qr_image ? (
                              <img
                                src={machine.machine_qr_image}
                                alt="QR Code"
                                style={imageStyles}
                              />
                            ) : (
                              <Typography>No image found</Typography>
                            )}
                          </Typography>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </AccordionSummary>
                <AccordionDetails>
                  {machine.isolationPoints &&
                  machine.isolationPoints.length > 0 ? (
                    <Grid container spacing={2}>
                      {machine.isolationPoints.map((isolationPoint, idx) => (
                        <Grid item xs={12} key={idx}>
                          <Accordion>
                            <AccordionSummary
                              expandIcon={<GridExpandMoreIcon />}
                              aria-controls={`sub-panel${idx}-content`}
                              id={`sub-panel${idx}-header`}
                            >
                              <Typography>
                                <strong>Isolation Point Details: </strong>
                              </Typography>
                            </AccordionSummary>
                            <AccordionDetails>
                              <Grid container spacing={2}>
                                <Grid item xs={12} sm={6}>
                                  <Typography>
                                    Isolation Name:{" "}
                                    {isolationPoint.isolationName}
                                    <br />
                                    Isolation ID: {isolationPoint.isolationId}
                                    <br />
                                    Isolation Latitude:{" "}
                                    {isolationPoint.iso_lat}
                                    <br />
                                    Isolation Longitude:{" "}
                                    {isolationPoint.iso_long}
                                  </Typography>
                                </Grid>
                                <Grid item xs={6}>
                                  <Grid container spacing={2}>
                                    <Grid item xs={12} sm={6}>
                                      <Typography>
                                        <strong>Isolation Image:</strong>
                                        <br />
                                        {isolationPoint.iso_image ? (
                                          <img
                                            src={isolationPoint.iso_image}
                                            alt="Isolation"
                                            style={imageStyles}
                                          />
                                        ) : (
                                          <Typography>
                                            No image found
                                          </Typography>
                                        )}
                                      </Typography>
                                    </Grid>
                                    <Grid item xs={12} sm={6}>
                                      <Typography>
                                        <strong>QR Image:</strong>
                                        <br />
                                        {isolationPoint.iso_qr_image ? (
                                          <img
                                            src={isolationPoint.iso_qr_image}
                                            alt="QR Code"
                                            style={imageStyles}
                                          />
                                        ) : (
                                          <Typography>
                                            No image found
                                          </Typography>
                                        )}
                                        {/* Download Button beside Isolation Point Image */}
                                      {/* <Button
                                        startIcon={<DownloadIcon />}
                                        sx={{ mt: 2, ml: 10 }}
                                        onClick={() =>
                                          handleDownload(
                                            isolationPoint.iso_qr_image ||
                                              "defaultQR.png",
                                            `${isolationPoint.isolationName}_QR.png`
                                          )
                                        }
                                      >
                                        Download QR
                                      </Button> */}

                                      </Typography>
                                    </Grid>
                                  </Grid>
                                </Grid>
                              </Grid>
                            </AccordionDetails>
                          </Accordion>
                        </Grid>
                      ))}
                    </Grid>
                  ) : (
                    <Typography>
                      <strong>No isolation details found</strong>
                    </Typography>
                  )}
                </AccordionDetails>
              </Accordion>
            ))}
        </Card>
      </div>
    </div>
  );
};

export default EquipmentDetails;
