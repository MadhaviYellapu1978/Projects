import React, {
  useState,
  useEffect,
  useCallback,
  useMemo,
  useRef,
} from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useLocation } from "react-router-dom";
import ReactFlow, {
  Background,
  Controls,
  MiniMap,
  useNodesState,
  useEdgesState,
  addEdge,
  Handle,
  Position,
  MarkerType,
} from "reactflow";
import "reactflow/dist/style.css";
import html2canvas from "html2canvas";
import Navbar from "../components/Navbar";
import { workflowArch } from "../assets";
import {
  apiCall,
  decryptAesBase64,
  encryptAesBase64,
  isValidToken,
} from "../utils";
import { workflowEndPoints, methods, userEndPoints } from "../constants";
import { setUser, setToken } from "../features/auth/authSlice";

// Custom Node Component for React Flow with enhanced styling
const CustomNode = ({ data, selected }) => {
  // Generate gradient color based on step number
  const getGradientColor = (stepNumber) => {
    const colors = [
      "from-blue-500 to-blue-600",
      "from-indigo-500 to-indigo-600",
      "from-purple-500 to-purple-600",
      "from-pink-500 to-pink-600",
      "from-rose-500 to-rose-600",
      "from-orange-500 to-orange-600",
      "from-amber-500 to-amber-600",
      "from-yellow-500 to-yellow-600",
    ];
    return colors[(stepNumber - 1) % colors.length];
  };

  const gradientClass = getGradientColor(data.stepNumber);

  return (
    <div
      className={`bg-white border-2 rounded-xl shadow-lg p-4 min-w-[220px] transition-all duration-300 ${
        selected
          ? "border-blue-500 shadow-2xl scale-105 ring-4 ring-blue-200"
          : "border-gray-200 hover:border-blue-300 hover:shadow-xl"
      }`}
      style={{
        background: selected
          ? "linear-gradient(135deg, #ffffff 0%, #f0f9ff 100%)"
          : "#ffffff",
      }}
    >
      {/* Input Handle */}
      <Handle
        type="target"
        position={Position.Top}
        className="w-5 h-5 bg-gradient-to-br from-blue-500 to-blue-600 border-3 border-white shadow-lg"
        style={{ top: -10 }}
      />

      <div className="flex justify-between items-center mb-3">
        <div className="flex items-center gap-3">
          <div
            className={`w-10 h-10 bg-gradient-to-br ${gradientClass} text-white rounded-full flex items-center justify-center text-sm font-bold shadow-md ring-2 ring-white`}
          >
            {data.stepNumber}
          </div>
          <span className="font-bold text-gray-800 text-base">
            {data.label}
          </span>
        </div>
        <div className="flex gap-1">
          <button
            onClick={() => data.onRemove(data.stepId)}
            className="text-gray-400 hover:text-red-500 p-1.5 rounded-md hover:bg-red-50 transition-all duration-200"
            title="Delete step"
          >
            <svg
              className="w-4 h-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
              />
            </svg>
          </button>
          <button
            onClick={() => data.onCopy(data.stepId)}
            className="text-gray-400 hover:text-blue-500 p-1.5 rounded-md hover:bg-blue-50 transition-all duration-200"
            title="Copy step"
          >
            <svg
              className="w-4 h-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"
              />
            </svg>
          </button>
        </div>
      </div>
      <div className="space-y-1.5 mt-2 pt-2 border-t border-gray-100">
        {data.actions.map((action, actionIndex) => (
          <div
            key={actionIndex}
            className="flex items-center text-gray-700 hover:text-blue-700 transition-colors duration-200"
          >
            <div
              className={`w-2.5 h-2.5 bg-gradient-to-br ${gradientClass} rounded-full mr-2.5 shadow-sm`}
            ></div>
            <span className="text-xs font-medium">{action}</span>
          </div>
        ))}
      </div>

      {/* Output Handle */}
      <Handle
        type="source"
        position={Position.Bottom}
        className="w-5 h-5 bg-gradient-to-br from-blue-500 to-blue-600 border-3 border-white shadow-lg"
        style={{ bottom: -10 }}
      />
    </div>
  );
};

const nodeTypes = {
  custom: CustomNode,
};

const WorkflowOrchestration = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedAction, setSelectedAction] = useState(null);
  const [workflowActions, setWorkflowActions] = useState([]);
  const [workflowActionsData, setWorkflowActionsData] = useState([]);
  const [isLoadingActions, setIsLoadingActions] = useState(false);
  const [actionsError, setActionsError] = useState(null);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [hasBeenSaved, setHasBeenSaved] = useState(false); // Track if workflow has been saved

  const user = useSelector((state) => state.authSlice.user);

  // Get token from URL parameters first, then fallback to localStorage
  const searchParams = new URLSearchParams(window.location.search);
  const tokenFromUrl = searchParams.get("token");
  const tokenFromStorage = localStorage.getItem("token");
  const token = tokenFromUrl || tokenFromStorage || "";

  // Ensure token is in URL - update URL if token exists but not in URL
  useEffect(() => {
    if (token && !tokenFromUrl) {
      // Token exists in localStorage but not in URL, update URL
      const newSearchParams = new URLSearchParams(window.location.search);
      newSearchParams.set("token", token);
      navigate(
        {
          pathname: location.pathname,
          search: newSearchParams.toString(),
        },
        { replace: true }
      );
    }
  }, [token, tokenFromUrl, navigate, location.pathname]);

  // Verify token and fetch user data on component mount
  useEffect(() => {
    const verifyTokenOnMount = async () => {
      // Get token from localStorage (which may have been updated from URL)
      const currentToken = localStorage.getItem("token") || "";

      // Check if token is valid before making API calls
      if (currentToken && isValidToken(currentToken)) {
        try {
          const data = await apiCall(userEndPoints.verifyToken, methods.post, {
            token: currentToken,
          });

          if (data && data.valid) {
            // Fetch user data after token verification
            try {
              const userData = await apiCall(
                `${userEndPoints.getUser}${data.userId}`,
                methods.get
              );
              dispatch(setUser(userData));
              dispatch(setToken(currentToken));
            } catch (error) {
              console.error("Failed to fetch user data:", error);
            }
          } else {
            console.warn("Token verification failed - invalid token");
          }
        } catch (error) {
          console.error("Token verification failed:", error);
        }
      } else {
        console.warn("No valid token found");
      }
    };

    verifyTokenOnMount();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const [workflowSteps, setWorkflowSteps] = useState([]);
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [nodeIdCounter, setNodeIdCounter] = useState(1);
  const [selectedNodeIds, setSelectedNodeIds] = useState([]); // Track multiple selected nodes (for branches)
  const reactFlowRef = useRef(null); // Ref for React Flow container to capture for download

  // Fetch main actions using getMainActions endpoint
  useEffect(() => {
    const fetchActions = async () => {
      setIsLoadingActions(true);
      setActionsError(null);
      try {
        const token = localStorage.getItem("token");
        console.log("Fetching main actions with token:", token);

        // First get the encrypted data
        const encryptedRes = await apiCall(
          workflowEndPoints.orgGetMainActions,
          methods.get,
          null,
          token
        );

        console.log("Encrypted response:", encryptedRes);

        if (!encryptedRes?.data) {
          throw new Error("No encrypted data received");
        }

        // Decrypt the data locally using SubtleCrypto helper
        let decryptedRes;
        try {
          decryptedRes = await decryptAesBase64(encryptedRes.data);
        } catch (e) {
          console.error("Local decryption failed:", e);
          throw new Error("Failed to decrypt data locally");
        }

        console.log("Decrypted string:", decryptedRes);

        // Parse the decrypted JSON response (handle array/object/string)
        let actions = [];
        if (Array.isArray(decryptedRes)) {
          actions = decryptedRes;
        } else if (decryptedRes && Array.isArray(decryptedRes.data)) {
          actions = decryptedRes.data;
        } else if (typeof decryptedRes === "string") {
          try {
            const parsed = JSON.parse(decryptedRes);
            actions = Array.isArray(parsed)
              ? parsed
              : Array.isArray(parsed.data)
              ? parsed.data
              : [];
          } catch (e) {
            console.error("Failed to parse decrypted response string:", e);
            throw new Error("Invalid decrypted data format");
          }
        } else if (decryptedRes && typeof decryptedRes === "object") {
          const maybeArray =
            decryptedRes.body ||
            decryptedRes.result ||
            decryptedRes.payload ||
            decryptedRes.data;
          if (Array.isArray(maybeArray)) actions = maybeArray;
        } else {
          throw new Error("Invalid decrypted data format");
        }

        console.log("Actions array:", actions);

        // Store full actions data for ID/enum lookup
        setWorkflowActionsData(actions.filter(Boolean));

        // Extract the action field from each item
        const actionsList = actions.filter(Boolean).map((item) => {
          console.log("Processing action item:", item);
          return item.action;
        });

        console.log("Final actionsList:", actionsList);

        // Filter out any undefined/null values and ensure we have actions
        const validActions = actionsList.filter(Boolean);
        if (validActions.length === 0) {
          console.warn("No valid actions found in response");
          setActionsError("No actions available");
        } else {
          setWorkflowActions(validActions);
        }
      } catch (err) {
        console.error("Failed to fetch workflow actions:", err);
        setActionsError(err.message || "Failed to load actions");
      } finally {
        setIsLoadingActions(false);
      }
    };

    fetchActions();
  }, []);

  // Fetch saved workflow steps on component mount
  useEffect(() => {
    const fetchWorkflowSteps = async () => {
      if (!user?.org?.org_id) {
        return;
      }

      try {
        const token = localStorage.getItem("token");
        const orgId = user.org.org_id;

        const fetchUrl = `${
          workflowEndPoints.getFinalAssignedByOrgId
        }?org_id=${encodeURIComponent(orgId)}`;
        const fetchResponse = await apiCall(fetchUrl, methods.get, null, token);

        if (fetchResponse?.status >= 400) {
          // If fetch fails, don't show error, just return
          return;
        }

        // Decrypt the response if needed
        let decryptedFetchResponse;
        if (fetchResponse?.data && typeof fetchResponse.data === "string") {
          try {
            decryptedFetchResponse = await decryptAesBase64(fetchResponse.data);
            if (typeof decryptedFetchResponse === "string") {
              try {
                decryptedFetchResponse = JSON.parse(decryptedFetchResponse);
              } catch (e) {
                // If parsing fails, use decrypted string as is
              }
            }
          } catch (e) {
            // If decryption fails, maybe response.data is already plain JSON
            if (typeof fetchResponse.data === "object") {
              decryptedFetchResponse = fetchResponse.data;
            } else {
              return;
            }
          }
        } else {
          decryptedFetchResponse = fetchResponse;
        }

        // Extract actions array from response
        let actionsArray = [];
        if (Array.isArray(decryptedFetchResponse)) {
          actionsArray = decryptedFetchResponse;
        } else if (
          decryptedFetchResponse?.actions &&
          Array.isArray(decryptedFetchResponse.actions)
        ) {
          actionsArray = decryptedFetchResponse.actions;
        } else if (
          decryptedFetchResponse?.data &&
          Array.isArray(decryptedFetchResponse.data)
        ) {
          actionsArray = decryptedFetchResponse.data;
        }

        // Convert actions array to workflow steps format - group actions into steps
        // Actions with status=true start a new step, actions with status=false continue the current step
        if (actionsArray.length > 0 && workflowActionsData.length > 0) {
          const newWorkflowSteps = [];
          let currentStep = null;
          let stepCounter = 1;

          actionsArray.forEach((actionItem, index) => {
            const actionName =
              actionItem?.action || actionItem?.action_name || "";

            // Find the action name in workflowActionsData to get the display name
            const actionData = workflowActionsData.find(
              (item) =>
                item.action === actionName ||
                item.enum === actionItem?.enum ||
                item.action_id === actionItem?.enum
            );

            const displayActionName = actionData?.action || actionName;

            if (!displayActionName) return;

            // If this action has status=true or it's the first action, start a new step
            if (actionItem?.status === true || index === 0) {
              // Save previous step if exists
              if (currentStep) {
                newWorkflowSteps.push(currentStep);
              }
              // Start a new step
              currentStep = {
                id: stepCounter++,
                name: `Step ${stepCounter - 1}`,
                actions: [displayActionName],
              };
            } else if (currentStep) {
              // Add action to current step
              currentStep.actions.push(displayActionName);
            } else {
              // If no current step, create one
              currentStep = {
                id: stepCounter++,
                name: `Step ${stepCounter - 1}`,
                actions: [displayActionName],
              };
            }
          });

          // Add the last step if exists
          if (currentStep) {
            newWorkflowSteps.push(currentStep);
          }

          // Update workflow steps state
          if (newWorkflowSteps.length > 0) {
            setWorkflowSteps(newWorkflowSteps);
            // Update nodeIdCounter to avoid ID conflicts
            const maxId = Math.max(...newWorkflowSteps.map((s) => s.id));
            setNodeIdCounter(maxId + 1);
            // Mark as saved since we fetched from backend
            setHasBeenSaved(true);
          }
        }
      } catch (fetchError) {
        // If fetch fails, don't show error, just return silently
        return;
      }
    };

    fetchWorkflowSteps();
  }, [user?.org?.org_id, workflowActionsData]);

  const filteredActions = workflowActions.filter((action) =>
    action.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleActionToggle = (action) => {
    if (selectedAction === action) {
      setSelectedAction(null);
    } else {
      setSelectedAction(action);
    }
  };

  const handleAddStep = () => {
    if (selectedAction) {
      const newStepId = nodeIdCounter;

      // Check if branch nodes are selected (filter to only branch nodes)
      const selectedBranchNodes = selectedNodeIds
        .map((nodeId) => nodes.find((n) => n.id === nodeId))
        .filter((node) => node && node.data.isBranch);

      // Check if regular (non-branch) nodes are selected
      const selectedRegularNodes = selectedNodeIds
        .map((nodeId) => nodes.find((n) => n.id === nodeId))
        .filter((node) => node && !node.data.isBranch);

      // Store all selected branch node IDs for connection
      // If multiple branch nodes are selected, connect from all of them
      const connectFromBranches =
        selectedBranchNodes.length > 0
          ? selectedBranchNodes.map((node) => node.id)
          : null;

      // Store the first selected regular node ID for connection (if any)
      // If a single regular node is selected, connect from that node
      const connectFromStep =
        selectedRegularNodes.length > 0 ? selectedRegularNodes[0].id : null;

      // Determine branchFlowId:
      // 1. If connected from branches, use the first branch's stepId as the flow identifier
      // 2. If connected from a regular step, inherit its branchFlowId (if it has one)
      let branchFlowId = null;
      if (connectFromBranches && connectFromBranches.length > 0) {
        // Extract the branch stepId from the first branch node ID (e.g., "node-branch-123-0" -> "branch-123-0")
        const firstBranchNodeId = connectFromBranches[0];
        const branchNode = nodes.find((n) => n.id === firstBranchNodeId);
        if (branchNode && branchNode.data.stepId) {
          // Use the branch stepId as the flow identifier (e.g., "branch-123-0")
          branchFlowId = branchNode.data.stepId;
        }
      } else if (connectFromStep) {
        // If connected from a regular step, inherit its branchFlowId
        const sourceStep = workflowSteps.find(
          (s) =>
            s.id === nodes.find((n) => n.id === connectFromStep)?.data.stepId
        );
        if (sourceStep?.branchFlowId) {
          branchFlowId = sourceStep.branchFlowId;
        }
      }

      const newStep = {
        id: newStepId,
        name: `Step ${newStepId}`,
        actions: [selectedAction],
        ...(connectFromBranches && { connectFromBranches }), // Store multiple branch connections
        ...(connectFromStep && { connectFromStep }), // Store regular step connection
        ...(branchFlowId && { branchFlowId }), // Store branch flow identifier
      };

      // Add to workflowSteps
      setWorkflowSteps([...workflowSteps, newStep]);

      // Create new node for React Flow - position it below existing nodes
      const lastNode = nodes.length > 0 ? nodes[nodes.length - 1] : null;
      const newNode = {
        id: `node-${newStepId}`,
        type: "custom",
        position: lastNode
          ? {
              x: lastNode.position.x,
              y: lastNode.position.y + 220,
            }
          : {
              x: 400,
              y: 100,
            },
        data: {
          label: newStep.name,
          stepNumber: workflowSteps.length + 1,
          stepId: newStepId,
          actions: newStep.actions,
          onRemove: handleRemoveStep,
          onCopy: handleCopyStep,
        },
      };

      setNodes((nds) => [...nds, newNode]);
      setNodeIdCounter(newStepId + 1);
      setSelectedAction(null);
      // Clear selection after adding step
      setSelectedNodeIds([]);
    }
  };

  const handleContinue = () => {
    if (selectedAction) {
      const newStepId = nodeIdCounter;

      // Check if branch nodes are selected (filter to only branch nodes)
      const selectedBranchNodes = selectedNodeIds
        .map((nodeId) => nodes.find((n) => n.id === nodeId))
        .filter((node) => node && node.data.isBranch);

      // Check if regular (non-branch) nodes are selected
      const selectedRegularNodes = selectedNodeIds
        .map((nodeId) => nodes.find((n) => n.id === nodeId))
        .filter((node) => node && !node.data.isBranch);

      // Store all selected branch node IDs for connection
      // If multiple branch nodes are selected, connect from all of them
      const connectFromBranches =
        selectedBranchNodes.length > 0
          ? selectedBranchNodes.map((node) => node.id)
          : null;

      // Store the first selected regular node ID for connection (if any)
      // If a single regular node is selected, connect from that node
      const connectFromStep =
        selectedRegularNodes.length > 0 ? selectedRegularNodes[0].id : null;

      // Determine branchFlowId:
      // 1. If connected from branches, use the first branch's stepId as the flow identifier
      // 2. If connected from a regular step, inherit its branchFlowId (if it has one)
      let branchFlowId = null;
      if (connectFromBranches && connectFromBranches.length > 0) {
        // Extract the branch stepId from the first branch node ID (e.g., "node-branch-123-0" -> "branch-123-0")
        const firstBranchNodeId = connectFromBranches[0];
        const branchNode = nodes.find((n) => n.id === firstBranchNodeId);
        if (branchNode && branchNode.data.stepId) {
          // Use the branch stepId as the flow identifier (e.g., "branch-123-0")
          branchFlowId = branchNode.data.stepId;
        }
      } else if (connectFromStep) {
        // If connected from a regular step, inherit its branchFlowId
        const sourceStep = workflowSteps.find(
          (s) =>
            s.id === nodes.find((n) => n.id === connectFromStep)?.data.stepId
        );
        if (sourceStep?.branchFlowId) {
          branchFlowId = sourceStep.branchFlowId;
        }
      }

      const newStep = {
        id: newStepId,
        name: `Step ${workflowSteps.length + 1}`,
        actions: [selectedAction],
        ...(connectFromBranches && { connectFromBranches }), // Store multiple branch connections
        ...(connectFromStep && { connectFromStep }), // Store regular step connection
        ...(branchFlowId && { branchFlowId }), // Store branch flow identifier
      };

      // Add to workflowSteps
      setWorkflowSteps([...workflowSteps, newStep]);
      setNodeIdCounter(newStepId + 1);
      setSelectedAction(null);
      // Clear selection after adding step
      setSelectedNodeIds([]);
    }
  };

  const handleCondition = () => {
    if (!selectedAction) {
      alert("Please select an action first");
      return;
    }

    // Determine which step to use as parent
    let stepId = null;
    let selectedStep = null;

    // Use the first selected node (if any)
    if (selectedNodeIds.length > 0) {
      const firstSelectedNode = nodes.find((n) => n.id === selectedNodeIds[0]);
      if (firstSelectedNode) {
        stepId = firstSelectedNode.data.stepId;
        selectedStep = workflowSteps.find((s) => s.id === stepId);
      }
    }

    // If no node is selected or node not found, use the most recent step (last step)
    if (!selectedStep && workflowSteps.length > 0) {
      selectedStep = workflowSteps[workflowSteps.length - 1];
      stepId = selectedStep.id;
    }

    if (!selectedStep) {
      alert("No step found. Please add a step first before adding conditions.");
      return;
    }

    // Convert the selected step to a condition step (if not already)
    // Add the condition action as a branch option (not a step)
    const updatedSteps = workflowSteps.map((step) => {
      if (step.id === stepId) {
        // If it's already a condition step, add the new action as a branch option
        // If not, convert it to a condition step with existing actions as parent and new action as branch
        if (step.isCondition === true) {
          // Already a condition step - add the new action to conditionBranches only
          const conditionBranches = step.conditionBranches || [];
          return {
            ...step,
            conditionBranches: [...conditionBranches, selectedAction], // Only condition actions go here
          };
        } else {
          // Convert to condition step: existing actions stay as parent, new action is added as condition branch
          return {
            ...step,
            isCondition: true,
            conditionBranches: [selectedAction], // Store condition branches separately
            // actions array keeps original actions for parent display
          };
        }
      }
      return step;
    });
    setWorkflowSteps(updatedSteps);
    setSelectedAction(null);
  };

  const handleRemoveStep = async (stepId) => {
    // Get org_id for API call if workflow has been saved
    const orgId = user?.org?.org_id || user?.org_id || "";

    // If workflow has been saved, call delete API
    if (hasBeenSaved && orgId) {
      try {
        const token = localStorage.getItem("token") || "";
        const deleteUrl = `${
          workflowEndPoints.deleteFinalAssignedByOrgId
        }?org_id=${encodeURIComponent(orgId)}`;
        const deleteResponse = await apiCall(
          deleteUrl,
          methods.delete,
          null,
          token
        );

        if (deleteResponse?.status >= 400) {
          const errorData = deleteResponse.data;
          const errorMessage =
            errorData?.error ||
            errorData?.message ||
            errorData?.details ||
            JSON.stringify(errorData) ||
            "Failed to delete workflow steps";
          alert(`Failed to delete workflow steps: ${errorMessage}`);
          return;
        }

        // Decrypt the response if needed
        let decryptedResponse;
        if (deleteResponse?.data && typeof deleteResponse.data === "string") {
          try {
            decryptedResponse = await decryptAesBase64(deleteResponse.data);
            if (typeof decryptedResponse === "string") {
              try {
                decryptedResponse = JSON.parse(decryptedResponse);
              } catch (e) {
                // If parsing fails, use decrypted string as is
              }
            }
          } catch (e) {
            // If decryption fails, maybe response.data is already plain JSON
            if (typeof deleteResponse.data === "object") {
              decryptedResponse = deleteResponse.data;
            }
          }
        } else {
          decryptedResponse = deleteResponse;
        }

        // Check if response indicates success
        if (decryptedResponse?.error || decryptedResponse?.success === false) {
          alert(
            decryptedResponse.error ||
              decryptedResponse.message ||
              "Failed to delete workflow steps"
          );
          return;
        }
      } catch (err) {
        let errorMessage = "Unknown error";
        if (err.response?.data) {
          const errorData = err.response.data;
          if (typeof errorData === "object" && errorData !== null) {
            errorMessage =
              errorData.error ||
              errorData.message ||
              errorData.details ||
              JSON.stringify(errorData);
          } else if (typeof errorData === "string" && errorData.trim() !== "") {
            errorMessage = errorData;
          } else {
            errorMessage = String(errorData);
          }
        } else {
          errorMessage = err.message || "Unknown error";
        }
        alert(`Failed to delete workflow steps: ${errorMessage}`);
        return;
      }
    }

    // Check if this is a branch node (stepId starts with "branch-")
    if (stepId && typeof stepId === "string" && stepId.startsWith("branch-")) {
      // Extract parent step ID and branch index from branch stepId
      // Format: "branch-{parentStepId}-{branchIndex}"
      const parts = stepId.split("-");
      if (parts.length >= 3) {
        const parentStepId = parseInt(parts[1]);
        const branchIndex = parseInt(parts[2]);

        // Find the parent step
        const parentStep = workflowSteps.find((s) => s.id === parentStepId);
        if (
          parentStep &&
          parentStep.isCondition &&
          parentStep.conditionBranches
        ) {
          // Get the branch node ID that will be deleted
          const deletedBranchNodeId = `node-${stepId}`;

          // Remove the specific branch from conditionBranches
          const updatedBranches = parentStep.conditionBranches.filter(
            (_, index) => index !== branchIndex
          );

          // Update the parent step and clean up steps connected from the deleted branch
          const updatedSteps = workflowSteps.map((step) => {
            if (step.id === parentStepId) {
              // If no branches remain, optionally convert back to regular step
              // Or keep as condition step with empty branches
              if (updatedBranches.length === 0) {
                // Convert back to regular step (remove isCondition and conditionBranches)
                const { isCondition, conditionBranches, ...rest } = step;
                return rest;
              } else {
                // Update conditionBranches
                return {
                  ...step,
                  conditionBranches: updatedBranches,
                };
              }
            }
            // Clean up steps that were connected from the deleted branch
            // Handle both single branch (connectFromBranch) and multiple branches (connectFromBranches)
            if (step.connectFromBranch === deletedBranchNodeId) {
              const { connectFromBranch, ...rest } = step;
              return rest;
            }
            if (
              step.connectFromBranches &&
              Array.isArray(step.connectFromBranches)
            ) {
              const updatedBranches = step.connectFromBranches.filter(
                (branchId) => branchId !== deletedBranchNodeId
              );
              if (updatedBranches.length === 0) {
                // Remove connectFromBranches if empty
                const { connectFromBranches, ...rest } = step;
                return rest;
              } else {
                return {
                  ...step,
                  connectFromBranches: updatedBranches,
                };
              }
            }
            return step;
          });

          // Update workflowSteps - the useEffect will handle node repositioning and edge recreation
          setWorkflowSteps(updatedSteps);
          return; // Exit early, no need to renumber or update counter
        }
      }
    }

    // Regular step deletion (not a branch)
    const updatedSteps = workflowSteps.filter((step) => step.id !== stepId);

    // Renumber the step names to reflect their new positions
    const renumberedSteps = updatedSteps.map((step, index) => ({
      ...step,
      name: `Step ${index + 1}`,
    }));

    // Update workflowSteps - the useEffect will handle node repositioning and edge recreation
    setWorkflowSteps(renumberedSteps);

    // Update nodeIdCounter if needed (to prevent ID conflicts)
    if (renumberedSteps.length > 0) {
      const maxId = Math.max(...renumberedSteps.map((s) => s.id));
      setNodeIdCounter(maxId + 1);
    } else {
      // Reset counter if no steps remain
      setNodeIdCounter(1);
    }
  };

  const handleCopyStep = (stepId) => {
    const stepToCopy = workflowSteps.find((step) => step.id === stepId);
    if (stepToCopy) {
      const newStepId = nodeIdCounter;
      const newStep = {
        id: newStepId,
        name: stepToCopy.name,
        actions: [...stepToCopy.actions],
        ...(stepToCopy.isCondition && {
          isCondition: true,
          conditionBranches: stepToCopy.conditionBranches
            ? [...stepToCopy.conditionBranches]
            : [],
        }),
      };

      // Add to workflowSteps
      setWorkflowSteps([...workflowSteps, newStep]);

      // Find the original node position and place copy below it
      const originalNode = nodes.find((node) => node.data.stepId === stepId);
      const newNode = {
        id: `node-${newStepId}`,
        type: "custom",
        position: originalNode
          ? {
              x: originalNode.position.x,
              y: originalNode.position.y + 220,
            }
          : {
              x: 400,
              y: 100,
            },
        data: {
          label: newStep.name,
          stepNumber: workflowSteps.length + 1,
          stepId: newStepId,
          actions: newStep.actions,
          onRemove: handleRemoveStep,
          onCopy: handleCopyStep,
        },
      };

      setNodes((nds) => [...nds, newNode]);
      setNodeIdCounter(newStepId + 1);
    }
  };

  const onConnect = useCallback(
    (params) => setEdges((eds) => addEdge(params, eds)),
    [setEdges]
  );

  // Helper function to determine if a step should branch and what branches to create
  // Note: "Assign Custodian", "Assign Issuer", and "Assign Isolators" are now treated as regular sequential nodes
  const getBranchActions = (stepActions) => {
    // Removed "Assign Custodian", "Assign Issuer", and "Assign Isolators" from branch map
    // They will now render as individual sequential nodes
    const branchMap = {
      // Add other branching actions here if needed in the future
    };

    for (const [assignAction, branchActions] of Object.entries(branchMap)) {
      if (stepActions.includes(assignAction)) {
        return branchActions;
      }
    }
    return null;
  };

  // Helper function to get the next action for an accept branch
  const getNextAction = (acceptAction) => {
    const acceptToNextMap = {
      "Custodian Accept": "Assign Issuer",
      "Issuer Accept": "Assign Isolators",
      "Isolator Accept": "Start Isolation",
      "All Isolators Accepted": "Start Isolation",
    };
    return acceptToNextMap[acceptAction] || null;
  };

  // Convert workflowSteps to nodes when they change
  useEffect(() => {
    if (workflowSteps.length === 0) {
      setNodes([]);
      setEdges([]);
      return;
    }

    const allNodes = [];
    const branchEdges = [];
    let verticalOffset = 0;
    let stepCounter = 1;

    workflowSteps.forEach((step, index) => {
      // Safety check: ensure step exists
      if (!step) return;

      const existingNode = nodes.find((node) => node.data.stepId === step.id);

      // Check if this step should branch (predefined branches or condition steps)
      const branchActions = getBranchActions(step.actions || []);
      const isConditionStep = step.isCondition === true;

      if (branchActions || isConditionStep) {
        // For condition steps, use conditionBranches array (only condition actions)
        // For predefined branches, use branchActions
        const branchesToUse = isConditionStep
          ? step.conditionBranches || [] // Only condition branches, not original actions
          : branchActions;

        // Create parent node
        // For condition steps, use step name as parent label (the selected step becomes parent)
        // For predefined branches, show step name
        const parentLabel = step.name;

        const parentNode = {
          id: `node-${step.id}`,
          type: "custom",
          position: {
            x: 400,
            y: 100 + verticalOffset * 220,
          },
          data: {
            label: parentLabel,
            stepNumber: stepCounter++,
            stepId: step.id,
            actions: step.actions || [], // Original actions for parent display
            onRemove: handleRemoveStep,
            onCopy: handleCopyStep,
          },
        };
        allNodes.push(parentNode);
        verticalOffset++;

        // Create branch nodes (side by side)
        // For condition steps: only conditionBranches are rendered as branches (parent keeps original actions)
        // For predefined branches: all actions are branches
        const branchStepIds = [];
        const branchesToRender = branchesToUse; // Only condition branches for condition steps

        const branchCount = branchesToRender.length;
        const shouldCreateBranches = branchCount > 0;

        if (shouldCreateBranches) {
          branchesToRender.forEach((branchAction, branchIndex) => {
            const branchStepId = `branch-${step.id}-${branchIndex}`;
            branchStepIds.push(branchStepId);

            // Calculate x position based on number of branches
            let xPosition;
            if (branchCount === 2) {
              // Two branches: left at x:200, right at x:600
              xPosition = branchIndex === 0 ? 200 : 600;
            } else if (branchCount === 3) {
              // Three branches: left at x:150, middle at x:400, right at x:650
              xPosition =
                branchIndex === 0 ? 150 : branchIndex === 1 ? 400 : 650;
            } else if (branchCount === 4) {
              // Four branches: evenly spaced from x:100 to x:700
              xPosition = 100 + branchIndex * 200;
            } else {
              // Default: evenly spaced (for 5+ branches)
              xPosition = 100 + branchIndex * 150;
            }

            const branchNode = {
              id: `node-${branchStepId}`,
              type: "custom",
              position: {
                x: xPosition,
                y: 100 + verticalOffset * 220,
              },
              data: {
                label: branchAction,
                stepNumber: stepCounter++,
                stepId: branchStepId,
                actions: [branchAction],
                onRemove: handleRemoveStep,
                onCopy: handleCopyStep,
                isBranch: true,
                parentStepId: step.id,
              },
            };
            allNodes.push(branchNode);

            // Create edge from parent to branch
            branchEdges.push({
              id: `edge-${step.id}-${branchStepId}`,
              source: `node-${step.id}`,
              target: `node-${branchStepId}`,
              type: "smoothstep",
              animated: true,
              style: {
                stroke: "#3B82F6",
                strokeWidth: 2.5,
                strokeDasharray: "5,5",
              },
              markerEnd: {
                type: MarkerType.ArrowClosed,
                color: "#3B82F6",
                width: 20,
                height: 20,
              },
            });
          });
          verticalOffset++;
        }
      } else {
        // Regular sequential node (not a condition step, not a predefined branch)
        const regularNode = {
          id: `node-${step.id}`,
          type: "custom",
          position: {
            x: 400,
            y: 100 + verticalOffset * 220,
          },
          data: {
            label: step.name || `Step ${stepCounter}`,
            stepNumber: stepCounter++,
            stepId: step.id,
            actions: step.actions || [],
            onRemove: handleRemoveStep,
            onCopy: handleCopyStep,
          },
        };
        allNodes.push(regularNode);
        verticalOffset++;
      }
    });

    // Improve node positioning based on actual parent-child relationships
    // Position nodes directly under their parent nodes for clear flow visualization
    const nodePositionMap = new Map(); // Map of nodeId -> {x, y}
    const processedNodes = new Set();
    const nodeToStepMap = new Map(); // Map node.id to step for quick lookup
    const occupiedPositions = new Map(); // Map of y -> Array of [minX, maxX] ranges to track overlaps
    const flowGroups = new Map(); // Map of flowId -> Set of nodeIds to track which nodes belong to which flow
    const NODE_WIDTH = 220; // Approximate node width
    const MIN_HORIZONTAL_GAP = 250; // Minimum gap between different flows horizontally (increased to prevent edge mixing)
    const VERTICAL_SPACING = 250; // Vertical spacing between nodes (reduced for shorter arrow lines)
    const FLOW_SEPARATION = 400; // Minimum separation between different flows to prevent edge mixing

    // Helper function to get flow ID for a node
    const getFlowId = (nodeId, step) => {
      if (!step) return null;
      // If node is in a branch flow, use branchFlowId
      if (step.branchFlowId) {
        return step.branchFlowId;
      }
      // If node is a branch node, use its parent step's branchFlowId or create one
      const node = allNodes.find((n) => n.id === nodeId);
      if (node?.data.isBranch && node.data.parentStepId) {
        const parentStep = workflowSteps.find(
          (s) => s.id === node.data.parentStepId
        );
        if (parentStep?.branchFlowId) {
          return parentStep.branchFlowId;
        }
        // Create a flow ID for this branch
        return `branch-${node.data.parentStepId}-${nodeId}`;
      }
      // For root nodes or nodes without branchFlowId, use their step ID as flow ID
      return step.id ? `flow-${step.id}` : null;
    };

    // Helper function to check if position is available and adjust if needed
    // Uses actual node boundaries for more accurate overlap detection
    // Ensures nodes in the same flow stay aligned and different flows are well separated
    const findAvailableX = (
      desiredX,
      y,
      nodeWidth = NODE_WIDTH,
      flowId = null
    ) => {
      const occupiedAtY = occupiedPositions.get(y) || [];
      const halfWidth = nodeWidth / 2;
      const minX = desiredX - halfWidth;
      const maxX = desiredX + halfWidth;
      const requiredGap = flowId ? MIN_HORIZONTAL_GAP : FLOW_SEPARATION; // Larger gap for different flows

      // Check if desired position overlaps with any existing node
      // Also check if it's too close to nodes from different flows
      const hasOverlap = occupiedAtY.some((occupiedRange) => {
        const [occupiedMin, occupiedMax, occupiedFlowId] = occupiedRange;
        const occupiedFlowIdSafe = occupiedFlowId || null;
        const occupiedCenter = (occupiedMin + occupiedMax) / 2;
        const occupiedHalfWidth = (occupiedMax - occupiedMin) / 2;

        // If same flow, use smaller gap; if different flow, use larger gap
        const isSameFlow =
          flowId && occupiedFlowIdSafe && flowId === occupiedFlowIdSafe;
        const gapRequired = isSameFlow ? MIN_HORIZONTAL_GAP : FLOW_SEPARATION;

        // Check if there's any overlap or insufficient gap
        return (
          (minX <= occupiedMax && maxX >= occupiedMin) ||
          Math.abs(desiredX - occupiedCenter) <
            halfWidth + gapRequired + occupiedHalfWidth
        );
      });

      if (!hasOverlap) {
        // Mark position as occupied with flow ID
        occupiedAtY.push([minX, maxX, flowId]);
        occupiedPositions.set(y, occupiedAtY);
        // Track node in flow group
        if (flowId) {
          if (!flowGroups.has(flowId)) {
            flowGroups.set(flowId, new Set());
          }
        }
        return desiredX;
      }

      // Find nearest available position with proper spacing
      // Sort occupied ranges by their center position
      const sortedRanges = [...occupiedAtY]
        .sort((a, b) => (a[0] + a[1]) / 2 - (b[0] + b[1]) / 2)
        .map((range) => {
          // Ensure range has flowId (for backward compatibility)
          if (range.length === 2) {
            return [range[0], range[1], null];
          }
          return range;
        });

      // Try positions between existing nodes
      for (let i = 0; i < sortedRanges.length; i++) {
        const currentRange = sortedRanges[i];
        const currentCenter = (currentRange[0] + currentRange[1]) / 2;
        const currentHalfWidth = (currentRange[1] - currentRange[0]) / 2;
        const currentFlowId = currentRange[2] || null;

        // Try position to the right of current range
        if (i === sortedRanges.length - 1) {
          const isSameFlowAsCurrent =
            flowId && currentFlowId && flowId === currentFlowId;
          const gapRequired = isSameFlowAsCurrent
            ? MIN_HORIZONTAL_GAP
            : FLOW_SEPARATION;

          const testX =
            currentCenter + currentHalfWidth + gapRequired + halfWidth;
          const testMinX = testX - halfWidth;
          const testMaxX = testX + halfWidth;

          // Check if this position doesn't overlap with any range and respects flow separation
          const isAvailable = !occupiedAtY.some((range) => {
            const [rangeMin, rangeMax, rangeFlowId] = range;
            const rangeFlowIdSafe = rangeFlowId || null;
            const isSameFlow =
              flowId && rangeFlowIdSafe && flowId === rangeFlowIdSafe;
            const requiredGapForRange = isSameFlow
              ? MIN_HORIZONTAL_GAP
              : FLOW_SEPARATION;
            const rangeCenter = (rangeMin + rangeMax) / 2;
            const rangeHalfWidth = (rangeMax - rangeMin) / 2;

            return (
              (testMinX <= rangeMax && testMaxX >= rangeMin) ||
              Math.abs(testX - rangeCenter) <
                halfWidth + requiredGapForRange + rangeHalfWidth
            );
          });

          if (isAvailable) {
            occupiedAtY.push([testMinX, testMaxX, flowId]);
            occupiedPositions.set(y, occupiedAtY);
            if (flowId) {
              if (!flowGroups.has(flowId)) {
                flowGroups.set(flowId, new Set());
              }
            }
            return testX;
          }
        }

        // Try position between current and next range
        if (i < sortedRanges.length - 1) {
          const nextRange = sortedRanges[i + 1];
          const nextCenter = (nextRange[0] + nextRange[1]) / 2;
          const nextHalfWidth = (nextRange[1] - nextRange[0]) / 2;
          const nextFlowId = nextRange[2] || null;

          // Check if we need larger gap for different flows
          const isSameFlowAsNext =
            flowId && nextFlowId && flowId === nextFlowId;
          const gapRequired = isSameFlowAsNext
            ? MIN_HORIZONTAL_GAP
            : FLOW_SEPARATION;

          const gap =
            nextCenter - nextHalfWidth - (currentCenter + currentHalfWidth);
          if (gap >= gapRequired * 2 + nodeWidth) {
            // There's enough space between these two nodes
            const testX =
              currentCenter + currentHalfWidth + gapRequired + halfWidth;
            const testMinX = testX - halfWidth;
            const testMaxX = testX + halfWidth;

            // Verify it doesn't overlap and respects flow separation
            const isAvailable = !occupiedAtY.some((range) => {
              const [rangeMin, rangeMax, rangeFlowId] = range;
              const rangeFlowIdSafe = rangeFlowId || null;
              const isSameFlow =
                flowId && rangeFlowIdSafe && flowId === rangeFlowIdSafe;
              const requiredGapForRange = isSameFlow
                ? MIN_HORIZONTAL_GAP
                : FLOW_SEPARATION;
              const rangeCenter = (rangeMin + rangeMax) / 2;
              const rangeHalfWidth = (rangeMax - rangeMin) / 2;

              return (
                (testMinX <= rangeMax && testMaxX >= rangeMin) ||
                Math.abs(testX - rangeCenter) <
                  halfWidth + requiredGapForRange + rangeHalfWidth
              );
            });

            if (isAvailable) {
              occupiedAtY.push([testMinX, testMaxX, flowId]);
              occupiedPositions.set(y, occupiedAtY);
              if (flowId) {
                if (!flowGroups.has(flowId)) {
                  flowGroups.set(flowId, new Set());
                }
              }
              return testX;
            }
          }
        }
      }

      // Try position to the left of first range
      if (sortedRanges.length > 0) {
        const firstRange = sortedRanges[0];
        const firstCenter = (firstRange[0] + firstRange[1]) / 2;
        const firstHalfWidth = (firstRange[1] - firstRange[0]) / 2;
        const firstFlowId = firstRange[2] || null;
        const isSameFlowAsFirst =
          flowId && firstFlowId && flowId === firstFlowId;
        const gapRequired = isSameFlowAsFirst
          ? MIN_HORIZONTAL_GAP
          : FLOW_SEPARATION;

        const testX = firstCenter - firstHalfWidth - gapRequired - halfWidth;
        const testMinX = testX - halfWidth;
        const testMaxX = testX + halfWidth;

        const isAvailable = !occupiedAtY.some((range) => {
          const [rangeMin, rangeMax, rangeFlowId] = range;
          const rangeFlowIdSafe = rangeFlowId || null;
          const isSameFlow =
            flowId && rangeFlowIdSafe && flowId === rangeFlowIdSafe;
          const requiredGapForRange = isSameFlow
            ? MIN_HORIZONTAL_GAP
            : FLOW_SEPARATION;
          const rangeCenter = (rangeMin + rangeMax) / 2;
          const rangeHalfWidth = (rangeMax - rangeMin) / 2;

          return (
            (testMinX <= rangeMax && testMaxX >= rangeMin) ||
            Math.abs(testX - rangeCenter) <
              halfWidth + requiredGapForRange + rangeHalfWidth
          );
        });

        if (isAvailable) {
          occupiedAtY.push([testMinX, testMaxX, flowId]);
          occupiedPositions.set(y, occupiedAtY);
          if (flowId) {
            if (!flowGroups.has(flowId)) {
              flowGroups.set(flowId, new Set());
            }
          }
          return testX;
        }
      }

      // Fallback: place far to the right with proper flow separation
      let maxRight = 0;
      if (sortedRanges.length > 0) {
        maxRight = Math.max(...sortedRanges.map((r) => r[1]));
      }
      const fallbackX = maxRight + FLOW_SEPARATION + halfWidth;
      const fallbackMinX = fallbackX - halfWidth;
      const fallbackMaxX = fallbackX + halfWidth;
      occupiedAtY.push([fallbackMinX, fallbackMaxX, flowId]);
      occupiedPositions.set(y, occupiedAtY);
      if (flowId) {
        if (!flowGroups.has(flowId)) {
          flowGroups.set(flowId, new Set());
        }
      }
      return fallbackX;
    };

    // Build node to step mapping
    allNodes.forEach((node) => {
      const step = workflowSteps.find((s) => {
        if (node.data.isBranch) {
          // For branch nodes, stepId is like "branch-{stepId}-{branchIndex}"
          return s.id === node.data.parentStepId;
        }
        return s.id === node.data.stepId;
      });
      if (step) {
        nodeToStepMap.set(node.id, step);
      }
    });

    // Find root nodes (nodes with no incoming connections)
    const rootNodes = allNodes.filter((node) => {
      if (node.data.isBranch) return false; // Branch nodes are positioned relative to parent
      const step = nodeToStepMap.get(node.id);
      return (
        step &&
        !step.connectFromStep &&
        !step.connectFromBranches &&
        !step.connectFromBranch
      );
    });

    // Position root nodes first with proper spacing
    rootNodes.forEach((node, index) => {
      const baseX = 400;
      const spacingMultiplier = 2.5; // Increase spacing between root nodes
      const step = nodeToStepMap.get(node.id);
      const flowId = getFlowId(node.id, step);
      const x =
        index === 0
          ? baseX
          : findAvailableX(
              baseX +
                index * (NODE_WIDTH + FLOW_SEPARATION * spacingMultiplier),
              100,
              NODE_WIDTH,
              flowId
            );
      nodePositionMap.set(node.id, { x, y: 100 });
      // Position is already marked as occupied by findAvailableX
      if (flowId) {
        if (!flowGroups.has(flowId)) {
          flowGroups.set(flowId, new Set());
        }
        flowGroups.get(flowId).add(node.id);
      }
    });

    // Calculate positions for all nodes using BFS, maintaining parent-child relationships
    const queue = [...rootNodes.map((node) => ({ node, depth: 0 }))];

    while (queue.length > 0) {
      const { node, depth } = queue.shift();
      if (processedNodes.has(node.id)) continue;
      processedNodes.add(node.id);

      const step = nodeToStepMap.get(node.id);
      if (!step) continue;

      // Handle branch nodes for condition steps - position them below parent
      if (step.isCondition && step.conditionBranches && !node.data.isBranch) {
        const parentPos = nodePositionMap.get(node.id);
        if (parentPos) {
          const branchCount = step.conditionBranches.length;
          const branchY = parentPos.y + VERTICAL_SPACING;

          // Calculate base x positions for branches with proper spacing
          const branchSpacing = NODE_WIDTH + MIN_HORIZONTAL_GAP * 1.5; // Increased spacing between branches
          const totalBranchWidth =
            branchCount * NODE_WIDTH +
            (branchCount - 1) * MIN_HORIZONTAL_GAP * 1.5;
          const startX = parentPos.x - totalBranchWidth / 2 + NODE_WIDTH / 2;

          step.conditionBranches.forEach((_, branchIndex) => {
            const branchNodeId = `node-branch-${step.id}-${branchIndex}`;
            const branchNode = allNodes.find((n) => n.id === branchNodeId);
            if (branchNode && !nodePositionMap.has(branchNode.id)) {
              // Calculate desired x position
              const desiredX = startX + branchIndex * branchSpacing;
              // Create flow ID for this branch
              const branchFlowId = `branch-${step.id}-${branchIndex}`;
              // Find available position to avoid overlaps, maintaining flow alignment
              const xPosition = findAvailableX(
                desiredX,
                branchY,
                NODE_WIDTH,
                branchFlowId
              );

              nodePositionMap.set(branchNode.id, {
                x: xPosition,
                y: branchY,
              });
              // Track branch in flow group
              if (!flowGroups.has(branchFlowId)) {
                flowGroups.set(branchFlowId, new Set());
              }
              flowGroups.get(branchFlowId).add(branchNode.id);
              queue.push({ node: branchNode, depth: depth + 1 });
            }
          });
        }
      }

      // Find child nodes connected from this node
      workflowSteps.forEach((nextStep) => {
        let isChild = false;
        let childParentId = null;

        // Check if connected from this node (regular step)
        if (nextStep.connectFromStep === node.id) {
          isChild = true;
          childParentId = node.id;
        }
        // Check if connected from branches of this node
        else if (
          nextStep.connectFromBranches &&
          Array.isArray(nextStep.connectFromBranches)
        ) {
          if (nextStep.connectFromBranches.includes(node.id)) {
            isChild = true;
            childParentId = node.id;
          }
        }
        // Check if connected from single branch
        else if (nextStep.connectFromBranch === node.id) {
          isChild = true;
          childParentId = node.id;
        }

        if (isChild) {
          const childNode = allNodes.find(
            (n) => n.data.stepId === nextStep.id && !n.data.isBranch
          );
          if (childNode && !nodePositionMap.has(childNode.id)) {
            const parentPos = nodePositionMap.get(childParentId);
            const parentNode = allNodes.find((n) => n.id === childParentId);

            if (parentPos) {
              // Position child directly below parent node (step or branch)
              // Always use parent's x position to keep child directly below parent
              let desiredChildX = parentPos.x; // Use parent's x position
              // Position directly below parent with VERTICAL_SPACING
              const childY = parentPos.y + VERTICAL_SPACING;

              // Determine flow ID for child node
              let childFlowId = null;
              if (parentNode?.data.isBranch) {
                // Parent is a branch node - maintain branch x position for clear branch flow
                // Get flow ID from parent branch
                const parentStep = nodeToStepMap.get(parentNode.id);
                if (parentStep) {
                  childFlowId = getFlowId(parentNode.id, parentStep);
                }
              } else if (nextStep.branchFlowId) {
                // Child is in a branch flow - find the original branch node to maintain x position
                // branchFlowId format: "branch-{stepId}-{branchIndex}"
                childFlowId = nextStep.branchFlowId;
                const branchFlowParts = nextStep.branchFlowId.split("-");
                if (branchFlowParts.length >= 3) {
                  const branchStepId = parseInt(branchFlowParts[1]);
                  const branchIndex = parseInt(branchFlowParts[2]);
                  const branchNodeId = `node-branch-${branchStepId}-${branchIndex}`;
                  const branchNode = allNodes.find(
                    (n) => n.id === branchNodeId
                  );
                  if (branchNode) {
                    const branchPos = nodePositionMap.get(branchNode.id);
                    if (branchPos) {
                      desiredChildX = branchPos.x;
                    } else {
                      // Fallback to branch node's initial position
                      desiredChildX = branchNode.position.x;
                    }
                  }
                }
              } else {
                // Regular child node connected from regular parent - maintain parent's x position
                // Get flow ID from step
                childFlowId = getFlowId(childNode.id, nextStep);
                // desiredChildX is already set to parentPos.x above
              }

              // Position child directly below parent (same x position)
              // Use findAvailableX to avoid overlaps, but it should maintain parent's x if possible
              const childX = findAvailableX(
                desiredChildX,
                childY,
                NODE_WIDTH,
                childFlowId
              );

              nodePositionMap.set(childNode.id, {
                x: childX,
                y: childY,
              });
              // Track child in flow group
              if (childFlowId) {
                if (!flowGroups.has(childFlowId)) {
                  flowGroups.set(childFlowId, new Set());
                }
                flowGroups.get(childFlowId).add(childNode.id);
              }
              queue.push({ node: childNode, depth: depth + 1 });
            }
          }
        }
      });
    }

    // Handle nodes that weren't processed in BFS (sequential nodes without explicit connections)
    // Position them based on their order and any branch flow they belong to
    allNodes.forEach((node) => {
      if (!nodePositionMap.has(node.id)) {
        const step = nodeToStepMap.get(node.id);
        if (step && !node.data.isBranch) {
          // Try to find the previous step in workflowSteps to position relative to it
          const stepIndex = workflowSteps.findIndex((s) => s.id === step.id);
          if (stepIndex > 0) {
            const prevStep = workflowSteps[stepIndex - 1];
            const prevNode = allNodes.find(
              (n) => n.data.stepId === prevStep.id && !n.data.isBranch
            );
            if (prevNode) {
              const prevPos = nodePositionMap.get(prevNode.id);
              if (prevPos) {
                // Position after previous node, maintaining x if in branch flow
                let desiredXPos = 400;
                const nodeY = prevPos.y + VERTICAL_SPACING;

                // Get flow ID for this node
                const nodeFlowId =
                  step.branchFlowId || getFlowId(node.id, step);

                if (step.branchFlowId) {
                  const branchFlowParts = step.branchFlowId.split("-");
                  if (branchFlowParts.length >= 3) {
                    const branchStepId = parseInt(branchFlowParts[1]);
                    const branchIndex = parseInt(branchFlowParts[2]);
                    const branchNodeId = `node-branch-${branchStepId}-${branchIndex}`;
                    const branchNode = allNodes.find(
                      (n) => n.id === branchNodeId
                    );
                    if (branchNode) {
                      const branchPos = nodePositionMap.get(branchNode.id);
                      if (branchPos) {
                        desiredXPos = branchPos.x;
                      }
                    }
                  }
                }

                // Find available position to avoid overlaps, maintaining flow alignment
                const xPos = findAvailableX(
                  desiredXPos,
                  nodeY,
                  NODE_WIDTH,
                  nodeFlowId
                );

                nodePositionMap.set(node.id, {
                  x: xPos,
                  y: nodeY,
                });
                // Track node in flow group
                if (nodeFlowId) {
                  if (!flowGroups.has(nodeFlowId)) {
                    flowGroups.set(nodeFlowId, new Set());
                  }
                  flowGroups.get(nodeFlowId).add(node.id);
                }
              }
            }
          }
        }
      }
    });

    // Final update: apply all calculated positions
    allNodes.forEach((node) => {
      const pos = nodePositionMap.get(node.id);
      if (pos) {
        node.position.x = pos.x;
        node.position.y = pos.y;
      }
      // If no position calculated, keep the initial position (shouldn't happen for most cases)
    });

    setNodes(allNodes);

    // Removed acceptToNextEdges - only create edges based on explicit connections

    // Create edges from selected branches to new steps (when Continue/Add Step is used with branch selected)
    const branchToStepEdges = [];
    workflowSteps.forEach((step) => {
      // Safety check: ensure step exists
      if (!step) return;

      // Handle both single branch (connectFromBranch) and multiple branches (connectFromBranches)
      const branchIds =
        step.connectFromBranches ||
        (step.connectFromBranch ? [step.connectFromBranch] : []);

      branchIds.forEach((branchId) => {
        // Find the branch node
        const branchNode = allNodes.find((n) => n.id === branchId);
        // Find the target step node
        const targetNode = allNodes.find(
          (n) => n.data.stepId === step.id && !n.data.isBranch
        );

        if (branchNode && targetNode) {
          branchToStepEdges.push({
            id: `edge-${branchNode.id}-${targetNode.id}`,
            source: branchNode.id,
            target: targetNode.id,
            type: "smoothstep",
            animated: true,
            style: {
              stroke: "#3B82F6",
              strokeWidth: 2.5,
              strokeDasharray: "5,5",
            },
            markerEnd: {
              type: MarkerType.ArrowClosed,
              color: "#3B82F6",
              width: 20,
              height: 20,
            },
          });
        }
      });
    });

    // Create edges from selected regular steps to new steps (when Continue/Add Step is used with regular step selected)
    // BUT: Don't connect directly if the source step has branch nodes - only connect through branch nodes
    const stepToStepEdges = [];
    workflowSteps.forEach((step) => {
      // Safety check: ensure step exists
      if (!step) return;

      // Check if this step is connected from a regular step
      if (step.connectFromStep) {
        // Find the source step node
        const sourceNode = allNodes.find((n) => n.id === step.connectFromStep);
        // Find the target step node
        const targetNode = allNodes.find(
          (n) => n.data.stepId === step.id && !n.data.isBranch
        );

        if (sourceNode && targetNode) {
          // Check if the source step has branch nodes (condition branches)
          const sourceStepId = sourceNode.data.stepId;
          const sourceStep = workflowSteps.find((s) => s.id === sourceStepId);

          // If source step has branch nodes (isCondition with conditionBranches), don't create direct connection
          // Connections should only go through branch nodes
          if (
            sourceStep &&
            sourceStep.isCondition &&
            sourceStep.conditionBranches &&
            sourceStep.conditionBranches.length > 0
          ) {
            // Don't create direct edge - connections should only go through branch nodes
            return;
          }

          // Only create direct edge if source step doesn't have branch nodes
          stepToStepEdges.push({
            id: `edge-${sourceNode.id}-${targetNode.id}`,
            source: sourceNode.id,
            target: targetNode.id,
            type: "smoothstep",
            animated: true,
            style: {
              stroke: "#3B82F6",
              strokeWidth: 2.5,
              strokeDasharray: "5,5",
            },
            markerEnd: {
              type: MarkerType.ArrowClosed,
              color: "#3B82F6",
              width: 20,
              height: 20,
            },
          });
        }
      }
    });

    // Only create edges based on explicit connections - no automatic sequential connections
    if (allNodes.length > 0) {
      // Track all edges to avoid duplicates
      const allEdges = [
        ...branchEdges,
        ...branchToStepEdges,
        ...stepToStepEdges,
      ];

      // Remove duplicate edges based on source and target
      const uniqueEdges = [];
      const edgeKeySet = new Set();
      allEdges.forEach((edge) => {
        const edgeKey = `${edge.source}-${edge.target}`;
        if (!edgeKeySet.has(edgeKey)) {
          edgeKeySet.add(edgeKey);
          uniqueEdges.push(edge);
        }
      });

      setEdges(uniqueEdges);
    } else {
      // No nodes, no edges
      setEdges([]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [workflowSteps]);

  const handleDeleteWorkflow = async () => {
    if (
      !window.confirm("Are you sure you want to delete this entire workflow?")
    ) {
      return;
    }

    try {
      const token = localStorage.getItem("token") || "";
      const orgId = user?.org?.org_id || user?.org_id || "";

      if (!orgId) {
        alert("Organization ID not found. Please ensure you are logged in.");
        return;
      }

      const deleteUrl = `${
        workflowEndPoints.deleteFinalAssignedByOrgId
      }?org_id=${encodeURIComponent(orgId)}`;
      const deleteResponse = await apiCall(
        deleteUrl,
        methods.delete,
        null,
        token
      );

      if (deleteResponse?.status >= 400) {
        const errorData = deleteResponse.data;
        const errorMessage =
          errorData?.error ||
          errorData?.message ||
          errorData?.details ||
          JSON.stringify(errorData) ||
          "Failed to delete workflow";
        alert(`Failed to delete workflow: ${errorMessage}`);
        return;
      }

      // Decrypt the response if needed
      let decryptedResponse;
      if (deleteResponse?.data && typeof deleteResponse.data === "string") {
        try {
          decryptedResponse = await decryptAesBase64(deleteResponse.data);
          if (typeof decryptedResponse === "string") {
            try {
              decryptedResponse = JSON.parse(decryptedResponse);
            } catch (e) {
              // If parsing fails, use decrypted string as is
            }
          }
        } catch (e) {
          if (typeof deleteResponse.data === "object") {
            decryptedResponse = deleteResponse.data;
          }
        }
      } else {
        decryptedResponse = deleteResponse;
      }

      // Check if response indicates success
      if (decryptedResponse?.error || decryptedResponse?.success === false) {
        alert(
          decryptedResponse.error ||
            decryptedResponse.message ||
            "Failed to delete workflow"
        );
        return;
      }

      // Reset all workflow states
      setWorkflowSteps([]);
      setNodes([]);
      setEdges([]);
      setSelectedAction(null);
      setSelectedNodeIds([]);
      setHasBeenSaved(false);
      setSaveSuccess(false);
      setNodeIdCounter(1);

      alert("Workflow deleted successfully");
    } catch (err) {
      let errorMessage = "Unknown error";
      if (err.response?.data) {
        const errorData = err.response.data;
        if (typeof errorData === "object" && errorData !== null) {
          errorMessage =
            errorData.error ||
            errorData.message ||
            errorData.details ||
            JSON.stringify(errorData);
        } else if (typeof errorData === "string" && errorData.trim() !== "") {
          errorMessage = errorData;
        } else {
          errorMessage = String(errorData);
        }
      } else {
        errorMessage = err.message || "Unknown error";
      }
      alert(`Failed to delete workflow: ${errorMessage}`);
    }
  };

  const handleDownloadWorkflow = async () => {
    try {
      // Find the React Flow container element
      const reactFlowElement = document.querySelector(".react-flow");

      if (!reactFlowElement) {
        alert("Workflow not found. Please ensure the workflow is displayed.");
        return;
      }

      // Wait a bit for React Flow to fully render
      await new Promise((resolve) => setTimeout(resolve, 300));

      // Capture the React Flow canvas as an image with enhanced SVG support
      const canvas = await html2canvas(reactFlowElement, {
        backgroundColor: "#f9fafb", // Match the background color
        scale: 2, // Higher quality
        logging: false,
        useCORS: true,
        allowTaint: true,
        foreignObjectRendering: true,
        // Ensure SVG elements (edges/arrows) are captured
        onclone: (clonedDoc) => {
          // Find the cloned React Flow element
          const clonedFlow = clonedDoc.querySelector(".react-flow");
          if (clonedFlow) {
            // Ensure all SVG elements (edges) are visible
            const svgs = clonedFlow.querySelectorAll("svg");
            svgs.forEach((svg) => {
              svg.style.display = "block";
              svg.style.visibility = "visible";
              svg.style.opacity = "1";
            });

            // Ensure edge paths are visible and styled
            const paths = clonedFlow.querySelectorAll("path");
            paths.forEach((path) => {
              path.style.display = "block";
              path.style.visibility = "visible";
              path.style.opacity = "1";
              // Ensure stroke color is preserved
              const strokeColor =
                path.getAttribute("stroke") || path.style.stroke || "#3B82F6";
              path.setAttribute("stroke", strokeColor);
              path.setAttribute(
                "stroke-width",
                path.getAttribute("stroke-width") || "2.5"
              );
            });

            // Ensure markers (arrows) are visible
            const markers = clonedFlow.querySelectorAll("marker");
            markers.forEach((marker) => {
              marker.style.display = "block";
              marker.style.visibility = "visible";
              marker.style.opacity = "1";
            });

            // Ensure all node elements are visible
            const nodes = clonedFlow.querySelectorAll(".react-flow__node");
            nodes.forEach((node) => {
              node.style.display = "block";
              node.style.visibility = "visible";
              node.style.opacity = "1";
            });
          }
        },
      });

      // Convert canvas to blob
      canvas.toBlob((blob) => {
        if (!blob) {
          alert("Failed to generate image");
          return;
        }

        // Create download link
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = `workflow-${
          new Date().toISOString().split("T")[0]
        }.png`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
      }, "image/png");
    } catch (error) {
      console.error("Error downloading workflow:", error);
      alert("Failed to download workflow. Please try again.");
    }
  };

  const handleSaveSteps = async () => {
    if (workflowSteps.length === 0) {
      alert("Please add at least one workflow step");
      return;
    }

    setIsSaving(true);
    setSaveSuccess(false);

    try {
      // Get token from localStorage
      const tokenToUse = localStorage.getItem("token") || "";

      // If user data is not available, try to fetch it first
      let currentUser = user;

      if (!currentUser?.org?.org_id) {
        if (tokenToUse && isValidToken(tokenToUse)) {
          try {
            // Verify token and fetch user data
            const data = await apiCall(
              userEndPoints.verifyToken,
              methods.post,
              {
                token: tokenToUse,
              }
            );

            if (data && data.valid) {
              const userData = await apiCall(
                `${userEndPoints.getUser}${data.userId}`,
                methods.get
              );
              dispatch(setUser(userData));
              dispatch(setToken(tokenToUse));
              currentUser = userData;
            }
          } catch (error) {
            console.error("Failed to fetch user data:", error);
          }
        }
      }

      // Check again after attempting to fetch user data
      if (!currentUser?.org?.org_id) {
        alert(
          "Organization ID not found. Please ensure you are logged in and refresh the page."
        );
        setIsSaving(false);
        return;
      }

      const orgId = currentUser?.org?.org_id || currentUser?.org_id || "";
      const zoneId = currentUser?.org?.zone_id || currentUser?.zone_id || "";
      const siteId = currentUser?.org?.site_id || currentUser?.site_id || "";

      if (!orgId) {
        alert("Organization ID not found");
        setIsSaving(false);
        return;
      }

      // Determine order of actions based on React Flow edges (connections)
      // If no edges exist, use node order; otherwise traverse the graph
      const orderedStepIds = [];

      if (edges.length === 0) {
        // No connections, use node order
        orderedStepIds.push(...nodes.map((node) => node.data.stepId));
      } else {
        // Traverse graph starting from nodes with no incoming edges
        const nodeMap = new Map();
        const incomingCount = new Map();

        nodes.forEach((node) => {
          nodeMap.set(node.data.stepId, node);
          incomingCount.set(node.data.stepId, 0);
        });

        edges.forEach((edge) => {
          const targetStepId = parseInt(edge.target.replace("node-", ""));
          incomingCount.set(
            targetStepId,
            (incomingCount.get(targetStepId) || 0) + 1
          );
        });

        // Find starting nodes (no incoming edges)
        const queue = [];
        incomingCount.forEach((count, stepId) => {
          if (count === 0) {
            queue.push(stepId);
          }
        });

        // Topological sort
        while (queue.length > 0) {
          const currentStepId = queue.shift();
          orderedStepIds.push(currentStepId);

          // Find outgoing edges
          edges.forEach((edge) => {
            const sourceStepId = parseInt(edge.source.replace("node-", ""));
            if (sourceStepId === currentStepId) {
              const targetStepId = parseInt(edge.target.replace("node-", ""));
              const newCount = (incomingCount.get(targetStepId) || 0) - 1;
              incomingCount.set(targetStepId, newCount);
              if (newCount === 0) {
                queue.push(targetStepId);
              }
            }
          });
        }

        // Add any remaining nodes (in case of disconnected components)
        nodes.forEach((node) => {
          if (!orderedStepIds.includes(node.data.stepId)) {
            orderedStepIds.push(node.data.stepId);
          }
        });
      }

      // Collect all actions in the determined order
      const allActions = [];
      orderedStepIds.forEach((stepId, index) => {
        const step = workflowSteps.find((s) => s.id === stepId);
        if (step) {
          step.actions.forEach((actionName) => {
            // Find the action data from workflowActionsData
            const actionData = workflowActionsData.find(
              (item) => item.action === actionName
            );

            if (actionData) {
              // Check if this action is already in allActions (avoid duplicates)
              const actionEnum =
                actionData.enum ||
                actionData.action_id ||
                actionData.actionId ||
                actionData.id ||
                "";
              const existingIndex = allActions.findIndex(
                (a) => a.enum === actionEnum
              );

              if (existingIndex === -1) {
                // Generate socket_event from enum if not present: "CREATE_WORK_PERMIT" -> "on_create_work_permit"
                let socketEvent = actionData.socket_event;
                if (!socketEvent && actionEnum) {
                  socketEvent = `on_${actionEnum.toLowerCase()}`;
                } else if (!socketEvent) {
                  socketEvent = `on_${(actionData.action || actionName)
                    .toLowerCase()
                    .replace(/\s+/g, "_")}`;
                }

                allActions.push({
                  action: actionData.action || actionName,
                  enum: actionEnum,
                  socket_event: socketEvent,
                  status: index === 0 && allActions.length === 0, // First action in first step gets status=true
                });
              }
            }
            // If action not found in workflowActionsData, skip it (don't add fallback data)
          });
        }
      });

      // Set status: true for the first action, status: false for others
      if (allActions.length > 0) {
        allActions[0].status = true;
        for (let i = 1; i < allActions.length; i++) {
          allActions[i].status = false;
        }
      }

      // Construct the payload
      const payload = {
        org_id: String(orgId),
        zone_id: String(zoneId),
        site_id: String(siteId),
        actions: allActions,
      };

      // Encrypt the payload
      const encryptedPayload = await encryptAesBase64(payload);

      if (typeof encryptedPayload !== "string") {
        throw new Error(
          "Encryption failed: Expected string but got " +
            typeof encryptedPayload
        );
      }

      // Create the request payload with data field containing encrypted string
      const encryptedRequestPayload = {
        data: encryptedPayload.trim(),
      };

      // Call the API
      const response = await apiCall(
        workflowEndPoints.finalSetpAssignedByOrdId,
        methods.post,
        encryptedRequestPayload,
        tokenToUse
      );

      // Check if apiCall returned an error response (status >= 400)
      if (response?.status >= 400) {
        const errorData = response.data;
        const errorMessage =
          errorData?.error ||
          errorData?.message ||
          errorData?.details ||
          JSON.stringify(errorData) ||
          "Failed to save workflow steps";

        throw new Error(errorMessage);
      }

      // Decrypt the response if needed
      let finalResponse;
      if (response?.data && typeof response.data === "string") {
        try {
          finalResponse = await decryptAesBase64(response.data);
          if (typeof finalResponse === "string") {
            try {
              finalResponse = JSON.parse(finalResponse);
            } catch (e) {
              // If parsing fails, use decrypted string as is
            }
          }
        } catch (e) {
          // If decryption fails, maybe response.data is already plain JSON
          if (typeof response.data === "object") {
            finalResponse = response.data;
          } else {
            throw new Error("Failed to decrypt response");
          }
        }
      } else {
        finalResponse = response;
      }

      // Check if response indicates success
      if (finalResponse?.error || finalResponse?.success === false) {
        throw new Error(
          finalResponse.error ||
            finalResponse.message ||
            "Failed to save workflow steps"
        );
      }

      // Call getFinalAssignedByOrgId API after successful save
      try {
        const fetchUrl = `${
          workflowEndPoints.getFinalAssignedByOrgId
        }?org_id=${encodeURIComponent(orgId)}`;
        const fetchResponse = await apiCall(
          fetchUrl,
          methods.get,
          null,
          tokenToUse
        );

        if (fetchResponse?.status < 400 && fetchResponse?.data) {
          // Decrypt the response if needed
          let decryptedFetchResponse;
          if (typeof fetchResponse.data === "string") {
            try {
              decryptedFetchResponse = await decryptAesBase64(
                fetchResponse.data
              );
              if (typeof decryptedFetchResponse === "string") {
                try {
                  decryptedFetchResponse = JSON.parse(decryptedFetchResponse);
                } catch (e) {
                  // If parsing fails, use decrypted string as is
                }
              }
            } catch (e) {
              // If decryption fails, maybe response.data is already plain JSON
              if (typeof fetchResponse.data === "object") {
                decryptedFetchResponse = fetchResponse.data;
              }
            }
          } else {
            decryptedFetchResponse = fetchResponse.data;
          }
          // Response is fetched but not used to update the visual flow
          // The visual flow remains exactly as it was when saved
        }
      } catch (fetchError) {
        // If getFinalAssignedByOrgId fails, don't block the success flow
        // Just log the error silently
        console.warn("Failed to fetch final assigned workflow:", fetchError);
      }

      // Mark workflow as saved
      setHasBeenSaved(true);

      // Show success indicator
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 2000);

      // Show success message
      const successMessage =
        finalResponse?.message ||
        `Workflow steps saved successfully with ${allActions.length} actions`;
      alert(successMessage);

      // Keep the same workflow format/flow - don't fetch and update workflowSteps
      // The visual flow remains exactly as it was when saved
    } catch (err) {
      // Try to extract error message from response
      let errorMessage = "Unknown error";
      if (err.response?.data) {
        const errorData = err.response.data;
        if (typeof errorData === "object" && errorData !== null) {
          errorMessage =
            errorData.error ||
            errorData.message ||
            errorData.details ||
            JSON.stringify(errorData);
        } else if (typeof errorData === "string" && errorData.trim() !== "") {
          try {
            const decryptedError = await decryptAesBase64(errorData);
            try {
              const parsedError = JSON.parse(decryptedError);
              errorMessage =
                parsedError.error ||
                parsedError.message ||
                parsedError.details ||
                decryptedError;
            } catch (e) {
              errorMessage = decryptedError;
            }
          } catch (decryptErr) {
            errorMessage = errorData;
          }
        } else {
          errorMessage = String(errorData);
        }
      } else {
        errorMessage = err.message || "Unknown error";
      }

      alert(`Failed to save workflow steps: ${errorMessage}`);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar token={token} />

      {/* Header */}
      <div className="bg-white px-6 py-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => window.history.back()}
            className="text-gray-600 hover:text-gray-800 transition-colors"
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
              <path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z" />
            </svg>
          </button>
          <h1 className="text-2xl font-bold text-gray-800">
            Workflow Orchestration
          </h1>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-6 pt-2 pb-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-2">
          {/* Column 1: LOTO Action Checklist */}
          <div className="bg-white rounded-lg p-6 shadow-sm lg:col-span-1">
            <h2 className="text-lg font-semibold text-gray-800 mb-6">
              LOTO Action Checklist
            </h2>

            {/* Action Checklist */}
            <div className="bg-white border border-gray-300 rounded-lg p-4 h-[28rem] flex flex-col">
              {/* Search Bar */}
              <div className="relative mb-4 flex-shrink-0">
                <input
                  type="text"
                  placeholder="Search..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full px-3 py-2 pl-10 rounded-md focus:outline-none bg-blue-50"
                />
                <div className="absolute inset-y-0 left-0 flex items-center pl-3">
                  <svg
                    className="w-4 h-4 text-gray-400"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                    />
                  </svg>
                </div>
              </div>

              {/* Action Checklist - Scrollable Area */}
              <div className="flex-1 overflow-y-auto">
                {isLoadingActions ? (
                  <div className="flex flex-col justify-center items-center h-full">
                    <p className="text-gray-600 font-medium">
                      Loading actions...
                    </p>
                  </div>
                ) : actionsError ? (
                  <div className="flex flex-col justify-center items-center h-full">
                    <p className="text-red-600 font-medium">{actionsError}</p>
                  </div>
                ) : filteredActions.length > 0 ? (
                  <div className="space-y-3">
                    {filteredActions.map((action, index) => (
                      <div key={index} className="flex items-center">
                        <input
                          type="radio"
                          id={`action-${index}`}
                          name="loto-action"
                          checked={selectedAction === action}
                          onChange={() => handleActionToggle(action)}
                          className="w-4 h-4 text-blue-600 border-gray-300 focus:ring-blue-500"
                        />
                        <label
                          htmlFor={`action-${index}`}
                          className="ml-3 text-sm text-gray-700 cursor-pointer"
                        >
                          {action}
                        </label>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-col justify-center items-center h-full">
                    <img
                      src={workflowArch}
                      alt="No actions found"
                      className="w-8 h-8 mx-auto mb-4"
                    />
                    <p className="text-gray-600 font-medium">
                      No Action/Role found
                    </p>
                  </div>
                )}
              </div>

              {/* Condition and Continue Buttons */}
              <div className="flex gap-3 mt-4 pt-4 border-t border-gray-200 flex-shrink-0">
                <button
                  onClick={handleCondition}
                  disabled={!selectedAction}
                  className={`flex-1 border py-2 px-4 rounded-full transition-colors font-medium ${
                    selectedAction
                      ? "border-blue-500 text-blue-500 hover:bg-blue-50"
                      : "border-gray-300 text-gray-400 cursor-not-allowed"
                  }`}
                >
                  Condition
                </button>
                <button
                  onClick={handleContinue}
                  disabled={!selectedAction}
                  className={`flex-1 py-2 px-4 rounded-full transition-colors font-medium ${
                    selectedAction
                      ? "bg-blue-500 text-white hover:bg-blue-600"
                      : "bg-gray-300 text-gray-400 cursor-not-allowed"
                  }`}
                >
                  Continue
                </button>
              </div>
            </div>

            {/* Add Step Button - Outside Card */}
            <div className="mt-4 flex justify-end">
              <button
                onClick={handleAddStep}
                className="w-auto border border-blue-500 text-blue-500 py-2 px-6 rounded-full hover:bg-blue-50 transition-colors font-medium"
              >
                Add Step
              </button>
            </div>
          </div>

          {/* Column 2: Work Flow Steps */}
          <div className="bg-white rounded-lg p-6 shadow-sm lg:col-span-2">
            <h2 className="text-lg font-semibold text-gray-800 mb-4">
              Work Flow Steps
            </h2>

            {/* Workflow Steps Display - React Flow */}
            {hasBeenSaved ? (
              <div className="bg-white border-2 border-gray-200 rounded-lg shadow-lg overflow-hidden">
                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 px-4 py-3 border-b border-gray-200 flex justify-between items-center">
                  <h3 className="text-sm font-semibold text-gray-700">
                    Saved Workflow
                  </h3>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleDownloadWorkflow}
                      className="px-4 py-2 bg-blue-500 text-white rounded-full hover:bg-blue-600 transition-colors font-medium text-sm flex items-center gap-2"
                    >
                      <svg
                        className="w-4 h-4"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"
                        />
                      </svg>
                      Download
                    </button>
                    <button
                      onClick={handleDeleteWorkflow}
                      className="px-4 py-2 bg-red-500 text-white rounded-full hover:bg-red-600 transition-colors font-medium text-sm flex items-center gap-2"
                    >
                      <svg
                        className="w-4 h-4"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                        />
                      </svg>
                      Delete Workflow
                    </button>
                  </div>
                </div>
                <div className="h-[28rem] overflow-auto relative bg-gradient-to-br from-gray-50 to-blue-50">
                  {nodes.length > 0 ? (
                    <ReactFlow
                      nodes={nodes}
                      edges={edges}
                      onNodesChange={onNodesChange}
                      onEdgesChange={onEdgesChange}
                      onConnect={onConnect}
                      onNodeClick={(event, node) => {
                        // Only allow multiple selection for branch nodes
                        if (node.data.isBranch) {
                          setSelectedNodeIds((prev) => {
                            if (prev.includes(node.id)) {
                              // Deselect if already selected
                              return prev.filter((id) => id !== node.id);
                            } else {
                              // Add to selection
                              return [...prev, node.id];
                            }
                          });
                        } else {
                          // For non-branch nodes, single selection (replace array)
                          setSelectedNodeIds([node.id]);
                        }
                      }}
                      onPaneClick={() => {
                        // Clear selection when clicking on empty space
                        setSelectedNodeIds([]);
                      }}
                      nodeTypes={nodeTypes}
                      fitView
                      minZoom={0.2}
                      maxZoom={2}
                      defaultViewport={{ x: 0, y: 0, zoom: 1 }}
                      className="bg-gradient-to-br from-gray-50 to-blue-50"
                      defaultEdgeOptions={{
                        type: "smoothstep",
                        animated: true,
                        style: {
                          stroke: "#3B82F6",
                          strokeWidth: 2.5,
                          strokeDasharray: "5,5",
                        },
                        markerEnd: {
                          type: MarkerType.ArrowClosed,
                          color: "#3B82F6",
                          width: 20,
                          height: 20,
                        },
                      }}
                      connectionLineStyle={{
                        stroke: "#3B82F6",
                        strokeWidth: 2.5,
                        strokeDasharray: "5,5",
                      }}
                      connectionLineType="smoothstep"
                      snapToGrid={true}
                      snapGrid={[20, 20]}
                      attributionPosition="bottom-left"
                      panOnScroll={true}
                      panOnScrollMode="vertical"
                      panOnScrollSpeed={1}
                      preventScrolling={false}
                    >
                      <Background
                        color="#cbd5e1"
                        gap={20}
                        size={1}
                        variant="dots"
                      />
                      <Controls
                        showInteractive={false}
                        style={{
                          button: {
                            backgroundColor: "#ffffff",
                            border: "1px solid #e5e7eb",
                            color: "#374151",
                          },
                        }}
                      />
                      <MiniMap
                        nodeColor={(node) => {
                          const stepNumber = node.data?.stepNumber || 1;
                          const colors = [
                            "#3B82F6",
                            "#6366F1",
                            "#8B5CF6",
                            "#EC4899",
                            "#F43F5E",
                            "#F97316",
                            "#F59E0B",
                            "#EAB308",
                          ];
                          return colors[(stepNumber - 1) % colors.length];
                        }}
                        maskColor="rgba(0, 0, 0, 0.1)"
                        style={{
                          backgroundColor: "#ffffff",
                          border: "1px solid #e5e7eb",
                        }}
                      />
                    </ReactFlow>
                  ) : (
                    <div className="flex flex-col justify-center items-center h-full">
                      <img
                        src={workflowArch}
                        alt="Create workflow steps"
                        className="w-16 h-16 mx-auto mb-4"
                      />
                      <p className="text-gray-600 font-medium">
                        Create LOTO Work Flow steps
                      </p>
                    </div>
                  )}
                </div>
                <div className="bg-gray-50 px-4 py-2 border-t border-gray-200">
                  <p className="text-xs text-gray-500 text-center">
                    Workflow saved successfully
                  </p>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-lg h-[28rem] overflow-auto relative">
                {nodes.length > 0 ? (
                  <ReactFlow
                    nodes={nodes}
                    edges={edges}
                    onNodesChange={onNodesChange}
                    onEdgesChange={onEdgesChange}
                    onConnect={onConnect}
                    onNodeClick={(event, node) => {
                      // Only allow multiple selection for branch nodes
                      if (node.data.isBranch) {
                        setSelectedNodeIds((prev) => {
                          if (prev.includes(node.id)) {
                            // Deselect if already selected
                            return prev.filter((id) => id !== node.id);
                          } else {
                            // Add to selection
                            return [...prev, node.id];
                          }
                        });
                      } else {
                        // For non-branch nodes, single selection (replace array)
                        setSelectedNodeIds([node.id]);
                      }
                    }}
                    onPaneClick={() => {
                      // Clear selection when clicking on empty space
                      setSelectedNodeIds([]);
                    }}
                    nodeTypes={nodeTypes}
                    fitView
                    minZoom={0.2}
                    maxZoom={2}
                    defaultViewport={{ x: 0, y: 0, zoom: 1 }}
                    className="bg-gradient-to-br from-gray-50 to-blue-50"
                    defaultEdgeOptions={{
                      type: "smoothstep",
                      animated: true,
                      style: {
                        stroke: "#3B82F6",
                        strokeWidth: 2.5,
                        strokeDasharray: "5,5",
                      },
                      markerEnd: {
                        type: MarkerType.ArrowClosed,
                        color: "#3B82F6",
                        width: 20,
                        height: 20,
                      },
                    }}
                    connectionLineStyle={{
                      stroke: "#3B82F6",
                      strokeWidth: 2.5,
                      strokeDasharray: "5,5",
                    }}
                    connectionLineType="smoothstep"
                    snapToGrid={true}
                    snapGrid={[20, 20]}
                    attributionPosition="bottom-left"
                    panOnScroll={true}
                    panOnScrollMode="vertical"
                    panOnScrollSpeed={1}
                    preventScrolling={false}
                  >
                    <Background
                      color="#cbd5e1"
                      gap={20}
                      size={1}
                      variant="dots"
                    />
                    <Controls
                      showInteractive={false}
                      style={{
                        button: {
                          backgroundColor: "#ffffff",
                          border: "1px solid #e5e7eb",
                          color: "#374151",
                        },
                      }}
                    />
                    <MiniMap
                      nodeColor={(node) => {
                        const stepNumber = node.data?.stepNumber || 1;
                        const colors = [
                          "#3B82F6",
                          "#6366F1",
                          "#8B5CF6",
                          "#EC4899",
                          "#F43F5E",
                          "#F97316",
                          "#F59E0B",
                          "#EAB308",
                        ];
                        return colors[(stepNumber - 1) % colors.length];
                      }}
                      maskColor="rgba(0, 0, 0, 0.1)"
                      style={{
                        backgroundColor: "#ffffff",
                        border: "1px solid #e5e7eb",
                      }}
                    />
                  </ReactFlow>
                ) : (
                  <div className="flex flex-col justify-center items-center h-full">
                    <img
                      src={workflowArch}
                      alt="Create workflow steps"
                      className="w-16 h-16 mx-auto mb-4"
                    />
                    <p className="text-gray-600 font-medium">
                      Create LOTO Work Flow steps
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Save Steps Button */}
            <div className="flex justify-end mt-4">
              <button
                onClick={handleSaveSteps}
                disabled={isSaving}
                className={`py-2.5 px-8 rounded-full transition-colors font-semibold text-base ${
                  saveSuccess
                    ? "bg-green-500 text-white"
                    : isSaving
                    ? "bg-gray-400 text-white cursor-not-allowed"
                    : "bg-primary text-white hover:bg-primary-dark"
                }`}
              >
                {isSaving
                  ? "Saving..."
                  : saveSuccess
                  ? "✓ Saved!"
                  : "Save Steps"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WorkflowOrchestration;
