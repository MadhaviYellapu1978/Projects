import { Route, Routes } from "react-router-dom";
import Home from "./pages/RoleManagement";
import { useEffect } from "react";
import { apiCall, isValidToken, isProtectedRoute } from "./utils";
import { methods, userEndPoints } from "./constants";
import { useDispatch } from "react-redux";
import { setToken, setUser } from "./features/auth/authSlice";
import UserManagement from "./pages/UserManagement";
import LotoPage from "./pages/Dashboard";
import { Toaster } from "react-hot-toast";
import PadlockManagement from "./pages/PadlockManagement";
import Dashboard from "./pages/Dashboard";
import WorkorderDetail from "./pages/WorkorderDetail";
import EquipmentDetails from "./pages/EquipmentDetails";
import EquipmentCard from "./components/Equipment/EquipmentCard";
import WorkflowManagement from "./pages/WorkflowManagement";
import ApprovalMechanism from "./pages/ApprovalMechanism";
import WorkflowOrchestration from "./pages/WorkflowOrchestration";
import WorkOrderFormBuilder from "./pages/WorkOrderFormBuilder";
import SelfWorkOrderFormBuilder from "./pages/SelfWorkOrderFormBuilder";
import LOTOWorkOrderFormBuilder from "./pages/LOTOWorkOrderFormBuilder";

function App() {
  const dispatch = useDispatch();

  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    const tokenValue = searchParams.get("token");

    // Check if token is valid before making API calls
    if (isValidToken(tokenValue)) {
      apiCall(userEndPoints.verifyToken, methods.post, { token: tokenValue })
        .then((data) => {
          if (data && data.valid) {
            return apiCall(
              `${userEndPoints.getUser}${data.userId}`,
              methods.get
            )
              .then((userData) => {
                dispatch(setUser(userData));
                dispatch(setToken(tokenValue));
              })
              .catch((error) => {
                console.error("Failed to fetch user data:", error);
                // Handle gracefully - maybe redirect to login or show error
              });
          } else {
            console.warn("Token verification failed - invalid token");
            if (window.location.pathname.includes("workorder")) {
              window.location.href = "/";
            }
          }
        })
        .catch((error) => {
          console.error("Token verification failed:", error);
          // Handle gracefully - maybe redirect to login or show error
        });
    } else {
      console.warn("No valid token found in URL parameters");
      // Redirect protected routes to home if no valid token
      if (isProtectedRoute(window.location.pathname)) {
        window.location.href = "/";
      }
    }
    // eslint-disable-next-line
  }, []);

  return (
    <div>
      <Toaster position="top-center" reverseOrder={false} />
      <Routes>
        <Route path="/loto" element={<LotoPage />} />
        <Route path="/" element={<LotoPage />} />
        <Route path="/loto/dashboard" element={<Dashboard />} />
        <Route path="/loto/roleManagement" element={<Home />} />
        <Route
          path="/loto/roleManagement/equipmentCard"
          element={<EquipmentCard />}
        />
        <Route path="/loto/userManagement" element={<UserManagement />} />
        <Route path="/loto/padlockManagement" element={<PadlockManagement />} />
        <Route
          path="/loto/workflowManagement"
          element={<WorkflowManagement />}
        />
        <Route path="/loto/approvalMechanism" element={<ApprovalMechanism />} />
        <Route
          path="/loto/workflowOrchestration"
          element={<WorkflowOrchestration />}
        />
        <Route
          path="/loto/workOrderFormBuilder"
          element={<WorkOrderFormBuilder />}
        />
        <Route
          path="/loto/selfWorkOrderFormBuilder"
          element={<SelfWorkOrderFormBuilder />}
        />
        <Route
          path="/loto/lotoWorkOrderFormBuilder"
          element={<LOTOWorkOrderFormBuilder />}
        />
        <Route
          path="/loto/workorder/:workorderId"
          element={<WorkorderDetail />}
        />
        <Route path="/equipment-details" element={<EquipmentDetails />} />
      </Routes>
    </div>
  );
}

export default App;
