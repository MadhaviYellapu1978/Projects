import React, { useState, useRef } from "react";
import {
  alertIcon,
  homeIcon,
  logo,
  settingsIcon,
  tasksIcon,
  workflowManagement,
  assetManagement,
  roleManagement,
  approvalMechanism,
  workflowArch,
  workorderIcon,
} from "../assets";
import { Link, useLocation } from "react-router-dom";

const Navbar = ({ token }) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [hover, setHover] = useState(false);
  const timeoutRef = useRef(null);
  const location = useLocation();

  // Get token from URL params if not provided as prop, or from localStorage
  const searchParams = new URLSearchParams(window.location.search);
  const tokenFromUrl = searchParams.get("token");
  const tokenFromStorage = localStorage.getItem("token");
  const effectiveToken = token || tokenFromUrl || tokenFromStorage || "";

  // Helper function to build URL with token if available
  const buildUrlWithToken = (path) => {
    return effectiveToken ? `${path}?token=${effectiveToken}` : path;
  };

  // Helper function to build ApprovalMechanism URL with token
  const buildApprovalMechanismUrl = () => {
    if (effectiveToken) {
      return `/loto/approvalMechanism/?token=${effectiveToken}`;
    }
    // If no token available, try to get from current URL or localStorage
    const currentToken = tokenFromUrl || tokenFromStorage;
    return currentToken 
      ? `/loto/approvalMechanism/?token=${currentToken}` 
      : `/loto/approvalMechanism/`;
  };

  const handleMouseEnter = () => {
    clearTimeout(timeoutRef.current);
    setHover(true);
  };

  const handleMouseLeave = () => {
    timeoutRef.current = setTimeout(() => {
      setHover(false);
    }, 200); // Adjust the delay as needed
  };

  return (
    <>
      {/* Desktop and Medium Navigation */}
      <nav className="hidden md:flex  items-center py-5 shadow-md pl-12 bg-white">
        <div>
          <img src={logo} alt="Innvendt" />
        </div>
        <div className="flex justify-evenly w-full max-w-5xl ">
          <div
            className={`flex gap-2  py-2 rounded-full  cursor-pointer ${
              location.pathname === "/home" ? "bg-blue-300" : ""
            }`}
            onClick={() => {
              window.location.href = "/home";
            }}
          >
            <img src={homeIcon} alt="Home" />
            <h5>Home</h5>
          </div>
          <div
            className={`flex gap-2 px-11 py-2 rounded-full items-center cursor-pointer ${
              location.pathname === "/mytasks" ? "bg-blue-300" : ""
            }`}
          >
            <img src={tasksIcon} alt="Tasks" />
            <h5>My Tasks</h5>
          </div>
          <Link
            to={`/loto/dashboard?token=${token}`}
            className={`flex gap-2 px-11 py-2 rounded-full items-center cursor-pointer ${
              location.pathname.includes("/loto/dashboard") ? "bg-blue-300" : ""
            }`}
          >
            <img src={alertIcon} alt="Loto" />
            <h5>LOTO</h5>
          </Link>
          <div
            className={`flex gap-2 px-11 py-2 rounded-full items-center cursor-pointer relative z-50 ${
              hover ? "bg-blue-300" : ""
            }`}
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
          >
            <img src={settingsIcon} alt="Settings" />
            <h5>Settings</h5>
            <div
              className={`absolute top-full left-0 mt-2 w-56 bg-white shadow-lg rounded-lg overflow-hidden transition-all z-50 ${
                hover ? "block" : "hidden"
              }`}
            >
              <Link
                to={`/loto/roleManagement/?token=${token}`}
                className={`flex items-center gap-3 px-4 py-3.5 !text-black hover:bg-blue-50 hover:text-blue-700 transition-colors ${
                  location.pathname.includes("/loto/roleManagement")
                    ? "bg-blue-50 text-blue-700"
                    : ""
                }`}
              >
                <img
                  src={assetManagement}
                  alt="Asset Management"
                  width="16"
                  height="16"
                  style={{ filter: "brightness(0) saturate(100%)" }}
                />
                <span className="text-sm font-semibold">Asset Management</span>
              </Link>
              <Link
                to={`/loto/padlockManagement/?token=${token}`}
                className={`flex items-center gap-3 px-4 py-3.5 !text-black hover:bg-blue-50 hover:text-blue-700 transition-colors ${
                  location.pathname.includes("/loto/padlockManagement")
                    ? "bg-blue-50 text-blue-700"
                    : ""
                }`}
              >
                <svg
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                  style={{ filter: "brightness(0) saturate(100%)" }}
                >
                  <path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zM12 17c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zM15.1 8H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z" />
                </svg>
                <span className="text-sm font-semibold">
                  Padlock Management
                </span>
              </Link>
              <Link
                to={`/loto/userManagement/?token=${token}`}
                className={`flex items-center gap-3 px-4 py-3.5 !text-black hover:bg-blue-50 hover:text-blue-700 transition-colors ${
                  location.pathname.includes("/loto/userManagement")
                    ? "bg-blue-50 text-blue-700"
                    : ""
                }`}
              >
                <img
                  src={roleManagement}
                  alt="Role Management"
                  width="16"
                  height="16"
                  style={{ filter: "brightness(0) saturate(100%)" }}
                />
                <span className="text-sm font-semibold">Role Management</span>
              </Link>
              <Link
                to={`/loto/workflowManagement/?token=${token}`}
                className={`flex items-center gap-3 px-4 py-3.5 !text-black hover:bg-blue-50 hover:text-blue-700 transition-colors ${
                  location.pathname.includes("/loto/workflowManagement")
                    ? "bg-blue-50 text-blue-700"
                    : ""
                }`}
              >
                <img
                  src={workflowManagement}
                  alt="Workflow Management"
                  width="16"
                  height="16"
                  style={{ filter: "brightness(0) saturate(100%)" }}
                />
                <span className="text-sm font-semibold">
                  Workflow Management
                </span>
              </Link>
              <Link
                to={buildApprovalMechanismUrl()}
                className={`flex items-center gap-3 px-4 py-3.5 !text-black hover:bg-blue-50 hover:text-blue-700 transition-colors ${
                  location.pathname.includes("/loto/approvalMechanism")
                    ? "bg-blue-50 text-blue-700"
                    : ""
                }`}
              >
                <img
                  src={approvalMechanism}
                  alt="Approval Mechanism"
                  width="16"
                  height="16"
                  style={{ filter: "brightness(0) saturate(100%)" }}
                />
                <span className="text-sm font-semibold">
                  Approval Mechanism
                </span>
              </Link>
              <Link
                to={`/loto/workflowOrchestration/?token=${token}`}
                className={`flex items-center gap-3 px-4 py-3.5 !text-black hover:bg-blue-50 hover:text-blue-700 transition-colors ${
                  location.pathname.includes("/loto/workflowOrchestration")
                    ? "bg-blue-50 text-blue-700"
                    : ""
                }`}
              >
                <img
                  src={workflowArch}
                  alt="Workflow Orchestration"
                  width="16"
                  height="16"
                  style={{ filter: "brightness(0) saturate(100%)" }}
                />
                <span className="text-sm font-semibold">
                  Workflow Orchestration
                </span>
              </Link>
              <Link
                to={`/loto/workOrderFormBuilder/?token=${token}`}
                className={`flex items-center gap-3 px-4 py-3.5 !text-black hover:bg-blue-50 hover:text-blue-700 transition-colors ${
                  location.pathname.includes("/loto/workOrderFormBuilder")
                    ? "bg-blue-50 text-blue-700"
                    : ""
                }`}
              >
                <img
                  src={workorderIcon}
                  alt="Work Order Form Builder"
                  width="16"
                  height="16"
                />
                <span className="text-sm font-semibold">
                  Work Order Form Builder
                </span>
              </Link>
            </div>
          </div>
        </div>
        <div></div>
      </nav>

      {/* Mobile Navigation */}
      <nav className="md:hidden flex justify-between items-center py-5 px-5 shadow-md bg-white">
        <div>
          <img src={logo} alt="Innvendt" />
        </div>
        <button
          onClick={() => setMenuOpen(!menuOpen)}
          className="focus:outline-none"
        >
          <svg
            className="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d={menuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16m-7 6h7"}
            ></path>
          </svg>
        </button>

        <div
          className={`fixed top-0 left-0 w-full h-full bg-white z-50 transition-transform transform ${
            menuOpen ? "translate-x-0" : "translate-x-full"
          }`}
        >
          <div className="flex justify-between items-center px-5 py-5 border-b shadow-md">
            <img src={logo} alt="Innvendt" />
            <button
              onClick={() => setMenuOpen(false)}
              className="focus:outline-none"
            >
              <svg
                className="w-6 h-6"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M6 18L18 6M6 6l12 12"
                ></path>
              </svg>
            </button>
          </div>
          <div className="flex flex-col items-center mt-10">
            <Link
              to="/home"
              className={`flex items-center gap-2 py-2 text-lg ${
                location.pathname === "/home" ? "bg-blue-300" : ""
              }`}
            >
              <img src={homeIcon} alt="Home" className="w-6 h-6" />
              Home
            </Link>
            <Link
              to="/mytasks"
              className={`flex items-center gap-2 py-2 text-lg ${
                location.pathname === "/mytasks" ? "bg-blue-300" : ""
              }`}
            >
              <img src={tasksIcon} alt="My Tasks" className="w-6 h-6" />
              My Tasks
            </Link>
            <Link
              to={`/loto/?token=${token}`}
              className={`flex items-center gap-2 py-2 text-lg ${
                location.pathname.includes("/loto/dashboard")
                  ? "bg-blue-300"
                  : ""
              }`}
            >
              <img src={alertIcon} alt="Loto" className="w-6 h-6" />
              Loto
            </Link>
            <div className="relative z-50">
              <div
                className={`flex items-center gap-2 py-2 text-lg cursor-pointer ${
                  hover ? "bg-blue-300" : ""
                }`}
                onClick={() => setHover(!hover)}
              >
                <img src={settingsIcon} alt="Settings" className="w-6 h-6" />
                Settings
                <svg
                  className="ml-2 w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M19 9l-7 7-7-7"
                  ></path>
                </svg>
              </div>
              <div
                className={`absolute left-0 top-10 bg-white shadow-md rounded-md overflow-hidden transition-all z-50 ${
                  hover ? "block" : "hidden"
                }`}
              >
                <Link
                  to={`/loto/roleManagement/?token=${token}`}
                  className={`flex items-center !text-black gap-3 px-14 py-3 hover:bg-blue-300 ${
                    location.pathname.includes("/loto/roleManagement")
                      ? "bg-blue-300"
                      : ""
                  }`}
                >
                  <img
                    src={assetManagement}
                    alt="Asset Management"
                    width="16"
                    height="16"
                    style={{ filter: "brightness(0) saturate(100%)" }}
                  />
                  <span className="text-sm font-semibold">
                    Asset Management
                  </span>
                </Link>
                <Link
                  to={`/loto/padlockManagement/?token=${token}`}
                  className={`flex items-center !text-black gap-3 px-14 py-3 hover:bg-blue-300 ${
                    location.pathname.includes("/loto/padlockManagement")
                      ? "bg-blue-300"
                      : ""
                  }`}
                >
                  <svg
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                  >
                    <path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zM12 17c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zM15.1 8H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z" />
                  </svg>
                  <span>Padlock Management</span>
                </Link>
                <Link
                  to={`/loto/userManagement/?token=${token}`}
                  className={`flex items-center !text-black gap-3 px-14 py-3 hover:bg-blue-300 ${
                    location.pathname.includes("/loto/userManagement")
                      ? "bg-blue-300"
                      : ""
                  }`}
                >
                  <img
                    src={roleManagement}
                    alt="Role Management"
                    width="16"
                    height="16"
                    style={{ filter: "brightness(0) saturate(100%)" }}
                  />
                  <span className="text-sm font-semibold">Role Management</span>
                </Link>
                <Link
                  to={`/loto/workflowManagement/?token=${token}`}
                  className={`flex items-center !text-black gap-3 px-14 py-3 hover:bg-blue-300 ${
                    location.pathname.includes("/loto/workflowManagement")
                      ? "bg-blue-300"
                      : ""
                  }`}
                >
                  <img
                    src={workflowManagement}
                    alt="Workflow Management"
                    width="16"
                    height="16"
                    style={{ filter: "brightness(0) saturate(100%)" }}
                  />
                  <span className="text-sm font-semibold">
                    Workflow Management
                  </span>
                </Link>
                <Link
                  to={buildApprovalMechanismUrl()}
                  className={`flex items-center !text-black gap-3 px-14 py-3 hover:bg-blue-300 ${
                    location.pathname.includes("/loto/approvalMechanism")
                      ? "bg-blue-300"
                      : ""
                  }`}
                >
                  <img
                    src={approvalMechanism}
                    alt="Approval Mechanism"
                    width="16"
                    height="16"
                    style={{ filter: "brightness(0) saturate(100%)" }}
                  />
                  <span className="text-sm font-semibold">
                    Approval Mechanism
                  </span>
                </Link>
                <Link
                  to={`/loto/workflowOrchestration/?token=${token}`}
                  className={`flex items-center !text-black gap-3 px-14 py-3 hover:bg-blue-300 ${
                    location.pathname.includes("/loto/workflowOrchestration")
                      ? "bg-blue-300"
                      : ""
                  }`}
                >
                  <img
                    src={workflowArch}
                    alt="Workflow Orchestration"
                    width="16"
                    height="16"
                    style={{ filter: "brightness(0) saturate(100%)" }}
                  />
                  <span className="text-sm font-semibold">
                    Workflow Orchestration
                  </span>
                </Link>
                <Link
                  to={`/loto/workOrderFormBuilder/?token=${token}`}
                  className={`flex items-center !text-black gap-3 px-14 py-3 hover:bg-blue-300 ${
                    location.pathname.includes("/loto/workOrderFormBuilder")
                      ? "bg-blue-300"
                      : ""
                  }`}
                >
                  <img
                    src={workorderIcon}
                    alt="Work Order Form Builder"
                    width="16"
                    height="16"
                  />
                  <span className="text-sm font-semibold">
                    Work Order Form Builder
                  </span>
                </Link>
                {/* <Link
                  to={`/loto/padlockManagement/?token=${token}`}
                  className="flex items-center !text-black gap-2 px-14 py-2 hover:bg-blue-300"
                >
                  <span>Padlock Management</span>
                </Link> */}
              </div>
            </div>
          </div>
        </div>
      </nav>
    </>
  );
};

export default Navbar;
