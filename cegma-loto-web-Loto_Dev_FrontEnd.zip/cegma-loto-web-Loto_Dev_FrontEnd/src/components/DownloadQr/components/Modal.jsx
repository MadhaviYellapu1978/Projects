import React from "react";
import * as yup from "yup";
import { Form, Formik } from "formik";
import FormikTextField from "../../../lib/Formik/FormikTextfield";
import { apiCall } from "../../../utils";
import { equipmentEndPoints, methods } from "../../../constants";
import toast from "react-hot-toast"; // Import the toast library

const DownloadQr = ({ setIsOpen }) => {
  const validationSchema = yup.object().shape({
    no_of_qrs: yup
      .number()
      .typeError("Must be a number")
      .required("No Of QR'S is required")
      .min(1, "At least 1 QR code is required")
      .max(1000, "Cannot generate more than 1000 QR codes"),
      
  });

  const initialValues = {
    no_of_qrs: "",
  };

  const handleSignIn = async (values) => {
    try {
      const res = await apiCall(equipmentEndPoints.downloadQr, methods.post, {
        downloadCount: parseInt(values.no_of_qrs),
      });

      if (res.qrfile && typeof res.qrfile === "string") {
        const link = document.createElement("a");
        link.href = res.qrfile;
        link.download = "QRCode.zip";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        // Show success message
        toast.success("QR Code downloaded successfully!" , { duration: 6000,});
        

        // Close the modal
        setIsOpen(false);
      } else {
        toast.error("Failed to download the QR Code. Please try again." , { duration: 5000,});
      }
    } catch (error) {
      toast.error("An error occurred. Please try again." , { duration: 5000,});
    }
  };

  const handleChange = (e, setFieldValue) => {
    let { value } = e.target;
    value = value.replace(/\D/g, ""); // Only allow numeric values
    setFieldValue("no_of_qrs", value);
  };

  return (
    <div className="text-center">
      <div className="flex justify-between items-center mb-5">
        <h1 className="text-center">Download QR</h1>
        <button
          onClick={() => {
            setIsOpen(false);
          }}
          className="text-gray-500 hover:text-gray-700 focus:outline-none"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-6 w-6"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M6 18L18 6M6 6l12 12"
            />
          </svg>
        </button>
      </div>
      <hr className="my-5" />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={handleSignIn}
      >
        {({ handleSubmit, setFieldValue, errors, touched }) => (
          <Form className="flex flex-col gap-4">
            <FormikTextField
              name="no_of_qrs"
              label="No Of QRS *"
              className="text-lg"
              type="text"
              onChange={(e) => handleChange(e, setFieldValue)}
            />

            <div className="flex justify-center gap-4 mt-4">
              <button
                type="button"
                className="bg-white flex items-center gap-2 py-3 px-8 rounded-full text-primary font-bold border-2 border-primary text-lg"
                onClick={() => {
                  setIsOpen(false);
                }}
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-primary flex items-center gap-3 py-3 px-8 rounded-full text-white font-bold text-lg"
              >
                Download
              </button>
            </div>
          </Form>
        )}
      </Formik>
    </div>
  );
};

export default DownloadQr;
