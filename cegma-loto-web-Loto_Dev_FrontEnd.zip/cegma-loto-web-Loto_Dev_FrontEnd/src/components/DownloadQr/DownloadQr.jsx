import React, { useState } from "react";
import { downloadqr } from "../../assets";
import ModalForm from "./components/Modal";
import { Box, Modal } from "@mui/material";

const DownloadQr = (props) => {
  const style = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: "462px", // Adjust the width as needed
    maxWidth: "90%", // Ensure it doesn't exceed the viewport width
    bgcolor: "background.paper",
    boxShadow: 24,
    p: 4,
    outline: "none",
    borderRadius: "12px"
  };
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div>
      <button
        className="bg-white flex items-center gap-2 py-3 px-5 rounded-full text-primary font-bold border-2 border-background: #1832B9;
"
        onClick={() => {
          setIsOpen(true);
        }}
      >
        <img src={downloadqr} alt="add" />
        Download QR
      </button>

      {
        <Modal
          open={isOpen}
          onClose={() => {
            setIsOpen(false);
          }}
        >
          <Box sx={style}>
            <ModalForm setIsOpen={setIsOpen} />
          </Box>
        </Modal>
      }
    </div>
  );
};

export default DownloadQr;
