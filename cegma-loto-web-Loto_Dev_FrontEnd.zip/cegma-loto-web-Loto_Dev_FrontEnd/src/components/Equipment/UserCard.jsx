import { Close } from "@mui/icons-material";
import {
  Box,
  Card,
  FormControl,
  Grid,
  InputLabel,
  MenuItem,
  Modal,
  Select,
  Stack,
  TextField,
  Tooltip,
  CircularProgress,
} from "@mui/material";
import Placeholder from "../../assets/placeholder.jpg";
import Multiselect from "multiselect-react-dropdown";
import React, { useEffect, useRef, useState } from "react";
import {
  equipmentEndPoints,
  methods,
  userEndPoints,
  workflowEndPoints,
} from "../../constants";
import { apiCall, decryptAesBase64 } from "../../utils";
import { encrypt, decrypt } from "../../crypto";
import toast from "react-hot-toast";

import Camera from "../UserManagement/Camera";
import { useSelector } from "react-redux";

const UserCard = (props) => {
  const { user: lotoUser, departments, roles, fetchData } = props;
  const [assignClicked, setAssignClicked] = useState();

  const [capturedFile, setCapturedFile] = useState(null);
  // eslint-disable-next-line
  const [capturedImage, setCapturedImage] = useState(null);
  const user = useSelector((state) => state.authSlice.user);

  // State for fetched roles and departments from API
  const [fetchedRoles, setFetchedRoles] = useState([]);
  const [fetchedDepartments, setFetchedDepartments] = useState([]);
  const [isLoadingRolesDept, setIsLoadingRolesDept] = useState(false);

  const transformedArray =
    fetchedRoles && Array.isArray(fetchedRoles)
      ? fetchedRoles.map((item) => {
          return { id: item.role_id, name: item.role_name };
        })
      : [];
  const [prefill, setPrefill] = useState([]);
  const [data, setData] = useState({
    emp_id: lotoUser?.emp_id || "",
    lotoDepartment: lotoUser?.Department || lotoUser?.lotoDepartment || "",
    lotoRoles: lotoUser?.lotoRoles || "",
    alias: lotoUser?.alias || "",
  });

  const [editClicked, setEditClicked] = useState(false);
  const editRef = useRef(null); // Create a ref
  const [assignFaceClicked, setAssignFaceClicked] = useState(false);
  const [loading, setLoading] = useState(false); // Add loading state
  const [assignLoading, setAssignLoading] = useState(false); // Add loading state for face assignment
  const [hasAssignedRole, setHasAssignedRole] = useState(false); // Track if role has been assigned
  const [assignedRoles, setAssignedRoles] = useState([]); // Track assigned roles for display

  // Reset assignedRoles when modal opens
  useEffect(() => {
    if (assignClicked) {
      setAssignedRoles([]);
    }
  }, [assignClicked]);

  // Fetch roles and departments from getRolesAndDept API when modal opens
  useEffect(() => {
    const fetchRolesAndDept = async () => {
      if (!assignClicked || !user?.org?.org_id) {
        return;
      }

      setIsLoadingRolesDept(true);
      try {
        const token = localStorage.getItem("token");

        // Call the getRolesAndDept endpoint
        const response = await apiCall(
          workflowEndPoints.getRolesAndDept,
          methods.get,
          null,
          token
        );

        // Handle different response formats
        let rolesData = [];
        if (Array.isArray(response)) {
          rolesData = response;
        } else if (response && Array.isArray(response.data)) {
          rolesData = response.data;
        } else if (response && Array.isArray(response.roles)) {
          rolesData = response.roles;
        } else if (response && typeof response === "object") {
          const maybeArray =
            response.body ||
            response.result ||
            response.payload ||
            response.data ||
            response.roles;
          if (Array.isArray(maybeArray)) {
            rolesData = maybeArray;
          }
        }

        // If response contains encrypted data field, decrypt it
        if (response?.data && typeof response.data === "string") {
          try {
            const decryptedRes = await decryptAesBase64(response.data);
            let parsedData;
            if (typeof decryptedRes === "string") {
              parsedData = JSON.parse(decryptedRes);
            } else {
              parsedData = decryptedRes;
            }

            if (Array.isArray(parsedData)) {
              rolesData = parsedData;
            } else if (parsedData && Array.isArray(parsedData.data)) {
              rolesData = parsedData.data;
            } else if (parsedData && Array.isArray(parsedData.roles)) {
              rolesData = parsedData.roles;
            }
          } catch (e) {
            console.error("Failed to decrypt roles data:", e);
          }
        }

        // Set fetched roles
        setFetchedRoles(rolesData);

        // Extract unique departments from roles data
        const uniqueDepartments = [];
        const departmentMap = new Map();

        rolesData.forEach((role) => {
          const deptName =
            role.department ||
            role.dept_name ||
            role.department_name ||
            role.deptName ||
            "";

          if (deptName && !departmentMap.has(deptName)) {
            departmentMap.set(deptName, true);
            uniqueDepartments.push({
              dept_name: deptName,
              dept_id: role.dept_id || role.department_id || "",
            });
          }
        });

        setFetchedDepartments(uniqueDepartments);
      } catch (err) {
        console.error("Failed to fetch roles and departments:", err);
        toast.error("Failed to load roles and departments");
        // Fallback to props if API fails
        if (roles && Array.isArray(roles)) {
          setFetchedRoles(roles);
        }
        if (departments && Array.isArray(departments)) {
          setFetchedDepartments(departments);
        }
      } finally {
        setIsLoadingRolesDept(false);
      }
    };

    fetchRolesAndDept();
  }, [assignClicked, user?.org?.org_id]);

  useEffect(() => {
    // Check for new structure first (Roles array)
    if (
      lotoUser?.Roles &&
      Array.isArray(lotoUser.Roles) &&
      lotoUser.Roles.length > 0
    ) {
      const prefill = lotoUser.Roles.map((role) => {
        return { name: role.role_name };
      });
      setPrefill(prefill);
      setHasAssignedRole(true); // User already has roles assigned
    } else if (lotoUser?.lotoRoles) {
      // Fallback to old structure
      const prefill = lotoUser.lotoRoles.split(",").map((item) => {
        return { name: item };
      });
      setPrefill(prefill);
      setHasAssignedRole(true); // User already has roles assigned
    } else {
      setHasAssignedRole(false); // User doesn't have roles assigned
    }
    function handleClickOutside(event) {
      if (editRef.current && !editRef.current.contains(event.target)) {
        setEditClicked(false);
      }
    }

    // Bind the event listener
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      // Unbind the event listener on clean up
      document.removeEventListener("mousedown", handleClickOutside);
    };
    // eslint-disable-next-line
  }, [editRef, data, lotoUser]);

  const handleChange = (e) => {
    setData((prev) => {
      return {
        ...prev,
        [e.target.name]: e.target.value,
      };
    });
  };

  const onSelect = (e) => {
    const joinedArr = e.map((each) => {
      return each.name;
    });
    setData((prev) => {
      return {
        ...prev,
        lotoRoles: joinedArr.join(","),
      };
    });
  };

  const onRemove = (e) => {
    const joinedArr = e.map((each) => {
      return each.name;
    });
    setData((prev) => {
      return {
        ...prev,
        lotoRoles: joinedArr.join(","),
      };
    });
  };

  const footerActions = (
    <button
      variant="contained"
      className="bg-primary flex gap-3 py-2 px-4 rounded-full text-white font-semibold"
      onClick={async () => {
        setAssignLoading(true);

        try {
          const formData = new FormData();
          formData.append("image", capturedFile);
          formData.append("emp_id", lotoUser?.emp_id || "");
          formData.append("org_id", user.org?.org_id);

          // Make API call without condition checks
          const response = await apiCall(
            userEndPoints.createFace,
            methods.post,
            formData,
            true,
            {
              "Content-Type": "multipart/form-data",
            }
          );

          if (response) {
            // Display success message, either from the response or a default message
            toast.success(
              response?.body?.message || "Successfully created face"
            );

            // Reset form and close the modal on success
            setAssignFaceClicked(false);
            setCapturedFile(null);
            fetchData();
          }
        } catch (error) {
          if (error?.response?.status === 400) {
            toast.error("Something went wrong while assigning face");
          } else {
            toast.error(
              error?.response?.data?.message,
              { duration: 6000 } || "An error occurred."
            );
          }
          // Keep the modal open when there's an error
        } finally {
          setAssignLoading(false);
        }
      }}
      disabled={assignLoading}
    >
      {assignLoading ? <CircularProgress size={24} /> : "Assign Face"}
    </button>
  );

  const onCaptureFile = (file) => {
    setCapturedFile(file);
  };

  return (
    <>
      <Grid item xs={12} md={4} sx={{ mt: 5, px: 3 }}>
        <Card className="bg-white border-2 border-slate-100 rounded-md p-4">
          <Grid container alignItems={"flex-start"} spacing={2}>
            <Grid item xs={12} sm={5}>
              <img
                src={lotoUser?.imageUrl || Placeholder}
                alt="img"
                style={{
                  height: 120,
                  width: "100%",
                  objectFit: "cover",
                  marginBottom: "15px",
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <h3 className="text-[#545d68] text-xl">
                {lotoUser?.first_name && lotoUser?.last_name
                  ? `${lotoUser.first_name} ${lotoUser.last_name}`
                  : lotoUser?.first_name || "N/A"}
              </h3>
              <h3>
                <span className="font-normal">Department:</span>{" "}
                {lotoUser?.Department || lotoUser?.lotoDepartment || "N/A"}
              </h3>
              <h3>
                <span className="font-normal">Roles:</span>{" "}
                <Tooltip
                  title={
                    lotoUser?.Roles && Array.isArray(lotoUser.Roles)
                      ? lotoUser.Roles.map(
                          (role) => `${role.role_name} (${role.alias_name})`
                        ).join(", ")
                      : lotoUser?.lotoRoles || ""
                  }
                  arrow
                  placement="top"
                >
                  <span style={{ cursor: "pointer" }}>
                    {(() => {
                      if (lotoUser?.Roles && Array.isArray(lotoUser.Roles)) {
                        if (lotoUser.Roles.length === 0) {
                          return <span style={{ color: "#999" }}>N/A</span>;
                        }
                        const rolesText = lotoUser.Roles.map(
                          (role) => role.role_name
                        ).join(", ");
                        // Truncate if longer than 30 characters
                        return rolesText.length > 30
                          ? rolesText.slice(0, 30) + "..."
                          : rolesText;
                      }
                      // Fallback to old structure
                      if (lotoUser?.lotoRoles) {
                        return lotoUser.lotoRoles.length > 30
                          ? lotoUser.lotoRoles.slice(0, 30) + "..."
                          : lotoUser.lotoRoles;
                      }
                      return <span style={{ color: "#999" }}>N/A</span>;
                    })()}
                  </span>
                </Tooltip>
              </h3>
            </Grid>
            <Grid item xs={12} sm={1} ref={editRef}>
              <div
                onClick={() => {
                  setEditClicked(!editClicked);
                }}
                className="cursor-pointer"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="5"
                  height="14"
                  viewBox="0 0 5 25"
                  fill="none"
                >
                  <circle cx="2.5" cy="2.5" r="2.5" fill="#999999" />
                  <circle cx="2.5" cy="12.5" r="2.5" fill="#999999" />
                  <circle cx="2.5" cy="22.5" r="2.5" fill="#999999" />
                </svg>
              </div>
              {editClicked ? (
                <div>
                  <Card className="absolute">
                    <ul>
                      <li
                        className=" min-w-24 text-center py-2 cursor-pointer hover:bg-blue-300 "
                        onClick={() => {
                          setEditClicked(false);
                          setAssignClicked(true);
                        }}
                      >
                        {hasAssignedRole ? "Edit Role" : "Assign Role"}
                      </li>
                      {!lotoUser?.face_id && (
                        <li
                          className="min-w-24 text-center py-2 cursor-pointer hover:bg-blue-300"
                          onClick={() => {
                            setAssignFaceClicked(true);
                          }}
                        >
                          Assign Face
                        </li>
                      )}
                    </ul>
                  </Card>
                </div>
              ) : (
                <></>
              )}
            </Grid>
          </Grid>
        </Card>
      </Grid>
      <Modal
        open={assignClicked}
        sx={{
          border: 0,
        }}
      >
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: 400,
            bgcolor: "background.paper",
            outline: "none",
            border: 0,
            boxShadow: 24,
            padding: 4,
            borderRadius: "12px",
          }}
        >
          <Stack
            direction={"row"}
            justifyContent={"space-between"}
            sx={{
              borderBottom: "1px solid black",
              marginBottom: 5,
              paddingY: 2,
            }}
          >
            <div></div>
            <h3 className="text-xl">Assign Role</h3>
            <p className="text-xl">
              <Close
                onClick={() => {
                  setAssignClicked(false);
                }}
                className="cursor-pointer"
              />
            </p>
          </Stack>
          <form>
            <Stack gap={2}>
              <TextField
                label="Name"
                value={
                  lotoUser?.first_name && lotoUser?.last_name
                    ? `${lotoUser.first_name} ${lotoUser.last_name}`
                    : lotoUser?.first_name || ""
                }
                disabled
              />
              <FormControl>
                <InputLabel id="department">Department*</InputLabel>
                <Select
                  id="department"
                  labelId="department"
                  label="Department*"
                  name="lotoDepartment"
                  onChange={handleChange}
                  value={data.lotoDepartment}
                  disabled={isLoadingRolesDept}
                  displayEmpty
                >
                  {isLoadingRolesDept ? (
                    <MenuItem disabled value="">
                      <CircularProgress size={16} sx={{ mr: 1 }} />
                      Loading departments...
                    </MenuItem>
                  ) : fetchedDepartments &&
                    Array.isArray(fetchedDepartments) &&
                    fetchedDepartments.length > 0 ? (
                    fetchedDepartments.map((department, index) => (
                      <MenuItem key={index} value={department.dept_name}>
                        {department.dept_name}
                      </MenuItem>
                    ))
                  ) : (
                    <MenuItem disabled value="">
                      No departments available
                    </MenuItem>
                  )}
                </Select>
              </FormControl>
              <FormControl>
                <InputLabel id="role">Role*</InputLabel>
                <Select
                  id="role"
                  labelId="role"
                  label="Role*"
                  name="lotoRoles"
                  onChange={handleChange}
                  value={data.lotoRoles}
                  disabled={isLoadingRolesDept}
                  displayEmpty
                >
                  {isLoadingRolesDept ? (
                    <MenuItem disabled value="">
                      <CircularProgress size={16} sx={{ mr: 1 }} />
                      Loading roles...
                    </MenuItem>
                  ) : fetchedRoles &&
                    Array.isArray(fetchedRoles) &&
                    fetchedRoles.length > 0 ? (
                    fetchedRoles.map((role, index) => (
                      <MenuItem key={index} value={role.role_name}>
                        {role.role_name}
                      </MenuItem>
                    ))
                  ) : (
                    <MenuItem disabled value="">
                      No roles available
                    </MenuItem>
                  )}
                </Select>
              </FormControl>
              <TextField
                label="Alias or Aka"
                name="alias"
                value={data.alias}
                onChange={handleChange}
                placeholder="Area Owner"
              />
            </Stack>
            <div
              style={{
                display: "flex",
                justifyContent: "flex-start",
                marginTop: "16px",
              }}
            >
              <button
                type="button"
                className="bg-primary flex gap-3 py-2 px-7 rounded-full text-white font-semibold"
                onClick={() => {
                  if (data.lotoRoles && data.alias) {
                    const newRole = `${data.lotoRoles} ${data.alias}`;
                    setAssignedRoles([...assignedRoles, newRole]);
                    // Clear only the form fields, don't assign the role yet
                    setData((prev) => ({ ...prev, lotoRoles: "", alias: "" }));
                  }
                }}
              >
                Add
              </button>
            </div>
            {assignedRoles.length > 0 && (
              <div
                className="flex flex-wrap gap-2"
                style={{ marginTop: "8px" }}
              >
                {assignedRoles.map((role, index) => (
                  <div
                    key={index}
                    style={{
                      backgroundColor: "#E3F2FD",
                      color: "#1976D2",
                      borderRadius: "20px",
                      padding: "6px 12px",
                      fontSize: "14px",
                      fontWeight: "500",
                      display: "inline-flex",
                      alignItems: "center",
                      gap: "8px",
                      width: "fit-content",
                      maxWidth: "200px",
                    }}
                  >
                    <span>{role}</span>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        setAssignedRoles(
                          assignedRoles.filter((_, i) => i !== index)
                        );
                      }}
                      style={{
                        background: "none",
                        border: "none",
                        cursor: "pointer",
                        fontSize: "16px",
                        lineHeight: "1",
                        color: "#1976D2",
                        padding: "0",
                        marginLeft: "4px",
                        outline: "none",
                      }}
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
            )}
            <Stack direction={"row"} justifyContent={"center"} sx={{ mt: 2 }}>
              <button
                variant="outlined"
                onClick={() => setAssignClicked(false)}
                className="border-2 border-primary flex gap-3 py-1 px-5 rounded-full text-primary font-semibold"
              >
                Cancel
              </button>
              <button
                variant="contained"
                type="button"
                className="bg-primary flex gap-3 py-2 px-7 ml-4 rounded-full text-white font-semibold"
                onClick={async (e) => {
                  e.preventDefault();
                  setLoading(true);
                  if (
                    data.emp_id &&
                    data.lotoDepartment &&
                    assignedRoles.length > 0
                  ) {
                    try {
                      const token = localStorage.getItem("token");
                      const orgId = user?.org?.org_id || user?.org_id || "";

                      if (!orgId) {
                        toast.error("Organization ID not found!");
                        setLoading(false);
                        return;
                      }

                      // Process all assigned roles and build roles array
                      const rolesArray = [];
                      for (const assignedRole of assignedRoles) {
                        // Extract role name (first word before space, e.g., "Technician" from "Technician Area Owner")
                        const roleName = assignedRole.split(" ")[0];

                        // Extract alias name (everything after the first space)
                        const aliasName = assignedRole
                          .substring(roleName.length)
                          .trim();

                        // Find the role_id from the fetchedRoles
                        const roleData = fetchedRoles?.find(
                          (role) => role.role_name === roleName
                        );

                        if (!roleData) {
                          continue;
                        }

                        const roleId = roleData.role_id || roleData.id || "";

                        if (!roleId) {
                          continue;
                        }

                        // Add role to the roles array
                        rolesArray.push({
                          roleId: Number(roleId),
                          roleName: roleName,
                          alias_names: aliasName,
                        });
                      }

                      if (rolesArray.length === 0) {
                        toast.error(
                          "No valid roles found. Please check role names."
                        );
                        setLoading(false);
                        return;
                      }

                      // Prepare payload for assignRoles API with roles array
                      const payload = {
                        orgId: orgId,
                        emp_id: lotoUser?.emp_id || data.emp_id || "",
                        roles: rolesArray,
                      };

                      // Encrypt the payload
                      const encryptedPayload = encrypt(payload);

                      const requestPayload = {
                        data: encryptedPayload,
                      };

                      // Call the assignRoles API with all roles at once
                      const response = await apiCall(
                        workflowEndPoints.assignRoles,
                        methods.post,
                        requestPayload,
                        token
                      );

                      // Check for errors (same pattern as users API)
                      if (response?.status >= 400) {
                        const errorData = response.data;
                        const errorMessage =
                          errorData?.error ||
                          errorData?.message ||
                          errorData?.details ||
                          JSON.stringify(errorData) ||
                          "Failed to assign roles";
                        throw new Error(errorMessage);
                      }

                      // Decrypt the response data (same pattern as users API)
                      const decryptedResponse = decrypt(response.data);
                      console.log("decryptedResponse:", decryptedResponse);

                      // Handle successful response
                      setAssignClicked(false);
                      setHasAssignedRole(true);
                      toast.success(
                        `Successfully assigned ${rolesArray.length} role(s)!`
                      );
                      fetchData();
                    } catch (error) {
                      toast.error(error?.message || "Error assigning roles!");
                    }
                  } else {
                    toast.dismiss();
                    toast.error(
                      "Please fill all the fields and add at least one role"
                    );
                  }
                  setLoading(false);
                }}
              >
                {loading ? (
                  <CircularProgress size={24} color="inherit" />
                ) : (
                  "Save"
                )}
              </button>
            </Stack>
          </form>
        </Box>
      </Modal>
      <Modal open={assignFaceClicked}>
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: 400,
            bgcolor: "background.paper",
            outline: "none",
            border: 0,
            boxShadow: 24,
            padding: 4,
            borderRadius: "12px",
          }}
        >
          <Stack
            direction={"row"}
            justifyContent={"space-between"}
            sx={{
              borderBottom: "1px solid black",
              marginBottom: 5,
              paddingY: 2,
            }}
          >
            <div></div>
            <h3 className="text-xl">Capture Photo</h3>
            <p className="text-xl">
              <Close
                onClick={() => {
                  setAssignFaceClicked(false);
                }}
                className="cursor-pointer"
              />
            </p>
          </Stack>
          <Stack justifyContent={"center"} alignItems={"center"}>
            <Camera
              footerActions={footerActions}
              handleClose={() => setAssignFaceClicked(false)}
              onCaptureFile={onCaptureFile}
              // onCaptureImage={onCaptureImage}
            />
          </Stack>
        </Box>
      </Modal>
    </>
  );
};

export default UserCard;
