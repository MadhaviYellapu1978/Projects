import React, { useEffect, useRef, useState } from "react";
import { apiCall } from "../../utils";
import { equipmentEndPoints, methods } from "../../constants";
import AddLotoEquipmentForm from "../AddAssets/components/Modal";
import { Link } from "react-router-dom";
import { Box, Card, Grid, Modal, Tooltip, Typography } from "@mui/material";
import toast from "react-hot-toast";

const EquipmentCard = (props) => {
  const searchParams = new URLSearchParams(window.location.search);
  const tokenValue = searchParams.get("token");

  const { data, fetchData, selectedZone, selectedSite } = props;
  const [machineData, setMachineData] = useState({});
  const [editClicked, setEditClicked] = useState(false);
  const editRef = useRef(null);
  const [equipmentEdit, setEquipmentEdit] = useState(false);
  const [deleteConfirmation, setDeleteConfirmation] = useState(false);

  const style = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    bgcolor: "background.paper",
    boxShadow: 24,
    height: "auto",
    p: 4,
    outline: "none",
    borderRadius: "12px",
  };

  useEffect(() => {
    setMachineData(data);
  }, [data]);

  useEffect(() => {
    function handleClickOutside(event) {
      if (editRef.current && !editRef.current.contains(event.target)) {
        setEditClicked(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [editRef]);

  const handleDelete = async () => {
    try {
      const response = await apiCall(
        `${equipmentEndPoints.deleteEquipment}/?equipmentId=${data.equipmentId}`,
        methods.delete
      );

      if (response && response.message) {
        toast.success(response.message);
      }

      fetchData();
      setDeleteConfirmation(false);
      setEditClicked(false);
    } catch (error) {
      if (
        error.response &&
        error.response.data &&
        error.response.data.message
      ) {
        toast.error(error.response.data.message); // Show error message from the API
      } else {
        toast.error("An error occurred. Please try again."); // Generic error message
      }
    }
  };

  if (!data) return <></>;

  return (
    <Card className="p-5">
      <Grid container spacing={2}>
        <Grid item xs={4}>
          <img
            src={data.equipmentImgPath}
            alt={data.equipmentName}
            style={{ height: 120 }}
          />
        </Grid>
        <Grid item xs={7}>
          <Tooltip title={data.equipmentName}>
            <span className="font-semibold text-black">Equipment:</span>
            {(data.equipmentName + " ").slice(0, 10) + "..."}
          </Tooltip>
          <br />
          <Tooltip title={data.machines[0]?.machineName}>
            <span className="font-semibold text-black">Machines: </span>
            {(data.machines[0]?.machineName + " ").slice(0, 10) + "..."}
          </Tooltip>
          <br />
          <Tooltip title={data.machines[0]?.isolationPoints[0]?.isolationName}>
            <span className="font-semibold text-black">Isolation Point: </span>
            {(data.machines[0]?.isolationPoints[0]?.isolationName + " ").slice(
              0,
              10
            ) + "..."}
          </Tooltip>
        </Grid>
        <Grid item xs={1} ref={editRef}>
          <div
            onClick={() => {
              setEditClicked(!editClicked);
            }}
            className="cursor-pointer"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="5"
              height="25"
              viewBox="0 0 5 25"
              fill="none"
            >
              <circle cx="2.5" cy="2.5" r="2.5" fill="#999999" />
              <circle cx="2.5" cy="12.5" r="2.5" fill="#999999" />
              <circle cx="2.5" cy="22.5" r="2.5" fill="#999999" />
            </svg>
          </div>
          {editClicked ? (
            <div className="relative">
              <Card className="absolute right-0">
                <ul>
                  <li
                    className="min-w-28 py-2 text-center cursor-pointer hover:bg-blue-300"
                    onClick={() => {
                      setEquipmentEdit(true);
                    }}
                  >
                    Edit
                  </li>
                  <li
                    className="min-w-28 py-2 text-center cursor-pointer hover:bg-blue-300"
                    onClick={() => {
                      setDeleteConfirmation(true);
                    }}
                  >
                    Delete
                  </li>
                  <li className="min-w-28 py-2 text-center cursor-pointer hover:bg-blue-300">
                    <Link
                      to={`/equipment-details?token=${tokenValue}`}
                      className=" cursor-pointer "
                      state={{ state: data }}
                    >
                      View More
                    </Link>
                  </li>
                </ul>
              </Card>
            </div>
          ) : (
            <></>
          )}
        </Grid>
      </Grid>
      <hr className="my-5" />
      <Grid container>
        <Grid item xs={12} md={4}>
          <p>Location</p>
          <Tooltip title={data.location} className="font-semibold text-black">
            {data.location.length > 10
              ? data.location.slice(0, 10) + "..."
              : data.location}
          </Tooltip>
        </Grid>
        <Grid item xs={12} md={4}>
          <p>Zone</p>
          <Tooltip title={selectedZone} className="font-semibold text-black">
            {selectedZone}
          </Tooltip>
        </Grid>
        <Grid item xs={12} md={4}>
          <p>Site</p>
          <Tooltip title={selectedSite} className="font-semibold text-black">
            {selectedSite}
          </Tooltip>
        </Grid>
      </Grid>
      <Modal
        open={equipmentEdit}
        onClose={() => {
          setEquipmentEdit(false);
        }}
      >
        <Box sx={style}>
          <AddLotoEquipmentForm
            setIsOpen={setEquipmentEdit}
            fetchData={fetchData}
            setMachineData={setMachineData}
            machineData={{
              ...machineData,
              lastTestedDate: machineData.lastTestedDate,
            }}
            data={machineData}
            type="edit"
          />
        </Box>
      </Modal>
      <Modal
        open={deleteConfirmation}
        onClose={() => setDeleteConfirmation(false)}
      >
        <Box sx={style}>
          <Typography variant="h6" component="h2" mb={2}>
            Are you sure you want to delete this equipment?
          </Typography>
          <Box display="flex" justifyContent="center">
            <button
              className="border-2 border-primary py-2 px-6 rounded-full text-primary font-semibold mr-3"
              onClick={() => setDeleteConfirmation(false)}
            >
              Cancel
            </button>
            <button
              className="bg-primary py-2 px-6 rounded-full text-white font-semibold"
              onClick={handleDelete}
            >
              Delete
            </button>
          </Box>
        </Box>
      </Modal>
    </Card>
  );
};

export default EquipmentCard;
