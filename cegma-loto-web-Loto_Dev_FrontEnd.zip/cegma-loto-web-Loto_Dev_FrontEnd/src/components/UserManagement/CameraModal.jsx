import React, { useState } from "react";
import { Box, Modal } from "@mui/material";
import { plusIcon } from "../../assets";
import { apiCall } from "../../utils";
import { methods, userEndPoints } from "../../constants";
import { useSelector } from "react-redux";
import AddContractUser from "../UserManagement/AddContractUser";
import toast from "react-hot-toast";
import Camera from "./Camera";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  maxWidth: 400,
  width: "100%",
  bgcolor: "background.paper",
  boxShadow: 24,
  p: 4,
  outline: "none",
  borderRadius: "12px",
};

export default function ParentComponent({ fetchData }) {
  const [openModal, setOpenModal] = useState(false);
  const [capturedImage, setCapturedImage] = useState(null);
  const [capturedFile, setCapturedFile] = useState(null);
  const [faceId, setFaceId] = useState(null);
  const [currentStep, setCurrentStep] = useState(0); // 0: Camera, 1: AddContractUser
  const user = useSelector((state) => state.authSlice.user);

  const handleOpenModal = () => setOpenModal(true);
  const handleCloseModal = () => {
    resetCapture();
    setOpenModal(false);
    setCurrentStep(0);
  };

  const handleNextStep = () => {
    if (currentStep === 0 && capturedFile) {
      const formData = new FormData();
      formData.append("image", capturedFile);
      formData.append("org_id", user.org.org_id);
  
      try {
        apiCall(userEndPoints.createFace, methods.post, formData, true, {
          "Content-Type": "multipart/form-data",
        })
          .then((response) => {
            if (response && response.body && response.body.face_id) {
              setFaceId(response.body.face_id); // Set the face ID from the response
              setCurrentStep(1);
  
              // Show success message from API response or default message
              const successMessage = response.body.message || "Face creation was successful!";
              console.log(successMessage, "response success message");
              toast.success(successMessage, { duration: 8000 });
            }
          })
          .catch((error) => {
            // Handle error and show error message if necessary
            const errorMessage = error?.response?.body?.message || "There was an error creating the face.";
            toast.error(errorMessage, { duration: 8000 });
          });
      } catch (err) {
        // Optional: handle additional errors here
      }
    }
  };
  
  const resetCapture = () => {
    setCapturedImage(null);
    setCurrentStep(0);
  };

  const footerActions = (
    <button
      className="bg-primary gap-3 rounded-full w-full text-white text-center font-bold py-3"
      onClick={handleNextStep}
    >
      Next
    </button>
  );

  const onCaptureImage = (img) => {
    setCapturedImage(img);
  };

  const onCaptureFile = (file) => {
    setCapturedFile(file);
  };

  return (
    <div>
      <button
        className="bg-primary flex gap-2 py-3 px-7 rounded-full text-white font-bold mr-0"
        onClick={handleOpenModal}
      >
        <img src={plusIcon} alt="add" />
        Contractor
      </button>
      <Modal
        open={openModal}
        onClose={handleCloseModal}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          {currentStep === 0 ? (
            <Camera
              handleClose={handleCloseModal}
              footerActions={footerActions}
              onCaptureImage={onCaptureImage}
              onCaptureFile={onCaptureFile}
            />
          ) : (
            <AddContractUser
              handleClose={handleCloseModal}
              capturedImage={capturedImage}
              faceId={faceId}
              fetchData={fetchData}
            />
          )}
        </Box>
      </Modal>
    </div>
  );
}
