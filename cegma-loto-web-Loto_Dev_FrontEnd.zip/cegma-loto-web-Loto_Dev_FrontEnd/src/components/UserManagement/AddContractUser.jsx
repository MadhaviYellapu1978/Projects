import React from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { Grid, TextField } from "@mui/material";
import { useSelector } from "react-redux";
import { apiCall } from "../../utils";
import { methods, userEndPoints } from "../../constants";
import toast from "react-hot-toast";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  maxWidth: 400,
  width: "100%",
  bgcolor: "background.paper",
  boxShadow: 24,
  p: 4,
  outline: "none",
  borderRadius: "12px",
};

export default function AddContractUser({
  handleClose,
  capturedImage,
  faceId,
  fetchData,
}) {
  const [formData, setFormData] = React.useState({
    first_name: "",
    last_name: "",
    phno: "",
  });

  const [formErrors, setFormErrors] = React.useState({
    first_name: "",
    last_name: "",
    phno: "",
  });

  const [isPhoneValid, setIsPhoneValid] = React.useState(false);
  const user = useSelector((state) => state.authSlice.user);

  const validatePhone = (phone) => {
    const phoneRegex = /^\d{10}$/;
    return phoneRegex.test(phone);
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    let error = "";

    if (value.includes(" ")) {
      error = "Spaces are not allowed";
    }

    setFormData({ ...formData, [name]: value });
    setFormErrors({ ...formErrors, [name]: error });

    if (name === "phno") {
      setIsPhoneValid(validatePhone(value));
      setFormErrors({
        ...formErrors,
        phno: validatePhone(value) ? "" : "Invalid phone number",
      });
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    apiCall(userEndPoints.createContractor, methods.post, {
      ...formData,
      org_id: user.org.org_id,
      face_id: faceId,
      email_id: "",
    })
      .then((data) => {
        fetchData();
        toast.success(data.body.message, { duration: 6000 });
        handleClose(); // Close the modal after form submission
      })
      .catch((err) => {
        console.error(err);
        toast.error("Failed to add contractor");
      });
  };

  const isFormValid =
    formData.first_name &&
    formData.last_name &&
    isPhoneValid &&
    !formErrors.first_name &&
    !formErrors.last_name;

  return (
    <Box sx={style}>
      <Typography
        variant="body1"
        sx={{ display: "flex", justifyContent: "center", mb: "10px" }}
      >
        Add Contractor
      </Typography>
      <hr />
      <form
        onSubmit={handleSubmit}
        style={{ marginTop: "20px", marginBottom: "10px" }}
      >
        <Grid container spacing={2}>
          <Grid item lg={12} md={12} xs={12}>
            <TextField
              label="First Name"
              fullWidth
              name="first_name"
              required
              value={formData.first_name}
              error={!!formErrors.first_name}
              helperText={formErrors.first_name}
              onChange={handleInputChange}
            />
          </Grid>
          <Grid item lg={12} md={12} xs={12}>
            <TextField
              label="Last Name"
              fullWidth
              name="last_name"
              required
              value={formData.last_name}
              error={!!formErrors.last_name}
              helperText={formErrors.last_name}
              onChange={handleInputChange}
            />
          </Grid>
          <Grid item lg={12} md={12} xs={12}>
            <TextField
              sx={{ mr: "16px" }}
              label="Phone number"
              fullWidth
              name="phno"
              required
              value={formData.phno}
              error={!isPhoneValid && formData.phno.length > 0}
              helperText={!isPhoneValid && formData.phno.length > 0 ? "Invalid phone number" : ""}
              onChange={handleInputChange}
            />
          </Grid>
        </Grid>
        <div
          style={{
            marginTop: "10px",
            display: "flex",
            justifyContent: "center",
          }}
        >
          <button
            type="submit"
            className="flex gap-3 py-3 px-5 rounded-full text-white font-bold ml-3 mt-5"
            style={{
              backgroundColor: isFormValid ? "#1976d2" : "#cccccc",
              color: isFormValid ? "white" : "#666666",
              cursor: isFormValid ? "pointer" : "not-allowed",
            }}
            disabled={!isFormValid}
          >
            Submit
          </button>
        </div>
      </form>
    </Box>
  );
}
