// import * as React from "react";
// import Button from "@mui/material/Button";
// import Typography from "@mui/material/Typography";
// import Webcam from "react-webcam";
// import { apiCall } from "../../utils";
// import { methods, userEndPoints } from "../../constants";

// const style = {
//   position: "absolute",
//   top: "50%",
//   left: "50%",
//   transform: "translate(-50%, -50%)",
//   width: 700,
//   bgcolor: "background.paper",
//   border: "2px solid #000",
//   boxShadow: 24,
//   p: 4,
// };

// const AddContractUserDetails = () => {
//   const [captureMode, setCaptureMode] = React.useState(false);
//   const [capturedImage, setCapturedImage] = React.useState(null);
//   const webcamRef = React.useRef(null);

//   const videoConstraints = {
//     width: 1280,
//     height: 720,
//     facingMode: "user",
//   };

//   const handleClose = () => {
//     setCaptureMode(false); // Reset capture mode
//   };

//   const capturePhoto = () => {
//     const imageSrc = webcamRef.current.getScreenshot();
//     setCapturedImage(imageSrc);
//     setCaptureMode(true);
//   };

//   const resetCapture = () => {
//     setCapturedImage(null);
//     setCaptureMode(false);
//   };

//   const handleSave = () => {
//     if (capturedImage) {
//       // Convert JPEG to PNG
//       const img = new Image();
//       img.onload = () => {
//         const canvas = document.createElement("canvas");
//         canvas.width = img.width;
//         canvas.height = img.height;
//         const ctx = canvas.getContext("2d");
//         ctx.drawImage(img, 0, 0);
//         canvas.toBlob((blob) => {
//           console.log(blob); // Blob object containing PNG image data
//         }, "image/png");
//       };
//       img.src = capturedImage;

//       apiCall(userEndPoints.createFace, methods.post).then((response) => {
//         console.log("Image is saved successfully", response).catch((error) => {
//           console.error("Error saving image", error);
//         });
//       }, "image/png");
//     }
//   };

//   return (
//     <div>
//       <Typography id="modal-modal-title" variant="h6" component="h2">
//         Camera
//       </Typography>

//       {captureMode ? (
//         <div>
//           {capturedImage && <img src={capturedImage} alt="Captured" />}
//           <br />
//           <Button onClick={handleSave}>Save </Button>
//           <Button onClick={resetCapture}>Recapture</Button>
//         </div>
//       ) : (
//         <div>
//           <Webcam
//             ref={webcamRef}
//             audio={true}
//             screenshotFormat="image/png"
//             videoConstraints={videoConstraints}
//             height={500}
//             width={500}
//           />
//           <button
//             className="bg-primary flex rounded-full p-3 m-3 text-white font-bold  "
//             onClick={capturePhoto}
//           >
//             Capture
//           </button>
//         </div>
//       )}
//     </div>
//   );
// };

// export default AddContractUserDetails;
