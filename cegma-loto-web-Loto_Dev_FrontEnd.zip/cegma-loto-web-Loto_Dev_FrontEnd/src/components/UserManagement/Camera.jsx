/* eslint-disable */
import React, { useState, useRef, useEffect } from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Webcam from "react-webcam";


export default function Camera({
  handleClose,
  footerActions,
  onCaptureImage,
  onCaptureFile,
}) {
  const [capturedImage, setCapturedImage] = useState(null);
  const [capturedFile, setCapturedFile] = useState(null);
  const webcamRef = useRef(null);

  useEffect(() => {}, [capturedFile]); // Log capturedFile whenever it changes

  const videoConstraints = {
    width: 1280,
    height: 720,
    facingMode: "user",
  };

  // const dataURLtoFile = (dataurl, filename) => {
  //   const arr = dataurl.split(",");
  //   const mime = arr[0].match(/:(.*?);/)[1];
  //   const bstr = atob(arr[1]);
  //   let n = bstr.length;
  //   const u8arr = new Uint8Array(n);
  //   while (n--) {
  //     u8arr[n] = bstr.charCodeAt(n);
  //   }
  //   return new File([u8arr], filename, { type: mime });
  // };

  const capturePhoto = async () => {
    try {
      const imageSrc = webcamRef.current.getScreenshot();

      const response = await fetch(imageSrc);
      const blob = await response.blob();

      const file = new File([blob], "capturedImage.png", { type: "image/png" });

      setCapturedImage(imageSrc);
      setCapturedFile(file);
      if (onCaptureImage) {
        onCaptureImage(imageSrc);
      }
      onCaptureFile(file);
    } catch (error) {
      console.error("Error capturing photo:", error);
    }
  };

  const resetCapture = () => {
    setCapturedImage(null);
    setCapturedFile(null);
    if (onCaptureImage) {
      onCaptureImage(null);
    }
    onCaptureFile(null);
  };

  return (
    <Box>
      <>
        <Typography id="modal-modal-title" variant="h6" component="h2">
          Camera
        </Typography>
        <div>
          {capturedImage ? (
            <div>
              <img src={capturedImage} alt="Captured" className="w-full" />
              <br />
              <div className="grid grid-cols-2 md:grid-cols-3 gap-5">
                <button
                  onClick={handleClose}
                  className="bg-primary gap-3 rounded-full w-full text-white text-center font-bold py-3"
                >
                  Cancel
                </button>
                <button
                  onClick={resetCapture}
                  className="bg-primary gap-3 rounded-full w-full text-white text-center font-bold py-3"
                >
                  Recapture
                </button>
                {footerActions}
              </div>
            </div>
          ) : (
            <div>
              <Webcam
                ref={webcamRef}
                audio={false}
                screenshotFormat="image/png"
                videoConstraints={videoConstraints}
                height={
                  window.innerWidth < 320
                    ? 250
                    : window.innerWidth < 500
                    ? 300
                    : 400
                }
                width={
                  window.innerWidth < 320
                    ? 250
                    : window.innerWidth < 500
                    ? 300
                    : 400
                }
              />
              <button
                className="bg-primary flex rounded-full p-3 m-3 text-white font-bold"
                onClick={capturePhoto}
              >
                Capture
              </button>
            </div>
          )}
        </div>
      </>
    </Box>
  );
}
