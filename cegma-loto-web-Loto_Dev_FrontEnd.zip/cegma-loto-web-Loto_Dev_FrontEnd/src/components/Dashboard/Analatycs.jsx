import React, { useState } from "react";
import Chart from "react-apexcharts";
import LinearWithValueLabel from "../Dashboard/ProgressBar";
import { MenuItem, Select, FormControl, Stack, Box } from "@mui/material";
import DownTime from "../../assets/DownTime.svg";
import ScheduleTime from "../../assets/ScheduleTime.svg";
import { useTheme } from "@mui/material/styles";
import useMediaQuery from "@mui/material/useMediaQuery";

const pieOptions = {
  labels: [
    "Avg Loto Approval Time",
    "Avg Isolation Process Time",
    "Avg Time taken for work completion",
    "Avg De-Isolation Process Time",
  ],
  colors: ["#0095FF", "#1832B9", "#40E8B0", "#FE9A0F"],
  legend: {
    itemMargin: {
      vertical: 12,
    },
    height: "100%",
    formatter: function (seriesName, opts) {
      const times = ["02 mins", "01 mins", "1.5 hours", "01 mins"];
      return `<div style="display: flex; align-items: center; gap: 8px;">
      <span style=" width: 12px; height: 12px; border-radius: 50%; display: inline-block; margin-right: 2px; "></span>
      <div>
        ${seriesName}
        <br/>
        <span style="font-size: 14px; color: black; font-weight: 500;"><b>${
          times[opts.seriesIndex]
        }</b></span>
      </div>
    </div>`;
    },
  },
};

const pieSeries = [2, 1, 1.5, 1];

const barOptions = {
  chart: {
    type: "bar",
    toolbar: {
      show: false,
    },
    events: {
      dataPointMouseEnter: function (event, chartContext, config) {
        const seriesIndex = config.seriesIndex;
        const scheduleTimeLogo = document.getElementById("scheduleTimeLogo");
        const downTimeLogo = document.getElementById("downTimeLogo");

        if (seriesIndex === 0) {
          scheduleTimeLogo.style.filter = "brightness(1.5)";
        } else if (seriesIndex === 1) {
          downTimeLogo.style.filter = "brightness(1.5)";
        }
      },
      dataPointMouseLeave: function () {
        const scheduleTimeLogo = document.getElementById("scheduleTimeLogo");
        const downTimeLogo = document.getElementById("downTimeLogo");

        scheduleTimeLogo.style.filter = "brightness(1)";
        downTimeLogo.style.filter = "brightness(1)";
      },
    },
  },
  plotOptions: {
    bar: {
      horizontal: false,
      columnWidth: "45%",
      endingShape: "rounded",
      borderRadius: 4,
    },
  },
  dataLabels: {
    enabled: false,
  },
  stroke: {
    show: true,
    width: 2,
    colors: ["transparent"],
  },
  xaxis: {
    categories: ["1/06", "2/06", "3/06", "4/06", "5/06", "6/06", "7/06"],
  },
  yaxis: {
    tickAmount: 6,
    labels: {
      formatter: function (val) {
        return Math.ceil(val) * 2;
      },
    },
  },
  grid: {
    show: false,
  },
  fill: {
    opacity: 1,
  },
  tooltip: {
    y: {
      formatter: function (val) {
        return val + " counts";
      },
    },
  },
  legend: {
    show: false,
  },
};

const barSeries = [
  {
    name: "Avg Schedule Maintenance",
    data: [4, 2, 4, 4, 3, 4, 2],
    color: "#0095FF",
  },
  {
    name: "Avg Unexpected downtime",
    data: [1, 3, 1, 3, 1, 2, 1],
    color: "#FE9A0F",
  },
];

const Analytics = () => {
  const theme = useTheme();
  const isMedium = useMediaQuery(theme.breakpoints.down("lg"));
  const [timePeriod, setTimePeriod] = useState("1 Month");

  const handleTimePeriodChange = (event) => {
    setTimePeriod(event.target.value);
  };

  console.log("isMedium", isMedium);

  return (
    <div style={{ borderRadius: "12px", width: "100%" }}>
      <h1>
        <b>Analytics</b>
      </h1>

      <Stack flexDirection={{ sm: "column", md: "row" }} gap={2}>
        <Box
          sx={{
            backgroundColor: "white",
            borderRadius: "12px",
            boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
            p: "20px",
            width: { xs: "100%", md: "50%" },
          }}
        >
          <Stack justifyContent="space-between" flexDirection="row">
            <h3>
              <b>Efficiency of Loto process</b>
            </h3>
            <FormControl variant="standard" size="small">
              <Select
                value={timePeriod}
                onChange={handleTimePeriodChange}
                label="Time Period"
              >
                <MenuItem value="1 Month">1 Month</MenuItem>
                <MenuItem value="3 Months">3 Months</MenuItem>
                <MenuItem value="6 Months">6 Months</MenuItem>
                <MenuItem value="1 Year">1 Year</MenuItem>
              </Select>
            </FormControl>
          </Stack>
          <Stack sx={{ height: "100%" }} justifyContent="center">
            <Chart
              options={{
                ...pieOptions,
                legend: {
                  ...pieOptions.legend,
                  position: isMedium ? "bottom" : "right",
                },
              }}
              series={pieSeries}
              type="pie"
              height={isMedium ? "450" : "250"}
              // width="550"
              overflow="hidden"
            />
          </Stack>
        </Box>
        <Stack
          sx={{
            backgroundColor: "white",
            borderRadius: "12px",
            boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
            p: "20px",
            width: { xs: "100%", md: "30%" },
          }}
        >
          <h3>
            <b>Loto process per day</b>
          </h3>
          <Chart
            options={barOptions}
            series={barSeries}
            type="bar"
            height="250"
          />
          <div style={{ display: "flex", flexDirection: "column" }}>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                marginBottom: "6px",
                marginRight: "20px",
                marginLeft: "20px",
              }}
            >
              <img
                src={ScheduleTime}
                alt="Avg Schedule Maintenance"
                id="scheduleTimeLogo"
                style={{
                  width: "32px",
                  height: "32px",
                  marginRight: "8px",
                  transition: "filter 0.3s ease",
                  filter: "brightness(1)",
                }}
              />
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  width: "100%",
                  paddingLeft: "10px",
                }}
              >
                <div style={{ fontSize: "12px", color: "#000" }}>
                  Avg Schedule Maintenance
                </div>
                <div style={{ fontSize: "14px", fontWeight: "bold" }}>
                  04/day
                </div>
              </div>
            </div>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                marginRight: "20px",
                marginLeft: "20px",
                marginTop: "10px",
                marginBottom: "25px",
              }}
            >
              <img
                src={DownTime}
                alt="Avg Unexpected downtime"
                id="downTimeLogo"
                style={{
                  width: "32px",
                  height: "32px",
                  marginRight: "8px",
                  transition: "filter 0.3s ease",
                  filter: "brightness(1)",
                }}
              />
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  width: "100%",
                  paddingLeft: "10px",
                }}
              >
                <div style={{ fontSize: "12px", color: "#000" }}>
                  Avg Unexpected downtime
                </div>
                <div style={{ fontSize: "14px", fontWeight: "bold" }}>
                  01/day
                </div>
              </div>
            </div>
          </div>
        </Stack>
        <Box
          sx={{
            backgroundColor: "white",
            borderRadius: "12px",
            boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
            p: "20px",
            width: { xs: "100%", md: "20%" },
          }}
        >
          <LinearWithValueLabel />
        </Box>
      </Stack>
    </div>
  );
};

export default Analytics;
