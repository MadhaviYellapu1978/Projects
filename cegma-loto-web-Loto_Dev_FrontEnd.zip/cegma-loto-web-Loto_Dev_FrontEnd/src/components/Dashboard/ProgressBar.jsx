import * as React from "react";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import LinearProgressWithLabel from "./LinearProgressWithLabel";

export default function LinearWithValueLabel() {
  const data = [
    { name: "Jenny Wilson", value: 45, color: "#2196f3" }, // Blue
    { name: "Jane Cooper", value: 29, color: "#4caf50" }, // Green
    { name: "Guy Hawkins", value: 18, color: "#9c27b0" }, // Purple
    { name: "Courtney Henry", value: 25, color: "#ff9800" }, // Orange
    { name: "Tom Helton", value: 15, color: "#f44336" }, // Red
  ];

  console.log("Data in LinearWithValueLabel:", data);

  return (
    <div
    // style={{
    //   padding: "30px",
    //   backgroundColor: "white",
    //   borderRadius: "12px",
    //   boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
    //   height: "400px",
    // }}
    // className="sm:w-full md:w-[20%]"
    >
      <Typography
        variant="h6"
        sx={{
          marginBottom: "6px",
          fontWeight: "bold",
          fontSize: "16px",
          color: "#333",
        }}
      >
        Top 5 Efficient Technicians
      </Typography>
      <Box sx={{ width: "100%", paddingTop: "10px" }}>
        {data.map((item) => (
          <LinearProgressWithLabel
            key={item.name}
            label={item.name}
            value={item.value}
            color={item.color}
          />
        ))}
      </Box>
    </div>
  );
}
