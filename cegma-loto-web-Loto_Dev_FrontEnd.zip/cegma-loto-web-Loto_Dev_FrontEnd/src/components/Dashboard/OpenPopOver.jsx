import * as React from "react";
import Popover from "@mui/material/Popover";
import Button from "@mui/material/Button";
import TuneIcon from "@mui/icons-material/Tune";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import DatePickerValue from "./DatePickerValue";

const DropdownPopover = () => {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [isSubDropdownOpen, setIsSubDropdownOpen] = React.useState(false);
  const [showDatePicker, setShowDatePicker] = React.useState(false);

  const toggleDropdown = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
    setShowDatePicker(false);
    setIsSubDropdownOpen(false);
  };

  const open = Boolean(anchorEl);
  const id = open ? "dropdown-popover" : undefined;

  const toggleSubDropdown = () => {
    setIsSubDropdownOpen(!isSubDropdownOpen);
    setShowDatePicker(false); // Close date picker when role is opened
  };

  const toggleDatePicker = () => {
    setShowDatePicker(!showDatePicker);
    setIsSubDropdownOpen(false); // Close role dropdown when date is opened
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <div>
        <Button aria-describedby={id} onClick={toggleDropdown}>
          <TuneIcon className="ms-3" style={{ color: "black" }} />
        </Button>
        <Popover
          id={id}
          open={open}
          anchorEl={anchorEl}
          onClose={handleClose}
          anchorOrigin={{
            vertical: "bottom",
            horizontal: "left",
          }}
          transformOrigin={{
            vertical: "top",
            horizontal: "left",
          }}
          PaperProps={{
            style: { maxHeight: "none", overflow: "visible" },
          }}
        >
          <div className="relative bg-white divide-y divide-gray-100 rounded-lg shadow w-33 z-30">
            <ul className="py-2 text-sm text-gray-700">
              {/* Date section with arrow */}
              <li className="relative">
                <button
                  onClick={toggleDatePicker}
                  className="flex items-center justify-between w-full px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white"
                >
                  Date
                  <svg
                    className="w-2.5 h-2.5 ms-3 rtl:rotate-180"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 6 10"
                  >
                    <path
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="m1 9 4-4-4-4"
                    />
                  </svg>
                </button>
                {showDatePicker && (
                  <div
                    className="absolute bg-white p-4 z-40 shadow-lg flex flex-col"
                    style={{ top: 0, left: "100%" }} // Position the DatePicker to the right
                  >
                    <DatePickerValue />
                  </div>
                )}
              </li>

              {/* Roles section with arrow */}
              <li className="relative">
                <button
                  id="doubleDropdownButton"
                  onClick={toggleSubDropdown}
                  className="flex items-center justify-between w-full px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white"
                >
                  Roles
                  <svg
                    className="w-2.5 h-2.5 ms-3 rtl:rotate-180"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 6 10"
                  >
                    <path
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="m1 9 4-4-4-4"
                    />
                  </svg>
                </button>
                {/* Sub-dropdown menu */}
                {isSubDropdownOpen && (
                  <div
                    className="absolute bg-white divide-y divide-gray-100 rounded-lg shadow w-44 z-40"
                    style={{ top: 0, left: "100%" }}
                  >
                    <ul className="py-2 text-sm text-gray-700">
                      <li className="px-4 py-2 flex items-center">
                        <input type="checkbox" id="all" className="mr-2" />
                        <label htmlFor="all">All</label>
                      </li>
                      <li className="px-4 py-2 flex items-center">
                        <input
                          type="checkbox"
                          id="initiator"
                          className="mr-2"
                        />
                        <label htmlFor="initiator">Initiator</label>
                      </li>
                      <li className="px-4 py-2 flex items-center">
                        <input
                          type="checkbox"
                          id="custodian"
                          className="mr-2"
                        />
                        <label htmlFor="custodian">Custodian</label>
                      </li>
                      <li className="px-4 py-2 flex items-center">
                        <input type="checkbox" id="issuer" className="mr-2" />
                        <label htmlFor="issuer">Issuer</label>
                      </li>
                      <li className="px-4 py-2 flex items-center">
                        <input type="checkbox" id="isolator" className="mr-2" />
                        <label htmlFor="isolator">Isolator</label>
                      </li>
                      <li className="px-4 py-2 flex items-center">
                        <input
                          type="checkbox"
                          id="technician"
                          className="mr-2"
                        />
                        <label htmlFor="technician">Technician</label>
                      </li>
                    </ul>
                    <div className="px-4 py-2 flex justify-end">
                      <Button
                        variant="contained"
                        color="primary"
                        className="px-4 py-1"
                      >
                        Apply
                      </Button>
                    </div>
                  </div>
                )}
              </li>
            </ul>
          </div>
        </Popover>
      </div>
    </LocalizationProvider>
  );
};

export default DropdownPopover;
