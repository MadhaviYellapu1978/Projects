import React, { useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, LayersControl, Polyline } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import markerIcon2x from 'leaflet/dist/images/marker-icon-2x.png';
import markerShadow from 'leaflet/dist/images/marker-shadow.png';

// Fixes issue with default marker icons not displaying correctly
delete L.Icon.Default.prototype._getIconUrl;

L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x,
  shadowUrl: markerShadow,
  iconUrl: markerIcon2x,
});

const machines = [
  { position: [21.146633, 79.088860], popupText: "Machine 1" },
  { position: [21.150633, 79.09860], popupText: "Machine 2" },
  { position: [21.155633, 79.105860], popupText: "Machine 3" }
];

const equipments = [
  [
    { position: [21.147633, 79.091961], popupText: "Equipment 1-1" },
    { position: [21.148633, 79.089882], popupText: "Equipment 1-2" },
    { position: [21.149633, 79.085860], popupText: "Equipment 1-3" },
    { position: [21.150633, 79.08860], popupText: "Equipment 1-4" }
  ],
  [
    { position: [21.151633, 79.101961], popupText: "Equipment 2-1" },
    { position: [21.152633, 79.099882], popupText: "Equipment 2-2" },
    { position: [21.153633, 79.095860], popupText: "Equipment 2-3" },
    { position: [21.154633, 79.09860], popupText: "Equipment 2-4" }
  ],
  [
    { position: [21.156633, 79.108961], popupText: "Equipment 3-1" },
    { position: [21.157633, 79.106882], popupText: "Equipment 3-2" },
    { position: [21.158633, 79.102860], popupText: "Equipment 3-3" },
    { position: [21.159633, 79.10560], popupText: "Equipment 3-4" }
  ]
];

const MapComponent = () => {
  const [visibleMarkers, setVisibleMarkers] = useState([]);
  const [expandedMachines, setExpandedMachines] = useState(Array(machines.length).fill(false));
  const [activeMachineIndex, setActiveMachineIndex] = useState(null);

  const handleMachineClick = (machineIndex) => {
    const newExpandedMachines = [...expandedMachines];
    const newVisibleMarkers = [];

    if (activeMachineIndex === machineIndex) {
      // Toggle off
      newExpandedMachines[machineIndex] = false;
      setActiveMachineIndex(null);
    } else {
      // Toggle on
      newExpandedMachines[machineIndex] = true;
      newVisibleMarkers.push(...equipments[machineIndex]);
      setActiveMachineIndex(machineIndex);
    }

    setVisibleMarkers(newVisibleMarkers);
    setExpandedMachines(newExpandedMachines);
  };

  const position = [21.146633, 79.088860]; // Center position for the map
  const zoom = 15;

  return (
    // <div style={{  boxShadow: '0 2px 4px rgba(0,0,0,0.1)', }}>
    <div style={{ 
      boxShadow: '0 2px 4px rgba(0,0,0,0.1)', 
      border: '15px solid #f3f4f6', // Light grey border
      borderRadius: '8px' // Optional: for rounded corners
    }}>
      {/* <h2>Most Loto Process Used Area</h2> */}
      <MapContainer center={position} zoom={zoom} style={{ height: '500px', width: '100%' }}>
        <LayersControl position="topright">
          <LayersControl.BaseLayer checked name="Basic Map">
            <TileLayer
              url="https://api.maptiler.com/maps/landscape/256/{z}/{x}/{y}.png?key=DE1UwvaTlO58u1JmiA2c"
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            />
          </LayersControl.BaseLayer>
          <LayersControl.BaseLayer name="Satellite Map">
            <TileLayer
              url="https://api.maptiler.com/maps/hybrid/256/{z}/{x}/{y}.jpg?key=DE1UwvaTlO58u1JmiA2c"
              attribution='&copy; <a href="https://www.maptiler.com/copyright">MapTiler</a>'
            />
          </LayersControl.BaseLayer>
        </LayersControl>
        {machines.map((machine, index) => (
          (activeMachineIndex === null || activeMachineIndex === index) && (
            <Marker
              key={index}
              position={machine.position}
              eventHandlers={{
                click: () => handleMachineClick(index),
              }}
            >
              <Popup>{machine.popupText}</Popup>
            </Marker>
          )
        ))}
        {visibleMarkers.map((marker, index) => (
          <Marker key={index} position={marker.position}>
            <Popup>{marker.popupText}</Popup>
          </Marker>
        ))}
        {expandedMachines.map((expanded, machineIndex) =>
          expanded && equipments[machineIndex].map((marker, index) => (
            <Polyline
              key={index}
              positions={[machines[machineIndex].position, marker.position]}
              color={machineIndex === 0 ? "blue" : machineIndex === 1 ? "red" : "green"}
            />
          ))
        )}
      </MapContainer>
    </div>
  );
};

export default MapComponent;
