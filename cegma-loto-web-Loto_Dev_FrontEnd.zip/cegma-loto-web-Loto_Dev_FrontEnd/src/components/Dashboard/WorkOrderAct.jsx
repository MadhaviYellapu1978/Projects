import React, { useEffect, useState } from "react";
import { dashboardEndPoints } from "../../constants";

const WorkOrderAct = () => {
  const [workOrderDetails, setWorkOrderDetails] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchWorkOrders = async () => {
      try {
        const response = await dashboardEndPoints.getAllWorkOrders();
        console.log(response,"responseeeeee testttt");
        setWorkOrderDetails(response.data?.WorkOrder_Details || []);
      } catch (err) {
        console.error("Error fetching work orders:", err);
        setError("Failed to load work order details.");
      } finally {
        setLoading(false);
      }
    };

    fetchWorkOrders();
    console.log(fetchWorkOrders,"fwo")
  }, []);

  

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>{error}</div>;
  }

  // Extracting track_action from the first WorkOrder_Details object
  const trackAction = workOrderDetails?.[0]?.track_action || null;

  return (
    <div className="flex gap-2">
      {trackAction ? (
        <span>{trackAction}</span>
      ) : (
        <span>No Action Available</span>
      )}
    </div>
  );
};
export default WorkOrderAct;
