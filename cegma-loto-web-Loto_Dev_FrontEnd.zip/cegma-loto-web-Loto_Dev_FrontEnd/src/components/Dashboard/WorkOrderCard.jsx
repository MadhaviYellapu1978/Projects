import React from "react";
import { CheckCircle, Cancel } from "@mui/icons-material";

const WorkOrderCard = ({ workOrder }) => {
  return (
    <div className="bg-white shadow-md rounded-lg p-4 w-80 mt-5">
      {/* Header: Work Order Name and Action Icons */}
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold text-gray-800">Work Order Name</h3>
        <div className="flex gap-2">
          <CheckCircle className="text-green-500 cursor-pointer" />
          <Cancel className="text-red-500 cursor-pointer" />
        </div>
      </div>

      {/* <hr className="my-2" /> */}
      {/* <hr className="my-2 border-t-2 border-gray-300" /> */}
      <hr className="my-2 border-t-2 border-[#D3D3D3]" />



      {/* Work Permit Id and Status - in the same row */}
      <div className="flex justify-between mb-3 px-4">
        <div>
          <div className="text-sm text-gray-500">Work Permit Id</div>
          <div className="font-medium text-gray-700">{workOrder.permitId}</div>
        </div>
        <div className="text-right">
          <div className="text-sm text-gray-500">Status</div>
          <div className="font-medium text-gray-700">{workOrder.status}</div>
        </div>
      </div>

      {/* Equipment and Role - in the same row */}
      <div className="flex justify-between px-4">
        <div>
          <div className="text-sm text-gray-500">Equipment</div>
          <div className="font-medium text-blue-600">{workOrder.equipment}</div>
        </div>
        <div className="text-right">
          <div className="text-sm text-gray-500">Role</div>
          <div className="font-medium text-gray-700">{workOrder.role}</div>
        </div>
      </div>
    </div>
  );
};

export default WorkOrderCard;
