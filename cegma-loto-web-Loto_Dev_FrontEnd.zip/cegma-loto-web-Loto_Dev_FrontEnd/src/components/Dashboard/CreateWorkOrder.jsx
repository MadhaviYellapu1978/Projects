/* eslint-disable */
import React, { useEffect, useState } from "react";
import { plusIcon } from "../../assets";
import { apiCall, decryptAesBase64 } from "../../utils";
import {
  methods,
  userEndPoints,
  workOrderEndPoints,
  workflowEndPoints,
} from "../../constants";
import { useSelector } from "react-redux";
import { encrypt, decrypt } from "../../crypto";
import {
  FormControl,
  FormHelperText,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Autocomplete,
  Checkbox,
} from "@mui/material";
import { LocalizationProvider, TimePicker } from "@mui/x-date-pickers";
import { DemoContainer } from "@mui/x-date-pickers/internals/demo";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { useFormik } from "formik";
import * as Yup from "yup";
// import axios from "axios";
import toast from "react-hot-toast";

const CreateWorkOrder = ({ refetch }) => {
  const [showModal, setShowModal] = useState(false);
  const [zones, setZones] = useState([]);
  const [sites, setSites] = useState([]);
  const [equipmentList, setEquipmentList] = useState([]);
  const [machineList, setMachineList] = useState([]);
  const [isolationPoints, setIsolationPoints] = useState([]);
  const [custodians, setCustodians] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false); // New state for submission control
  const [formFields, setFormFields] = useState([]); // State to store fetched form fields
  const user = useSelector((state) => state.authSlice.user);

  // Function to render dynamic fields based on fieldType
  const renderDynamicField = (field) => {
    const fieldKey = `customField_${
      field.fieldName?.replace(/\s+/g, "_") || ""
    }`;
    const fieldValue = formik.values[fieldKey] || "";

    if (field.fieldType === "text") {
      return (
        <TextField
          key={fieldKey}
          fullWidth
          name={fieldKey}
          label={field.fieldName}
          value={fieldValue}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched[fieldKey] && Boolean(formik.errors[fieldKey])}
          helperText={formik.touched[fieldKey] && formik.errors[fieldKey]}
          required={field.required}
        />
      );
    } else if (field.fieldType === "select") {
      // For select fields, use options from API if available
      const options = field.options || field.optionValues || field.values || [];
      return (
        <FormControl
          key={fieldKey}
          fullWidth
          error={formik.touched[fieldKey] && Boolean(formik.errors[fieldKey])}
        >
          <InputLabel>{field.fieldName}</InputLabel>
          <Select
            name={fieldKey}
            value={fieldValue}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            label={field.fieldName}
            required={field.required}
          >
            {!field.required && (
              <MenuItem value="">
                <em>None</em>
              </MenuItem>
            )}
            {options.length > 0 ? (
              options.map((option) => (
                <MenuItem key={option} value={option}>
                  {option}
                </MenuItem>
              ))
            ) : (
              // Default options if no options provided
              <>
                <MenuItem value="High">High</MenuItem>
                <MenuItem value="Medium">Medium</MenuItem>
                <MenuItem value="Low">Low</MenuItem>
              </>
            )}
          </Select>
          {formik.touched[fieldKey] && formik.errors[fieldKey] && (
            <FormHelperText>{formik.errors[fieldKey]}</FormHelperText>
          )}
        </FormControl>
      );
    } else if (field.fieldType === "radio") {
      // For radio fields, show as radio buttons
      const options = field.options || field.optionValues || field.values || [];
      return (
        <div key={fieldKey} className="flex items-center gap-4">
          <label className="whitespace-nowrap">{field.fieldName}</label>
          <div className="flex gap-4">
            {options.length > 0 ? (
              options.map((option) => (
                <label key={option} className="flex items-center">
                  <input
                    type="radio"
                    name={fieldKey}
                    value={option}
                    checked={fieldValue === option}
                    onChange={formik.handleChange}
                    className="mr-2"
                  />
                  {option}
                </label>
              ))
            ) : (
              // Default options if no options provided
              <>
                <label className="flex items-center">
                  <input
                    type="radio"
                    name={fieldKey}
                    value="High"
                    checked={fieldValue === "High"}
                    onChange={formik.handleChange}
                    className="mr-2"
                  />
                  High
                </label>
                <label className="flex items-center">
                  <input
                    type="radio"
                    name={fieldKey}
                    value="Medium"
                    checked={fieldValue === "Medium"}
                    onChange={formik.handleChange}
                    className="mr-2"
                  />
                  Medium
                </label>
                <label className="flex items-center">
                  <input
                    type="radio"
                    name={fieldKey}
                    value="Low"
                    checked={fieldValue === "Low"}
                    onChange={formik.handleChange}
                    className="mr-2"
                  />
                  Low
                </label>
              </>
            )}
          </div>
          {formik.touched[fieldKey] && formik.errors[fieldKey] && (
            <p className="text-red-500 text-sm mt-2">
              {formik.errors[fieldKey]}
            </p>
          )}
        </div>
      );
    }
    // Default to text input for unknown types
    return (
      <TextField
        key={fieldKey}
        fullWidth
        name={fieldKey}
        label={field.fieldName}
        value={fieldValue}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        error={formik.touched[fieldKey] && Boolean(formik.errors[fieldKey])}
        helperText={formik.touched[fieldKey] && formik.errors[fieldKey]}
        required={field.required}
      />
    );
  };

  // Helper function to check if a field exists in API response
  const fieldExistsInAPI = (fieldName) => {
    if (!formFields || !Array.isArray(formFields)) return false;
    return formFields.some(
      (field) =>
        field.fieldName?.toLowerCase().trim() === fieldName.toLowerCase().trim()
    );
  };

  // Helper function to get field from API by name
  const getFieldFromAPI = (fieldName) => {
    if (!formFields || !Array.isArray(formFields)) return null;
    return (
      formFields.find(
        (field) =>
          field.fieldName?.toLowerCase().trim() ===
          fieldName.toLowerCase().trim()
      ) || null
    );
  };

  // Helper function to render field based on fieldName from API
  const renderFieldByAPIOrder = (field) => {
    const fieldName = field.fieldName?.toLowerCase().trim() || "";
    const fieldKey = `customField_${field.fieldName?.replace(/\s+/g, "_") || ""}`;
    
    // Map field names to their specific renderers
    switch (fieldName) {
      case "work order name":
        return (
          <TextField
            key="workOrderName"
            fullWidth
            name="workOrderName"
            label="Work Order Name"
            value={formik.values.workOrderName}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            error={
              formik.touched.workOrderName &&
              Boolean(formik.errors.workOrderName)
            }
            helperText={
              formik.touched.workOrderName && formik.errors.workOrderName
            }
          />
        );

      case "operation type":
        return (
          <div key="operationType" className="flex items-center gap-4">
            <label className="whitespace-nowrap">Operation Type</label>
            <div className="flex gap-4">
              {["Maintenance", "Repair"].map((type) => (
                <label key={type} className="flex items-center">
                  <input
                    type="radio"
                    name="operationType"
                    value={type}
                    checked={formik.values.operationType === type}
                    onChange={formik.handleChange}
                    className="mr-2"
                  />
                  {type}
                </label>
              ))}
            </div>
            {formik.touched.operationType && formik.errors.operationType && (
              <p className="text-red-500 text-sm mt-2">
                {formik.errors.operationType}
              </p>
            )}
          </div>
        );

      case "erp number":
        return (
          <TextField
            key="erpNumber"
            fullWidth
            name="erpNumber"
            label="ERP Number"
            value={formik.values.erpNumber}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            error={
              formik.touched.erpNumber && Boolean(formik.errors.erpNumber)
            }
            helperText={formik.touched.erpNumber && formik.errors.erpNumber}
          />
        );

      case "work description":
        return (
          <TextField
            key="workDescription"
            fullWidth
            multiline
            rows={4}
            name="workDescription"
            label="Work Description"
            value={formik.values.workDescription}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            error={
              formik.touched.workDescription &&
              Boolean(formik.errors.workDescription)
            }
            helperText={
              formik.touched.workDescription && formik.errors.workDescription
            }
          />
        );

      case "work type":
        return (
          <div key="workOrder_type" className="flex items-center gap-4">
            <label className="whitespace-nowrap">Work Type</label>
            <div className="flex gap-4">
              {["Hot Work", "Cold Work"].map((type) => (
                <label key={type} className="flex items-center">
                  <input
                    type="radio"
                    name="workOrder_type"
                    value={type}
                    checked={formik.values.workOrder_type === type}
                    onChange={formik.handleChange}
                    className="mr-2"
                  />
                  {type}
                </label>
              ))}
            </div>
            {formik.touched.workOrder_type && formik.errors.workOrder_type && (
              <p className="text-red-500 text-sm mt-2">
                {formik.errors.workOrder_type}
              </p>
            )}
          </div>
        );

      case "time to complete":
        return (
          <LocalizationProvider key="timeToComplete" dateAdapter={AdapterDayjs}>
            <DemoContainer components={["TimePicker"]}>
              <TimePicker
                label="Time to Complete"
                value={formik.values.timeToComplete}
                onChange={(value) =>
                  formik.setFieldValue("timeToComplete", value)
                }
                slotProps={{
                  textField: {
                    fullWidth: true,
                    error:
                      formik.touched.timeToComplete &&
                      Boolean(formik.errors.timeToComplete),
                    helperText:
                      formik.touched.timeToComplete &&
                      formik.errors.timeToComplete,
                  },
                }}
              />
            </DemoContainer>
          </LocalizationProvider>
        );

      case "zone":
        return (
          <FormControl key="selectedZone" fullWidth>
            <InputLabel>Zone</InputLabel>
            <Select
              name="selectedZone"
              value={formik.values.selectedZone}
              onChange={(e) => {
                formik.setFieldValue("selectedZone", e.target.value);
                formik.setFieldValue("selectedSite", "");
                formik.setFieldValue("selectedEquipment", "");
                formik.setFieldValue("selectedMachine", []);
                formik.setFieldValue("selectedIsolationPoint", []);
                fetchSites(e.target.value);
              }}
              label="Zone"
              disabled={loading}
            >
              {zones.map((zone) => (
                <MenuItem key={zone.zone_id} value={zone.zone_id}>
                  {zone.zone_name}
                </MenuItem>
              ))}
            </Select>
            {formik.touched.selectedZone && formik.errors.selectedZone && (
              <FormHelperText error>
                {formik.errors.selectedZone}
              </FormHelperText>
            )}
          </FormControl>
        );

      case "site":
        return (
          <FormControl key="selectedSite" fullWidth>
            <InputLabel>Site</InputLabel>
            <Select
              name="selectedSite"
              value={formik.values.selectedSite}
              onChange={(e) => {
                formik.setFieldValue("selectedSite", e.target.value);
                formik.setFieldValue("selectedEquipment", "");
                formik.setFieldValue("selectedMachine", []);
                formik.setFieldValue("selectedIsolationPoint", []);
                fetchEquipment(formik.values.selectedZone, e.target.value);
              }}
              label="Site"
              disabled={!formik.values.selectedZone || loading}
            >
              {sites.map((site) => (
                <MenuItem key={site.site_id} value={site.site_id}>
                  {site.site_name}
                </MenuItem>
              ))}
            </Select>
            {formik.touched.selectedSite && formik.errors.selectedSite && (
              <FormHelperText error>
                {formik.errors.selectedSite}
              </FormHelperText>
            )}
          </FormControl>
        );

      case "equipment":
        return (
          <FormControl key="selectedEquipment" fullWidth>
            <InputLabel>Equipment</InputLabel>
            <Select
              name="selectedEquipment"
              value={formik.values.selectedEquipment}
              onChange={(e) => {
                formik.setFieldValue("selectedEquipment", e.target.value);
                formik.setFieldValue("selectedMachine", []);
                formik.setFieldValue("selectedIsolationPoint", []);
              }}
              label="Equipment"
              disabled={loading || !formik.values.selectedSite}
            >
              {equipmentList.map((equipment) => (
                <MenuItem
                  key={equipment.equipmentId}
                  value={equipment.equipmentId}
                >
                  {equipment.equipmentName}
                </MenuItem>
              ))}
            </Select>
            {formik.touched.selectedEquipment &&
              formik.errors.selectedEquipment && (
                <FormHelperText error>
                  {formik.errors.selectedEquipment}
                </FormHelperText>
              )}
          </FormControl>
        );

      case "machines":
        return (
          <Autocomplete
            key="selectedMachine"
            multiple
            options={machineList}
            getOptionLabel={(machine) => machine.machineName}
            value={machineList.filter((machine) =>
              formik.values.selectedMachine.includes(machine.machineId)
            )}
            onChange={(event, value) => {
              const selectedIds = value.map((machine) => machine.machineId);
              formik.setFieldValue("selectedMachine", selectedIds);
              formik.setFieldValue("selectedIsolationPoint", []);
            }}
            disableCloseOnSelect
            renderOption={(props, option, { selected }) => (
              <li {...props}>
                <Checkbox checked={selected} style={{ marginRight: 8 }} />
                {option.machineName}
              </li>
            )}
            renderInput={(params) => (
              <TextField
                {...params}
                label="Machines"
                error={
                  formik.touched.selectedMachine &&
                  Boolean(formik.errors.selectedMachine)
                }
                helperText={
                  formik.touched.selectedMachine &&
                  formik.errors.selectedMachine
                }
              />
            )}
          />
        );

      case "isolation points":
        return (
          <Autocomplete
            key="selectedIsolationPoint"
            multiple
            options={isolationPoints.filter(
              (point) => point.isolationName !== ""
            )}
            getOptionLabel={(point) => point.isolationName}
            value={isolationPoints
              .filter((point) =>
                (formik.values.selectedIsolationPoint || []).includes(
                  point.isolationId
                )
              )
              .filter((point) => point.isolationName !== "")}
            onChange={(event, value) => {
              const selectedIds = value.map((point) => point.isolationId);
              formik.setFieldValue("selectedIsolationPoint", selectedIds);
            }}
            renderOption={(props, option, { selected }) => (
              <li {...props}>
                <input
                  type="checkbox"
                  checked={selected}
                  readOnly
                  style={{ marginRight: 8 }}
                />
                {option.isolationName}
              </li>
            )}
            disableCloseOnSelect
            isOptionEqualToValue={(option, value) =>
              option.isolationId === value.isolationId
            }
            renderInput={(params) => (
              <TextField
                {...params}
                label="Isolation Points"
                error={
                  formik.touched.selectedIsolationPoint &&
                  Boolean(formik.errors.selectedIsolationPoint)
                }
                helperText={
                  formik.touched.selectedIsolationPoint &&
                  formik.errors.selectedIsolationPoint
                }
              />
            )}
          />
        );

      case "custodian":
        return (
          <FormControl key="selectedCustodian" fullWidth className="mb-4">
            <Autocomplete
              options={custodians}
              getOptionLabel={(option) =>
                `${option.first_name} ${option.last_name}`
              }
              value={
                custodians.find(
                  (custodian) =>
                    custodian.emp_id === formik.values.selectedCustodian
                ) || null
              }
              onChange={(event, newValue) => {
                formik.setFieldValue(
                  "selectedCustodian",
                  newValue?.emp_id || ""
                );
              }}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Custodian"
                  placeholder="Search Custodians"
                  error={
                    formik.touched.selectedCustodian &&
                    Boolean(formik.errors.selectedCustodian)
                  }
                  helperText={
                    formik.touched.selectedCustodian &&
                    formik.errors.selectedCustodian
                  }
                  variant="outlined"
                />
              )}
              disabled={loading || !formik.values.selectedSite}
            />
          </FormControl>
        );

      case "risk level":
        return (
          <div key="riskLevel" className="flex items-center gap-4">
            <label className="whitespace-nowrap">Risk Level</label>
            <div className="flex gap-4">
              {["High", "Medium", "Low"].map((level) => (
                <label key={level} className="flex items-center">
                  <input
                    type="radio"
                    name="riskLevel"
                    value={level}
                    checked={formik.values.riskLevel === level}
                    onChange={formik.handleChange}
                    className="mr-2"
                  />
                  {level}
                </label>
              ))}
            </div>
            {formik.touched.riskLevel && formik.errors.riskLevel && (
              <p className="text-red-500 text-sm mt-2">
                {formik.errors.riskLevel}
              </p>
            )}
          </div>
        );

      case "actions":
        // Actions field with radio buttons: "Cancel" and "Create Work Order"
        const actionsFieldKey = `customField_${field.fieldName?.replace(/\s+/g, "_") || "actions"}`;
        const actionsOptions = field.options || field.optionValues || field.values || ["Cancel", "Create Work Order"];
        // Get the first option as default if value is empty
        const defaultActionsValue = actionsOptions.length > 0 ? actionsOptions[0] : "";
        const actionsValue = formik.values[actionsFieldKey] || defaultActionsValue;
        
        return (
          <div key={actionsFieldKey} className="flex items-center gap-4">
            <label className="whitespace-nowrap">{field.fieldName || "Actions"}</label>
            <div className="flex gap-4">
              {actionsOptions.map((option) => (
                <label key={option} className="flex items-center">
                  <input
                    type="radio"
                    name={actionsFieldKey}
                    value={option}
                    checked={actionsValue === option}
                    onChange={formik.handleChange}
                    className="mr-2"
                  />
                  {option}
                </label>
              ))}
            </div>
            {formik.touched[actionsFieldKey] && formik.errors[actionsFieldKey] && (
              <p className="text-red-500 text-sm mt-2">
                {formik.errors[actionsFieldKey]}
              </p>
            )}
          </div>
        );

      default:
        // For all other fields, use renderDynamicField
        return renderDynamicField(field);
    }
  };

  // Initialize formik values - restore original fields
  const getInitialValues = () => {
    // Helper function to get first option for radio fields
    const getFirstRadioOption = (field) => {
      const options = field.options || field.optionValues || field.values || [];
      return options.length > 0 ? options[0] : "";
    };

    const baseValues = {
      workOrderName: "",
      // Set first option as default for radio fields
      operationType: "Maintenance", // First option: ["Maintenance", "Repair"]
      erpNumber: "",
      workDescription: "",
      workOrder_type: "Hot Work", // First option: ["Hot Work", "Cold Work"]
      timeToComplete: null,
      selectedZone: "",
      selectedSite: "",
      selectedEquipment: "",
      selectedMachine: [],
      selectedIsolationPoint: [],
      selectedCustodian: "",
      riskLevel: "High", // First option: ["High", "Medium", "Low"]
    };

    // Add dynamic fields from API
    if (formFields && Array.isArray(formFields)) {
      formFields.forEach((field) => {
        const fieldName = field.fieldName?.toLowerCase().trim() || "";
        const hardcodedFields = [
          "work order name",
          "operation type",
          "erp number",
          "work description",
          "work type",
          "time to complete",
          "zone",
          "site",
          "equipment",
          "machines",
          "isolation points",
          "custodian",
          "risk level",
        ];
        
        // Only add fields that are not hardcoded
        if (!hardcodedFields.includes(fieldName)) {
          const fieldKey = `customField_${field.fieldName?.replace(/\s+/g, "_") || ""}`;
          if (field.fieldType === "radio") {
            // For radio fields, set first option as default
            baseValues[fieldKey] = getFirstRadioOption(field);
          } else if (field.fieldType === "select") {
            baseValues[fieldKey] = "";
          } else {
            baseValues[fieldKey] = "";
          }
        } else {
          // For hardcoded radio fields, check if API provides options and use first one
          if (fieldName === "operation type" && field.fieldType === "radio") {
            const firstOption = getFirstRadioOption(field);
            if (firstOption) {
              baseValues.operationType = firstOption;
            }
          } else if (fieldName === "work type" && field.fieldType === "radio") {
            const firstOption = getFirstRadioOption(field);
            if (firstOption) {
              baseValues.workOrder_type = firstOption;
            }
          } else if (fieldName === "risk level" && field.fieldType === "radio") {
            const firstOption = getFirstRadioOption(field);
            if (firstOption) {
              baseValues.riskLevel = firstOption;
            }
          }
        }
      });
    }

    return baseValues;
  };

  // Build validation schema - only validate fields that exist in API
  const getValidationSchema = () => {
    const baseSchema = {};

    // Only add validation for fields that exist in API response
    if (fieldExistsInAPI("Work Order Name")) {
      baseSchema.workOrderName = Yup.string()
        .matches(/^\S.*$/, "Initial spaces are not allowed")
        .required("Work Name is required");
    }
    if (fieldExistsInAPI("Operation Type")) {
      baseSchema.operationType = Yup.string().required(
        "Operation Type is required"
      );
    }
    if (fieldExistsInAPI("ERP Number")) {
      baseSchema.erpNumber = Yup.string()
        .matches(/^\S.*$/, "Initial spaces are not allowed")
        .required("ERP Number is required");
    }
    if (fieldExistsInAPI("Work Description")) {
      baseSchema.workDescription = Yup.string()
        .matches(/^\S.*$/, "Initial spaces are not allowed")
        .required("Work Description is required");
    }
    if (fieldExistsInAPI("Work Type")) {
      baseSchema.workOrder_type = Yup.string().required(
        "Work Type is required"
      );
    }
    if (fieldExistsInAPI("Time to Complete")) {
      baseSchema.timeToComplete = Yup.date()
        .nullable()
        .required("Time to complete is required");
    }
    if (fieldExistsInAPI("Zone")) {
      baseSchema.selectedZone = Yup.string().required("Zone is required");
    }
    if (fieldExistsInAPI("Site")) {
      baseSchema.selectedSite = Yup.string().required("Site is required");
    }
    if (fieldExistsInAPI("Equipment")) {
      baseSchema.selectedEquipment = Yup.string().required(
        "Equipment is required"
      );
    }
    if (fieldExistsInAPI("Machines")) {
      baseSchema.selectedMachine = Yup.array().min(
        1,
        "Select at least one machine"
      );
    }
    if (fieldExistsInAPI("Isolation Points")) {
      baseSchema.selectedIsolationPoint = Yup.array().min(
        1,
        "Select at least one isolation point"
      );
    }
    if (fieldExistsInAPI("Custodian")) {
      baseSchema.selectedCustodian = Yup.string().required(
        "Custodian is required"
      );
    }
    if (fieldExistsInAPI("Risk Level")) {
      baseSchema.riskLevel = Yup.string().required("Risk Level is required");
    }

    // Add validation for dynamic fields from API
    if (formFields && Array.isArray(formFields)) {
      formFields.forEach((field) => {
        const fieldName = field.fieldName?.toLowerCase().trim() || "";
        const hardcodedFields = [
          "work order name",
          "operation type",
          "erp number",
          "work description",
          "work type",
          "time to complete",
          "zone",
          "site",
          "equipment",
          "machines",
          "isolation points",
          "custodian",
          "risk level",
        ];
        
        // Only add validation for fields that are not hardcoded
        if (!hardcodedFields.includes(fieldName)) {
          const fieldKey = `customField_${field.fieldName?.replace(/\s+/g, "_") || ""}`;
          if (field.required) {
            if (field.fieldType === "select" || field.fieldType === "radio") {
              baseSchema[fieldKey] = Yup.string().required(
                `${field.fieldName} is required`
              );
            } else {
              baseSchema[fieldKey] = Yup.string()
                .matches(/^\S.*$/, "Initial spaces are not allowed")
                .required(`${field.fieldName} is required`);
            }
          }
        }
      });
    }

    return Yup.object(baseSchema);
  };

  const formik = useFormik({
    enableReinitialize: true, // Allow formik to reinitialize when initialValues change
    initialValues: getInitialValues(),
    validationSchema: getValidationSchema(),
    onSubmit: async (values) => {
      const selectedCust = custodians.find(
        (cust) => cust.emp_id === values.selectedCustodian
      );

      const selectedEqp = equipmentList.filter(
        (equipment) => equipment.equipmentId === values.selectedEquipment
      );

      const workOrderData = {
        createdBy: user.emp_id,
        equipmentId: selectedEqp[0]?.equipmentName || "",
        erpNumber: values.erpNumber || "",
        wo_operation_type: values.operationType,
        orgId: user.org.org_id,
        risk_level:
          values.riskLevel === "Low"
            ? "low"
            : values.riskLevel === "Medium"
            ? "medium"
            : "high",
        siteId: values.selectedSite || "",
        timeToComplete: values.timeToComplete || new Date().toISOString(),
        description: values.workDescription || "",
        workOrderName: values.workOrderName || "",
        workOrder_type:
          values.workOrder_type === "Hot Work" ? "hotwork" : "coldwork",
        zoneId: values.selectedZone || "",
        workOrder_status: "Pending",
        initiator_id: user.emp_id,
        initiator_name: user.first_name + " " + user.last_name,
        machines: values.selectedMachine.map((machineId) => {
          const machine = machineList.find((m) => m.machineId === machineId);
          return {
            machineId: machineId,
            machineName: machine ? machine.machineName : "",
            isolationPoints: values.selectedIsolationPoint
              .map((isolationId) => {
                const isolationPoint = machine
                  ? machine.isolationPoints.find(
                      (point) => point.isolationId === isolationId
                    )
                  : null;
                if (isolationPoint && isolationPoint.isolationName !== "") {
                  return {
                    isolationId: isolationId,
                    isolationName: isolationPoint.isolationName,
                    isolationStatus: "Pending" || "",
                  };
                }
                return null;
              })
              .filter((point) => point !== null),
          };
        }),
        custodian_details: [
          {
            custodian_id: values.selectedCustodian,
            custodian_name:
              selectedCust?.first_name + " " + selectedCust?.last_name,
            custodian_status: "Pending",
            custodian_rejected_reason: "",
            custodian_device_id: selectedCust?.device_id,
          },
        ],
      };

      // Add dynamic fields from API to workOrderData
      if (formFields && Array.isArray(formFields)) {
        formFields.forEach((field) => {
          const fieldName = field.fieldName?.toLowerCase().trim() || "";
          const hardcodedFields = [
            "work order name",
            "operation type",
            "erp number",
            "work description",
            "work type",
            "time to complete",
            "zone",
            "site",
            "equipment",
            "machines",
            "isolation points",
            "custodian",
            "risk level",
          ];
          
          // Only add fields that are not hardcoded
          if (!hardcodedFields.includes(fieldName)) {
            const fieldKey = `customField_${field.fieldName?.replace(/\s+/g, "_") || ""}`;
            const fieldValue = values[fieldKey];
            if (fieldValue !== undefined && fieldValue !== null && fieldValue !== "") {
              // Add custom field to workOrderData
              workOrderData[field.fieldName?.replace(/\s+/g, "_") || fieldKey] = fieldValue;
            }
          }
        });
      }

      if (submitting) return; // Prevent multiple submissions
      setSubmitting(true); // Lock the submit button
      setLoading(true);
      try {
        const createResponse = await apiCall(
          `${workOrderEndPoints.createWorkOrder}`,
          methods.post,
          workOrderData // Sending the constructed payload
        );
        // alert("Work order submitted successfully!");
        // setShowModal(false);
        // formik.resetForm();

        toast.success(
          createResponse?.message || "Work order created successfully!"
        );

        // console.log("Work order created successfully:", createResponse);
        formik.resetForm();
        setShowModal(false);
        refetch();
      } catch (error) {
        // console.error("Error creating work order:", error.message || error);
        toast.error(
          error?.response?.data?.message ||
            "An error occurred while creating the work order. Please try again."
        );
      } finally {
        //  console.log(workOrderData, "Work order data");
        setSubmitting(false); // Allow submission again
        setLoading(false); // Stop loading spinner
      }
    },
  });

  useEffect(() => {
    // eslint-disable-next-line
    formik.resetForm();
  }, []);

  // Reset form and update initial values when formFields change
  useEffect(() => {
    if (formFields && Array.isArray(formFields) && formFields.length > 0) {
      const newInitialValues = getInitialValues();
      // Update formik values for all fields, especially radio fields to set first option
      Object.keys(newInitialValues).forEach((key) => {
        const currentValue = formik.values[key];
        const newValue = newInitialValues[key];
        // Update if field doesn't exist, or if it's a radio field with empty value
        if (!(key in formik.values) || (currentValue === "" && newValue !== "")) {
          formik.setFieldValue(key, newValue);
        }
      });
      
      // Also ensure Actions field gets default value
      formFields.forEach((field) => {
        const fieldName = field.fieldName?.toLowerCase().trim() || "";
        if (fieldName === "actions" && field.fieldType === "radio") {
          const actionsFieldKey = `customField_${field.fieldName?.replace(/\s+/g, "_") || "actions"}`;
          const actionsOptions = field.options || field.optionValues || field.values || ["Cancel", "Create Work Order"];
          const defaultActionsValue = actionsOptions.length > 0 ? actionsOptions[0] : "";
          if (!formik.values[actionsFieldKey] && defaultActionsValue) {
            formik.setFieldValue(actionsFieldKey, defaultActionsValue);
          }
        }
      });
    }
    // eslint-disable-next-line
  }, [formFields]);

  // Fetch Zones on component mount
  useEffect(() => {
    if (user?.org?.org_id) {
      setLoading(true);
      apiCall(
        `${userEndPoints.getAllZonesByOrg}/${user.org.org_id}/getAllZones`,
        methods.get
      )
        .then((data) => {
          setZones(data);
          // if (data.length > 0) {
          //   formik.setFieldValue("selectedZone", data[0].zone_id);
          //   fetchSites(data[0].zone_id);
          // }
        })
        .catch((err) => {
          setError("Failed to fetch zones");
          console.error(err);
        })
        .finally(() => setLoading(false));
    }
  }, [user]);

  // Fetch Sites for selected Zone
  const fetchSites = async (zoneId) => {
    if (zoneId) {
      setLoading(true);
      try {
        const sitesData = await apiCall(
          `${userEndPoints.getAllSitesByZone}/${zoneId}/getAllSites`,
          methods.get
        );
        setSites(sitesData);
        // if (sitesData.length > 0) {
        //   formik.setFieldValue("selectedSite", sitesData[0].site_id);
        //   fetchEquipment(zoneId, sitesData[0].site_id);
        // }
      } catch (err) {
        setError("Failed to fetch sites");
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
  };

  // Fetch Equipment for selected Zone and Site
  const fetchEquipment = async (zoneId, siteId) => {
    if (zoneId && siteId) {
      setLoading(true);
      try {
        const body = {
          orgId: user.org.org_id,
          zoneId,
          siteId,
        };
        const equipmentData = await apiCall(
          userEndPoints.getAssetsByZoneAndSite,
          methods.post,
          body
        );
        setEquipmentList(equipmentData);
      } catch (err) {
        setError("Failed to fetch equipment");
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
  };

  // Fetch Machines for selected Equipment
  useEffect(() => {
    if (formik.values.selectedEquipment) {
      const selectedEquipment = equipmentList.find(
        (eq) => eq.equipmentId === formik.values.selectedEquipment
      );
      setMachineList(selectedEquipment?.machines || []);
    }
  }, [formik.values.selectedEquipment, equipmentList]);

  // Fetch Isolation Points for selected Machines
  useEffect(() => {
    if (
      formik.values.selectedMachine &&
      Array.isArray(formik.values.selectedMachine) &&
      formik.values.selectedMachine.length > 0
    ) {
      const pointsWithNames = formik.values.selectedMachine.flatMap(
        (machineId) => {
          const machine = machineList.find((m) => m.machineId === machineId);
          return machine
            ? machine.isolationPoints.map((point) => ({
                ...point,
                machineName: machine.machineName,
              }))
            : [];
        }
      );
      setIsolationPoints([
        ...new Map(pointsWithNames.map((p) => [p.isolationId, p])).values(),
      ]);
    }
  }, [formik.values.selectedMachine, machineList]);

  // Fetch Custodians
  useEffect(() => {
    if (formik.values.selectedZone && formik.values.selectedSite) {
      const fetchCustodians = async () => {
        try {
          setLoading(true);
          const response = await apiCall(
            workOrderEndPoints.getCustodians,
            methods.post,
            {
              org_id: user.org.org_id,
              zone_id: formik.values.selectedZone,
              site_id: formik.values.selectedSite,
            }
          );
          const filteredCustodians = (response?.custodians || []).filter(
            (custodian) => custodian.emp_id !== user.emp_id
          );
          setCustodians(filteredCustodians);
        } catch (err) {
          setError("Failed to fetch custodians");
          console.error(err);
        } finally {
          setLoading(false);
        }
      };
      fetchCustodians();
    }
    // eslint-disable-next-line
  }, [formik.values.selectedZone, formik.values.selectedSite]);

  // Fetch form fields when modal opens
  const handleOpenModal = async () => {
    setShowModal(true);
    
    // Set default values for radio fields if formFields are already loaded
    if (formFields && Array.isArray(formFields) && formFields.length > 0) {
      formFields.forEach((field) => {
        if (field.fieldType === "radio") {
          const fieldKey = `customField_${field.fieldName?.replace(/\s+/g, "_") || ""}`;
          const options = field.options || field.optionValues || field.values || [];
          if (options.length > 0 && !formik.values[fieldKey]) {
            formik.setFieldValue(fieldKey, options[0]);
          }
        }
      });
    }

    // Fetch form fields for work order
    try {
      const token = localStorage.getItem("token");
      const orgId = user?.org?.org_id || user?.org_id || "";

      if (!orgId) {
        console.warn("Organization ID not found");
        return;
      }

      // Create payload with orgId
      const payload = {
        orgId: orgId,
      };

      console.log("Fetching form fields - Payload before encryption:", payload);

      // Encrypt the payload using encrypt from crypto.js
      const encryptedPayload = encrypt(payload);
      console.log("Encrypted payload:", encryptedPayload);

      // Verify encryption format (should be base64 string)
      if (typeof encryptedPayload !== "string") {
        throw new Error(
          "Encryption failed: Expected string but got " +
            typeof encryptedPayload
        );
      }

      // Create the request payload with data field containing encrypted string
      const requestPayload = {
        data: encryptedPayload,
      };

      // Call the API
      const response = await apiCall(
        workflowEndPoints.getFieldsforWorkOrder,
        methods.post,
        requestPayload,
        token
      );

      console.log("API response:", response);

      // Check if apiCall returned an error response (status >= 400)
      if (response?.status >= 400) {
        const errorData = response.data;
        const errorMessage =
          errorData?.error ||
          errorData?.message ||
          errorData?.details ||
          JSON.stringify(errorData) ||
          "Failed to fetch form fields";

        console.error("Error fetching form fields:", errorMessage);
        // Don't show error toast, just log it - form can still work without custom fields
        return;
      }

      // Decrypt the response data (API returns encrypted base64 payload)
      let decryptedResponse = null;
      if (response?.data && typeof response.data === "string") {
        try {
          // Try decryptAesBase64 first (for encrypted base64 responses)
          decryptedResponse = await decryptAesBase64(response.data);
          if (typeof decryptedResponse === "string") {
            try {
              decryptedResponse = JSON.parse(decryptedResponse);
            } catch (e) {
              // If parsing fails, try regular decrypt
              try {
                decryptedResponse = decrypt(response.data);
                if (typeof decryptedResponse === "string") {
                  try {
                    decryptedResponse = JSON.parse(decryptedResponse);
                  } catch (e2) {
                    console.warn("Failed to parse decrypted response:", e2);
                  }
                }
              } catch (decryptErr) {
                console.warn("Failed to decrypt response:", decryptErr);
              }
            }
          }
        } catch (e) {
          // If decryptAesBase64 fails, try regular decrypt
          try {
            decryptedResponse = decrypt(response.data);
            if (typeof decryptedResponse === "string") {
              try {
                decryptedResponse = JSON.parse(decryptedResponse);
              } catch (e2) {
                console.warn("Failed to parse decrypted response:", e2);
              }
            }
          } catch (decryptErr) {
            console.warn("Failed to decrypt response:", decryptErr);
          }
        }
      } else if (response?.data && typeof response.data === "object") {
        // If response.data is already an object, check if it has encrypted data field
        if (response.data.data && typeof response.data.data === "string") {
          try {
            decryptedResponse = await decryptAesBase64(response.data.data);
            if (typeof decryptedResponse === "string") {
              try {
                decryptedResponse = JSON.parse(decryptedResponse);
              } catch (e) {
                console.warn("Failed to parse decrypted response:", e);
              }
            }
          } catch (e) {
            decryptedResponse = response.data;
          }
        } else {
          decryptedResponse = response.data;
        }
      } else {
        decryptedResponse = response;
      }

      console.log("Final decrypted response:", decryptedResponse);

      // Extract fields array from response
      let extractedFields = [];
      if (
        decryptedResponse?.fields &&
        Array.isArray(decryptedResponse.fields)
      ) {
        extractedFields = decryptedResponse.fields;
      } else if (Array.isArray(decryptedResponse)) {
        extractedFields = decryptedResponse;
      } else if (
        decryptedResponse?.data &&
        Array.isArray(decryptedResponse.data)
      ) {
        extractedFields = decryptedResponse.data;
      }

      console.log("Extracted fields:", extractedFields);
      setFormFields(extractedFields);
      
      // Set default values for radio fields, especially Actions field
      if (Array.isArray(extractedFields) && extractedFields.length > 0) {
        extractedFields.forEach((field) => {
          const fieldName = field.fieldName?.toLowerCase().trim() || "";
          if (field.fieldType === "radio") {
            const fieldKey = `customField_${field.fieldName?.replace(/\s+/g, "_") || ""}`;
            const options = field.options || field.optionValues || field.values || [];
            if (options.length > 0 && !formik.values[fieldKey]) {
              // Set first option as default for radio fields
              formik.setFieldValue(fieldKey, options[0]);
            }
          }
        });
      }
    } catch (error) {
      console.error("Error fetching form fields:", error);
      // Don't show error toast, just log it - form can still work without custom fields
    }
  };

  return (
    <>
      <button
        onClick={handleOpenModal}
        className="bg-primary flex gap-2 py-2 px-4 md:py-3 md:px-7 rounded-full text-white font-bold text-sm md:text-base"
      >
        <img src={plusIcon} alt="add" className="w-4 h-4 md:w-6 md:h-6" />
        New Work Order
      </button>

      {showModal && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50 ">
          <div className="bg-white rounded-xl shadow-lg p-10 w-full max-w-2xl md:max-w-2xl max-h-[90vh] overflow-y-auto ">
            <div className="flex justify-between items-center border-b pb-3">
              <h2 className="text-lg font-semibold">New Work Order</h2>
              <button
                onClick={() => setShowModal(false)}
                className="text-gray-600 hover:text-gray-900 font-bold text-2xl"
              >
                &times;
              </button>
            </div>

            {error && (
              <div className="text-red-500 mb-4 p-2 bg-red-50 rounded">
                {error}
              </div>
            )}

            <form onSubmit={formik.handleSubmit} className="mt-4 space-y-4">
              {/* Render all fields in the order they appear in the API response */}
              {formFields && Array.isArray(formFields) && formFields.length > 0
                ? formFields.map((field, index) => (
                    <React.Fragment key={field.id || field._id || `field-${index}`}>
                      {renderFieldByAPIOrder(field)}
                    </React.Fragment>
                  ))
                : null}

              {/* Submit and Cancel Buttons */}
              <div className="flex justify-end gap-4 mt-6">
                <button
                  type="button"
                  onClick={() => {
                    formik.resetForm(); // Optional: Reset form if you want to clear the form values
                    setShowModal(false);
                  }}
                  className="border-2 border-primary py-2 px-5 rounded-full text-primary font-semibold "
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-primary py-2 px-5 rounded-full text-sm font-semibold text-white hover:bg-primary-dark"
                  disabled={loading}
                >
                  {loading ? "Submitting..." : "Submit"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
};

export default CreateWorkOrder;
