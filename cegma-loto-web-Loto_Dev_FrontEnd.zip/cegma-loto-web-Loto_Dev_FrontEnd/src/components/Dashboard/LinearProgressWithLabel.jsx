import * as React from "react";
import PropTypes from "prop-types";
import LinearProgress from "@mui/material/LinearProgress";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";

function LinearProgressWithLabel(props) {
  const color = props.color || "#000000"; 

  return (
    <Box sx={{ width: "100%", display: 'flex', flexDirection: 'column', mb: 2 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="body2" color="textPrimary">{props.label}</Typography>
        <Typography
          variant="caption"
          sx={{
            backgroundColor: `${color}20`,
            color: color,
            borderWidth: "2px",
            borderColor: color,
            borderRadius: "12px",
            padding: "2px 6px",
            fontWeight: "semi-bold",
          }}
        >
          {`${Math.round(props.value)}%`}
        </Typography>
      </Box>
      <LinearProgress
        variant="determinate"
        value={props.value}
        sx={{
          "& .MuiLinearProgress-bar": {
            backgroundColor: color,
          },
          backgroundColor: `${color}20`,
          height: "6px",
          borderRadius: "4px",
          mt: 1
        }}
      />
    </Box>
  );
}

LinearProgressWithLabel.propTypes = {
  value: PropTypes.number.isRequired,
  color: PropTypes.string.isRequired,
  label: PropTypes.string.isRequired,
};

export default LinearProgressWithLabel;
