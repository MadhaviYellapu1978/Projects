import React, { useState } from "react";
import {
  DataGrid,
  GridToolbarContainer,
  GridToolbarExport,
  GridToolbarFilterButton,
  GridToolbarDensitySelector,
} from "@mui/x-data-grid";
import {
  Box,
  Pagination,
  TextField,
  FormControl,
  Select,
  MenuItem,
  IconButton,
  Popover,
} from "@mui/material";
import { FilterList } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
const DateFilterPopover = ({
  anchorEl,
  handleClose,
  startDate,
  endDate,
  handleStartDateChange,
  handleEndDateChange,
}) => (
  <Popover
    open={Boolean(anchorEl)}
    anchorEl={anchorEl}
    onClose={handleClose}
    anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
    transformOrigin={{ vertical: "top", horizontal: "center" }}
  >
    <div style={{ padding: "10px" }}>
      <TextField
        label="From"
        type="date"
        value={startDate}
        onChange={handleStartDateChange}
        InputLabelProps={{ shrink: true }}
        style={{ width: "200px", marginBottom: "10px" }}
      />
      <TextField
        label="To"
        type="date"
        value={endDate}
        onChange={handleEndDateChange}
        InputLabelProps={{ shrink: true }}
        style={{ width: "200px" }}
      />
    </div>
  </Popover>
);

const RoleFilterPopover = ({
  anchorEl,
  handleClose,
  roleFilter,
  handleRoleFilterChange,
}) => (
  <Popover
    open={Boolean(anchorEl)}
    anchorEl={anchorEl}
    onClose={handleClose}
    anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
    transformOrigin={{ vertical: "top", horizontal: "center" }}
  >
    <div style={{ padding: "10px" }}>
      <FormControl style={{ width: "200px" }}>
        <Select
          value={roleFilter}
          onChange={handleRoleFilterChange}
          displayEmpty
        >
          <MenuItem value="">All</MenuItem>
          <MenuItem value="Initiator">Initiator</MenuItem>
          <MenuItem value="Custodian">Custodian</MenuItem>
          <MenuItem value="Issuer">Issuer</MenuItem>
          <MenuItem value="Isolater">Isolater</MenuItem>
          <MenuItem value="Technician">Technician</MenuItem>
        </Select>
      </FormControl>
    </div>
  </Popover>
);

const columns = (
  dateFilterAnchorEl,
  handleDateFilterOpen,
  handleDateFilterClose,
  startDate,
  endDate,
  handleStartDateChange,
  handleEndDateChange,
  roleFilterAnchorEl,
  handleRoleFilterOpen,
  handleRoleFilterClose,
  roleFilter,
  handleRoleFilterChange,
  notifications,
  apiData
) => [
  {
    field: "createdAt",
    filterable: false,
    resizable: false,
    headerName: (
      <div style={{ display: "flex", alignItems: "center" }}>
        Date
        <IconButton size="small" onClick={handleDateFilterOpen}>
          <FilterList />
        </IconButton>
        <DateFilterPopover
          anchorEl={dateFilterAnchorEl}
          handleClose={handleDateFilterClose}
          startDate={startDate}
          endDate={endDate}
          handleStartDateChange={handleStartDateChange}
          handleEndDateChange={handleEndDateChange}
        />
      </div>
    ),
    width: 200,
  },
  {
    field: "workOrderId",
    filterable: false,
    resizable: false,
    headerName: "Work Permit ID",
    width: 200,
  },
  {
    field: "workOrderName",
    filterable: false,
    resizable: false,
    headerName: "Work Permit Name",
    width: 200,
  },
  {
    field: "equipmentId",
    filterable: false,
    resizable: false,
    headerName: "Equipment Name",
    width: 200,
  },
  {
    field: "workOrder_status",
    filterable: false,
    resizable: false,
    headerName: "Status",
    width: 150,
  },
  {
    field: "your_role",
    filterable: false,
    resizable: false,
    headerName: (
      <div style={{ display: "flex", alignItems: "center" }}>
        Role
        <IconButton size="small" onClick={handleRoleFilterOpen}>
          <FilterList />
        </IconButton>
        <RoleFilterPopover
          anchorEl={roleFilterAnchorEl}
          handleClose={handleRoleFilterClose}
          roleFilter={roleFilter}
          handleRoleFilterChange={handleRoleFilterChange}
        />
      </div>
    ),
    width: 190,
  },
  {
    field: "track_action",
    filterable: false,
    resizable: false,
    headerName: "Action",
    width: 200,
    renderCell: (params) => {
      if (
        params.row.track_action === "Pending Custodian" &&  
        params.row.your_role === "Custodian"
      ) {
        return (
          <button className="bg-blue-300 text-black border-none rounded-lg cursor-pointer w-[150px]  h-10">
            Accept
          </button>
        );
      } else if (
        // params.row.track_action === "Completed Isolation" &&
        params.row.your_role === "Issuer" &&
        notifications?.some(
          (notification) =>
            notification.workOrderId === params.row.workOrderId &&
            notification.action === "await_Issuer_verify_iso"
        )
      ) {
        return (
          <button className="bg-blue-300 text-black border-none rounded-lg cursor-pointer w-[150px]  h-10">
            Verify Isolation
          </button>
        );
      }
      // else if (
      //   params.row.track_action === "Completed Isolation" &&
      //   (params.row.your_role === "Isolator" ||
      //     // params.row.your_role === "Custodian" ||
      //     params.row.your_role === "Initiator")
      // ) {
      //   return (
      //     <h1>
      //       issuer to verify Iso
      //     </h1>
      //   );
      // }
      // else if (
      //   params.row.track_action === "Completed Isolation" &&
      //   params.row.your_role === "Custodian"
      // ) {
      //   return (
      //     <h1
      //     // className="bg-blue-300 text-black border-none rounded-lg cursor-pointer w-[150px]  h-10"
      //     // disable
      //     >
      //       Initiator to assign technician{" "}
      //     </h1>
      //   );
      // }
      else if (
        // params.row.track_action === "Completed De-Isolation" &&
        params.row.your_role === "Issuer" &&
        notifications?.some(
          (notification) =>
            notification.workOrderId === params.row.workOrderId &&
            notification.action === "await_issuer_verify_deiso"
        )
      ) {
        return (
          <button className="bg-blue-300 text-black border-none rounded-lg cursor-pointer w-[150px]  h-10">
            Verify De-Isolation
          </button>
        );
      } else if (
        params.row.track_action === "Pending Issuer" &&
        params.row.your_role === "Issuer"
      ) {
        return (
          <button className="bg-blue-300 text-black border-none rounded-lg cursor-pointer w-[150px]  h-10">
            Accept
          </button>
        );
      } else if (
        params.row.track_action === "Completed Isolation" &&
        params.row.your_role === "Initiator" &&
        notifications?.some(
          (notification) =>
            notification.workOrderId === params.row.workOrderId &&
            notification.action === "await_technicians_added"
        )
      ) {
        return (
          <button className="bg-blue-300 text-black border-none rounded-lg cursor-pointer w-[150px] h-10">
            Assign Technicians
          </button>
        );
      }
      // else if (
      //   params.row.track_action === "Completed Isolation" &&
      //   (params.row.your_role === "Isolator" ||
      //     params.row.your_role === "Custodian" ||
      //     params.row.your_role === "Issuer") &&
      //   notifications?.some(
      //     (notification) =>
      //       notification.workOrderId === params.row.workOrderId &&
      //       notification.action === "await_technicians_added"
      //   )
      // ) {
      //   return (
      //     <button className="bg-blue-300 text-black border-none rounded-lg cursor-pointer w-[150px]  h-10">
      //       Initiator to Assign Technicians
      //     </button>
      //   );
      // }
      else if (
        params.row.track_action === "Completed Work" &&
        params.row.your_role === "Initiator"
      ) {
        return (
          <button className="bg-blue-300 text-black border-none rounded-lg cursor-pointer w-[150px]  h-10">
            Accept
          </button>
        );
      } else if (
        params.row.track_action === "Completed De-Isolation" &&
        params.row.your_role === "Initiator" &&
        notifications?.some(
          (notification) =>
            notification.workOrderId === params.row.workOrderId &&
            notification.action === "completed_workOrder"
        )
      ) {
        return (
          <button className="bg-blue-300 text-black border-none rounded-lg cursor-pointer w-[150px]  h-10">
            Complete Work Order
          </button>
        );
      } else if (
        params.row.track_action === "Custodian Accepted" &&
        params.row.your_role === "Custodian"
      ) {
        return (
          <button className="bg-blue-300 text-black border-none rounded-lg cursor-pointer w-[150px]  h-10">
            Assign Issuer
          </button>
        );
      } else if (
        params.row.track_action === "All Issuers Accepted" &&
        params.row.your_role === "Issuer"
      ) {
        return (
          <button className="bg-blue-300 text-black border-none rounded-lg cursor-pointer w-[150px]  h-10">
            Assign Isolators
          </button>
        );
      } else if (
        params.row.track_action === "WorkOrder Completed" &&
        (params.row.your_role !== "Initiator" ||
          (params.row.your_role === "Initiator" &&
            notifications?.some(
              (notification) =>
                notification.workOrderId === params.row.workOrderId &&
                notification.action === "completed_workOrder"
            )))
      ) {
        console.log("vgbhj");
        return (
          <h1 className="bg-green-200 text-black border-none rounded-lg cursor-pointer w-[150px]  h-10 pl-1">
            WorkOrder Completed
          </h1>
        );
      } else {
        return (
          <h1 className="ml-16" style={{ fontSize: "20px" }}>
            --
          </h1>
        );
      }
      // return params.row.track_action || "Custodian Accepted";
    },
  },
];

const CustomToolbar = () => (
  <GridToolbarContainer>
    <GridToolbarExport />
    <GridToolbarFilterButton />
    <GridToolbarDensitySelector />
  </GridToolbarContainer>
);

const WorkOrderTable = ({
  apiData = [],
  totalPages,
  setPage,
  page,
  notifications = [],
}) => {
  const [roleFilter, setRoleFilter] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [dateFilterAnchorEl, setDateFilterAnchorEl] = useState(null);
  const [roleFilterAnchorEl, setRoleFilterAnchorEl] = useState(null);
  const searchParams = new URLSearchParams(window.location.search);
  const tokenValue = searchParams.get("token");

  const navigate = useNavigate();

  const handleRoleFilterChange = (event) => {
    setRoleFilter(event.target.value);
  };

  const handleStartDateChange = (event) => {
    setStartDate(event.target.value);
  };

  const handleEndDateChange = (event) => {
    setEndDate(event.target.value);
  };

  const handleDateFilterOpen = (event) => {
    setDateFilterAnchorEl(event.currentTarget);
  };

  const handleDateFilterClose = () => {
    setDateFilterAnchorEl(null);
  };

  const handleRoleFilterOpen = (event) => {
    setRoleFilterAnchorEl(event.currentTarget);
  };

  const handleRoleFilterClose = () => {
    setRoleFilterAnchorEl(null);
  };

  const filteredRows = apiData
    .filter((item) => {
      const itemDate = new Date(item.createdAt);
      const startDateObj = new Date(startDate);
      const endDateObj = new Date(endDate);

      const dateInRange =
        (!startDate || itemDate >= startDateObj) &&
        (!endDate || itemDate <= endDateObj);
      const roleMatches = !roleFilter || item.your_role === roleFilter;

      return dateInRange && roleMatches;
    })
    .map((item, index) => ({
      id: index,
      createdAt: item.createdAt,
      workOrderId: item.workOrderId,
      workOrderName: item.workOrderName,
      equipmentId: item.equipmentId,
      workOrder_status: item.workOrder_status,
      your_role: item.your_role,
      track_action: item.track_action,
    }));

  function encodeString(str) {
    return btoa(str);
  }

  return (
    <>
      <Box
        sx={{
          width: "100%",
          maxHeight: "500px",
          "& .MuiDataGrid-root": {
            border: "none",
          },
          "& .MuiDataGrid-cell": {
            borderBottom: "none",
          },
          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: "#f3f4f6",
            borderBottom: "none",
            position: "sticky",
            top: 0,
            zIndex: 1,
          },
          "& .MuiDataGrid-columnHeaderTitle": {
            fontWeight: "bold",
            color: "#4b5563",
          },
          "& .MuiDataGrid-footerContainer": {
            justifyContent: "center",
            height: "100px",
            display: "none",
          },
          "& .MuiDataGrid-toolbarContainer": {
            backgroundColor: "#f3f4f6",
          },
          "& .MuiDataGrid-noRowsOverlay": {
            minHeight: "80px",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          },
          "& .MuiDataGrid-overlayWrapper": {
            height: "auto !important",
          },
          "& .MuiDataGrid-overlayWrapperInner": {
            height: "50px !important",
          },
          "& .MuiDataGrid-overlay": {
            height: "50px !important",
          },
        }}
      >
        <div
          style={{
            height: "500px", // Ensure the height is fixed to manage overflow
            overflowY: "auto",
            overflowX: "auto", // Ensure horizontal scrollbar is always available
            backgroundColor: "white",
            borderRadius: "12px",
          }}
        >
          <DataGrid
            disableColumnMenu
            rows={filteredRows}
            rowHeight={40}
            columns={columns(
              dateFilterAnchorEl,
              handleDateFilterOpen,
              handleDateFilterClose,
              startDate,
              endDate,
              handleStartDateChange,
              handleEndDateChange,
              roleFilterAnchorEl,
              handleRoleFilterOpen,
              handleRoleFilterClose,
              roleFilter,
              handleRoleFilterChange,
              notifications?.notifications
            )}
            rowCount={filteredRows.length}
            getRowClassName={() => "pointer-cursor"}
            components={{
              Toolbar: CustomToolbar,
            }}
            onRowClick={(row) => {
              navigate(
                `/loto/workorder/${encodeString(
                  row.row.workOrderId
                )}?token=${tokenValue}`,
                { state: { rowData: row.row } } // Sending only clicked row data
              );
            }}
          />
        </div>
      </Box>
      <div className="flex justify-end py-2">
        <Pagination
          count={totalPages}
          page={page}
          onChange={(e, value) => setPage(value)}
        />
      </div>
      <style>
        {`
            .pointer-cursor {
              cursor: pointer;
            }
          `}
      </style>
    </>
  );
};

export default WorkOrderTable;
