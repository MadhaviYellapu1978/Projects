import * as React from 'react';
import dayjs from 'dayjs';
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { TextField } from '@mui/material';

// Custom date format function
const formatDate = (date) => {
  return date ? dayjs(date).format('DD-MM-YYYY') : '';
};

export default function DatePickerValue() {
  const [value, setValue] = React.useState(dayjs()); // Set default value to current date

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <DemoContainer components={['DatePicker', 'DatePicker']}>
        <DatePicker
          label="From"
          defaultValue={dayjs()} // Set default value to current date
          renderInput={(params) => <TextField {...params} helperText={formatDate(params.inputProps?.value)} />}
        />
        <DatePicker
          label="To"
          value={value}
          onChange={(newValue) => setValue(newValue)}
          renderInput={(params) => <TextField {...params} helperText={formatDate(value)} />}
        />
      </DemoContainer>
    </LocalizationProvider>
  );
}
