import React from 'react';

const Cards = ({ cards, setFilterStatus, status, selectedCardIndex, setSelectedCardIndex }) => {
  const handleCardClick = (index, status) => {
    if (selectedCardIndex === index) {
      setSelectedCardIndex("null");
      setFilterStatus('All');
    } else {
      setSelectedCardIndex(index);
      setFilterStatus(status);
    }
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 xl:grid-cols-6 gap-4">
      {cards.map((card, index) => (
        <div
          key={index}
          className={`bg-white rounded-xl shadow-md p-2 cursor-pointer ${
            selectedCardIndex === index ? 'border-4 border-orange-300' : ''
          }`}
          onClick={() => handleCardClick(index, status[index])}
        >
          <div style={{ display: 'flex', alignItems: 'center', marginTop: '5px' }}>
            {card.image && (
              <img
                src={card.image}
                alt={`${card.title} icon`}
                className="mb-4"
                style={{ width: '45px', height: '45px'}}
              />
            )}
            <div
              style={{
                display: 'flex',
                flexWrap: 'wrap',
                flexDirection: 'column',
                alignContent: 'start',
                justifyContent: 'center',
                marginLeft: 20,
              }}
            >
              <h3 className="font mb-2">{card.title}</h3>
              <p className="text-2xl" style={{ fontWeight: 'bold' }}>
                {card.description}
              </p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Cards;
