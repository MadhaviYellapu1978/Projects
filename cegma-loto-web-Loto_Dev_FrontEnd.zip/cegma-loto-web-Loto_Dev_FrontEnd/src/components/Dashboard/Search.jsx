import React from "react";
import SearchIcon from "../../assets/searchIcon.svg";
import Switch from "@mui/material/Switch";

const Search = ({ onSearch, toggleMapView  }) => {
  const label = { inputProps: { "aria-label": "Switch demo" } };

  const handleSearchChange = (event) => {
    onSearch(event.target.value);
  };

  const handleToggleChange = (event) => {
    toggleMapView(event.target.checked);
  };


  return (
    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 py-4">
      <h2 className="font-semibold text-lg">WorkOrder</h2>

      

      <div className="flex flex-col sm:flex-row gap-4 sm:items-center">
        <input
          type="search"
          className="bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-full text-sm px-10 py-2.5 me-2 dark:bg-gray-800 dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700 w-full sm:w-auto"
          placeholder="Search..."
          style={{
            backgroundImage: `url(${SearchIcon})`,
            backgroundRepeat: "no-repeat",
            backgroundPosition: "10px center",
          }}
          onChange={handleSearchChange}
        />

        <div className="flex items-center gap-3">
          <h2 className="font-semibold text-lg">Map View</h2>
          <Switch {...label} onChange={handleToggleChange} />
        </div>
      </div>
    </div>
  );
};

export default Search;
