import React, { useState } from "react";
import { plusIcon } from "../../assets";
import { apiCall } from "../../utils";
import { equipmentEndPoints, methods } from "../../constants";
import { Formik, Form, FieldArray, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { useSelector } from "react-redux";
import toast from "react-hot-toast";

const AddPadlock = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [error, setError] = useState("");

  const user = useSelector((state) => state.authSlice.user);

  const handleOpen = () => {
    setIsModalOpen(true);
  };

  const handleClose = () => {
    setIsModalOpen(false);
  };

  const handleSave = async (values, { resetForm }) => {
    const macIds = values.macIds;
    if (macIds.length === 0) {
      setError("At least one MAC ID is required");
      return;
    }

    setError(""); // Clear existing errors before the API call

    try {
      const response = await apiCall(
        equipmentEndPoints.addPadlocks,
        methods.post,
        {
          orgid: user.org?.org_id,
          orgname: user.org?.org_name,
          macid: macIds,
        }
      );

      toast.success(response.message);
      resetForm();
      handleClose();
    } catch (err) {
      toast.error(err.message || "An error occurred while adding the padlocks");
    }
  };

  const validationSchema = Yup.object({
    newMacId: Yup.string()
      .matches(
        /^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/,
        "Invalid MAC ID format. Use XX:XX:XX:XX:XX:XX."
      )
      .nullable(),
    macIds: Yup.array()
      .of(
        Yup.string().matches(
          /^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/,
          "Invalid MAC ID format."
        )
      )
  });

  return (
    <>
      <div>
        <button
          className="bg-primary flex gap-3 py-3 px-5 rounded-full text-white font-bold min-w-32"
          onClick={handleOpen}
        >
          <img src={plusIcon} alt="add" className="img-fluid" />
          Add Padlock
        </button>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex justify-center items-center bg-black bg-opacity-50">
          <div className="bg-white p-8 rounded-lg shadow-lg w-96 relative z-50">
            <h2 className="text-xl font-bold mb-4">Add Padlock</h2>

            <Formik
              initialValues={{ macIds: [], newMacId: "" }}
              validationSchema={validationSchema}
              onSubmit={handleSave}
            >
              {({
                values,
                handleChange,
                handleSubmit,
                errors,
                touched,
                isValid,
                setFieldValue,
              }) => (
                <Form onSubmit={handleSubmit}>
                  <FieldArray name="macIds">
                    {({ push, remove }) => (
                      <>
                        <div className="mb-4">
                          <label className="block text-gray-700">MAC ID</label>
                          <div className="flex">
                            <Field
                              name="newMacId"
                              className={`w-full px-4 py-2 border ${
                                errors.newMacId && touched.newMacId
                                  ? "border-red-500"
                                  : "border-gray-300"
                              } rounded-lg`}
                              placeholder="Enter MAC ID"
                              onChange={(e) => {
                                handleChange(e);
                                // Clear error message when the user is typing a valid MAC ID
                                if (Yup.string()
                                  .matches(
                                    /^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/,
                                    "Invalid MAC ID format"
                                  )
                                  .isValidSync(e.target.value)) {
                                  setError("");
                                }
                              }}
                            />
                            <button
                              type="button"
                              className="bg-primary text-white px-4 py-2 rounded-lg ml-2"
                              onClick={() => {
                                if (!errors.newMacId && values.newMacId) {
                                  push(values.newMacId); // Add the valid MAC ID
                                  setFieldValue("newMacId", ""); // Clear the input field
                                }
                              }}
                              disabled={!!errors.newMacId || !values.newMacId} // Disable if MAC ID is invalid or empty
                            >
                              Add
                            </button>
                          </div>

                          {/* Display error message in real-time */}
                          <ErrorMessage
                            name="newMacId"
                            component="div"
                            className="text-red-500 mt-2"
                          />
                        </div>

                        {/* Display added MAC IDs */}
                        {values.macIds.length > 0 && (
                          <div className="mb-4">
                            <h3 className="font-bold">Added MAC IDs:</h3>
                            <div className="grid grid-cols-2 gap-2">
                              {values.macIds.map((macId, index) => (
                                <div key={index} className="flex items-center">
                                  <span className="border border-gray-400 bg-gray-200 px-2 py-1 rounded-lg flex items-center w-full">
                                    {macId}
                                    <button
                                      className="ml-2 text-red-500"
                                      onClick={() => remove(index)} // Remove MAC ID
                                      aria-label="Remove MAC ID"
                                    >
                                      &times;
                                    </button>
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </>
                    )}
                  </FieldArray>

                  {error && <p className="text-red-500 mt-2">{error}</p>}

                  <div className="flex justify-end gap-3 mt-4">
                    <button
                      type="button"
                      className="border-2 border-primary flex gap-1 py-2 px-4 mt-1 rounded-full text-primary font-semibold"
                      onClick={handleClose}
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="bg-primary flex gap-3 py-3 px-6 rounded-full mt-1 text-white font-bold min-w-3"
                      disabled={!isValid || values.macIds.length === 0} // Disable if form is invalid or no MAC IDs
                    >
                      Save
                    </button>
                  </div>
                </Form>
              )}
            </Formik>
          </div>
        </div>
      )}
    </>
  );
};

export default AddPadlock;
