import React from 'react'
import { Modal, Box, Button } from '@mui/material'
import { closeIcon } from '../../assets';
const ViewPadlock = ({ padlock, viewPadlock,
    setViewPadlock, setEditPadlock }) => {
    const style = {
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        minWidth: 300,
        maxWidth: 800,
        width: "100%",
        bgcolor: "background.paper",
        // border: '2px solid #000',
        boxShadow: 24,
        p: 4,
        outline: 'none',
        borderRadius: 4
    };
    return (
        <Modal
            open={viewPadlock}
            onClose={() => {
                setViewPadlock(false);
            }}
        >
            <Box sx={style}>
                <div>
                    <div className='flex justify-between border-b-2 border-zinc-200 pb-5'>
                        <h3 className='text-xl'>Padlock Information</h3>
                        <img src={closeIcon} alt="Close Icon" className='cursor-pointer' onClick={() => {
                            setViewPadlock(false);
                        }} />
                    </div>
                    <div className='py-5 grid grid-cols-2 md:grid-cols-4'>
                        <div className='py-2'>
                            <p className='text-xs'>Padlock</p>
                            <p>{padlock.name}</p>
                        </div>
                        <div className='py-2'>
                            <p className='text-xs'>Mac Id</p>
                            <p className='text-wrap'>{padlock.mac_id}</p>
                        </div>
                        <div className='py-2'>
                            <p className='text-xs'>Status</p>
                            <p>{padlock.name}</p>
                        </div>
                        <div className='py-2'>
                            <p className='text-xs'>Battery Level</p>
                            <p>{padlock.battery_level}%</p>
                        </div>
                        <div className='py-2'>
                            <p className='text-xs'>Equipment</p>
                            <p>{padlock.battery_level}%</p>
                        </div>
                    </div>
                    <div className='grid grid-cols-3 gap-5'>
                        <Button variant='outlined' onClick={() => {
                            setViewPadlock(false);
                        }}>Close</Button>
                        <Button variant='contained' onClick={() => {
                            setEditPadlock(true);
                            setViewPadlock(false);
                        }}>Edit</Button>
                        <Button variant='contained'>Detach</Button>
                    </div>
                </div>
            </Box>
        </Modal>
    )
}

export default ViewPadlock
