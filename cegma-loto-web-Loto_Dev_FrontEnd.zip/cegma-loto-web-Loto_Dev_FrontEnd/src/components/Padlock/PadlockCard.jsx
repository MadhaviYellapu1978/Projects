/* eslint-disable */
import React from 'react'
import { padlockImg } from '../../assets'
import ViewPadlock from './ViewPadlock';
import EditPadlock from './EditPadlock';
import DetachPadlock from './DetachPadlock';

const PadlockCard = ({ lock }) => {
    const [anchorEl, setAnchorEl] = React.useState(null);
    const [viewPadlock, setViewPadlock] = React.useState(false);
    const [editPadlock, setEditPadlock] = React.useState(false);
    const [detachPadlock, setDetachPadlock] = React.useState(false);
  

    const open = Boolean(anchorEl);
    return (
        <>
            <div className='shadow-md drop-shadow-md m-5 flex justify-between gap-7 p-3'>
                <img src={padlockImg} alt="padlock" />
                <div className='flex flex-col justify-between'>
                    <p>Padlock: {lock.name}</p>
                    <p>Mac Id: {lock.mac_id}</p>
                    <p>Status: {lock.pdStatus}</p>
                    <p>Battery Level: {lock.battery_level}%</p>
                </div>
                {/* <div>
                    <img src={moreIcon} alt='more icon' onClick={handleClick} className='cursor-pointer w-10 h-4' />
                    <Popover
                        id={id}
                        open={open}
                        anchorEl={anchorEl}
                        onClose={handleClose}
                        anchorOrigin={{
                            vertical: 'bottom',
                            horizontal: 'left',
                        }}
                    >
                        <ul >
                            <li className='min-w-40 text-center py-2 hover:bg-blue-300 cursor-pointer' onClick={() => {
                                setViewPadlock(true)
                                handleClose()
                            }}>View</li>
                            <li className='min-w-40 text-center py-2 hover:bg-blue-300 cursor-pointer' onClick={() => {
                                setEditPadlock(true)
                                handleClose()
                            }}>Edit</li>
                            {
                                lock.isAssigned ? <li className='min-w-40 text-center py-2 hover:bg-blue-300 cursor-pointer' onClick={() => {
                                    setDetachPadlock(true)
                                    handleClose()

                                }}>Detach</li> : <li></li>
                            }
                        </ul>
                    </Popover>
                </div> */}
            </div>
            {
                viewPadlock && <ViewPadlock padlock={lock} viewPadlock={viewPadlock}
                    setViewPadlock={setViewPadlock} setEditPadlock={setEditPadlock} />
            }
            {
                editPadlock && <EditPadlock padlock={lock} editPadlock={editPadlock}
                    setEditPadlock={setEditPadlock} />
            }
            {
                detachPadlock && <DetachPadlock padlock={lock} detachPadlock={detachPadlock} setDetachPadlock={setDetachPadlock} />
            }
        </>
    )
}

export default PadlockCard
