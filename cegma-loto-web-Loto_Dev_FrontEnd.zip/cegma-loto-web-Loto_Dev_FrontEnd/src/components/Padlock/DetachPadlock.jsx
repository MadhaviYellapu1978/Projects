import React from 'react'
import { Modal, Box, Button } from '@mui/material'
import { apiCall } from '../../utils'
import { closeIcon } from '../../assets'
import { equipmentEndPoints, methods } from '../../constants'
import { useSelector } from 'react-redux'
const DetachPadlock = (props) => {
    const user = useSelector(state => state.authSlice.user)
    const { detachPadlock,
        padlock,
        setDetachPadlock } = props
    const style = {
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        minWidth: 300,
        maxWidth: 400,
        width: "100%",
        bgcolor: "background.paper",
        // border: '2px solid #000',
        boxShadow: 24,
        p: 4,
        outline: 'none',
        borderRadius: 4
    };

    const handleDetach = () => {
        const data = {
            padLockData: {
                ...padlock,
                orgId: user.org.org_id,
                equipmentData: {

                },
                isAttached: false,
                // isLocked: false
            }
        }

        apiCall(equipmentEndPoints.updatePadlock, methods.post, data).then(data => {
            setDetachPadlock(false)
        })
    }


    return (
        <Modal open={detachPadlock} onClose={() => {
            setDetachPadlock(false)
        }}>
            <Box sx={style}>
                <div className='flex justify-between border-b-2 border-slate-200 pb-5'>
                    <h3 className='text-xl text-red-600'>Detach Padlock</h3>
                    <img src={closeIcon} alt="close icon" className='cursor-pointer' onClick={() => {
                        setDetachPadlock(false)
                    }} />
                </div>
                <p className='text-md my-5 font-normal text-center'>
                    Are you sure you want to detached the PadLock from Isolation Point??
                </p>
                <div className='grid grid-cols-2 gap-5'>
                    <Button variant='outlined' onClick={() => {
                        setDetachPadlock(false)
                    }}>Cancel</Button>
                    <Button variant='contained' onClick={handleDetach}>Yes</Button>
                </div>
            </Box>
        </Modal>
    )
}

export default DetachPadlock
