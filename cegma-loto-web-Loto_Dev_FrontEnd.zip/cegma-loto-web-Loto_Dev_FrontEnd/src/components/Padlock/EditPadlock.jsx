import React, { useState } from 'react'
import { Modal, Box, TextField, Button } from '@mui/material'
import { closeIcon } from '../../assets';
import { equipmentEndPoints, methods } from '../../constants';
import { apiCall } from '../../utils';
const EditPadlock = (props) => {
    const { editPadlock,
        padlock,
        setEditPadlock } = props
    const style = {
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        minWidth: 300,
        maxWidth: 400,
        width: "100%",
        bgcolor: "background.paper",
        // border: '2px solid #000',
        boxShadow: 24,
        p: 4,
        outline: 'none',
        borderRadius: 4
    };
    const [initialValue, setInitialValue] = useState(padlock)
    const handleSubmit = () => {
        const data = {
            padlockData: {
                ...initialValue
            }
        }
        apiCall(equipmentEndPoints.updatePadlock, methods.post, data).then(data => {
            setEditPadlock(false)
        })

    }
    return (
        <Modal open={editPadlock} onClose={() => {
            setEditPadlock(false)
        }}>
            <Box sx={style}>
                <div>
                    <div className='flex justify-between border-b-2 border-zinc-200 pb-5'>
                        <h3 className='text-xl'>Edit Padlock</h3>
                        <img src={closeIcon} alt="Close Icon" className='cursor-pointer' onClick={() => {
                            setEditPadlock(false);
                        }} />
                    </div>
                    <div className='py-5 flex flex-col gap-5'>
                        <TextField fullWidth label='Padlock Name *' value={initialValue.name} onChange={(e) => {
                            setInitialValue({
                                ...initialValue,
                                name: e.target.value
                            })
                        }} />
                        <TextField fullWidth label='Mac Id' disabled value={initialValue.mac_id} />
                        <TextField fullWidth label='Status' disabled value={initialValue.status} />
                        <TextField fullWidth label='Battery Level' disabled value={initialValue.battery_level} />
                    </div>
                    <div className='flex gap-5'>
                        <Button variant='outlined' className='w-full'>Cancel</Button>
                        <Button variant='contained' className='w-full' onClick={handleSubmit}>Save</Button>
                    </div>
                </div>
            </Box>
        </Modal>
    )
}

export default EditPadlock
