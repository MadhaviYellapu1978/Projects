import React from 'react'

const AttachPadlock = () => {
    return (
        <div>

        </div>
    )
}

export default AttachPadlock
