import React, { useState } from "react";
import { plusIcon } from "../../assets";
import { Box, Modal } from "@mui/material";
import { v4 as uuidv4 } from "uuid";
import dayjs from "dayjs";
import AddLotoEquipmentForm from "./components/Modal";

const AddAssets = ({ fetchData }) => {
  const [machineData, setMachineData] = useState({
    equipmentName: "",
    equipmentFilePath:"",
    location: "",
    zoneId: "",
    siteId: "",
    latitude: "",
    longitude: "",
    testFrequency: "",
    lastTestedDate: dayjs(),
    serialNumber: "",
    manufacturer: "",
    modelNumber: "",
    createdAt: "",
    updatedAt: "",
    machines: [
      {
        machineId: uuidv4(),
        machineName: "",
        isolationPoints: [
          {
            isolationId: uuidv4(),
            isolationName: "",
            padlockName: "",
            macId: "",
          },
        ],
      },
    ],
  });

  const [isOpen, setIsOpen] = useState(false);
  const handleOpen = () => {
    setMachineData({
      equipmentName: "",
      equipmentFilePath:"",
      location: "",
      zoneId: "",
      siteId: "",
      latitude: "",
      longitude: "",
      testFrequency: "",
      lastTestedDate: dayjs(),
      serialNumber: "",
      manufacturer: "",
      modelNumber: "",
      createdAt: "",
      updatedAt: "",
      machines: [
        {
          machineId: uuidv4(),
          machineName: "",
          isolationPoints: [
            {
              isolationId: uuidv4(),
              isolationName: "",
              padlockName: "",
              macId: "",
            },
          ],
        },
      ],
    });
    setIsOpen(true);
  };
  const handleCancel = () => {
    const mainImageInput = document.getElementById("image-upload");
    if (mainImageInput) {
      mainImageInput.value = "";
    }

    // Reset all machines and isolation points' images
    setMachineData((prev) => {
      const newMachines = prev.machines.map((machine, machineIndex) => {
        // Reset the machine-specific image input
        const machineImageInput = document.getElementById(
          `upload-machine-image-${machineIndex}`
        );
        if (machineImageInput) {
          machineImageInput.value = "";
        }

        const newIsolationPoints = machine.isolationPoints.map(
          (isoPoint, isoPointIndex) => {
            // Reset each isolation point's image input
            const isolationImageInput = document.getElementById(
              `upload-isolation-image-${machineIndex}-${isoPointIndex}`
            );
            if (isolationImageInput) {
              isolationImageInput.value = "";
            }

            return { ...isoPoint, imagePath: "" };
          }
        );

        return {
          ...machine,
          equipmentImgPath: "",
          isolationPoints: newIsolationPoints,
        };
      });

      return { ...prev, machines: newMachines };
    });
  };
  return (
    <div>
      <button
        className="bg-primary flex gap-3 py-3 px-5 rounded-full text-white font-bold min-w-32"
        onClick={handleOpen}
      >
        <img src={plusIcon} alt="add" className="img-fluid" />
        Add Asset
      </button>
      <Modal
        open={isOpen}
        onClose={() => {
          //start
          handleCancel();
          setIsOpen(false);
        }}
      >
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            maxWidth: 800,
            width: "100%",
            height: 650,
            bgcolor: "background.paper",
            border: "2px solid #000",
            boxShadow: 24,
            p: 4,

          }}
        >
          <AddLotoEquipmentForm
            setIsOpen={setIsOpen}
            fetchData={fetchData}
            machineData={machineData}
            setMachineData={setMachineData}
          />
        </Box>
      </Modal>
    </div>
  );
};

export default AddAssets;
