/* eslint-disable */
import React, { useEffect, useState } from "react";
import {
  TextField,
  Button,
  Grid,
  Stack,
  FormGroup,
  Select,
  MenuItem,
  InputLabel,
  FormControl,
  Box,
} from "@mui/material";
import Image from "../../../assets/image.png";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { DemoContainer } from "@mui/x-date-pickers/internals/demo";
import { apiCall } from "../../../utils";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { equipmentEndPoints, methods, userEndPoints } from "../../../constants";
import { plusIcon } from "../../../assets";
import { v4 as uuidv4 } from "uuid";
import { useSelector } from "react-redux";
import dayjs from "dayjs";
import toast from "react-hot-toast";
import plus11 from "../../../assets/plus11.svg";

const AddLotoEquipmentForm = ({
  setIsOpen,
  fetchData,
  setMachineData,
  machineData,
  data,
  type = "add",
}) => {
  const user = useSelector((state) => state.authSlice.user);
  // eslint-disable-next-line
  const [date, setDate] = useState();
  const [filename, setFilename] = useState(machineData.equipmentImgPath || "");
  const [pdfFilename, setPdfFilename] = useState(
    machineData.equipmentFilePath || ""
  );
  const [previousPdfFilename, setPreviousPdfFilename] = useState(null);
  const [count, setCount] = useState(0);
  const [zones, setZones] = useState([]);
  const [sites, setSites] = useState([]);
  const [pdfFile, setPdfFile] = useState(null);

  // eslint-disable-next-line
  const [showEditMachine, setShowEditMachine] = useState(false);
  // eslint-disable-next-line
  const [prevImage, setPrevImage] = useState(null);
  // const [previousImage, setPreviousImage] = useState(""); // To store the previous image URL

  useEffect(() => {
    const fetchDataEffect = () => {
      apiCall(
        `${userEndPoints.getAllZonesByOrg}/${user.org.org_id}/getAllZones`,
        methods.get
      ).then(setZones);
      if (machineData.zoneId) {
        apiCall(
          `${userEndPoints.getAllSitesByZone}/${machineData.zoneId}/getAllSites`,
          methods.get
        ).then(setSites);
      }
    };
    fetchDataEffect();
    return () => {};
  }, [machineData.zoneId, user.org.org_id]);

  useEffect(() => {
    if (machineData.equipmentImgPath) {
      setFilename({
        fileurl: machineData.equipmentImgPath,
        name: "Existing Image",
      });
      setPrevImage(machineData.equipmentImgPath); // Set the existing image as previous image
    }
  }, [machineData.equipmentImgPath]);

  const formattedInitialDate = machineData.lastTestedDate
    ? dayjs(machineData.lastTestedDate, "YYYY-MM-DD").format("DD-MM-YYYY")
    : "";

  const handleDateChange = (newValue) => {
    const selectedDate = dayjs(newValue);
    const formattedDate = selectedDate.format("DD-MM-YYYY");
    setDate(formattedDate);
    setMachineData((prev) => ({
      ...prev,
      lastTestedDate: selectedDate.format("YYYY-MM-DD"),
    }));
  };

  const handleMachineImageChange = async (machineIndex, event) => {
    const file = event.target.files[0];

    let result;
    var formdata = new FormData();
    formdata.append(file.name, file);
    formdata.append("path", "loto/test");
    var requestOptions = {
      method: "POST",
      body: formdata,
      redirect: "follow",
    };

    await fetch(
      "https://api-dev.smartloto.in/smartLotoUploadService/upload",
      requestOptions
    )
      .then((response) => response.json())
      .then((data) => {
        result = data.fileurl;
      });
    const reader = new FileReader();
    reader.onloadend = () => {
      console.log(result);
      setMachineData((prevData) => {
        const newMachines = prevData.machines.map((machine, idx) => {
          if (idx === machineIndex) {
            return { ...machine, machine_image: result };
          }
          return machine;
        });
        return { ...prevData, machines: newMachines };
      });
      event.target.value = "";
    };

    reader.readAsDataURL(file);
  };

  const handleCancelMachineImage = (machineIndex) => {
    setMachineData((prevData) => {
      const newMachines = prevData.machines.map((machine, idx) => {
        if (idx === machineIndex) {
          return { ...machine, machine_image: "" };
        }
        return machine;
      });
      return { ...prevData, machines: newMachines };
    });
  };
  useEffect(() => {
    const fetchDataEffect = () => {};
    fetchDataEffect();
    if (type === "edit")
      return () => {
        // eslint-disable-next-line
        setMachineData(data);
      };
  }, []);

  const handleChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("path", "loto/test");

      fetch("https://api-dev.smartloto.in/smartLotoUploadService/upload", {
        method: "POST",
        body: formData,
        redirect: "follow",
      })
        .then((response) => response.json())
        .then((result) => {
          // Store the previous image URL before updating the new one
          // setPreviousImage(machineData.equipmentImgPath || "");

          setFilename(result);
          setMachineData((prev) => ({
            ...prev,
            equipmentImgPath: result.fileurl,
          }));
        })
        .catch((error) => console.log("Error uploading image:", error));
    }
  };

  useEffect(() => {
    // Convert machine.lastTestedDate to a dayjs object
    const lastTestedDate = dayjs(machineData.lastTestedDate);
    // Format the date to match your requirements
    const formattedDate = lastTestedDate.format("YYYY-MM-DD");
    // Set the prepopulated date in the state
    setDate(formattedDate);
  }, [machineData.lastTestedDate]);

  const handleSubmit = (event) => {
    event.preventDefault();
    if (count === 0) {
      if (!filename) return toast.error("Please Select Image");
      setCount((prev) => prev + 1);
    } else {
      if (type === "add") {
        saveEquipment();
      } else {
        editEquipment();
      }
    }
  };

  const handleCancel = () => {
    // Revert to the previous image or initial image in edit mode
    setFilename("");
    setMachineData((prev) => ({
      ...prev,
      // equipmentImgPath: previousImage || initialImage,
    }));
  };

  const saveEquipment = () => {
    try {
      apiCall(equipmentEndPoints.postPadlocks, methods.post, {
        ...machineData,
        orgId: user.org.org_id,
      })
        .then((data) => {
          setIsOpen(false);
          fetchData();
          toast.success(data.message);
        })
        .catch((error) => {
          console.log(error);
          toast.error("Equipment name already exists");
        });
    } catch (error) {
      // Handle the error thrown if the equipment name already exists
      toast.error(error.message);
    }
  };

  const editEquipment = () => {
    try {
      apiCall(equipmentEndPoints.updateEquipment, methods.put, {
        ...machineData,
        orgId: user.org.org_id,
      }).then((data) => {
        setIsOpen(false);
        fetchData();
        toast.success(data.message);
        // return alert(data.message);
      });
    } catch (error) {
      // Handle the error thrown if the equipment name already exists
      toast.error(error.message);
    }
  };
  const handleZoneChange = (e) => {
    const newMachineData = { ...machineData };
    newMachineData.zoneId = e.target.value;
    apiCall(
      `${userEndPoints.getAllSitesByZone}/${newMachineData.zoneId}/getAllSites`,
      methods.get
    ).then((data) => {
      setSites(data);
      newMachineData.siteId = data[0].site_id;
      setMachineData(newMachineData);
    });
  };
  const handleSiteChange = (e) => {
    const newMachineData = { ...machineData };
    newMachineData.siteId = e.target.value;
    setMachineData(newMachineData);
  };
  const handleFieldChange2 = (machineIndex, isoPointIndex, field, value) => {
    const trimmedValue = value.trimStart();

    // Define regex to allow only alphanumeric characters and spaces
    const alphanumericRegex = /^[a-zA-Z0-9 ]*$/;

    // Apply restriction only to machineName and isolationName fields
    if (
      (field === "machineName" || field === "isolationName") &&
      !alphanumericRegex.test(trimmedValue)
    ) {
      return; // Don't update state if invalid characters are present
    }

    setMachineData((prev) => {
      const newMachines = prev.machines.map((machine, index) => {
        if (index === machineIndex) {
          const newMachine = { ...machine };
          if (isoPointIndex !== undefined) {
            newMachine.isolationPoints = machine.isolationPoints.map(
              (isoPoint, idx) => {
                if (idx === isoPointIndex) {
                  return { ...isoPoint, [field]: value };
                }
                return isoPoint;
              }
            );
          } else {
            newMachine[field] = value;
          }
          return newMachine;
        }
        return machine;
      });
      return { ...prev, machines: newMachines };
    });
  };
  const handleFieldChange = (event) => {
    const { name, value } = event.target;

    // Trim leading spaces using `trimStart()` before updating the state
    const trimmedValue = value.trimStart();
    // const trimmedValue = value.replace(/^\s+/, '');
    const alphanumericRegex = /^[a-zA-Z0-9 ]*$/;

    if (!alphanumericRegex.test(trimmedValue)) {
      // If value contains special characters, don't update state
      return;
    }

    setMachineData((prev) => {
      if (name in prev) {
        return { ...prev, [name]: trimmedValue };
      }

      console.error(
        "Field name is not recognized in the top-level of machineData state:",
        name
      );
      return prev;
    });
  };

  const addMachine = () => {
    setMachineData((prev) => {
      const newMachines = [...prev.machines];
      newMachines.push({
        machineId: uuidv4(),
        machineName: "",
        // description: "",
        machine_lat: "",
        machine_long: "",
        equipmentImgPath: "",
        isolationPoints: [],
      });
      return { ...prev, machines: newMachines };
    });
  };

  const removeMachine = (machineIndex) => {
    setMachineData((prev) => {
      // Copy the array and remove the machine at the specified index
      const newMachines = [...prev.machines];
      newMachines.splice(machineIndex, 1);
      return { ...prev, machines: newMachines };
    });
  };

  const addIsolationPoint = (machineIndex) => {
    setMachineData((prev) => {
      const newMachines = prev.machines.map((machine, index) => {
        if (index === machineIndex) {
          return {
            ...machine,
            isolationPoints: [
              ...machine.isolationPoints,
              {
                isolationId: uuidv4(),
                isolationName: "",
                description: "",
                iso_lat: "",
                iso_long: "",
                iso_image: "",
              },
            ],
          };
        }
        return machine;
      });

      return { ...prev, machines: newMachines };
    });
  };
  const handleImageChange = (machineIndex, isoPointIndex, event) => {
    const file = event.target.files[0];
    if (file) {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("path", "loto/images");

      fetch("https://api-dev.smartloto.in/smartLotoUploadService/upload", {
        method: "POST",
        body: formData,
        redirect: "follow",
      })
        .then((response) => response.json())
        .then((result) => {
          setMachineData((prevData) => {
            // Create a deep copy of the machines array
            const newMachines = prevData.machines.map((machine, idx) => {
              if (idx === machineIndex) {
                const newMachine = { ...machine };
                if (isoPointIndex !== undefined) {
                  // Deep copy of isolation points
                  newMachine.isolationPoints = machine.isolationPoints.map(
                    (isoPoint, isoIdx) => {
                      if (isoIdx === isoPointIndex) {
                        return { ...isoPoint, iso_image: result.fileurl };
                      }
                      return isoPoint;
                    }
                  );
                } else {
                  newMachine.machine_image = result.fileurl;
                }
                return newMachine;
              }
              return machine;
            });
            return { ...prevData, machines: newMachines };
          });
        })
        .catch((error) => console.log("Error uploading image:", error));
    }
  };

  const removeIsolationPoint = (machineIndex, isoPointIndex) => {
    setMachineData((prev) => {
      const newMachines = prev.machines.map((machine, idx) => {
        if (idx === machineIndex) {
          const newMachine = { ...machine };

          newMachine.isolationPoints = machine.isolationPoints.filter(
            (_, index) => index !== isoPointIndex
          );
          return newMachine;
        }
        return machine;
      });
      return { ...prev, machines: newMachines };
    });
  };
  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      setPreviousPdfFilename(pdfFilename); // Store the current file before changing it
      const formData = new FormData();
      formData.append("file", file);
      formData.append("path", "loto/test");

      fetch("https://api-dev.smartloto.in/smartLotoUploadService/upload", {
        method: "POST",
        body: formData,
        redirect: "follow",
      })
        .then((response) => response.json())
        .then((result) => {
          if (result && result.fileurl) {
            setMachineData((prev) => ({
              ...prev,
              equipmentFilePath: result.fileurl,
            }));
            setPdfFilename(result.fileurl); // Update the displayed file path
            console.log("File uploaded successfully: ", result.fileurl);
          } else {
            console.error("No file URL returned from the API.");
          }
        })
        .catch((error) => console.error("Error uploading file:", error));
    }
  };

  const handleFileCancel = () => {
    setPdfFilename(previousPdfFilename); // Revert to the previous file path
    setMachineData((prev) => ({
      ...prev,
      equipmentFilePath: previousPdfFilename,
    }));
    document.getElementById("file-upload").value = ""; // Clear the input field
  };

  const getFileNameFromPath = (path) => {
    const segments = path.split("/"); // Splits the path into segments
    const filename = segments.pop(); // Gets the last segment, which is the filename
    return filename.substring(filename.indexOf("-") + 1); // Returns the part after the first hyphen
  };

  return (
    <div
      style={{
        maxHeight: "calc(100vh - 2rem)",
        overflowY: "hidden",
      }}
    >
      {type !== "edit" ? (
        <h1 className="text-center">Add LOTO Equipment</h1>
      ) : (
        <h1 className="text-center">Edit LOTO Equipment</h1>
      )}

      <hr className="my-5 " />
      {count === 0 ? (
        <form
          onSubmit={handleSubmit}
          className="overflow-y-auto h-full overflow-x-hidden max-h-[600px]  "
        >
          <Grid container spacing={4}>
            <Grid item xs={12} md={6}>
              <div className="image-upload-wrapper ">
                <input
                  type="file"
                  id="image-upload"
                  className="image-upload-input"
                  onChange={handleChange}
                  // {...field}
                  name="image"
                  accept=".png, .jpg, .jpeg"
                />
                <label
                  htmlFor="image-upload"
                  className="image-upload-label flex justify-center items-center flex-col"
                >
                  {!filename.fileurl && !filename ? (
                    <>
                      <img
                        src={Image}
                        alt="Upload"
                        style={{
                          height: 50,
                        }}
                      />
                      <span>Add Image*</span>
                    </>
                  ) : (
                    <>
                      <img
                        src={machineData.equipmentImgPath || filename.fileurl}
                        alt={filename.name || "Uploaded Image"}
                        style={{
                          height: 100,
                        }}
                      />
                    </>
                  )}
                </label>
                {filename && (
                  <button
                    type="button"
                    className="image-upload-cancel md:left-80 top-28 sm:left-[15rem] ml-5 "
                    onClick={handleCancel}
                  >
                    &#10005;
                  </button>
                )}
              </div>
            </Grid>

            <Grid item xs={12} md={6}>
              <div>
                <input
                  type="file"
                  id="file-upload"
                  onChange={handleFileChange}
                  // {...field}
                  name="file"
                  accept=".pdf"
                />
                {pdfFilename && (
                  <>
                    <p> {getFileNameFromPath(pdfFilename)}</p>
                    <button
                      type="button"
                      className="file-upload-cancel"
                      onClick={handleFileCancel}
                    >
                      &#10005; Cancel
                    </button>
                  </>
                )}
              </div>
              <TextField
                onChange={handleFieldChange}
                fullWidth
                required
                name="equipmentName"
                label="Equipment Name"
                value={machineData.equipmentName || ""}
                sx={{ mb: 2, mt: 2 }}
              />
              <TextField
                onChange={handleFieldChange}
                fullWidth
                required
                name="location"
                label="Location"
                value={machineData.location || ""}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <FormControl fullWidth>
                <InputLabel id="selectZone">Select Zone</InputLabel>
                <Select
                  labelId="selectZone"
                  id="selectZone"
                  label="Select Zone"
                  onChange={handleZoneChange}
                  value={machineData.zoneId || ""}
                  required
                >
                  {
                    // <MenuItem></MenuItem>
                    zones?.map((zone) => {
                      return (
                        <MenuItem value={zone.zone_id}>
                          {zone.zone_name}
                        </MenuItem>
                      );
                    })
                  }
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={4}>
              <FormControl fullWidth disabled={!machineData.zoneId}>
                <InputLabel id="selectSite">Select Site</InputLabel>
                <Select
                  labelId="selectSite"
                  id="selectSite"
                  label="Select Site"
                  name="siteId"
                  onChange={handleSiteChange}
                  value={machineData.siteId || ""}
                  required
                >
                  {sites?.map((site) => {
                    return (
                      <MenuItem value={site.site_id}>{site.site_name}</MenuItem>
                    );
                  })}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={4}>
              <TextField
                onChange={handleFieldChange}
                fullWidth
                required
                name="latitude"
                label="Latitude"
                type="string"
                value={machineData.latitude || ""}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <TextField
                onChange={handleFieldChange}
                fullWidth
                required
                name="longitude"
                label="Longitude"
                type="string"
                value={machineData.longitude || ""}
                sx={{ mt: 1 }}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <TextField
                onChange={handleFieldChange}
                fullWidth
                required
                name="testFrequency"
                label="Test Frequency"
                value={machineData.testFrequency || ""}
                sx={{ mt: 1 }}
              />
            </Grid>
            <Grid item xs={12} md={4} lg={4}>
              <FormGroup>
                <LocalizationProvider dateAdapter={AdapterDayjs}>
                  <DemoContainer components={["DatePicker"]}>
                    <DatePicker
                      label="Last Tested Date"
                      format="DD/MM/YYYY"
                      value={dayjs(formattedInitialDate, "DD-MM-YYYY")}
                      onChange={handleDateChange}
                      renderInput={(params) => <TextField {...params} />}
                    />
                  </DemoContainer>
                </LocalizationProvider>
              </FormGroup>
            </Grid>
            <Grid item xs={12} md={4}>
              <TextField
                onChange={handleFieldChange}
                fullWidth
                required
                name="serialNumber"
                label="Serial Number"
                value={machineData.serialNumber || ""}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <TextField
                onChange={handleFieldChange}
                fullWidth
                required
                name="manufacturer"
                label="Manufacturer"
                value={machineData.manufacturer || ""}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <TextField
                onChange={handleFieldChange}
                fullWidth
                required
                name="modelNumber"
                label="Model Number"
                value={machineData.modelNumber || ""}
              />
            </Grid>
            <Grid justifyContent={"center"} item xs={12}>
              <Stack gap={5} direction={"row"} justifyContent={"center"}>
                <button
                  className="border-2 border-primary flex gap-3 py-2 px-6 rounded-full text-primary font-semibold"
                  onClick={() => {
                    setIsOpen(false); // This is where you'll call the function to close the modal
                  }}
                  style={{ marginTop: "1rem" }}
                >
                  Cancel
                </button>
                <button
                  className="bg-primary flex gap-3 py-2 px-8 rounded-full text-white font-semibold"
                  color="primary"
                  style={{ marginTop: "1rem" }}
                  // onClick={handleSubmit}
                >
                  Next
                </button>
              </Stack>
            </Grid>
          </Grid>
        </form>
      ) : (
        <form
          onSubmit={handleSubmit}
          className="overflow-y-auto h-full overflow-x-hidden max-h-[500px]"
        >
          <div
            style={{
              paddingRight: "16px",
            }}
          >
            {machineData.machines.map((machine, machineIndex) => (
              <Box key={machine.machineId} sx={{ borderRadius: "10px" }}>
                <Grid container spacing={2} mt={1} ml={1}>
                  <Grid container spacing={2}>
                    <Grid item xs={10} md={6} sm={6}>
                      <TextField
                        fullWidth
                        label="Machine Name"
                        value={machine.machineName}
                        required
                        sx={{ mb: 1 }}
                        onChange={(e) =>
                          handleFieldChange2(
                            machineIndex,
                            undefined,
                            "machineName",
                            e.target.value
                          )
                        }
                      />

                      <TextField
                        fullWidth
                        label="Machine Longitude"
                        value={machine.machine_long}
                        required
                        sx={{ mb: 1 }}
                        onChange={(e) =>
                          handleFieldChange2(
                            machineIndex,
                            undefined,
                            "machine_long",
                            e.target.value
                          )
                        }
                      />

                      <TextField
                        // className="sm:w-[10px] md:w-[20px]"
                        fullWidth
                        label="Machine Latitude"
                        required
                        value={machine.machine_lat}
                        onChange={(e) =>
                          handleFieldChange2(
                            machineIndex,
                            undefined,
                            "machine_lat",
                            e.target.value
                          )
                        }
                      />
                    </Grid>

                    <Grid item xs={10} md={4} mt={8} ml={4} sm={4}>
                      <div className="image-upload-wrapper">
                        <div key={machineIndex}>
                          <div>
                            <input
                              type="file"
                              id={`upload-machine-image-${machineIndex}`}
                              className="image-upload-input"
                              onChange={(event) =>
                                handleMachineImageChange(machineIndex, event)
                              }
                              style={{ display: "none" }}
                              name="image"
                            />
                            {!machine.machine_image && (
                              <label
                                htmlFor={`upload-machine-image-${machineIndex}`}
                              >
                                <Button component="span">
                                  Upload Machine Image
                                </Button>
                              </label>
                            )}

                            {machine.machine_image && (
                              <div className="flex items-center">
                                <img
                                  src={machine.machine_image}
                                  alt="Machine"
                                  className="w-full h-[70px] object-contain"
                                />
                                <button
                                  type="button"
                                  className="ml-2 text-black-600 text-1xl"
                                  onClick={() =>
                                    handleCancelMachineImage(machineIndex)
                                  }
                                >
                                  &#10005;
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </Grid>
                  </Grid>
                  <div className="mt-4">
                    <Button
                      color="error"
                      onClick={() => removeMachine(machineIndex)}
                    >
                      Remove Machine
                    </Button>
                  </div>
                  <Box borderBottom={1} width="100%" mt={2} />

                  {machine.isolationPoints.map((isoPoint, isoPointIndex) => (
                    <Grid
                      container
                      spacing={2}
                      key={isoPoint.isolationId}
                      px={6}
                    >
                      <Grid container spacing={2} mt={1} px={1}>
                        <Grid item xs={12} md={6}>
                          <TextField
                            fullWidth
                            label="Isolation Name"
                            sx={{ mt: 1 }}
                            required
                            value={isoPoint.isolationName}
                            onChange={(e) =>
                              handleFieldChange2(
                                machineIndex,
                                isoPointIndex,
                                "isolationName",
                                e.target.value
                              )
                            }
                          />
                        </Grid>

                        <Grid container spacing={2} mt={1} ml={2} mr={2}>
                          <Grid container spacing={2}>
                            <Grid item xs={12} md={6}>
                              <TextField
                                fullWidth
                                required
                                label="Isolation Longitude"
                                value={isoPoint.iso_long}
                                onChange={(e) =>
                                  handleFieldChange2(
                                    machineIndex,
                                    isoPointIndex,
                                    "iso_long",
                                    e.target.value
                                  )
                                }
                                sx={{ width: "calc(100% + 10px)" }}
                              />

                              <TextField
                                fullWidth
                                label="Isolation Latitude"
                                required
                                value={isoPoint.iso_lat}
                                onChange={(e) =>
                                  handleFieldChange2(
                                    machineIndex,
                                    isoPointIndex,
                                    "iso_lat",
                                    e.target.value
                                  )
                                }
                                sx={{ mt: 1, width: "calc(100% + 10px)" }}
                              />
                            </Grid>
                            <Grid item xs={10} md={5} ml={5}>
                              <div className="image-upload-wrapper">
                                <input
                                  type="file"
                                  id={`upload-isolation-image-${machineIndex}-${isoPointIndex}`}
                                  className="image-upload-input"
                                  onChange={(event) =>
                                    handleImageChange(
                                      machineIndex,
                                      isoPointIndex,
                                      event
                                    )
                                  }
                                  // <div className="flex items-center">
                                  // <img
                                  //   src={machine.machine_image}
                                  //   alt="Machine"
                                  //   className="w-24 h-24 object-contain"
                                  // />
                                  // <button
                                  //   type="button"
                                  //   className="ml-2 text-black-600 text-1xl"
                                  //   onClick={() =>
                                  //     handleCancelMachineImage(machineIndex)
                                  //   }
                                  // >
                                  //   &#10005;
                                  // </button>
                                  style={{ display: "none" }}
                                  name="image"
                                />
                                <label
                                  htmlFor={`upload-isolation-image-${machineIndex}-${isoPointIndex}`}
                                  className="image-upload-label flex justify-center items-center flex-col"
                                >
                                  {isoPoint.iso_image ? (
                                    <img
                                      src={isoPoint.iso_image}
                                      alt="Isolation Point"
                                      className="w-full h-[70px] object-contain"
                                    />
                                  ) : (
                                    <Button component="span">
                                      Upload Isolation Image
                                    </Button>
                                  )}
                                  {/* {!isoPoint.iso_image && !filename.filename && (
                                    <span>Add Image*</span>
                                  )} */}
                                </label>
                                {isoPoint.iso_image && (
                                  <button
                                    type="button"
                                    className="ml-2 text-black-600 text-1xl"
                                    onClick={handleCancel}
                                  >
                                    &#10005;
                                  </button>
                                )}
                              </div>
                            </Grid>
                          </Grid>
                        </Grid>
                      </Grid>
                      <Button
                        color="error"
                        onClick={() =>
                          removeIsolationPoint(machineIndex, isoPointIndex)
                        }
                      >
                        Remove Isolation Point
                      </Button>
                    </Grid>
                  ))}

                  <button
                    className=" flex gap-3 py-2 px-2 rounded-full text-primary font-bold min-w-32"
                    onClick={() => addIsolationPoint(machineIndex)}
                    type="button"
                  >
                    <img src={plus11} alt="adds" className="img-fluid" />
                    Add Isolation Point
                  </button>
                </Grid>
              </Box>
            ))}
            <Box borderBottom={1} width="100%" sx={{ borderRadius: "12px" }} />
            {/* <Button onClick={addMachine}>Add Machine</Button> */}
            <button
              className="bg-primary flex gap-3 py-2 px-2 rounded-full text-white font-bold min-w-32 mt-4"
              onClick={addMachine}
              type="button"
            >
              <img src={plusIcon} alt="add" className="img-fluid" />
              Add More Machines
            </button>

            <Grid
              item
              xs={12}
              display="flex"
              justifyContent="center"
              alignItems="center"
            >
              <Stack justifyContent={"center"} gap={5} direction={"row"}>
                <button
                  className="border-2 border-primary flex gap-3 py-3 px-8 rounded-full text-primary font-semibold"
                  onClick={(e) => {
                    e.preventDefault();
                    if (count === 0) {
                      setIsOpen(false);
                    } else {
                      setCount(0);
                    }
                  }}
                  style={{ marginTop: "1rem" }}
                >
                  Back
                </button>

                {type !== "edit" ? (
                  <button
                    className="bg-primary flex gap-3 py-3 px-8 rounded-full text-white font-semibold"
                    style={{ marginTop: "1rem" }}
                    type="submit"
                  >
                    Save
                  </button>
                ) : (
                  <button
                    className="bg-primary flex gap-3 py-3 px-8 rounded-full text-white font-semibold"
                    style={{ marginTop: "1rem" }}
                    type="submit"
                  >
                    Update
                  </button>
                )}
              </Stack>
            </Grid>
          </div>
        </form>
      )}
    </div>
  );
};

export default AddLotoEquipmentForm;
