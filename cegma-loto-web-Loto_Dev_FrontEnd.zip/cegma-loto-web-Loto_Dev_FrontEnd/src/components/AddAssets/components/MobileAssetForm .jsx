import React, { useState } from "react";
import Webcam from "react-webcam";
import { Button, TextField, MenuItem, Select, InputLabel, FormControl, IconButton } from "@mui/material";
import CameraAltIcon from "@mui/icons-material/CameraAlt";
import CameraEnhanceIcon from "@mui/icons-material/CameraEnhance";

const MobileAssetForm = ({ formfields, zones, sites }) => {
  const [webcamImage, setWebcamImage] = useState(null);
  const [showWebcam, setShowWebcam] = useState(false);
  const [assetForm, setAssetForm] = useState({}); // Form state for dynamic fields
  const [selectedAsset, setSelectedAsset] = useState(null);
  const [imageAttached, setImageAttached] = useState(false);

  const handleImage = (imageSrc) => {
    setWebcamImage(imageSrc);
    setImageAttached(true);
    setShowWebcam(false);
  };

  const openCamera = () => setShowWebcam(true);

  const captureImage = (webcamRef) => {
    const imageSrc = webcamRef.current.getScreenshot();
    handleImage(imageSrc);
  };

  const onSelectionChange = (e, field) => {
    setAssetForm({ ...assetForm, [field.api]: e.target.value });
  };

  const saveAsset = () => {
    console.log("Asset Saved:", assetForm, webcamImage);
  };

  return (
    <div className="p-4">
      <div>{selectedAsset}</div>

      {/* Camera Section */}
      <div className="camera-section mb-4">
        {showWebcam ? (
          <Webcam audio={false} screenshotFormat="image/jpeg" className="w-full" />
        ) : (
          <img src={webcamImage} alt="Captured" className="w-full" />
        )}

        <div className="camera-control flex space-x-2">
          <Button
            variant="contained"
            color="secondary"
            startIcon={<CameraAltIcon />}
            onClick={openCamera}
          >
            Open Camera
          </Button>

          <Button
            variant="contained"
            color="primary"
            startIcon={<CameraEnhanceIcon />}
            onClick={() => captureImage()}
            disabled={!showWebcam}
          >
            Capture
          </Button>
        </div>
      </div>

      {/* Dynamic Form */}
      <form>
        <div className="grid grid-cols-1 gap-4">
          {formfields.map((field, index) => (
            <div key={index}>
              {/* Text Input Fields */}
              {(field.type === "string" || field.type === "number" || field.type === "date") && (
                <TextField
                  label={field.label}
                  type={field.type}
                  fullWidth
                  variant="outlined"
                  required={field.required}
                  value={assetForm[field.api] || ""}
                  onChange={(e) => setAssetForm({ ...assetForm, [field.api]: e.target.value })}
                />
              )}

              {/* Dropdown Fields */}
              {field.type === "dropDown" && (
                <FormControl fullWidth variant="outlined">
                  <InputLabel>{field.label}</InputLabel>
                  <Select
                    value={assetForm[field.api] || ""}
                    onChange={(e) => onSelectionChange(e, field)}
                    label={field.label}
                  >
                    {field.api === "zone_id" &&
                      zones.map((zone) => (
                        <MenuItem key={zone.zone_id} value={zone.zone_id}>
                          {zone.zone_name}
                        </MenuItem>
                      ))}
                    {field.api === "site_id" &&
                      sites.map((site) => (
                        <MenuItem key={site.site_id} value={site.site_id}>
                          {site.site_name}
                        </MenuItem>
                      ))}
                    {field.data.map((item, i) => (
                      <MenuItem key={i} value={item.value}>
                        {item.displayName}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              )}
            </div>
          ))}
        </div>
      </form>

      {/* Form Buttons */}
      <div className="flex justify-between mt-4">
        <Button variant="contained" color="error" onClick={() => console.log("Canceled")}>
          Cancel
        </Button>
        <Button
          variant="contained"
          color="success"
          onClick={saveAsset}
          disabled={!assetForm || !imageAttached}
        >
          Add Asset
        </Button>
      </div>
    </div>
  );
};

export default MobileAssetForm;
