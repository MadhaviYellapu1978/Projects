import React, { useState } from "react";
import { qrScanIcon } from "../../assets";
import { Box, Modal } from "@mui/material";
import QrScanner from "./components/ScanQR";

const AttachQr = () => {
  const [isOpen, setIsOpen] = useState(false);

  const styles = {
    modal: {
      position: "absolute",
      top: "50%",
      left: "50%",
      transform: "translate(-50%, -50%)",
      width: 400,
      bgcolor: "background.paper",
      boxShadow: 24,
      p: 4,
      borderRadius: "12px"
    },
  };

  const handleQRClose = () => {
    setIsOpen(false);
    window.location.reload();
    
  };

  const handleQROpen = () => {
    setIsOpen(true);
  };

  const handleModalClose = (event, reason) => {
    if (reason !== "backdropClick") {
      handleQRClose();
    }
  };

  return (
    <div>
      <button
        className="bg-white flex items-center gap-2 py-3 px-5 rounded-full text-primary font-bold border-2 border-background: #1832B9;"
        onClick={handleQROpen}
      >
        <img src={qrScanIcon} alt="add" />
        Attach QR
      </button>
      <Modal
        open={isOpen}
        onClose={handleModalClose}
        aria-labelledby="modal-title"
        aria-describedby="modal-description"
        disableBackdropClick
      >
        <Box sx={styles.modal}>
          <QrScanner handleClose={handleQRClose} />
        </Box>
      </Modal>
    </div>
  );
};

export default AttachQr;
