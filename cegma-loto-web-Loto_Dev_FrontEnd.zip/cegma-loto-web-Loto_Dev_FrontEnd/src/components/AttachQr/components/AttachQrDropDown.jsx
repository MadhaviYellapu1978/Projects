/* eslint-disable */
import {
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  Tooltip,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { methods, userEndPoints } from "../../../constants";
import { apiCall } from "../../../utils";
import { useSelector } from "react-redux";

const AttachQrDropDown = (props) => {
  const { selectedZone, setSelectedZone, selectedSite, setSelectedSite } =
    props;

  const user = useSelector((state) => state.authSlice.user);
  const [zones, setZones] = useState([]);
  const [sites, setSites] = useState([]);
  useEffect(() => {
    if (Object.keys(user).length > 0) {
      apiCall(
        `${userEndPoints.getAllZonesByOrg}/${user.org?.org_id}/getAllZones`,
        methods.get
      ).then((data) => {
        setZones(data);
        setSelectedZone(data[0]?.zone_id);
        if (data.length > 0) {
          apiCall(
            `${userEndPoints.getAllSitesByZone}/${data[0]?.zone_id}/getAllSites`,
            methods.get,
            null
          ).then((data) => {
            setSites(data);
            setSelectedSite(data[0]?.site_id);
          });
        }
      });
    }
  }, [user]);
  useEffect(() => {
    if (Object.keys(user).length > 0) {
      apiCall(
        `${userEndPoints.getAllZonesByOrg}/${user.org?.org_id}/getAllZones`,
        methods.get
      ).then((data) => {
        setZones(data);
        // eslint-disable-next-line
        setSelectedZone(data[0]?.zone_id);
        if (data.length > 0) {
          apiCall(
            `${userEndPoints.getAllSitesByZone}/${data[0]?.zone_id}/getAllSites`,
            methods.get,
            null
          ).then((data) => {
            setSites(data);
            // eslint-disable-next-line
            setSelectedSite(data[0]?.site_id);
          });
        }
      });
    }
  }, [user]);

  return (
    <div className="flex gap-3 md:gap-0 flex-col md:flex-row justify-between items-center mt-5  md:mt-5">
      <div className="flex flex-col gap-3 md:flex-row md:gap-4">
        {selectedZone && (
          <FormControl fullWidth>
            <InputLabel id="zone-select-label">Select Zones</InputLabel>
            <Select
              labelId="zone-select-label"
              id="zone-select"
              value={selectedZone}
              label="Select Zones"
              onChange={(e) => {
                setSelectedZone(e.target.value);
                apiCall(
                  `${userEndPoints.getAllSitesByZone}/${e.target.value}/getAllSites`,
                  methods.get,
                  null
                ).then((data) => {
                  setSites(data);
                  setSelectedSite(data[0].site_id);
                });
              }}
            >
              {zones.map((zone, index) => {
                return (
                  <MenuItem value={zone.zone_id} key={index} className="w-full">
                    <Tooltip title={zone.zone_name} placement="bottom-end">
                      <span>{zone.zone_name}</span>
                    </Tooltip>
                  </MenuItem>
                );
              })}
            </Select>
          </FormControl>
        )}
        {sites.length > 0 && (
          <FormControl fullWidth>
            <InputLabel id="site-select-label">Select Sites</InputLabel>
            <Select
              labelId="site-select-label"
              id="site-select"
              value={selectedSite}
              label="Select Sites"
              onChange={(e) => {
                setSelectedSite(e.target.value);
              }}
            >
              {sites.map((site, index) => {
                return (
                  <MenuItem value={site.site_id} key={index}>
                    <Tooltip title={site.site_name} placement="bottom-end">
                      <span>{site.site_name}</span>
                    </Tooltip>
                  </MenuItem>
                );
              })}
            </Select>
          </FormControl>
        )}
      </div>
    </div>
  );
};

export default AttachQrDropDown;
