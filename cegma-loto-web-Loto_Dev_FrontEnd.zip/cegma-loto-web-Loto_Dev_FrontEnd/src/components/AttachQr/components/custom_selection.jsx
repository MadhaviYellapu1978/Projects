import React, { useState, useRef, useEffect } from "react";

const CustomSelection = ({ handleValueChange, data, label, itemKey, itemValue }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedValue, setSelectedValue] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const dropdownRef = useRef(null);

  const toggleDropdown = () => setIsOpen(!isOpen);

  const handleOptionClick = (value) => {
    setSelectedValue(value);
    handleValueChange(value);
    setIsOpen(false);
    setSearchTerm("");
  };

  const filteredData = data.filter((item) =>
    item[itemValue].toLowerCase().includes(searchTerm.toLowerCase())
  );

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <div className="relative" ref={dropdownRef}>
      <label className="block text-gray-700 text-sm font-bold mb-2">{label}</label>
      <div
        className="form-select mt-1 block w-full h-8 pl-2 overflow-y-auto cursor-pointer border border-gray-300 rounded-md"
        onClick={toggleDropdown}
      >
        {selectedValue ? data.find((item) => item[itemKey] === selectedValue)[itemValue] : `Select ${label}`}
      </div>
      {isOpen && (
        <div className="absolute z-10 mt-1 w-full bg-white border border-gray-300 rounded-md shadow-lg">
          <input
            type="text"
            className="w-full px-4 py-2 border-b border-gray-300"
            placeholder={`Search ${label}`}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <ul className="max-h-40 overflow-y-auto">
            {filteredData.map((item) => (
              <li
                key={item[itemKey]}
                className="px-4 py-2 cursor-pointer hover:bg-gray-100"
                onClick={() => handleOptionClick(item[itemKey])}
              >
                {item[itemValue]}
              </li>
            ))}
            {filteredData.length === 0 && (
              <li className="px-4 py-2 text-gray-500">No results found</li>
            )}
          </ul>
        </div>
      )}
    </div>
  );
};

export default CustomSelection;
