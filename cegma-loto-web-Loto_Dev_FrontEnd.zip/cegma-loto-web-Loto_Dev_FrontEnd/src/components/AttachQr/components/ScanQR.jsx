/* eslint-disable */
import React, { useState, useEffect, useRef } from "react";
import { QrReader } from "react-qr-reader";
import { apiCall } from "../../../utils";
import { equipmentEndPoints, methods, userEndPoints } from "../../../constants";
import CustomSelection from "./custom_selection";
import toast from "react-hot-toast";
import { useSelector } from "react-redux";
import AttachQrDropDown from "./AttachQrDropDown";
import { AiOutlineClose } from "react-icons/ai"; // Import close icon

let qrSuccess = false;

const getAllIsolationPoints = (data) => {
  const isolationPoints = [];

  data.forEach((equipment) => {
    equipment.machines.forEach((machine) => {
      machine.isolationPoints.forEach((point) => {
        isolationPoints.push(point);
      });
    });
  });

  return isolationPoints;
};

const QrScan = ({ handleClose }) => {
  const [selectedZone, setSelectedZone] = useState(null);
  const [selectedSite, setSelectedSite] = useState(null);
  const [data, setData] = useState("No result");
  const [permissions, setPermissions] = useState(false);
  const count = useRef(0); // Use useRef for count
  const [modalState, setModalState] = useState("SCAN");
  const [attachmentType, setAttachmentType] = useState("Machine");
  const [selectedAttachmentTypeId, setSelectedAttachmentTypeId] = useState("");
  const [isAttaching, setIsAttaching] = useState(false);
  const [message, setMessage] = useState("");
  const [equipments, setEquipments] = useState([]);
  const [machines, setMachines] = useState([]);
  const [isolation, setIsolation] = useState([]);
  const [searchInput, setSearchInput] = useState("");
  const [attachedIds, setAttachedIds] = useState([]); // Track attached IDs
  const [facingMode, setFacingMode] = useState("environment"); // Added facingMode state

  useEffect(() => {
    async function getCameraPermissions() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: true,
        });
        setPermissions(true);
        stream.getTracks().forEach((track) => track.stop());
      } catch (err) {
        console.error("Camera permission error:", err);
        setPermissions(false);
      }
    }
    getCameraPermissions();
  }, []);

  const handleError = (error) => {
    console.error("QR Scanner Error:", error);
    window.location.reload();
  };

  const handleAttachmentTypeChange = (event) => {
    setAttachmentType(event.target.value);
  };

  const handleAttach = async () => {
    if (isAttaching) return;

    setIsAttaching(true);
    setMessage("");

    if (!selectedAttachmentTypeId) {
      setMessage("Please select an option to attach.");
      setIsAttaching(false);
      return;
  }

    try {
      let requestData = { qrid: data };

      switch (attachmentType) {
        case "Equipment": 
          requestData.equipmentId = selectedAttachmentTypeId;
          break;
        case "Machine":
          requestData.machineId = selectedAttachmentTypeId;
          break;
        case "Isolation Point":
          requestData.isolationId = selectedAttachmentTypeId;
          break;
        default:
          setIsAttaching(false);
          return;
      }

      const res = await apiCall(
        equipmentEndPoints.attachQrEms,
        methods.post,
        requestData
      );

      if (res) {
        toast.success("Successful Machine QR has been Attached");

        setTimeout(() => {
          window.location.reload();
        }, [1000]);
      } else {
        setMessage("Attachment failed. Please try again.");
        window.location.reload();
      }

      setModalState("SCAN");
      count.current = 0; // Reset count using useRef
      setData("No result");
      setSelectedAttachmentTypeId("");
      setAttachedIds([...attachedIds, selectedAttachmentTypeId]); // Update attached IDs
      handleClose();
    } catch (error) {
      console.error("Error attaching QR code:", error);
      setMessage("Error attaching QR code. Please try again.");
    } finally {
      setIsAttaching(false);
    }
  };

  const checkIsQrAttatched = async (result) => {
    const res = await apiCall(
      equipmentEndPoints.checkIsAttatched,
      methods.post,
      {
        uniqueId: result?.text,
      }
    );
    if (res.isAttached) {
      throw new Error("Already attatched");
    } else {
      setData(result?.text);
      setModalState("ATTACH");
    }
  };

  const handleOnResult = async (result, error) => {
    if (!!result && !qrSuccess) {
      try {
        await checkIsQrAttatched(result);
        getAttachData();
        qrSuccess = true;
      } catch (err) {
        toast.dismiss();
        toast.error(err.message);
      }
    }

    if (!!error && !qrSuccess) {
      console.info(error);
    }
  };

  const user = useSelector((state) => state.authSlice.user);

  const getAttachData = async (site, zone) => {
    console.log(site, zone, "site & zone");
    try {
      const res = await apiCall(
        userEndPoints.getAssetsByZoneAndSite,
        methods.post,
        {
          orgId: user.org.org_id,
          zoneId: site,
          siteId: zone,
        }
      );

      if (res.length > 0) {
        console.log(res, "resssss");
        setEquipments(res);
        const machinesData = res.map((r) => r.machines);
        setMachines(machinesData.flat());
        setIsolation(getAllIsolationPoints(res));
      }
    } catch (error) {
      console.error("Error attaching QR code:", error);
    }
  };

  // const handleSearchChange = (event) => {
  //   setSearchInput(event.target.value);
  // };

  const filteredEquipments = equipments.filter((equipment) =>
    equipment.equipmentName.toLowerCase().includes(searchInput.toLowerCase())
  );

  const filteredMachines = machines.filter((machine) =>
    machine.machineName.toLowerCase().includes(searchInput.toLowerCase())
  );

  const filteredIsolationPoints = isolation.filter((point) =>
    point.isolationName.toLowerCase().includes(searchInput.toLowerCase())
  );

  const toggleFacingMode = () => {
    setFacingMode((prevMode) =>
      prevMode === "environment" ? "user" : "environment"
    );
  };

  useEffect(() => {
    if (selectedZone && selectedSite) {
      // eslint-disable-next-line
      getAttachData(selectedZone, selectedSite);
    }
    // eslint-disable-next-line
  }, [selectedSite, selectedZone]);

  return (
    <div className="p-5 flex flex-col items-center">
      {modalState === "SCAN" && count.current === 0 && (
        <div className="relative w-full">
          <h1 className="text-2xl font-bold mb-5">QR Scanner</h1>
          <AiOutlineClose
            className="absolute top-0 right-0 cursor-pointer text-2xl"
            onClick={handleClose}
          />
        </div>
      )}
      {modalState === "SCAN" ? (
        permissions ? (
          <div className="flex flex-col items-center">
            <QrReader
              delay={2000}
              scanDelay={2000}
              onError={handleError}
              onResult={handleOnResult}
              className="w-full"
              constraints={{ facingMode }} // Use the facingMode state
            />
            <button
              className="mt-4 bg-blue-500 text-white px-20 py-2 rounded-3xl"
              onClick={toggleFacingMode}
            >
              Toggle Camera
            </button>
          </div>
        ) : (
          <p>Camera access is not granted.</p>
        )
      ) : (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 ">
          <div className="bg-white p-5 rounded-lg shadow-lg max-w-md w-full">
            <div className="relative">
              <h1 className="text-xl font-bold mb-4">Attach QR</h1>
              <AiOutlineClose
                className="absolute top-0 right-0 cursor-pointer text-2xl"
                onClick={handleClose}
              />
            </div>
            <AttachQrDropDown
              selectedZone={selectedZone}
              setSelectedZone={setSelectedZone}
              selectedSite={selectedSite}
              setSelectedSite={setSelectedSite}
            />
            <div className="flex justify-center space-x-4 mb-2">
              <label className="flex items-center">
                <input
                  type="radio"
                  value="Equipment"
                  checked={attachmentType === "Equipment"}
                  onChange={handleAttachmentTypeChange}
                  className="form-radio h-4 w-4 text-blue-600"
                />
                <span className="ml-2">Equipment</span>
              </label>
              <label className="flex items-center">
                <input
                  type="radio"
                  value="Machine"
                  checked={attachmentType === "Machine"}
                  onChange={handleAttachmentTypeChange}
                  className="form-radio h-4 w-4 text-blue-600"
                />
                <span className="ml-2">Machine</span>
              </label>
              <label className="flex items-center">
                <input
                  type="radio"
                  value="Isolation Point"
                  checked={attachmentType === "Isolation Point"}
                  onChange={handleAttachmentTypeChange}
                  className="form-radio h-4 w-4 text-blue-600"
                />
                <span className="ml-2">Isolation Point</span>
              </label>
            </div>
            {attachmentType === "Equipment" && (
              <CustomSelection
              handleValueChange={(val) => {
                setSelectedAttachmentTypeId(val);
                setMessage(""); // Clear the message when a value is selected
              }}
                data={filteredEquipments.filter(
                  (item) => !attachedIds.includes(item.equipmentId)
                )}
                label={attachmentType}
                itemKey="equipmentId"
                itemValue="equipmentName"
                selectedAttachmentTypeId={selectedAttachmentTypeId}
                attachmentType={attachmentType}
              />
            )}
           {attachmentType === "Machine" && (
  <CustomSelection
    handleValueChange={(val) => {
      setSelectedAttachmentTypeId(val);
      setMessage(""); // Clear the message when a value is selected
    }}
    data={filteredMachines.filter(
      (item) => !attachedIds.includes(item.machineId)
    )}
    label={attachmentType}
    itemKey="machineId"
    itemValue="machineName"
    selectedAttachmentTypeId={selectedAttachmentTypeId}
    attachmentType={attachmentType}
  />
)}
            {attachmentType === "Isolation Point" && (
              <CustomSelection
              handleValueChange={(val) => {
                setSelectedAttachmentTypeId(val);
                setMessage(""); // Clear the message when a value is selected
              }}
                data={filteredIsolationPoints.filter(
                  (item) => !attachedIds.includes(item.isolationId)
                )}
                label={attachmentType}
                itemKey="isolationId"
                itemValue="isolationName"
                selectedAttachmentTypeId={selectedAttachmentTypeId}
                attachmentType={attachmentType}
              />
            )}
            {message && <p className="text-red-500">{message}</p>}
            <div className="flex justify-end mt-4">
              <button
                className="bg-white text-blue-500 px-4 py-2 rounded-3xl mr-2"
                onClick={handleClose}
              >
                Cancel
              </button>
              <button
                className={`${
                  isAttaching
                    ? "border bg-gray-400 cursor-not-allowed"
                    : "bg-blue-500"
                } text-white px-4 py-2 rounded-3xl`}
                onClick={handleAttach}
                disabled={isAttaching}
              >
                Attach
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default QrScan;
