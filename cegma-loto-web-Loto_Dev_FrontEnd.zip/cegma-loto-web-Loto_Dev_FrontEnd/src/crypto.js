import CryptoJS from "crypto-js";


const key = CryptoJS.enc.Utf8.parse("0123456789abcdef0123456789abcdef");
const iv = CryptoJS.enc.Utf8.parse("abcdef9876543210");

export function encrypt(jsonObj) {
  const jsonStr = JSON.stringify(jsonObj);
  const encrypted = CryptoJS.AES.encrypt(jsonStr, key, {
    iv: iv,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
  });
  return encrypted.toString(); // base64
}

export function decrypt(encryptedText) {
  const decrypted = CryptoJS.AES.decrypt(encryptedText, key, {
    iv: iv,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
  });
  const decryptedText = decrypted.toString(CryptoJS.enc.Utf8);
  return JSON.parse(decryptedText);
}