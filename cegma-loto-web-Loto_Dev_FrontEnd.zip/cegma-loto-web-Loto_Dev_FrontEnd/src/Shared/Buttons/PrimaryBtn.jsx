import React from 'react'
/**
 * Renders a primary button component with customizable type, text, and click handler.
 *
 * @param {string} type - The type of button (e.g., 'submit', 'button').
 * @param {string} text - The text to display on the button.
 * @param {Function} handleClick - The click event handler function.
 * @returns {JSX.Element} The rendered primary button component.
 */
const PrimaryBtn = ({ type, text, handleClick }) => {
  return (
    <button
      type={type}
      onClick={handleClick}
      className="rounded px-5 py-2.5 overflow-hidden group bg-primary relative hover:bg-gradient-to-r hover:primary hover:to-secondary text-white hover:ring-2 hover:ring-offset-2 hover:ring-primary transition-all ease-out duration-300 w-full"
    >
      <span className="absolute right-0 w-8 h-32 -mt-12 transition-all duration-1000 transform translate-x-12 bg-white opacity-10 rotate-12 group-hover:-translate-x-40 ease"></span>
      <span className="relative">{text}</span>
    </button>
  )
}

export default PrimaryBtn
