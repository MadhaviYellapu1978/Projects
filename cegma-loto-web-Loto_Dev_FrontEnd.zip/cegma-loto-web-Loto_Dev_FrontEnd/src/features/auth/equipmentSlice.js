import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  equipment: {},
};

const equipmentSlice = createSlice({
  name: "Equipment Data",
  initialState,
  reducers: {
    setEquipment: (state, action) => {
      state.equipment = action.payload;
    },
  },
});

export const { setEquipment } = equipmentSlice.actions;

export default equipmentSlice.reducer;
