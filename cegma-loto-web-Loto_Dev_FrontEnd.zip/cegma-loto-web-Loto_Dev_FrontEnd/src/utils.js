import axios from "axios";
import toast from "react-hot-toast";
const CRYPTO_KEY = "0123456789abcdef0123456789abcdef"; // 32 chars -> 32 bytes (AES-256)
const CRYPTO_IV = "abcdef9876543210"; // 16 chars -> 16 bytes (AES block size)

// Helper: convert base64 to ArrayBuffer
const base64ToArrayBuffer = (base64) => {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes.buffer;
};

// Helper: convert string to Uint8Array (UTF-8)
const stringToUint8 = (str) => new TextEncoder().encode(str);

// Helper: convert ArrayBuffer to base64
const arrayBufferToBase64 = (buffer) => {
  const bytes = new Uint8Array(buffer);
  let binary = "";
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
};

// Import the crypto key for AES-CBC (for decryption)
const importAesKey = async (keyStr) => {
  const keyBytes = stringToUint8(keyStr);
  return await window.crypto.subtle.importKey(
    "raw",
    keyBytes,
    { name: "AES-CBC" },
    false,
    ["decrypt"]
  );
};

// Import the crypto key for AES-CBC (for encryption)
const importAesKeyForEncrypt = async (keyStr) => {
  const keyBytes = stringToUint8(keyStr);
  return await window.crypto.subtle.importKey(
    "raw",
    keyBytes,
    { name: "AES-CBC" },
    false,
    ["encrypt"]
  );
};

// Encrypt a plaintext string to base64-encoded AES-CBC ciphertext
export const encryptAesBase64 = async (plainText) => {
  try {
    if (!plainText) return plainText;

    // Convert plaintext to string if it's an object
    const textToEncrypt =
      typeof plainText === "string" ? plainText : JSON.stringify(plainText);

    const ivBytes = stringToUint8(CRYPTO_IV);
    const plainBytes = stringToUint8(textToEncrypt);
    const aesKey = await importAesKeyForEncrypt(CRYPTO_KEY);

    const cipherBuffer = await window.crypto.subtle.encrypt(
      { name: "AES-CBC", iv: ivBytes },
      aesKey,
      plainBytes
    );

    const base64Cipher = arrayBufferToBase64(cipherBuffer);
    return base64Cipher;
  } catch (err) {
    console.error("encryptAesBase64 failed:", err);
    throw err;
  }
};

// Decrypt a base64-encoded AES-CBC ciphertext using provided key/iv strings
export const decryptAesBase64 = async (base64CipherText) => {
  try {
    if (!base64CipherText) return base64CipherText;
    // Some responses may include data wrapped like: "\"<base64>\"" (quoted). Trim quotes
    const trimmed =
      typeof base64CipherText === "string"
        ? base64CipherText.trim().replace(/^"|"$/g, "")
        : base64CipherText;

    const ivBytes = stringToUint8(CRYPTO_IV);
    const cipherBuffer = base64ToArrayBuffer(trimmed);
    const aesKey = await importAesKey(CRYPTO_KEY);
    const plainBuffer = await window.crypto.subtle.decrypt(
      { name: "AES-CBC", iv: ivBytes },
      aesKey,
      cipherBuffer
    );
    const decoded = new TextDecoder().decode(plainBuffer);
    return decoded;
  } catch (err) {
    // If decryption fails, silently return the original value to let caller handle it
    console.error("decryptAesBase64 failed:", err);
    throw err;
  }
};

// Utility function to validate JWT tokens
export const isValidToken = (token) => {
  if (!token) {
    return false;
  }

  // Check if token is not null, undefined, or empty string
  if (token === "null" || token === "undefined" || token.trim() === "") {
    return false;
  }

  // Basic JWT structure check (should have 3 parts separated by dots)
  const parts = token.split(".");
  if (parts.length !== 3) {
    return false;
  }

  // Check if token has reasonable length (JWT tokens are typically longer than 50 characters)
  if (token.length < 50) {
    return false;
  }

  return true;
};

// Helper function to check if a route requires authentication
export const isProtectedRoute = (pathname) => {
  const protectedRoutes = [
    "roleManagement",
    "userManagement",
    "padlockManagement",
    "workflowManagement",
    "approvalMechanism",
    "workflowOrchestration",
  ];

  return protectedRoutes.some((route) => pathname.includes(route));
};

export const apiCall = async (
  url,
  method,
  data = null,
  token = null,
  overridenHeaders = null
) => {
  console.log("data", data);
  try {
    // Clone overridenHeaders so we can pick out axios-specific options like withCredentials
    const extra = overridenHeaders ? { ...overridenHeaders } : {};
    let withCredentials = false;
    if (typeof extra.withCredentials !== "undefined") {
      withCredentials = !!extra.withCredentials;
      // remove it from headers so it's not sent as an HTTP header
      delete extra.withCredentials;
    }

    const normalizedMethod = method ? method.toUpperCase() : "GET";

    const headers = {
      // Tell server what response types we accept
      Accept: "application/json, text/plain, */*",
      // Only set Content-Type for non-GET requests (avoids unnecessary preflight for simple GETs)
      ...(normalizedMethod !== "GET"
        ? { "Content-Type": "application/json; charset=utf-8" }
        : {}),
      // spread any other custom headers provided by caller
      ...extra,
    };

    if (token) {
      headers["Authorization"] = `Bearer ${token}`;
    }

    const config = {
      method: normalizedMethod,
      url,
      headers,
      withCredentials,
    };
    if (data) {
      config.data = data;
    }
    const response = await axios(config);
    if (response.status >= 400) {
      return { data: response.data, status: response.status };
    }

    // If response is a string, attempt AES-CBC decryption (backend returns encrypted base64)
    let resData = response.data;
    try {
      if (typeof resData === "string" && resData.trim() !== "") {
        const decrypted = await decryptAesBase64(resData);
        try {
          // If decrypted is JSON, parse and return it
          return JSON.parse(decrypted);
        } catch (e) {
          // Not JSON — return decrypted string
          return decrypted;
        }
      }
    } catch (decryptErr) {
      // Decryption failed; log and fall back to raw response
      console.warn(
        "apiCall: response decryption failed, returning raw response.data",
        decryptErr
      );
    }

    return resData;
  } catch (err) {
    toast.dismiss();
    // Handle different error response structures
    let errorMessage = "An error occurred";
    
    // Check if we're on pages where 404 toast should be suppressed
    const currentPath = window.location.pathname;
    const suppress404Toast = 
      currentPath.includes("/workflowManagement") ||
      currentPath.includes("/approvalMechanism") ||
      currentPath.includes("/workflowOrchestration");

    if (err.response) {
      // Server responded with error status
      if (err.response.status === 500) {
        errorMessage = "Server error (500) - please try again later";
      } else if (err.response.status === 404) {
        errorMessage = "Service not found (404) - please check the URL";
        // Suppress toast for 404 errors on specific pages
        if (suppress404Toast) {
          throw err; // Re-throw without showing toast
        }
      } else if (err.response.status === 401) {
        errorMessage = "Unauthorized (401) - please login again";
      } else if (err.response.status === 403) {
        errorMessage = "Forbidden (403) - you don't have permission";
      } else if (err.response.data) {
        if (err.response.data.body && err.response.data.body.message) {
          errorMessage = err.response.data.body.message;
        } else if (err.response.data.message) {
          errorMessage = err.response.data.message;
        } else if (err.response.data.error) {
          errorMessage = err.response.data.error;
        } else if (typeof err.response.data === "string") {
          errorMessage = err.response.data;
        } else {
          errorMessage = `Server error: ${err.response.status}`;
        }
      } else {
        errorMessage = `Server error: ${err.response.status}`;
      }
    } else if (err.request) {
      // Network error
      errorMessage = "Network error - please check your connection";
    } else {
      // Other error
      errorMessage = err.message || "An unexpected error occurred";
    }

    toast.error(errorMessage, { duration: 4000 });
    throw err; // Re-throw the error so calling code can handle it
  }
};
