//api for prod
// export const baseUrl = "https://api.smartloto.in";
export const baseUrl = "https://api-dev.smartloto.in";

export const methods = {
  post: "POST",
  get: "GET",
  put: "PUT",
  delete: "DELETE",
};

//api for dev
export const userEndPoints = {
  verifyToken: `${baseUrl}/smartLOTO/userProfiles/verifyToken`,
  getUser: `${baseUrl}/smartLOTO/userProfiles/getUserProfile/`,
  getUserByOrg: `${baseUrl}/smartLOTO/userProfiles/getAllUserProfilesByOrdId/`,
  getAllZonesByOrg: `${baseUrl}/smartLOTO/profile/zones`, // For Dev
  getAllSitesByZone: `${baseUrl}/smartLOTO/profile/sites`, //For Dev
  getAssetsByZoneAndSite: `${baseUrl}/smartLOTO/equipment/getMachinesByOrgID`,
  createContractor: `${baseUrl}/smartLOTO/userProfiles/onBoardContractedUser`,
  createFace: `${baseUrl}/smartLOTO/userProfiles/createFace`,
};

export const equipmentEndPoints = {
  getAll: `${baseUrl}/smartLOTO/equipment/getAll`,
  deleteEquipment: `${baseUrl}/smartLOTO/equipment/delete`,
  getAllPadlocks: `${baseUrl}/smartLOTO/equipment/allPadLockDetails`, //For Dev
  addPadlocks: `${baseUrl}/smartLOTO/equipment/macidwithorgid`, //For Dev
  postPadlocks: `${baseUrl}/smartLOTO/equipment/createEquipments`,
  getDepts: `${baseUrl}/smartLOTO/userProfiles/getAllDepts`,
  getRoles: `${baseUrl}/smartLOTO/userProfiles/getAllLotoRoles`,
  updateRole: `${baseUrl}/smartLOTO/userProfiles/updateLotoRoleDept`,
  updateEquipment: `${baseUrl}/smartLOTO/equipment/update`,
  updatePadlock: `${baseUrl}/smartLOTO/equipment/updatePadLockDetails`,
  downloadQr: `${baseUrl}/smartLOTO/equipment/downloadQR`,
  checkIsAttatched: `${baseUrl}/smartLOTO/equipment/isAttachedQR`,
  attachQrEms: `${baseUrl}/smartLOTO/equipment/AttachedQRToEMS`,
};

export const dashboardEndPoints = {
  getAllWorkOrders: `${baseUrl}/smartLOTO/workOrder/getAllWeb`,
  SearchWorkOrder: `${baseUrl}/smartLOTO/workOrder/searchWO`,
};

export const workOrderEndPoints = {
  getWorkOrderById: `${baseUrl}/smartLOTO/workOrder/get`,
  createWorkOrder: `${baseUrl}/smartLOTO/workOrder/createWorkOrder`,
  getWorkOrders: `${baseUrl}/smartLOTO/workOrder/getAll`,
  getCustodians: `${baseUrl}/smartLOTO/profile/getAuthorizersAndTechnicians`,
  updateCustodiansWO: `${baseUrl}/smartLOTO/workOrder/updateAny`,
  getNotificationsByOrgId: `${baseUrl}/smartLOTO/workOrder/getAllNotificationsByOrgId`,
};

export const workflowEndPoints = {
  orgGetMainActions: `${baseUrl}/smartLOTOSockets/org/getMainActions`,
  getRolesAndDept: `${baseUrl}/smartLOTOSockets/org/getRolesAndDept`,
  assignActionsRolesByRoleIdOrgId: `${baseUrl}/smartLOTOSockets/org/assignActionsRolesByRoleIdOrgId`,
  getUsers: `${baseUrl}/smartLOTOSockets/org/users`,
  assignRoles: `${baseUrl}/smartLOTOSockets/org/assignRoles`,
  assignFieldsForWorkOrder: `${baseUrl}/smartLOTOSockets/org/assignFieldsForWorkOrder`,
  getFieldsforWorkOrder: `${baseUrl}/smartLOTOSockets/org/getFieldsforWorkOrder`,
  getMainFields: `${baseUrl}/smartLOTOSockets/org/getMainFields`,
  getAssignedActionsByOrgId: `${baseUrl}/smartLOTOSockets/org/getAssignedActionsByOrgId`,
  finalSetpAssignedByOrdId: `${baseUrl}/smartLOTOSockets/org/finalSetpAssignedByOrdId`,
  getFinalAssignedByOrgId: `${baseUrl}/smartLOTOSockets/org/getFinalAssignedByOrgId`,
  deleteFinalAssignedByOrgId: `${baseUrl}/smartLOTOSockets/org/deleteFinalAssignedByOrgId`,
  deleteAssignedActionsByOrgId: `${baseUrl}/smartLOTOSockets/org/deleteAssignedActionsByOrgId`,
};
