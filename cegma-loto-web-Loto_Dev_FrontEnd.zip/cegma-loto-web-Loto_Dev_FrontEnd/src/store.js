import { configureStore } from "@reduxjs/toolkit";
import authSlice from "./features/auth/authSlice";
import equipmentSlice from "./features/auth/equipmentSlice";
export const store = configureStore({
  reducer: {
    authSlice,
    equipmentSlice
  },
});
