import homeIcon from "./home-icon.svg";
import alertIcon from "./alerts-icon.svg";
import settingsIcon from "./settings-icon.svg";
import tasksIcon from "./tasks-icon.svg";
import assetManagement from "./asset_management.svg";
import plusIcon from "./plus-icon.svg";
import logo from "./logo.svg";
import noneFound from "./none-found.svg";
import padlockIcon from "./padlock.svg";
import padlockImg from "./padlockImg.png";
import moreIcon from "./moreIcon.svg";
import closeIcon from "./close.svg";
import qrScanIcon from "./qrscan-icon.svg";
import downloadqr from "./Base.svg";
import plus11 from "./plus11.svg";
import workflowManagement from "./workflow_management.svg";
import roleManagement from "./role_management.svg";
import approvalMechanism from "./Approval_mechanism.svg";
import workflowArch from "./workflow_arch.svg";
import workorderIcon from "./workorder_Icon.svg";

export {
  homeIcon,
  alertIcon,
  settingsIcon,
  tasksIcon,
  assetManagement,
  plusIcon,
  logo,
  noneFound,
  padlockIcon,
  padlockImg,
  moreIcon,
  closeIcon,
  qrScanIcon,
  downloadqr,
  plus11,
  workflowManagement,
  roleManagement,
  approvalMechanism,
  workflowArch,
  workorderIcon,
};
