const { red } = require('@mui/material/colors');

/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary:'#243DBB',
        gray:'#545D68',
        custom: '#d0d0f0da',
   
      },
    },
  },
  plugins: [],
}

